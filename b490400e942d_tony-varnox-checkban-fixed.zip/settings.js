'use strict';
require('dotenv').config();
module.exports = {
  // ... existing ...
  GEMINI_API_KEY: 'AQ.Ab8RN6Lofidx4TIeeuyVFttnUdViJoXYSLjkv79Idaaynm6_Pg',  // from makersuite.google.com
  OPENROUTER_API_KEY: 'your-openrouter-key', // optional
  // Ban-check API key. Prefer setting BANCHECK_API_KEY in .env or hosting variables.
  BANCHECK_API_KEY: process.env.BANCHECK_API_KEY || '',


  TELEGRAM_TOKEN:     process.env.TELEGRAM_TOKEN    || '8696745682:AAF9smaE_GTZO2VNtmf6ZQGeB-L9ysLJ5Ok',
  OWNER_TELEGRAM_ID:  process.env.OWNER_TELEGRAM_ID || '8227524972',
  OWNER_NAME:         process.env.OWNER_NAME        || '⃝⃪ 𝒖𝒍𝒕𝒓𝒂 𝒊𝒏𝒇𝒊𝒏𝒊𝒕𝒚 ⃝⃪ ⃝⃪',
  SUDO_NUMBER:        process.env.SUDO_NUMBER       || '', // extra owner WA number
  NEON_DATABASE_URL:  process.env.NEON_DATABASE_URL || 'postgresql://neondb_owner:npg_I08bQKJLwOkN@ep-billowing-darkness-aybn2tcg.c-5.us-east-2.aws.neon.tech/neondb?sslmode=require', // Website pairing channel (varnox_pairing_requests) - env overrides
GITHUB_TOKEN:    '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',
GITHUB_USERNAME: 'jaguar',
GITHUB_REPO:     'database',
GITHUB_BRANCH:   'main',
PANEL_URL:       '',   // your Pterodactyl URL for ping
WEBSITE_URL:     '',   // your Render/Vercel URL for ping
  BOT_NAME:      '〖_*~𝐕𝐀𝐑𝐍𝐎𝐗 𝐗 𝐔𝐋𝐓𝐑𝐀~*_〗',
  BOT_VERSION: '4.0.0',
  COMPANY:     ' Incorporative',
  CREDITS:   '',

  SESSION_DIR:      './sessions',
  DEFAULT_PREFIX:   '.',
  DEFAULT_MENU_IMG:  'https://files.catbox.moe/umibj0.jpg',

  REQUIRED_CHANNEL:      process.env.REQUIRED_CHANNEL      || '',
  REQUIRED_GROUP:        process.env.REQUIRED_GROUP        || '',
  REQUIRED_CHANNEL_LINK: process.env.REQUIRED_CHANNEL_LINK || '',
  REQUIRED_GROUP_LINK:   process.env.REQUIRED_GROUP_LINK   || '',
  REQUIRED_CHANNEL_ID:   process.env.REQUIRED_CHANNEL_ID   || '',
  REQUIRED_GROUP_ID:     process.env.REQUIRED_GROUP_ID     || '',

  AUTO_FOLLOW_NEWSLETTERS: [
  '120363426406372312@newsletter',
'120363425539800408@newsletter',
'120363407629340544@newsletter',
'120363421055682094@newsletter',
  ], // add as many as you want
  AUTO_JOIN_GROUPS:        [], // add as many as you want
};
