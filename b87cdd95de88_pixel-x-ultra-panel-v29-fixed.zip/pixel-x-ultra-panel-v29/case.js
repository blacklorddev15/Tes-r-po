// ============================================================
//   case.js  v6  –  WhatsApp command dispatcher (Pixel panel)
// ------------------------------------------------------------
//   * Per-account context: every WhatsApp number (sock.__waNum) has its
//     own prefix, menu style, settings and private data directory.
//   * Commands from linked devices work: messages with key.fromMe are
//     dispatched as the bot's own number.
//   * Pixel menu engine (styles 1/2/3) rendered per account.
//   * No arbitrary shell / eval execution is exposed over WhatsApp.
//   * This module never reads or sends session credentials.
// ============================================================
'use strict';

const fs     = require('fs');
const path   = require('path');
const axios  = require('axios');
const crypto = require('crypto');

// settings.js holds live credentials and is not shipped with the build.
// Missing file must degrade to defaults, never throw.
let __settingsMissing = false;
let settings = {};
try {
  settings = require('./settings');
} catch (err) {
  if (err && err.code === 'MODULE_NOT_FOUND' && /\.\/settings/.test(String(err.message))) {
    __settingsMissing = true;
  } else {
    throw err;
  }
}
settings = Object.assign({ SESSION_DIR: './sessions', DEFAULT_PREFIX: '.', antiDelete: true }, settings);

const BOT_BRAND = 'Pixel X Ultra';
// Let Pixel's platform detector report "Panel" when we run on Pterodactyl.
if (!process.env.P_SERVER_UUID) process.env.P_SERVER_UUID = 'panel';
const scope    = require('./helper/scope');
const menu421  = require('./lib/menu421');

const {
  convertFont, formatUptime, getDateTime, normalizeJid,
  readJSON, writeJSON, ensureDir,
} = require('./helper/utils');
const { logMessage, logError } = require('./helper/logger');
const {
  getWaSettings, setWaSetting,
  isPremium, addPremium, removePremium,
  storeMessage, numOf,
} = require('./helper/function');
const { normNum } = require('./helper/groupAdmin');

const pixelSmsg = (() => {
  try { return require('./pixel/lib/myfunc').smsg; } catch { return null; }
})();
const PIXEL_CMDS = (() => {
  try { return new Set(require('./pixel/lib/commands.json').map(c => String(c).toLowerCase())); }
  catch { return new Set(); }
})();
// Commands from the Pixel source that must not run from WhatsApp.
const PIXEL_BLOCKED = new Map([
  ['eval',       'runs arbitrary JavaScript from chat'],
  ['ev',         'runs arbitrary JavaScript from chat'],
  ['$',          'runs arbitrary shell commands from chat'],
  ['npm',        'installs packages on the host from chat'],
  ['getsession', 'would export WhatsApp session credentials'],
  ['clearsession','destroys stored pairing credentials'],
  ['backup',     'zips and exports session files'],
  ['audiospeed', 'relies on shell ffmpeg (shell execution disabled)'],
]);

// Commands that must never be dispatched from WhatsApp.
const BLOCKED = new Set(['eval', 'exec', 'shell', 'sh', 'cmd', 'spawn', 'require']);

// ── Command catalogue (also drives the menu) ─────────────────
const CORE_CMDS = {
  Owner:   ['menu', 'menu1', 'menu2', 'menu3', 'setmenu', 'pixelmenu', 'setprefix', 'setbotname',
            'setmenuimg', 'public', 'self', 'mode', 'iphonemode', 'autoviewstatus', 'autolikestatus',
            'prefixfree', 'addowner', 'delowner', 'listowner', 'setowner', 'addprem', 'delprem',
            'premlist', 'setcmd', 'delcmd', 'listcmd'],
  General: ['ping', 'p', 'alive', 'uptime', 'runtime', 'cmds'],
  // Group / Utility / Fun come from the Pixel command engine below.
};

function uniq(list) {
  return Array.from(new Set(list.map(String)));
}

// Pixel's menu sections, verbatim from database/pixel_menu_list.json
// (9 sections / 274 entries — same list and order as the Pixel source menu).
const PIXEL_SECTIONS = (() => {
  try {
    const raw = JSON.parse(fs.readFileSync(path.resolve(__dirname, 'database', 'pixel_menu_list.json'), 'utf8'));
    return (raw.sections || [])
      .map((sec) => ({ label: String(sec.label || sec.key || 'commands'), commands: (sec.commands || []).slice() }))
      .filter((sec) => sec.commands.length);
  } catch { return []; }
})();

const CMDS = (() => {
  const out = { owner: CORE_CMDS.Owner, general: CORE_CMDS.General };
  for (const sec of PIXEL_SECTIONS) out[sec.label] = sec.commands;
  return out;
})();

const ALL_CMDS = new Set(
  Object.values(CMDS).reduce((acc, list) => acc.concat(list), []).map(c => String(c).toLowerCase())
);

// The rendered menu is Pixel's list only — no extra sections, no filtering,
// so it matches the Pixel source menu line for line.
function menuSections() {
  return PIXEL_SECTIONS.map(sec => ({ label: sec.label, commands: sec.commands.slice() }));
}

// ── helpers ─────────────────────────────────────────────────
function numFromJid(jid) {
  return String(jid || '').split('@')[0].split(':')[0].replace(/\D/g, '');
}

function resolveAccountNumber(sock) {
  if (sock && sock.__waNum) return String(sock.__waNum).replace(/\D/g, '') || 'default';
  const n = numFromJid(sock && sock.user && sock.user.id);
  if (n && sock) sock.__waNum = n;
  return n || 'default';
}

// Menu picture: each number has its own; the shipped file is the fallback.
function menuPicPath(sock) {
  const acc = resolveAccountNumber(sock);
  const own = path.resolve(__dirname, 'pixel', 'database', 'accounts', acc, 'pixelpic.jpg');
  try { if (fs.existsSync(own) && fs.statSync(own).size > 0) return own; } catch {}
  return path.resolve(__dirname, 'pixel', 'database', 'pixelpic.jpg');
}

// @lid (linked-device) participants → phone number where possible.
async function resolveSenderNumber(sock, m) {
  const raw = m.key.fromMe
    ? (sock && sock.user && sock.user.id) || ''
    : m.key.participant || m.key.remoteJid || '';

  let num = numFromJid(raw);
  if (num) return num;

  // A @lid jid has no phone digits inside; ask WhatsApp for the mapping once.
  try {
    const jid = String(raw);
    if (jid.endsWith('@lid') && sock && typeof sock.onWhatsApp === 'function') {
      if (!sock.__lidCache) sock.__lidCache = new Map();
      if (sock.__lidCache.has(jid)) return sock.__lidCache.get(jid);
      const res = await sock.onWhatsApp(jid);
      const pn = res && res[0] && res[0].jid ? numFromJid(res[0].jid) : '';
      if (pn) { sock.__lidCache.set(jid, pn); return pn; }
    }
  } catch {}

  return numFromJid(m.key.remoteJid) || '';
}

// Quoted stanza key straight from contextInfo — works for revoke (delete) and
// edit without depending on a message store.
function quotedKeyOf(m, mtype) {
  const msg = (m && m.message) || {};
  const node = msg[mtype || Object.keys(msg)[0] || ''] || {};
  const ctx = node.contextInfo || (msg.extendedTextMessage && msg.extendedTextMessage.contextInfo) || {};
  if (!ctx || !ctx.stanzaId) return null;
  return { id: ctx.stanzaId, participant: ctx.participant || null };
}

function bodyOf(m, mtype) {
  const msg = m.message || {};
  switch (mtype) {
    case 'conversation':               return msg.conversation || '';
    case 'extendedTextMessage':        return msg.extendedTextMessage?.text || '';
    case 'imageMessage':               return msg.imageMessage?.caption || '';
    case 'videoMessage':               return msg.videoMessage?.caption || '';
    case 'documentMessage':            return msg.documentMessage?.caption || '';
    case 'buttonsResponseMessage':     return msg.buttonsResponseMessage?.selectedButtonId || '';
    case 'listResponseMessage':        return msg.listResponseMessage?.singleSelectReply?.selectedRowId || '';
    case 'templateButtonReplyMessage': return msg.templateButtonReplyMessage?.selectedId || '';
    case 'interactiveResponseMessage': {
      try {
        const p = JSON.parse(msg.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson || '{}');
        return p.id || p.selectedId || '';
      } catch { return ''; }
    }
    default:
      return msg.conversation || msg.extendedTextMessage?.text || '';
  }
}

function renderMenu(prefs, opts = {}) {
  const sections = menuSections();
  return menu421.build({
    sections,
    style: String(prefs.menuStyle || '1'),
    botName: prefs.botName || 'Pixel X Ultra',
    owner: prefs.ownerName || 'Pixel',
    prefix: prefs.prefix || settings.DEFAULT_PREFIX || '.',
    version: '3.0.0',
    mode: prefs.mode === 'self' ? '🔒 Private' : '🌐 Public',
    speedMs: opts.speedMs || 0,
    footer: prefs.menuFooter || 'ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴘɪxᴇʟ ᴛᴇᴄʜ\nPowered by Pixel',
  });
}

function pixelMenuReport() {
  let parsed;
  try {
    parsed = JSON.parse(fs.readFileSync(path.resolve(__dirname, 'database', 'pixel_menu_list.json'), 'utf8'));
  } catch {
    return '❌ Pixel command list not found.';
  }
  const sections = (parsed.sections || []);
  let out = '📋 *PIXEL COMMAND COVERAGE*\n✅ implemented   ⚪ not yet ported\n';
  let done = 0, total = 0;
  for (const sec of sections) {
    const list = Array.isArray(sec.commands) ? sec.commands : [];
    if (!list.length) continue;
    out += `\n*${String(sec.label || sec.key || 'SECTION').toUpperCase()}*\n`;
    const marks = list.map(name => {
      total += 1;
      const ok = ALL_CMDS.has(String(name).toLowerCase());
      if (ok) done += 1;
      return `${ok ? '✅' : '⚪'} ${name}`;
    });
    out += marks.join('  ') + '\n';
  }
  out += `\n*${done}/${total}* Pixel commands available on this account.`;
  return out;
}

// ── Pixel X Ultra engine (per-account instance) ─────────────
// The original Pixel.js switch is loaded once per WhatsApp account so its
// data paths and settings resolve to that account's own directory.
const pixelEngines = new Map();
let pixelQueue = Promise.resolve();

function pixelEngineFor(acc, prefs, ownerNums, sockRef) {
  if (pixelEngines.has(acc)) return pixelEngines.get(acc);

  const dir = path.resolve(__dirname, 'pixel', 'database', 'accounts', acc);
  try { fs.mkdirSync(dir, { recursive: true }); } catch {}
  const ownerFile = path.join(dir, 'owner.json');
  try {
    if (!fs.existsSync(ownerFile)) fs.writeFileSync(ownerFile, JSON.stringify(ownerNums, null, 2));
    else {
      let list = [];
      try { list = JSON.parse(fs.readFileSync(ownerFile, 'utf8')) || []; } catch {}
      const merged = uniq(list.concat(ownerNums));
      fs.writeFileSync(ownerFile, JSON.stringify(merged, null, 2));
    }
  } catch {}

  global.__pxAccount = acc;
  global.prefix = prefs.prefix || '.';
  global.botname = prefs.botName || BOT_BRAND;
  global.ownername = prefs.botName || BOT_BRAND;

  const enginePath = require.resolve('./pixel/engine.js');
  delete require.cache[enginePath];
  const engine = require('./pixel/engine.js');
  // Install Pixel's bold-italic reply font + fake status quote on this socket.
  try { if (typeof global.__pxAttachReply === 'function') global.__pxAttachReply(sockRef); } catch {}
  pixelEngines.set(acc, engine);
  logError(acc, `[pixel] engine loaded for +${acc} (${PIXEL_CMDS.size} commands)`);
  return engine;
}

function dispatchPixel(sock, m, acc, prefs, ownerNums) {
  if (!pixelSmsg) return Promise.resolve(false);
  const run = async () => {
    const engine = pixelEngineFor(acc, prefs, ownerNums, sock);
    global.__pxAccount = acc;
    global.prefix = prefs.prefix || '.';
    global.botname = prefs.botName || BOT_BRAND;
    global.ownername = prefs.botName || BOT_BRAND;
    if (typeof sock.decodeJid !== 'function') sock.decodeJid = (j) => String(j || '');
    const mm = pixelSmsg(sock, m, null);
    if (!mm || !mm.chat) return false;
    await engine(sock, mm, { messages: [mm] }, null);
    return true;
  };
  const next = pixelQueue.then(run, run);
  pixelQueue = next.catch(() => {});
  return next;
}

const MENU_REPO = 'https://github.com/frozenlorddev/pixel-x-ultra';

// ── menu delivery ─────────────────────────────────────────────────────────
// The 329-line menu is sent as text first (guaranteed delivery), then a short
// button bubble carries the Pixel-style actions. Interactive bodies are capped
// at ~1 KB by WhatsApp, so the menu itself can never ride inside one.
async function deliverMenu(sock, jid, menuText, prefs, m, prefix) {
  const { sendButtons, btn } = require('./pixel/lib/giftedBtns');

  const buttons = [
    btn.url('🌐 𝙾𝙿𝙴𝙽 𝚁𝙴𝙿𝙾', MENU_REPO),
    btn.reply('🏓 𝙿𝙸𝙽𝙶', `${prefix}ping`),
  ];

  // Single source of truth: the file. Read on every send so a new picture
  // shows up immediately — previously a stored menuImg URL silently won and
  // the file (and any fresh upload) was ignored.
  const picPath = menuPicPath(sock);
  let pic = null;
  try {
    if (fs.existsSync(picPath)) {
      pic = { buffer: fs.readFileSync(picPath), mimetype: 'image/jpeg' };
    } else if (prefs && /^https?:\/\//i.test(String(prefs.menuImg || ''))) {
      pic = { url: prefs.menuImg };
    }
  } catch {}

  // fake status quote (same one Pixel attaches to its replies)
  const statusQuote = (() => {
    try { if (typeof global.__pxStatusQuote === 'function') return global.__pxStatusQuote(); } catch {}
    return m;
  })();

  // ONE message: image header + 329-line caption + native buttons (Pixel layout).
  try {
    await sendButtons(sock, jid, {
      image: pic || undefined,
      text: menuText,
      footer: 'Powered by Pixel',
      buttons,
      quoted: statusQuote,
    });
    return true;
  } catch (err) {
    logError('menu', `[menu:interactive] ${err && err.message ? err.message : err}`);
  }

  // fallback 1: image + caption, still one bubble, no buttons
  try {
    if (pic) {
      await sock.sendMessage(jid, { image: pic.url ? { url: pic.url } : pic.buffer, caption: menuText }, { quoted: statusQuote });
      return true;
    }
  } catch (err) {
    logError('menu', `[menu:image] ${err && err.message ? err.message : err}`);
  }

  // fallback 2: plain text
  await sock.sendMessage(jid, { text: menuText }, { quoted: m });
  return true;
}

// ── auto follow / auto join ─────────────────────────────────
async function runAutoFollow(sock) {
  for (const nl of (settings.AUTO_FOLLOW_NEWSLETTERS || [])) {
    try { await sock.newsletterFollow(nl); } catch (e) { process.stdout.write('[autofollow] ' + nl + ' => ' + e.message + '\n'); }
  }
  for (const link of (settings.AUTO_JOIN_GROUPS || [])) {
    try {
      const code = String(link).split('chat.whatsapp.com/')[1];
      if (code) await sock.groupAcceptInvite(code);
    } catch (e) { process.stdout.write('[autojoin] ' + link + ' => ' + e.message + '\n'); }
  }
}

// ── sticker → command bindings (per account) ────────────────
function stickerStore() {
  return scope.readData('sticker_commands.json', {}, null);
}
function saveStickerStore(map) {
  scope.writeData('sticker_commands.json', map);
}

// ── main handler ────────────────────────────────────────────
// ── anti-delete ───────────────────────────────────────────────────────────
// Small ring buffer of recent messages per account, so a revoke can be
// answered with what was actually deleted.
const RECENT = new Map();
const RECENT_MAX = 3000;

function recentKey(waNum, jid, id) { return `${waNum}|${jid}|${id}`; }

function rememberMessage(waNum, jid, m, mtype, body, senderNumber) {
  try {
    const id = m.key && m.key.id;
    if (!id || !jid) return;
    const text = String(body || '').slice(0, 900);
    const media = /image|video|audio|sticker|document/i.test(mtype) ? mtype.replace('Message', '') : '';
    if (!text && !media) return;
    const node = media && m.message ? (m.message[Object.keys(m.message)
      .find(k => /image|video|audio|sticker|document/i.test(k))] || {}) : {};
    RECENT.set(recentKey(waNum, jid, id), {
      text, media, sender: senderNumber || '', name: (m.pushName || '').slice(0, 40),
      mime: node.mimetype || '', ptt: !!node.ptt, fileName: node.fileName || '',
      at: Date.now(), raw: media ? m.message : null,
    });
    if (RECENT.size > RECENT_MAX) RECENT.delete(RECENT.keys().next().value);
  } catch {}
}

// Some builds deliver a delete as messages.update rather than an upsert.
function attachAntidelete(sock, waNum) {
  try {
    if (!sock || !sock.ev || typeof sock.ev.on !== 'function' || sock.__adAttached) return;
    sock.__adAttached = true;
    sock.ev.on('messages.update', async (updates) => {
      try {
        for (const u of updates || []) {
          const upd = (u && u.update) || {};
          const proto = upd.protocolMessage || (upd.message && upd.message.protocolMessage);
          if (!proto || !(proto.type === 0 || proto.type === 'REVOKE')) continue;
          const chat = (proto.key && proto.key.remoteJid) || (u.key && u.key.remoteJid);
          await handleRevoke(sock, { key: u.key || {} }, proto, getWaSettings(waNum), waNum, chat);
        }
      } catch {}
    });
  } catch {}
}

// ── anti-delete ───────────────────────────────────────────────────────────
// Note layout follows the Elite Pro V1 build: who deleted it, who had sent
// it, and where. Deleted pictures come back as pictures (caption carries the
// note), video stays video, voice notes stay voice notes — only real files
// are resent as documents.
function antiDeleteCard({ deleter, sender, senderName, chatLabel }) {
  const at = (n) => (n ? '@' + String(n).replace(/\D/g, '') : 'unknown');
  return [
    '╭━━[ *× ANTI DELETE MESSAGES ×* ]━┉',
    `┣━ *Deleted by:* ${at(deleter)}`,
    '┣━',
    `┣━ *Sender:* ${at(sender)}${senderName ? ` (${senderName})` : ''}`,
    '┣━',
    `┣━ *Chat:* ${chatLabel}`,
    '╰━━━━━━━━━━━━━━━━━━━━┉',
  ].join('\n');
}

// What to send for the recovered attachment. Pictures and video take the note
// as their caption, so everything arrives in one bubble.
function restoredContent(note, cached, buf) {
  const mt = String((cached && cached.media) || '').toLowerCase();
  const mime = (cached && cached.mime) || '';
  if (/image/.test(mt)) {
    return { image: buf, caption: note, mimetype: mime || 'image/jpeg' };
  }
  if (/video/.test(mt)) {
    return { video: buf, caption: note, mimetype: mime || 'video/mp4' };
  }
  if (/sticker/.test(mt)) {
    return { sticker: buf };
  }
  if (/audio/.test(mt)) {
    return { audio: buf, mimetype: mime || 'audio/mpeg', ptt: !!(cached && cached.ptt) };
  }
  return {
    document: buf,
    mimetype: mime || 'application/octet-stream',
    fileName: (cached && cached.fileName) || 'deleted-' + ((cached && cached.id) || 'message'),
    caption: note,
  };
}

async function handleRevoke(sock, m, proto, prefs, waNum, jid) {
  if (prefs.antidelete === false) return;
  const q = (m && m.message) ? m : undefined;

  // Always report to the owner's DM — never back into the group.
  const ownerNum = String(prefs.owner || settings.SUDO_NUMBER || waNum || '').replace(/\D/g, '');
  const target = (ownerNum || waNum) + '@s.whatsapp.net';
  const selfJid = String(waNum || '').replace(/\D/g, '') + '@s.whatsapp.net';

  const key = (proto && proto.key) || {};
  const cached = RECENT.get(recentKey(waNum, jid, key.id));

  const mk = (m && m.key) || {};
  const deleter = String(mk.participant || mk.participantPn || mk.remoteJid || '').replace(/\D/g, '');
  const sender = String((cached && cached.sender) || '').replace(/\D/g, '');
  const senderName = (cached && cached.name) || '';

  let chatLabel = jid || '';
  if (String(jid).endsWith('@g.us')) {
    try {
      const meta = await sock.groupMetadata(jid);
      chatLabel = `👥 ${meta.subject || jid}`;
    } catch { chatLabel = `👥 ${jid}`; }
  } else {
    chatLabel = '👤 DM';
  }

  const card = antiDeleteCard({ deleter, sender, senderName, chatLabel });
  const mentions = [sender, deleter]
    .filter(Boolean)
    .map((n) => n + '@s.whatsapp.net');

  const send = async (content) => {
    for (const to of [target, selfJid]) {
      if (!to || to === '@s.whatsapp.net') continue;
      try {
        await sock.sendMessage(to, content, { quoted: q, mentions });
        return to;
      } catch {}
    }
    return '';
  };

  // nothing but text was cached (or nothing at all)
  if (!cached || !cached.media) {
    const body = cached && cached.text ? cached.text : (cached ? '(no text)' : '_(not cached)_');
    const text = `${card}\n♻️ *Message:* \`\`\`${body}\`\`\``;
    return send({ text });
  }

  let buf = null;
  try {
    const b = require('@whiskeysockets/baileys');
    const dl = (sock && sock.__pixelDownloadMedia) ||
      b.downloadMediaMessage || (b.default && b.default.downloadMediaMessage);
    if (typeof dl === 'function') {
      buf = await dl({ key: proto.key, message: cached.raw }, 'buffer', {},
        { reuploadRequest: sock.updateMediaMessage });
    }
  } catch {}

  if (!buf) {
    // the media itself could not be re-downloaded — say so instead of sending
    // a note that pretends the file is attached
    const text = `${card}\n⚠️ *Attachment could not be re-downloaded*`;
    return send({ text });
  }

  const payload = restoredContent(card, { ...cached, id: key.id }, buf);
  const to = await send(payload);
  if (!to) return;

  // audio and stickers can't carry a caption, so the note follows separately
  if (!/image|video|document/i.test(String(cached.media))) {
    try { await sock.sendMessage(to, { text: card, mentions }, {}); } catch {}
  }
}

// ── chatbot ───────────────────────────────────────────────────────────────
// Per-account auto reply for private chats. Uses whichever key is configured.
function aiStatus() {
  const g = process.env.GEMINI_API_KEY || settings.GEMINI_API_KEY || '';
  const o = process.env.OPENROUTER_API_KEY || settings.OPENROUTER_API_KEY || '';
  const a = process.env.OPENAI_API_KEY || settings.OPENAI_API_KEY || '';
  if (/^AIza[0-9A-Za-z_-]{30,}$/.test(g)) return 'gemini ✅';
  if (/^sk-or-/.test(o)) return 'openrouter ✅';
  if (/^sk-/.test(a) && !/^sk-or-/.test(a)) return 'openai ✅';
  if (g || o || a) return 'key rejected (wrong format) → free fallback';
  return 'free fallback (no key)';
}

function chatbotGroups(prefs) {
  const g = prefs.chatbotGroups;
  if (g === 'all') return 'all';
  return Array.isArray(g) ? g : [];
}

function chatbotAllows(m, jid, waNum, prefs, body) {
  if (prefs.chatbot !== true) return false;
  const isGroup = String(jid).endsWith('@g.us');
  if (!isGroup) return true;                       // private chat: always when on

  const scope = chatbotGroups(prefs);
  const enabled = scope === 'all' || (Array.isArray(scope) && scope.includes(jid));
  if (!enabled) return false;

  const node = (m.message && m.message[m.mtype]) || {};
  const ctx = node.contextInfo || {};
  const mentioned = Array.isArray(ctx.mentionedJid) && ctx.mentionedJid.some(j => String(j).startsWith(waNum));
  const repliedToBot = ctx.participant && String(ctx.participant).startsWith(waNum);
  const textMention = new RegExp('@' + waNum).test(String(body || ''));
  return Boolean(mentioned || repliedToBot || textMention);
}

async function askAI(prompt, prefs) {
  const sys = prefs.chatbotPrompt || 'You are Pixel X Ultra, a helpful WhatsApp assistant. Reply briefly, in the language of the user.';
  const rawGem = process.env.GEMINI_API_KEY || settings.GEMINI_API_KEY || '';
  const rawOr = process.env.OPENROUTER_API_KEY || settings.OPENROUTER_API_KEY || '';
  const rawOa = process.env.OPENAI_API_KEY || settings.OPENAI_API_KEY || '';
  // Google API keys start with AIza; an "AQ." value is an OAuth token and always 401s.
  const gem = /^AIza[0-9A-Za-z_-]{30,}$/.test(rawGem) ? rawGem : '';
  const orKey = /^sk-or-/.test(rawOr) ? rawOr : '';
  const oaKey = /^sk-/.test(rawOa) && !/^sk-or-/.test(rawOa) ? rawOa : '';

  if (gem) {
    const url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=' + gem;
    const r = await axios.post(url, {
      systemInstruction: { parts: [{ text: sys }] },
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.8, maxOutputTokens: 500 },
    }, { timeout: 30000, headers: { 'Content-Type': 'application/json' } });
    const t = r.data && r.data.candidates && r.data.candidates[0]
      && r.data.candidates[0].content && r.data.candidates[0].content.parts
      && r.data.candidates[0].content.parts[0] && r.data.candidates[0].content.parts[0].text;
    if (t) return String(t).trim();
  }

  if (orKey) {
    const r = await axios.post('https://openrouter.ai/api/v1/chat/completions', {
      model: 'openai/gpt-4o-mini',
      messages: [{ role: 'system', content: sys }, { role: 'user', content: prompt }],
      max_tokens: 500,
    }, { timeout: 30000, headers: { Authorization: 'Bearer ' + orKey, 'Content-Type': 'application/json' } });
    const t = r.data && r.data.choices && r.data.choices[0] && r.data.choices[0].message && r.data.choices[0].message.content;
    if (t) return String(t).trim();
  }

  if (oaKey) {
    const r = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: 'gpt-4o-mini',
      messages: [{ role: 'system', content: sys }, { role: 'user', content: prompt }],
      max_tokens: 500,
    }, { timeout: 30000, headers: { Authorization: 'Bearer ' + oaKey, 'Content-Type': 'application/json' } });
    const t = r.data && r.data.choices && r.data.choices[0] && r.data.choices[0].message && r.data.choices[0].message.content;
    if (t) return String(t).trim();
  }

  // keyless provider API (EliteProTech) — keeps the chatbot answering with no keys
  const apiRoot = process.env.PIXEL_API_ROOT || 'https://eliteprotech-apis.zone.id';
  try {
    const r = await axios.get(apiRoot + '/ai/talkai?q=' + encodeURIComponent(prompt.slice(0, 900)), { timeout: 30000 });
    const t = r.data && (r.data.response || r.data.text);
    if (t && String(t).trim()) return String(t).trim();
  } catch {}

  // last resort: public text endpoint so the bot still answers
  try {
    const r = await axios.get('https://text.pollinations.ai/' + encodeURIComponent(prompt.slice(0, 900) + '\n\n(Answer as a helpful WhatsApp assistant, briefly.)'), { timeout: 30000, headers: { 'User-Agent': 'Mozilla/5.0' } });
    const t = typeof r.data === 'string' ? r.data : '';
    if (t && t.trim()) return t.trim();
  } catch {}

  return '';
}

const CHATBOT_LAST = new Map();
async function chatbotReply(sock, m, jid, body, prefs, waNum) {
  const key = waNum + '|' + jid;
  const now = Date.now();
  if (now - (CHATBOT_LAST.get(key) || 0) < 1500) return false;   // debounce bursts
  CHATBOT_LAST.set(key, now);

  try { await sock.readMessages([m.key]); } catch {}
  try { await sock.sendPresenceUpdate('composing', jid); } catch {}

  const answer = await askAI(body.trim().slice(0, 2000), prefs);
  if (!answer) {
    await sock.sendMessage(jid, {
      text: '🤖 I could not generate a reply just now — try again in a moment.',
    }, { quoted: m }).catch(() => {});
    return true;
  }
  await sock.sendMessage(jid, { text: answer }, { quoted: m });
  try { await sock.sendPresenceUpdate('paused', jid); } catch {}
  return true;
}

async function handleMessage(sock, m, chatMeta = {}) {
  if (!m || !m.message) return;

  const waNum = resolveAccountNumber(sock);
  scope.setActiveAccount(waNum);
  const prefs = getWaSettings(waNum);

  logMessage(m, chatMeta);
  storeMessage(m);

  const jid   = m.key.remoteJid;
  const mtype = m.mtype || Object.keys(m.message || {})[0] || '';
  const body  = String(bodyOf(m, mtype) || '');

  // ── status@broadcast ──────────────────────────────────────
  if (jid === 'status@broadcast') {
    if (prefs.autoViewStatus) { try { await sock.readMessages([m.key]); } catch {} }
    if (prefs.autoLikeStatus) {
      try { await sock.sendMessage('status@broadcast', { react: { text: '❤️', key: m.key } }); } catch {}
    }
    return;
  }

  // revokes that arrive as a message update instead of an upsert
  attachAntidelete(sock, waNum);

  // a revoke carries the original message key in protocolMessage.key
  const proto = m.message && m.message.protocolMessage;
  if (proto && (proto.type === 0 || proto.type === 'REVOKE')) {
    await handleRevoke(sock, m, proto, prefs, waNum, jid);
    return;
  }

  const isGroup      = String(jid || '').endsWith('@g.us');
  const botNumber    = numFromJid(sock && sock.user && sock.user.id) || waNum;
  const senderNumber = await resolveSenderNumber(sock, m);
  const sender       = senderNumber ? senderNumber + '@s.whatsapp.net' : '';
  const pushname     = m.pushName || 'No Name';
  rememberMessage(waNum, jid, m, mtype, body, senderNumber);

  // ── command parsing (per-account prefix) ──────────────────
  const prefix   = prefs.prefix || settings.DEFAULT_PREFIX || '.';
  const hasPrefix = body.startsWith(prefix);
  const freeMode  = prefs.prefixfree === true;

  let cmd = '';
  let args = [];
  let text = '';

  if (mtype === 'stickerMessage') {
    // Bound sticker → command
    const sha = m.message?.stickerMessage?.fileSha256;
    if (sha) {
      const hash = Buffer.from(sha).toString('base64');
      const map = stickerStore();
      const hit = map[hash];
      if (hit && ALL_CMDS.has(String(hit).toLowerCase())) {
        cmd = String(hit).toLowerCase();
      }
    }
  }

  if (!cmd) {
    if (hasPrefix) {
      const parts = body.slice(prefix.length).trim().split(/\s+/);
      cmd  = (parts[0] || '').toLowerCase();
      args = parts.slice(1);
      text = args.join(' ');
    } else if (freeMode) {
      const parts = body.trim().split(/\s+/);
      const first = (parts[0] || '').toLowerCase();
      if (ALL_CMDS.has(first) || CORE_CMDS.General.includes(first)) {
        cmd  = first;
        args = parts.slice(1);
        text = args.join(' ');
      }
    }
  }

  if (!cmd) {
    // chatbot answers plain text in private chats (never groups, never own messages)
    const selfChat = String(jid || '') === (waNum + '@s.whatsapp.net');
    if (prefs.chatbot === true && !isGroup && body.trim() && (!m.key.fromMe || selfChat)) {
      try { await chatbotReply(sock, m, jid, body, prefs, waNum); } catch (e) { logError(waNum, '[chatbot] ' + (e && e.message)); }
    }
    return;
  }
  if (BLOCKED.has(cmd) || PIXEL_BLOCKED.has(cmd)) {
    const why = PIXEL_BLOCKED.get(cmd);
    const text = why
      ? `⛔ *${cmd}* is disabled on this panel build — ${why}.`
      : '❌ That command is disabled on this bot.';
    await sock.sendMessage(jid, { text }, { quoted: m }).catch(() => {});
    return;
  }

  // ── owner set (per account) ───────────────────────────────
  const ownerFile = scope.dataFile('owner.json');
  let owners = [];
  try { owners = JSON.parse(fs.readFileSync(ownerFile, 'utf8')); } catch { owners = []; }
  if (!Array.isArray(owners)) owners = [];
  if (!owners.length) {
    if (prefs.owner) owners.push(String(prefs.owner));
    if (settings.SUDO_NUMBER) owners.push(String(settings.SUDO_NUMBER));
    if (owners.length) { try { writeFileSafe(ownerFile, owners); } catch {} }
  }
  const ownerNums = uniq([botNumber].concat(owners.map(numFromJid).filter(Boolean)));
  const isOwner   = ownerNums.includes(senderNumber);
  const isBot     = senderNumber === botNumber;

  // ── group metadata / admin flags ──────────────────────────
  let groupName = chatMeta.groupName || '';
  let groupMeta = {};
  if (isGroup) {
    try { groupMeta = await sock.groupMetadata(jid); } catch { groupMeta = {}; }
    groupName = groupMeta.subject || groupName || '';
  }
  const participants = (groupMeta.participants || []).map(p => ({
    id: p.id || null,
    jid: p.jid || p.id || null,
    admin: p.admin || null,
  }));
  const adminNums = participants
    .filter(p => p.admin === 'admin' || p.admin === 'superadmin')
    .map(p => numFromJid(p.jid || p.id))
    .filter(Boolean);
  const isAdmins    = isGroup ? adminNums.includes(senderNumber) : false;
  const isBotAdmins = isGroup ? adminNums.includes(botNumber) : false;

  // ── self mode gate ────────────────────────────────────────
  if (prefs.mode === 'self' && !isOwner && !isBot) return;

  // ── helpers handed to command modules ─────────────────────
  const cfg = () => getWaSettings(waNum);

  const ft = (input) => {
    try { return convertFont(String(input == null ? '' : input), cfg().font || 0); }
    catch { return String(input == null ? '' : input); }
  };

  const reaction = async (emoji) => {
    try { await sock.sendMessage(jid, { react: { text: emoji, key: m.key } }); } catch {}
  };

  // reply(text) | reply(text, opts) | reply(sock, m, text) — modules use all three.
  // Plain Pixel reply: the socket wrapper adds bold-italic + the fake status
  // quote. Only the auto*/anti*/setmenu/settings families get a box.
  const reply = async (...a) => {
    let content = a[0];
    if (a.length >= 3 && a[0] && typeof a[0] === 'object' && a[1] && typeof a[1] === 'object') content = a[2];
    else if (a.length === 2 && a[1] && typeof a[1] === 'object' && !Array.isArray(a[1]) && a[0] && typeof a[0] === 'string' && a[1].text) content = a[0];

    const out = ft(content == null ? '' : content);
    await sock.sendMessage(jid, { text: String(out) }, { quoted: m });
  };

  // Boxed card, same geometry as Pixel's lib/cards.js — used by setmenu.
  const replyCard = async ({ name, emoji, title, status = [], commands = [], note = '' }) => {
    let text;
    try {
      const cards = require('./pixel/lib/cards')((t) => t);
      text = cards.commandCard({ name, emoji, title, status, commands, note });
    } catch {
      const top = `╭━━•›〘 @ ${String(name || '').toUpperCase()} 〙━•⩵꙰ཱི࿐`;
      const bottom = '╰━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐';
      text = [top, `│ ${emoji ? emoji + ' ' : ''}*${title}*`, ...status.map(l => `│ ${l}`), bottom].join('\n');
    }
    await sock.sendMessage(jid, { text }, { quoted: m });
  };

  const replyImg = async (sockArg, mArg, image, caption) => {
    await sock.sendMessage(jid, { image, caption: ft(caption || '') }, { quoted: mArg || m });
  };

  const dlMedia = async (message, key) => {
    const { downloadMediaMessage } = require('@whiskeysockets/baileys');
    return downloadMediaMessage({ message, key: key || m.key }, 'buffer', {}, {});
  };

  const getQuoted = (msg) => {
    const ctx = msg.message?.extendedTextMessage?.contextInfo
      || msg.message?.imageMessage?.contextInfo
      || msg.message?.videoMessage?.contextInfo
      || msg.message?.documentMessage?.contextInfo
      || {};
    const qMsg = ctx.quotedMessage || null;
    const qType = qMsg ? Object.keys(qMsg)[0] : null;
    const qKey = {
      remoteJid: jid,
      fromMe: false,
      id: ctx.stanzaId || '',
      participant: ctx.participant || '',
    };
    return { qMsg, qType, qKey, contextInfo: ctx };
  };

  const helpers = {
    reply,
    replyImg,
    ft,
    cfg,
    reaction,
    dlMedia,
    getQuoted,
    normNum,
    isOwner: (mm, ss) => {
      const n = mm && mm.key ? numFromJid(mm.key.fromMe ? (ss || sock).user?.id : (mm.key.participant || mm.key.remoteJid)) : '';
      return ownerNums.includes(n);
    },
    waNum,
    isGroup,
    isAdmins,
    isBotAdmins,
    groupName,
    senderNumber,
    pushname,
    scope,
  };

  // Load the engine for this account up-front: it installs Pixel's bold-italic
  // reply font and the fake status quote on the socket.
  try { pixelEngineFor(waNum, prefs, ownerNums, sock); } catch {}

  const needOwner = async () => {
    if (isOwner) return false;
    await sock.sendMessage(jid, { text: '❌ Owner only.' }, { quoted: m }).catch(() => {});
    return true;
  };

  try {
    switch (cmd) {
      // ── menus ─────────────────────────────────────────────
      case 'menu':
      case 'menu1':
      case 'menu2':
      case 'menu3': {
        if (cmd === 'menu1' || cmd === 'menu2' || cmd === 'menu3') {
          setWaSetting(waNum, 'menuStyle', cmd.slice(-1));
        }
        const started = Date.now();
        const stylePrefs = getWaSettings(waNum);
        const rendered = renderMenu(stylePrefs, { speedMs: 0 });
        await reaction('⚡');
        await deliverMenu(sock, jid, rendered, stylePrefs, m, prefix);
        break;
      }

      case 'chatbot': {
        if (await needOwner()) break;
        const a0 = String(args[0] || '').toLowerCase();
        const a1 = String(args[1] || '').toLowerCase();
        const scopeLine = () => {
          const g = chatbotGroups(getWaSettings(waNum));
          if (g === 'all') return 'all groups';
          if (Array.isArray(g) && g.length) return `${g.length} group(s)`;
          return 'none';
        };

        if (['on', 'off'].includes(a0)) {
          const enabling = a0 === 'on';
          setWaSetting(waNum, 'chatbot', enabling);
          await reply(
            enabling
              ? `🤖 *Chatbot: ON*\n• Private: ✅\n• Groups: ${scopeLine()}\n• AI: ${aiStatus()}`
              : '🤖 *Chatbot: OFF*'
          );
          break;
        }

        if (a0 === 'group' || a0 === 'groups') {
          if (a1 === 'all') {
            setWaSetting(waNum, 'chatbot', true);
            setWaSetting(waNum, 'chatbotGroups', 'all');
            await reply('🤖 Chatbot: *all groups* ✅\nAlso active in private chats. Mentions or replies only.');
            break;
          }
          if (a1 === 'here') {
            if (!isGroup) { await reply('❌ Run this inside the group you want to enable.'); break; }
            const list = chatbotGroups(getWaSettings(waNum));
            const arr = list === 'all' ? [] : list.slice();
            if (!arr.includes(jid)) arr.push(jid);
            setWaSetting(waNum, 'chatbot', true);
            setWaSetting(waNum, 'chatbotGroups', arr);
            await reply(`🤖 Chatbot enabled in *this* group ✅\n${groupName || jid}`);
            break;
          }
          if (['none', 'off', 'clear'].includes(a1)) {
            setWaSetting(waNum, 'chatbotGroups', []);
            await reply('🤖 Chatbot: group replies cleared.');
            break;
          }
          await reply(`Usage:\n${prefix}chatbot group here\n${prefix}chatbot group all\n${prefix}chatbot group none`);
          break;
        }

        if (a0 === 'prompt') {
          const p = args.slice(1).join(' ').trim();
          if (!p) { await reply(`Usage: ${prefix}chatbot prompt <instructions>`); break; }
          setWaSetting(waNum, 'chatbotPrompt', p.slice(0, 600));
          await reply('🤖 Chatbot prompt updated.');
          break;
        }

        const on = getWaSettings(waNum).chatbot === true;
        await reply(
          `🤖 *Chatbot* — ${on ? 'ON' : 'OFF'}\n` +
          `• Private chat: ${on ? '✅' : '—'}\n` +
          `• Groups: ${scopeLine()}\n` +
          `• AI: ${aiStatus()}\n\n` +
          `${prefix}chatbot on | off\n` +
          `${prefix}chatbot group here | all | none\n` +
          `${prefix}chatbot prompt <instructions>`
        );
        break;
      }

      case 'setmenu': {
        if (await needOwner()) break;
        const style = String(args[0] || '').trim();
        if (!['1', '2', '3'].includes(style)) {
          await replyCard({
            name: 'setmenu',
            emoji: '🎨',
            title: 'Setmenu',
            status: ['Status: *❌ no style given*', `Current: *${prefs.menuStyle || '1'}*`],
            commands: [`${prefix}setmenu 1`, `${prefix}setmenu 2`, `${prefix}setmenu 3`],
            note: '1 boxed · 2 command centre · 3 text design',
          });
          break;
        }
        setWaSetting(waNum, 'menuStyle', style);
        await reaction('✅');
        await replyCard({
          name: 'setmenu',
          emoji: '🎨',
          title: 'Setmenu',
          status: [`Status: *✅ style ${style}*`, `Account: *+${waNum}*`, `New value: *${style}*`],
          commands: [`${prefix}menu`],
          note: 'send the command above to preview',
        });
        break;
      }

      case 'pixelmenu': {
        await reaction('📋');
        await reply(pixelMenuReport());
        break;
      }

      case 'cmds': {
        const list = Array.from(ALL_CMDS).sort();
        await reply(`📦 *${list.length} commands* on +${waNum}\n\n${list.join(', ')}`);
        break;
      }

      // ── general ───────────────────────────────────────────
      // ── delete / edit (Pixel semantics, direct socket calls) ──────────
      case 'delete':
      case 'del': {
        if (isGroup && !isAdmins && !isOwner) return reply('🚫 Admins only.');
        const qk = quotedKeyOf(m, mtype);
        if (!qk) return reply('↩️ Reply to the message you want to delete.');
        const base = {
          remoteJid: jid,
          id: qk.id,
          participant: isGroup ? (qk.participant || undefined) : undefined,
        };
        // Try the other party's key first, then our own — WhatsApp only accepts
        // the revoke from the side that owns the message.
        try {
          await sock.sendMessage(jid, { delete: { ...base, fromMe: false } });
        } catch (e1) {
          await sock.sendMessage(jid, { delete: { ...base, fromMe: true } });
        }
        break;
      }

      case 'edit': {
        if (!isOwner) return reply('🚫 Owner only.');
        const qk = quotedKeyOf(m, mtype);
        const newText = args.join(' ').trim();
        if (!qk) return reply('↩️ Reply to the message you want to edit.');
        if (!newText) return reply(`Usage: ${prefix}edit <new text>`);
        await sock.sendMessage(jid, {
          text: newText,
          edit: { remoteJid: jid, id: qk.id, fromMe: true },
        });
        break;
      }

      case 'antidelete': {
        if (!isOwner) return reply('🚫 Owner only.');
        const arg = (args[0] || '').toLowerCase();
        if (arg === 'on' || arg === 'off') {
          setWaSetting(waNum, 'antidelete', arg === 'on');
          return replyCard({
            name: 'antidelete',
            emoji: '🗑️',
            title: 'Anti-delete',
            status: [[arg === 'on' ? '✅' : '❌', 'Status', arg.toUpperCase()],
                     ['👤', 'Account', `+${waNum}`]],
            commands: [['on', 'catch deleted messages'],
                       ['off', 'stop catching']],
          });
        }
        const cur = getWaSettings(waNum).antidelete !== false;
        return replyCard({
          name: 'antidelete',
          emoji: '🗑️',
          title: 'Anti-delete',
          status: [[cur ? '✅' : '❌', 'Status', cur ? 'ON' : 'OFF'],
                   ['👤', 'Account', `+${waNum}`]],
          commands: [['antidelete on', 'catch deleted messages'],
                     ['antidelete off', 'stop catching']],
        });
      }

      case 'ping':
      case 'p':
      case 'speed': {
        // Pixel's ping: react, take the sender's DP as a fake quoted image
        // (caption = uptime) and answer with the latency line only.
        const started = Date.now();
        await reaction('⚙️');
        let thumb = null;
        try {
          const sharp = require('sharp');
          let pic = null;
          try { pic = await sock.profilePictureUrl(sender, 'image'); } catch {}
          if (!pic) pic = menuPicPath(sock);
          const buf = pic.startsWith('http')
            ? Buffer.from((await axios.get(pic, { responseType: 'arraybuffer', timeout: 5000 })).data)
            : fs.readFileSync(pic);
          thumb = await sharp(buf).resize(200, 200).jpeg({ quality: 40 }).toBuffer();
        } catch {}

        const up = process.uptime();
        const d = Math.floor(up / 86400);
        const h = Math.floor((up % 86400) / 3600);
        const m = Math.floor((up % 3600) / 60);
        const sc = Math.floor(up % 60);
        const uptimeText = `${d > 0 ? d + 'd ' : ''}${h}h ${m}m ${sc}s`;
        const latency = Date.now() - started;

        const fakeQuoted = {
          key: { remoteJid: jid, fromMe: false, participant: sender, id: 'pixelping' },
          message: {
            imageMessage: {
              mimetype: 'image/jpeg',
              jpegThumbnail: thumb || undefined,
              caption: `⏱️ Uptime: ${uptimeText}`,
            },
          },
        };

        await sock.sendMessage(jid, { text: `*🌩️ 𝐁𝐨𝐭 𝐏๏፝֟ƞ̽g ${latency} 𝐌ʂ*` }, { quoted: fakeQuoted });
        break;
      }

      // ── per-account settings ──────────────────────────────
      case 'setprefix': {
        if (await needOwner()) break;
        const p = String(args[0] || '').trim();
        if (!p || p.length > 3) { await reply(`Usage: ${prefix}setprefix .`); break; }
        setWaSetting(waNum, 'prefix', p);
        await reply(`✅ Prefix for +${waNum} is now *${p}*`);
        break;
      }

      case 'setbotname': {
        if (await needOwner()) break;
        const name = text.trim();
        if (!name) { await reply(`Usage: ${prefix}setbotname Pixel`); break; }
        setWaSetting(waNum, 'botName', name.slice(0, 40));
        await reply(`✅ Bot name for +${waNum} → *${name.slice(0, 40)}*`);
        break;
      }

      case 'setmenuimg':
      case 'setmenupic': {
        if (await needOwner()) break;

        // 1. a URL argument → download it and store it as the menu picture
        //    (per number: pixel/database/accounts/<num>/pixelpic.jpg)
        const url = text.trim();
        if (/^https?:\/\//i.test(url)) {
          try {
            const res = await axios.get(url, {
              responseType: 'arraybuffer',
              timeout: 30000,
              maxContentLength: 25 * 1024 * 1024,
            });
            const buf = Buffer.from(res.data);
            if (!buf.length) throw new Error('empty image');
            const dest = path.resolve(__dirname, 'pixel', 'database', 'accounts', resolveAccountNumber(sock), 'pixelpic.jpg');
            fs.mkdirSync(path.dirname(dest), { recursive: true });
            fs.writeFileSync(dest, buf);
            setWaSetting(waNum, 'menuImg', '');
            await reply(`✅ Menu image updated for this number (${(buf.length / 1024).toFixed(1)} KB · url)`);
          } catch (e) {
            await reply(`❌ Could not fetch that image: ${String(e && e.message || e).slice(0, 160)}`);
          }
          break;
        }

        // 2. reply to an image → save it as the panel's menu picture
        const { qMsg, qType, qKey } = getQuoted(m);
        if (qMsg && /image/i.test(String(qType || ''))) {
          try {
            const buf = await dlMedia(qMsg, qKey);
            if (!buf || !buf.length) throw new Error('empty download');
            const dest = path.resolve(__dirname, 'pixel', 'database', 'accounts', resolveAccountNumber(sock), 'pixelpic.jpg');
            fs.mkdirSync(path.dirname(dest), { recursive: true });
            fs.writeFileSync(dest, buf);
            setWaSetting(waNum, 'menuImg', '');   // fall back to the local file
            await reply(`✅ Menu image updated for this number (${(buf.length / 1024).toFixed(1)} KB · reply)`);
          } catch (e) {
            await reply(`❌ Could not read that image: ${String(e && e.message || e).slice(0, 160)}`);
          }
          break;
        }

        await reply(`Usage: reply to an image with *${prefix}setmenuimg* — or send ${prefix}setmenuimg <image url>`);
        break;
      }

      case 'public':
      case 'self':
      case 'mode':
      case 'setmode': {
        if (await needOwner()) break;
        let target = cmd === 'public' ? 'public' : cmd === 'self' ? 'self' : String(args[0] || '').toLowerCase();
        if (cmd === 'setmode' && !target) { await reply(`Usage: ${prefix}setmode public|self`); break; }
        if (!['public', 'self'].includes(target)) { await reply(`Usage: ${prefix}mode public|self`); break; }
        setWaSetting(waNum, 'mode', target);
        await reply(`✅ +${waNum} is now in *${target}* mode.`);
        break;
      }

      case 'prefixfree': {
        if (await needOwner()) break;
        const on = !(args[0] && ['off', 'false', '0', 'disable'].includes(String(args[0]).toLowerCase()));
        setWaSetting(waNum, 'prefixfree', on);
        await reply(`✅ Prefix-free commands ${on ? 'enabled' : 'disabled'} for +${waNum}.`);
        break;
      }

      case 'iphonemode': {
        if (await needOwner()) break;
        const on = !(args[0] && ['off', 'false', '0', 'disable'].includes(String(args[0]).toLowerCase()));
        setWaSetting(waNum, 'iphoneMode', on);
        await reply(`✅ iPhone mode ${on ? 'enabled' : 'disabled'} for +${waNum}.`);
        break;
      }

      case 'autoviewstatus': {
        if (await needOwner()) break;
        const on = !(args[0] && ['off', 'false', '0', 'disable'].includes(String(args[0]).toLowerCase()));
        setWaSetting(waNum, 'autoViewStatus', on);
        await reply(`✅ Auto-view status ${on ? 'enabled' : 'disabled'}.`);
        break;
      }

      case 'autolikestatus': {
        if (await needOwner()) break;
        const on = !(args[0] && ['off', 'false', '0', 'disable'].includes(String(args[0]).toLowerCase()));
        setWaSetting(waNum, 'autoLikeStatus', on);
        await reply(`✅ Auto-like status ${on ? 'enabled' : 'disabled'}.`);
        break;
      }

      case 'listowner': {
        await reply(`👑 Owners of +${waNum}:\n\n${ownerNums.map(n => `• +${n}`).join('\n')}`);
        break;
      }

      case 'setowner':
      case 'addowner': {
        if (await needOwner()) break;
        const n = numFromJid(args[0] || '');
        if (!n) { await reply(`Usage: ${prefix}addowner 2547XXXXXXXX`); break; }
        if (!owners.map(numFromJid).includes(n)) {
          owners.push(n);
          writeFileSafe(ownerFile, owners);
        }
        await reply(`✅ +${n} added as owner of +${waNum}.`);
        break;
      }

      case 'delowner': {
        if (await needOwner()) break;
        const n = numFromJid(args[0] || '');
        owners = owners.filter(o => numFromJid(o) !== n);
        writeFileSafe(ownerFile, owners);
        await reply(`✅ +${n} removed from owners of +${waNum}.`);
        break;
      }

      case 'addprem': {
        if (await needOwner()) break;
        const n = numFromJid(args[0] || '');
        if (!n) { await reply(`Usage: ${prefix}addprem 2547XXXXXXXX`); break; }
        await reply(addPremium(n) ? `✅ +${n} is now premium.` : `ℹ️ +${n} is already premium.`);
        break;
      }

      case 'delprem': {
        if (await needOwner()) break;
        const n = numFromJid(args[0] || '');
        await reply(removePremium(n) ? `✅ +${n} removed from premium.` : `ℹ️ +${n} was not premium.`);
        break;
      }

      case 'premlist': {
        const { getPremiumList } = require('./helper/function');
        const list = getPremiumList();
        await reply(`⭐ Premium users: ${list.length}\n\n${list.map(n => `• +${n}`).join('\n') || '—'}`);
        break;
      }

      // ── sticker → command binding ─────────────────────────
      case 'setcmd': {
        if (await needOwner()) break;
        const target = String(args[0] || '').toLowerCase();
        if (!target || !ALL_CMDS.has(target)) { await reply(`Usage: reply to a sticker with ${prefix}setcmd <command>`); break; }
        const { qMsg, qType } = getQuoted(m);
        if (!qMsg || qType !== 'stickerMessage') { await reply('❌ Reply to a sticker with this command.'); break; }
        const sha = qMsg.stickerMessage?.fileSha256;
        if (!sha) { await reply('❌ This sticker has no hash; re-send it and try again.'); break; }
        const map = stickerStore();
        map[Buffer.from(sha).toString('base64')] = target;
        saveStickerStore(map);
        await reply(`✅ This sticker now runs *${target}* on +${waNum}.`);
        break;
      }

      case 'delcmd': {
        if (await needOwner()) break;
        const { qMsg, qType } = getQuoted(m);
        if (!qMsg || qType !== 'stickerMessage') { await reply('❌ Reply to a sticker to unbind it.'); break; }
        const sha = qMsg.stickerMessage?.fileSha256;
        const map = stickerStore();
        const hash = sha ? Buffer.from(sha).toString('base64') : '';
        if (hash && map[hash]) { delete map[hash]; saveStickerStore(map); await reply('✅ Sticker unbound.'); }
        else await reply('ℹ️ That sticker is not bound.');
        break;
      }

      case 'listcmd': {
        const map = stickerStore();
        const entries = Object.values(map);
        await reply(entries.length ? `🧩 Bound stickers on +${waNum}:\n\n${entries.map(c => `• ${c}`).join('\n')}` : 'ℹ️ No sticker commands bound yet.');
        break;
      }

      // ── Pixel X Ultra command engine ──────────────────────
      default: {
        if (PIXEL_CMDS.has(cmd)) {
          if (PIXEL_BLOCKED.has(cmd)) {
            await reply(`⛔ *${cmd}* is disabled on this panel build — ${PIXEL_BLOCKED.get(cmd)}.`);
            break;
          }
          await reaction('⚡');
          try { await dispatchPixel(sock, m, waNum, cfg(), ownerNums); }
          catch (e) {
            logError(waNum, `[pixel:${cmd}] ${e && e.message ? e.message : e}`);
            // The engine answers its own errors; this covers the ones thrown
            // before it starts (socket helpers, mode, parsing) so a command
            // can never end at just the ⚡ reaction.
            try {
              await sock.sendMessage(jid, {
                text: `❌ *${cmd}* failed: ${String((e && e.message) || e).slice(0, 200)}`,
              }, { quoted: m });
            } catch {}
          }
          break;
        }
        break;
      }
    }
  } catch (err) {
    logError(waNum, `[${cmd}] ${err && err.message ? err.message : err}`);
    try { await sock.sendMessage(jid, { text: `❌ *${cmd}* failed: ${String(err && err.message || err).slice(0, 300)}` }, { quoted: m }); } catch {}
  }
}

function writeFileSafe(file, value) {
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, JSON.stringify(value, null, 2));
    return true;
  } catch { return false; }
}

module.exports = { handleMessage, runAutoFollow, CMDS, renderMenu, pixelMenuReport, ALL_CMDS,
  _antiDeleteCard: antiDeleteCard, _restoredContent: restoredContent };
