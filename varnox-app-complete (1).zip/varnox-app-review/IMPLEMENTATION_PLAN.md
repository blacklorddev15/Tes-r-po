# Varnox Production Implementation Plan

## Approved architecture

The React/Vite frontend will remain deployable to Vercel. Persistent authentication, conversations, media metadata, statuses, groups, communities, channels, notifications, moderation, and device sessions will be served by a separate persistent Node.js API using MongoDB-compatible storage. Realtime messaging and calling will use a persistent WebSocket/WebRTC-capable service. Media will use object storage such as Cloudinary or S3. Email and SMS capabilities will use provider-backed services configured through environment variables.

The existing login and registration experience is a protected compatibility boundary. It must not be redesigned or removed while the authenticated product is rebuilt around it.

## Delivery phases

| Phase | Scope | Completion condition |
|---|---|---|
| 1 | Authentication boundary and persistent data foundation | Existing login, registration, verification, profile setup, logout, and session checks continue to work against the new data model. |
| 2 | Direct messaging and contacts | Conversations, messages, read/delivery state, presence, typing, replies, reactions, edits, deletion, search, attachments, and message organization work through authenticated APIs. |
| 3 | Groups | Group creation, members, admins, invitations, permissions, mentions, group media, moderation, notifications, and history are persisted and enforced server-side. |
| 4 | Media and calls | Upload validation, media metadata, camera/microphone flows, voice notes, media previews, and WebRTC call sessions are connected to providers. |
| 5 | Status, communities, channels, and broadcasts | Each publishing surface has persisted content, visibility rules, expiration where applicable, reactions/replies where applicable, and moderation controls. |
| 6 | Privacy and security | Device sessions, privacy controls, blocking/reporting, account recovery, two-step verification, passkeys, security notifications, deletion workflows, and audit events are implemented. |
| 7 | Administration and operations | Admin dashboard, moderation queues, rate limits, abuse prevention, storage quotas, notifications, backups, error logging, analytics, and recovery procedures are added. |
| 8 | Production validation and deployment | Frontend build, API tests, realtime tests, security checks, environment validation, deployment configuration, and rollback checkpoint are complete. |

## Explicit product boundary

Payments, commerce, and WhatsApp Business integrations are excluded from this implementation as approved. Their extension points may be documented, but no payment or business-account transaction will be enabled.

Features that depend on external providers—SMS, passkeys, push notifications, media storage, WebRTC TURN servers, backup storage, and email—will be implemented behind provider interfaces. They require production credentials before live use.

## Current state

The current dashboard contains a local browser demo for chats, attachments, statuses, calls, groups, settings, and responsive navigation. It is not the production implementation. Phase 1 replaces local-only behavior with authenticated persistence while preserving the existing authentication screens.
