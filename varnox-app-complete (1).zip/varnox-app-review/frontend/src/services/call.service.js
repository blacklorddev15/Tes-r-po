import { getRealtimeSocket } from "./realtime.service";

let peer;
let localStream;
let remoteStream;
const iceServers = [
  { urls: "stun:stun.l.google.com:19302" },
  ...(import.meta.env.VITE_TURN_URL ? [{ urls: import.meta.env.VITE_TURN_URL, username: import.meta.env.VITE_TURN_USERNAME, credential: import.meta.env.VITE_TURN_CREDENTIAL }] : []),
];

export const createCall = async ({ peerUserId, kind, onRemoteStream, onState }) => {
  const socket = getRealtimeSocket();
  if (!socket || !peerUserId) throw new Error("A realtime connection and remote user are required");
  localStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: kind === "video" });
  peer = new RTCPeerConnection({ iceServers });
  remoteStream = new MediaStream();
  peer.ontrack = (event) => { event.streams[0]?.getTracks().forEach((track) => remoteStream.addTrack(track)); onRemoteStream?.(remoteStream); };
  peer.onicecandidate = (event) => event.candidate && socket.emit("call:signal", { peerUserId, signal: { type: "ice", candidate: event.candidate } });
  localStream.getTracks().forEach((track) => peer.addTrack(track, localStream));
  const offer = await peer.createOffer();
  await peer.setLocalDescription(offer);
  socket.emit("call:signal", { peerUserId, signal: { type: "offer", sdp: offer, kind } });
  onState?.("calling");
  return localStream;
};

export const acceptCall = async ({ peerUserId, offer, kind, onRemoteStream, onState }) => {
  const socket = getRealtimeSocket();
  localStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: kind === "video" });
  peer = new RTCPeerConnection({ iceServers });
  remoteStream = new MediaStream();
  peer.ontrack = (event) => { event.streams[0]?.getTracks().forEach((track) => remoteStream.addTrack(track)); onRemoteStream?.(remoteStream); };
  peer.onicecandidate = (event) => event.candidate && socket.emit("call:signal", { peerUserId, signal: { type: "ice", candidate: event.candidate } });
  localStream.getTracks().forEach((track) => peer.addTrack(track, localStream));
  await peer.setRemoteDescription(offer);
  const answer = await peer.createAnswer();
  await peer.setLocalDescription(answer);
  socket.emit("call:signal", { peerUserId, signal: { type: "answer", sdp: answer } });
  onState?.("connected");
  return localStream;
};

export const handleCallSignal = async (signal, onState) => {
  if (!peer) return;
  if (signal.type === "answer") { await peer.setRemoteDescription(signal.sdp); onState?.("connected"); }
  if (signal.type === "ice" && signal.candidate) await peer.addIceCandidate(signal.candidate);
};

export const getLocalStream = () => localStream;
export const getRemoteStream = () => remoteStream;
export const endCall = () => { peer?.close(); localStream?.getTracks().forEach((track) => track.stop()); remoteStream?.getTracks().forEach((track) => track.stop()); peer = null; localStream = null; remoteStream = null; };
