import { io } from "socket.io-client";

const apiUrl = import.meta.env.VITE_API_URL || import.meta.env.REACT_APP_API_URL || "http://localhost:5001/api";
const socketUrl = apiUrl.replace(/\/api\/?$/, "");
let socket;

export const connectRealtime = () => {
  if (!socket) socket = io(socketUrl, { withCredentials: true, transports: ["websocket", "polling"] });
  return socket;
};
export const getRealtimeSocket = () => socket;
export const disconnectRealtime = () => { socket?.disconnect(); socket = null; };
export const joinConversation = (conversationId) => socket?.emit("conversation:join", conversationId);
export const leaveConversation = (conversationId) => socket?.emit("conversation:leave", conversationId);
export const setTyping = (conversationId, isTyping) => socket?.emit(isTyping ? "typing:start" : "typing:stop", { conversationId });
export const setRecording = (conversationId, isRecording) => socket?.emit(isRecording ? "recording:start" : "recording:stop", { conversationId });
export const sendRealtimeMessage = (conversationId, message) => socket?.emit("message:created", { conversationId, message });
export const markRealtimeRead = (conversationId, messageId) => socket?.emit("message:read", { conversationId, messageId });
export const showBrowserNotification = (title, options = {}) => {
  if (typeof window !== "undefined" && "Notification" in window && Notification.permission === "granted") new Notification(title, { icon: "/favicon.ico", ...options });
};
