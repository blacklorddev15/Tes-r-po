import React, { useEffect, useRef, useState } from "react";
import { FaCheck, FaCopy, FaEllipsisV, FaForward, FaHeart, FaPaperclip, FaPause, FaPlay, FaQuoteRight, FaStar, FaThumbtack, FaTrash } from "react-icons/fa";

export default function MessageBubble({ message, onReply, onForward, onAction, onRead }) {
  const audioRef = useRef(null);
  const [speed, setSpeed] = useState(1);
  const [menu, setMenu] = useState(false);
  useEffect(() => { if (!message.own) onRead?.(message.id); }, [message.id, message.own, onRead]);
  const setPlaybackSpeed = () => { const next = speed === 2 ? 1 : speed + 0.5; setSpeed(next); if (audioRef.current) audioRef.current.playbackRate = next; };
  const copy = async () => { await navigator.clipboard?.writeText(message.text || ""); setMenu(false); };
  return <div className={`group flex ${message.own ? "justify-end" : "justify-start"}`}>
    <div className={`relative max-w-[86%] rounded-lg px-3 py-2 text-sm shadow-sm ${message.own ? "bg-[#d9fdd3] dark:bg-[#005c4b]" : "bg-white dark:bg-[#202c33]"}`}>
      {message.replyTo && <div className="mb-2 border-l-2 border-[#128c7e] pl-2 text-xs opacity-70">Replying to a message</div>}
      {message.forwarded && <p className="mb-1 text-[10px] italic opacity-70"><FaForward className="mr-1 inline" />Forwarded</p>}
      {message.audioUrl ? <div className="flex items-center gap-2"><audio ref={audioRef} controls src={message.audioUrl} className="max-w-[210px]" /><button type="button" onClick={setPlaybackSpeed} className="rounded bg-black/10 px-1.5 py-1 text-[10px]">{speed}x</button></div> : message.media?.url ? <a href={message.media.url} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-[#128c7e] underline"><FaPaperclip />{message.media.name || "Open attachment"}</a> : <span className="text-[#111b21] dark:text-[#e9edef]">{message.viewOnce ? "View-once message" : message.text}</span>}
      <span className="ml-3 whitespace-nowrap text-[10px] text-[#667781] dark:text-[#aebac1]">{message.time} {message.own && <FaCheck className="inline" />}</span>
      <button type="button" onClick={() => setMenu((value) => !value)} className="absolute -right-7 top-1 hidden p-1 text-xs text-[#667781] group-hover:block"><FaEllipsisV /></button>
      {menu && <div className="absolute right-0 top-7 z-20 w-40 rounded-lg bg-white py-1 text-xs shadow-xl dark:bg-[#233138]"><button onClick={() => onReply?.(message)} className="flex w-full gap-2 px-3 py-2 text-left hover:bg-black/5"><FaQuoteRight />Reply</button><button onClick={copy} className="flex w-full gap-2 px-3 py-2 text-left hover:bg-black/5"><FaCopy />Copy</button><button onClick={() => { onForward?.(message); setMenu(false); }} className="flex w-full gap-2 px-3 py-2 text-left hover:bg-black/5"><FaForward />Forward</button><button onClick={() => { onAction?.(message, "star"); setMenu(false); }} className="flex w-full gap-2 px-3 py-2 text-left hover:bg-black/5"><FaStar />Star</button><button onClick={() => { onAction?.(message, "pin"); setMenu(false); }} className="flex w-full gap-2 px-3 py-2 text-left hover:bg-black/5"><FaThumbtack />Pin</button><button onClick={() => { onAction?.(message, "delete-for-me"); setMenu(false); }} className="flex w-full gap-2 px-3 py-2 text-left text-red-600 hover:bg-black/5"><FaTrash />Delete</button></div>}
      <button type="button" onClick={() => { const emoji = window.prompt("Reaction emoji", "❤️"); if (emoji) onAction?.(message, "react", emoji); }} className="ml-2 text-xs text-[#667781]"><FaHeart /></button>
    </div>
  </div>;
}
