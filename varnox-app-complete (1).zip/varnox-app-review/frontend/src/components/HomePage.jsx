import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  FaArrowLeft,
  FaCamera,
  FaCheck,
  FaCog,
  FaEllipsisV,
  FaFile,
  FaImage,
  FaMicrophone,
  FaMoon,
  FaPaperclip,
  FaPhone,
  FaPlus,
  FaSearch,
  FaSmile,
  FaSun,
  FaTimes,
  FaVideo,
} from "react-icons/fa";
import { MdCall, MdChat, MdGroups, MdLogout, MdOutlineSettings, MdSend } from "react-icons/md";
import MessageBubble from "./MessageBubble";
import CallOverlay from "./CallOverlay";
import CommunityPanel from "./CommunityPanel";
import NotificationCenter from "./NotificationCenter";
import StoragePanel from "./StoragePanel";
import AdminPanel from "./AdminPanel";
import { logoutUser } from "../services/userService";
import useThemeStore from "../store/useThemeStore";
import useUserStore from "../store/useUserStore";
import { changePassword, createGroup as createGroupApi, createStatus as createStatusApi, deleteAccount, exportAccountData, getPrivacy, listConversations, listDevices, revokeDevice, listMessages, reactToMessage, sendMessage as sendMessageApi, updatePrivacy, uploadMedia } from "../services/featureService";
import { connectRealtime, disconnectRealtime, getRealtimeSocket, joinConversation, leaveConversation, sendRealtimeMessage, setRecording, setTyping, showBrowserNotification } from "../services/realtime.service";
import { acceptCall, createCall, endCall, handleCallSignal } from "../services/call.service";

const initialContacts = [
  { id: 1, name: "Dev Stack", status: "online", message: "Hi everyone", time: "4:00 PM", color: "#128c7e" },
  { id: 2, name: "Kishor", status: "last seen today at 1:00 PM", message: "See you soon", time: "1:00 PM", color: "#6b7280" },
  { id: 3, name: "Collins", status: "online", message: "Hi Dev Stack", time: "8:00 AM", color: "#7c3aed" },
  { id: 4, name: "Balram Rathore", status: "last seen yesterday", message: "Photo", time: "Yesterday", color: "#2563eb" },
];

const starterMessages = {
  1: [
    { id: 1, text: "Welcome to Varnox", own: false, time: "3:58 PM" },
    { id: 2, text: "This dashboard follows the Flutter reference layout.", own: true, time: "4:00 PM" },
  ],
  2: [{ id: 3, text: "Hi Kishor", own: true, time: "12:59 PM" }],
  3: [{ id: 4, text: "Hi Dev Stack", own: false, time: "8:00 AM" }],
  4: [{ id: 5, text: "Let's catch up later.", own: false, time: "Yesterday" }],
};

const tabItems = [
  { id: "camera", label: "Camera", icon: FaCamera },
  { id: "chats", label: "Chats", icon: MdChat },
  { id: "communities", label: "Communities", icon: MdGroups },
  { id: "storage", label: "Storage", icon: FaFile },
  { id: "admin", label: "Admin", icon: MdOutlineSettings },
  { id: "status", label: "Status", icon: FaSun },
  { id: "calls", label: "Calls", icon: MdCall },
];

function Avatar({ name, color, size = "h-11 w-11" }) {
  return (
    <div className={`${size} flex shrink-0 items-center justify-center rounded-full text-sm font-bold text-white`} style={{ backgroundColor: color || "#128c7e" }}>
      {name?.slice(0, 1).toUpperCase() || "V"}
    </div>
  );
}

function EmptyPanel({ icon: Icon, title, description, action, onAction }) {
  return (
    <div className="flex h-full flex-col items-center justify-center px-8 text-center text-[#667781] dark:text-[#aebac1]">
      <div className="mb-5 flex h-20 w-20 items-center justify-center rounded-full bg-[#d9fdd3] text-[#128c7e] dark:bg-[#233f38] dark:text-[#7dd3a8]">
        <Icon className="h-9 w-9" />
      </div>
      <h2 className="text-xl font-semibold text-[#41525d] dark:text-[#e9edef]">{title}</h2>
      <p className="mt-2 max-w-md text-sm leading-6">{description}</p>
      {action && <button onClick={onAction} className="mt-5 rounded-lg bg-[#128c7e] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#0b6f63]">{action}</button>}
    </div>
  );
}

function SettingsPanel({ user, theme, toggleTheme, onLogout }) {
  const [privacy, setPrivacy] = useState({ readReceipts: true, typingIndicators: true, silenceUnknownCallers: false, lastSeen: "everyone", status: "contacts" });
  const [privacyMessage, setPrivacyMessage] = useState("");
  const [devices, setDevices] = useState([]);
  useEffect(() => { getPrivacy().then((result) => result?.data?.settings && setPrivacy(result.data.settings)).catch(() => {}); listDevices().then((result) => setDevices(result?.data?.devices || [])).catch(() => {}); }, []);
  const setPrivacyValue = async (key, value) => {
    const next = { ...privacy, [key]: value };
    setPrivacy(next);
    try { await updatePrivacy({ [key]: value }); setPrivacyMessage("Privacy settings saved"); } catch { setPrivacyMessage("Saved locally; connect the API to sync settings"); }
  };
  const handlePassword = async () => {
    const current = window.prompt("Current password");
    const next = window.prompt("New password (minimum 8 characters)");
    if (!current || !next) return;
    try { await changePassword(current, next); setPrivacyMessage("Password changed successfully"); } catch (error) { setPrivacyMessage(error?.response?.data?.message || "Password change failed"); }
  };
  const handleExport = async () => { try { const blob = await exportAccountData(); const url = URL.createObjectURL(blob); const link = document.createElement("a"); link.href = url; link.download = "varnox-account-data.json"; link.click(); URL.revokeObjectURL(url); } catch { setPrivacyMessage("Account export failed"); } };
  const handleDelete = async () => {
    if (window.confirm("Delete this Varnox account permanently?")) { try { await deleteAccount(); onLogout(); } catch (error) { setPrivacyMessage(error?.response?.data?.message || "Account deletion failed"); } }
  };
  return (
    <div className="h-full overflow-y-auto bg-[#f0f2f5] dark:bg-[#111b21]">
      <div className="flex items-center gap-3 bg-[#075e54] px-5 py-5 text-white dark:bg-[#202c33]"><MdOutlineSettings className="h-6 w-6" /><div><h2 className="font-semibold">Settings</h2><p className="text-xs text-white/70">Varnox account, privacy, and security</p></div></div>
      <div className="mx-auto max-w-2xl space-y-3 p-4 sm:p-8">
        <div className="flex items-center gap-4 rounded-xl bg-white p-4 shadow-sm dark:bg-[#202c33]"><Avatar name={user?.username || user?.email} color="#128c7e" size="h-14 w-14" /><div className="min-w-0"><p className="truncate font-semibold text-[#111b21] dark:text-[#e9edef]">{user?.username || "Varnox user"}</p><p className="truncate text-sm text-[#667781] dark:text-[#aebac1]">{user?.email || "Account profile"}</p></div></div>
        <button onClick={toggleTheme} className="flex w-full items-center justify-between rounded-xl bg-white p-4 text-left shadow-sm dark:bg-[#202c33]"><span className="flex items-center gap-3 text-sm font-medium"><span className="rounded-full bg-[#e9edef] p-2 dark:bg-[#374045]">{theme === "dark" ? <FaSun /> : <FaMoon />}</span>{theme === "dark" ? "Light theme" : "Dark theme"}</span><span className="text-xs text-[#667781]">Appearance</span></button>
        <div className="rounded-xl bg-white p-4 shadow-sm dark:bg-[#202c33]"><p className="font-semibold">Privacy</p><div className="mt-3 space-y-3 text-sm"><label className="flex items-center justify-between"><span>Read receipts</span><input type="checkbox" checked={privacy.readReceipts} onChange={(e) => setPrivacyValue("readReceipts", e.target.checked)} /></label><label className="flex items-center justify-between"><span>Typing indicators</span><input type="checkbox" checked={privacy.typingIndicators} onChange={(e) => setPrivacyValue("typingIndicators", e.target.checked)} /></label><label className="flex items-center justify-between"><span>Silence unknown callers</span><input type="checkbox" checked={privacy.silenceUnknownCallers} onChange={(e) => setPrivacyValue("silenceUnknownCallers", e.target.checked)} /></label><label className="flex items-center justify-between"><span>Last seen</span><select value={privacy.lastSeen} onChange={(e) => setPrivacyValue("lastSeen", e.target.value)} className="rounded border p-1 dark:bg-[#2a3942]"><option>everyone</option><option>contacts</option><option>nobody</option></select></label></div></div>
        {privacyMessage && <p className="rounded-lg bg-[#d9fdd3] p-3 text-sm text-[#075e54]">{privacyMessage}</p>}
        <button onClick={handlePassword} className="w-full rounded-xl bg-white p-4 text-left font-medium shadow-sm dark:bg-[#202c33]">Change password</button>
        <button onClick={handleExport} className="w-full rounded-xl bg-white p-4 text-left font-medium shadow-sm dark:bg-[#202c33]">Download account data</button>
        <div className="rounded-xl bg-white p-4 shadow-sm dark:bg-[#202c33]"><p className="font-semibold">Linked devices</p>{devices.length ? devices.map((device) => <div key={device._id} className="mt-2 flex items-center justify-between text-sm"><span>{device.deviceName || device.platform || "Browser"}<span className="ml-2 text-xs text-[#667781]">{device.lastActiveAt ? new Date(device.lastActiveAt).toLocaleString() : "Active"}</span></span><button onClick={async () => { await revokeDevice(device._id).catch(() => {}); setDevices((current) => current.filter((item) => item._id !== device._id)); }} className="text-xs text-red-600">Log out</button></div>) : <p className="mt-2 text-xs text-[#667781]">No other linked devices.</p>}</div>
        <button onClick={handleDelete} className="w-full rounded-xl bg-white p-4 text-left font-semibold text-red-600 shadow-sm dark:bg-[#202c33]">Delete account</button>
        <button onClick={onLogout} className="flex w-full items-center gap-3 rounded-xl bg-white p-4 text-left font-semibold text-red-600 shadow-sm dark:bg-[#202c33]"><MdLogout className="h-5 w-5" />Log out</button>
      </div>
    </div>
  );
}

export default function HomePage() {
  const { user, clearUser } = useUserStore();
  const { theme, toggleTheme } = useThemeStore();
  const [activeTab, setActiveTab] = useState("chats");
  const [contacts, setContacts] = useState(initialContacts);
  const [selectedId, setSelectedId] = useState(1);
  const [messages, setMessages] = useState(starterMessages);
  const [draft, setDraft] = useState("");
  const [search, setSearch] = useState("");
  const [chatSearch, setChatSearch] = useState("");
  const [showMenu, setShowMenu] = useState(false);
  const [showNewChat, setShowNewChat] = useState(false);
  const [statuses, setStatuses] = useState(() => JSON.parse(localStorage.getItem("varnox-statuses") || "[]"));
  const [callStatus, setCallStatus] = useState("");
  const [activeCall, setActiveCall] = useState(null);
  const [localCallStream, setLocalCallStream] = useState(null);
  const [remoteCallStream, setRemoteCallStream] = useState(null);
  const [callHistory, setCallHistory] = useState(() => JSON.parse(localStorage.getItem("varnox-call-history") || "[]"));
  const [typingUsers, setTypingUsers] = useState({});
  const [isRecording, setIsRecording] = useState(false);
  const mediaRecorderRef = useRef(null);
  const recordingChunksRef = useRef([]);
  const recordingStartedAtRef = useRef(0);
  const cameraInputRef = useRef(null);
  const attachmentInputRef = useRef(null);
  const statusInputRef = useRef(null);
  const selected = contacts.find((contact) => contact.id === selectedId);

  useEffect(() => {
    const loadRemoteData = async () => {
      try {
        const result = await listConversations();
        const remote = result?.data?.conversations || [];
        if (!remote.length) return;
        const mapped = remote.map((conversation) => ({
          id: String(conversation._id),
          remoteId: String(conversation._id),
          name: conversation.title || conversation.participants?.find((person) => String(person._id) !== String(user?._id))?.username || "Conversation",
          peerUserId: conversation.kind === "direct" ? conversation.participants?.find((person) => String(person._id) !== String(user?._id))?._id : null,
          status: conversation.kind === "group" ? "Group" : "available",
          message: conversation.lastMessage?.text || "No messages yet",
          time: conversation.updatedAt ? new Date(conversation.updatedAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }) : "Now",
          color: conversation.kind === "group" ? "#f59e0b" : "#128c7e",
        }));
        setContacts(mapped);
        setSelectedId(mapped[0].id);
      } catch (error) {
        console.info("Using local dashboard fallback until the API is configured.", error?.message);
      }
    };
    loadRemoteData();
    const savedMessages = localStorage.getItem("varnox-messages");
    const savedContacts = localStorage.getItem("varnox-contacts");
    if (savedMessages) setMessages(JSON.parse(savedMessages));
    if (savedContacts) setContacts(JSON.parse(savedContacts));
  }, []);
  useEffect(() => localStorage.setItem("varnox-messages", JSON.stringify(messages)), [messages]);
  useEffect(() => localStorage.setItem("varnox-contacts", JSON.stringify(contacts)), [contacts]);
  useEffect(() => localStorage.setItem("varnox-statuses", JSON.stringify(statuses)), [statuses]);
  useEffect(() => localStorage.setItem("varnox-call-history", JSON.stringify(callHistory)), [callHistory]);
  useEffect(() => {
    const socket = connectRealtime();
    const onMessage = (message) => {
      if (!message?.conversation) return;
      showBrowserNotification("New Varnox message", { body: message.text || `New ${message.contentType || "message"}` });
      setMessages((current) => ({ ...current, [String(message.conversation)]: [...(current[String(message.conversation)] || []), { id: message._id || Date.now(), text: message.text || `[${message.contentType}]`, own: false, time: new Date(message.createdAt || Date.now()).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }) }] }));
    };
    const onTyping = ({ conversationId, userId, isTyping }) => setTypingUsers((current) => ({ ...current, [`${conversationId}:${userId}`]: isTyping }));
    const onCallSignal = async ({ fromUserId, signal }) => {
      try {
      if (signal?.type === "offer") {
        showBrowserNotification("Incoming Varnox call", { body: "Tap Varnox to answer" });
        setActiveCall({ direction: "incoming", state: "incoming", kind: signal.kind || "audio", peerUserId: fromUserId, contactName: "Varnox contact", offer: signal.sdp });
      } else if (signal?.type !== "offer") await handleCallSignal(signal, (next) => { setCallStatus(next); setActiveCall((current) => current ? { ...current, state: next } : current); });
      } catch { setCallStatus("Unable to connect the call."); }
    };
    socket.on("message:new", onMessage);
    socket.on("typing:update", onTyping);
    socket.on("call:signal", onCallSignal);
    return () => { socket.off("message:new", onMessage); socket.off("typing:update", onTyping); socket.off("call:signal", onCallSignal); endCall(); disconnectRealtime(); };
  }, []);

  useEffect(() => {
    if (!selected?.remoteId) return;
    joinConversation(selected.remoteId);
    listMessages(selected.remoteId).then((result) => {
      const remoteMessages = result?.data?.messages || [];
      if (remoteMessages.length) setMessages((current) => ({ ...current, [selected.id]: remoteMessages.map((message) => ({ id: message._id, text: message.text || `[${message.contentType}]`, own: String(message.sender?._id || message.sender) === String(user?._id), time: new Date(message.createdAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }) })) }));
    }).catch(() => {});
    return () => leaveConversation(selected.remoteId);
  }, [selected?.remoteId]);

  const visibleContacts = useMemo(() => contacts.filter((contact) => contact.name.toLowerCase().includes(search.toLowerCase())), [contacts, search]);

  const sendMessage = (event) => {
    event.preventDefault();
    const text = draft.trim();
    if (!text || !selected) return;
    const next = { id: Date.now(), text, own: true, time: new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }) };
    if (selected.remoteId) {
      sendMessageApi({ conversationId: selected.remoteId, text }).then((result) => sendRealtimeMessage(selected.remoteId, result?.data?.message)).catch(() => {});
    }
    setMessages((current) => ({ ...current, [selected.id]: [...(current[selected.id] || []), next] }));
    setContacts((current) => current.map((contact) => contact.id === selected.id ? { ...contact, message: text, time: "Now" } : contact));
    setDraft("");
  };

  const handleAttachment = async (event) => {
    const file = event.target.files?.[0];
    if (!file || !selected) return;
    const localMessage = { id: Date.now(), text: `Attachment: ${file.name}`, own: true, time: "Now" };
    setMessages((current) => ({ ...current, [selected.id]: [...(current[selected.id] || []), localMessage] }));
    setContacts((current) => current.map((contact) => contact.id === selected.id ? { ...contact, message: `Attachment: ${file.name}`, time: "Now" } : contact));
    if (selected.remoteId) {
      try {
        const uploaded = await uploadMedia(file);
        await sendMessageApi({ conversationId: selected.remoteId, contentType: uploaded?.data?.media?.contentType || "document", media: uploaded?.data?.media, text: file.name });
      } catch (error) { console.info("Media upload unavailable; kept local attachment.", error?.message); }
    }
    event.target.value = "";
  };

  const toggleRecording = async () => {
    if (isRecording && mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) return setCallStatus("Voice recording is not supported in this browser.");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      recordingChunksRef.current = [];
      recorder.ondataavailable = (event) => event.data.size && recordingChunksRef.current.push(event.data);
      recorder.onstop = async () => {
        stream.getTracks().forEach((track) => track.stop());
        setIsRecording(false);
        const blob = new Blob(recordingChunksRef.current, { type: recorder.mimeType || "audio/webm" });
        const file = new File([blob], `voice-${Date.now()}.webm`, { type: blob.type });
        const duration = Math.max(1, Math.round((Date.now() - recordingStartedAtRef.current) / 1000));
        if (!selected) return;
        setMessages((current) => ({ ...current, [selected.id]: [...(current[selected.id] || []), { id: Date.now(), text: `Voice message (${duration}s)`, own: true, time: "Now", audioUrl: URL.createObjectURL(blob) }] }));
        if (selected.remoteId) {
          try { const uploaded = await uploadMedia(file); await sendMessageApi({ conversationId: selected.remoteId, contentType: "audio", media: { ...uploaded?.data?.media, duration }, text: "Voice message" }); } catch (error) { console.info("Voice upload unavailable; kept local recording.", error?.message); }
        }
      };
      mediaRecorderRef.current = recorder;
      recorder.start();
      recordingStartedAtRef.current = Date.now();
      setIsRecording(true);
    } catch { setCallStatus("Microphone permission was denied."); }
  };

  const createStatus = () => {
    const text = window.prompt("Write your status update");
    if (!text?.trim()) return;
    const localStatus = { id: Date.now(), text: text.trim(), createdAt: new Date().toISOString() };
    setStatuses((current) => [localStatus, ...current.filter((item) => Date.now() - new Date(item.createdAt).getTime() < 86400000)]);
    createStatusApi({ text: text.trim(), contentType: "text" }).catch(() => {});
  };

  const createStatusMedia = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      const uploaded = await uploadMedia(file);
      await createStatusApi({ contentType: file.type.startsWith("video/") ? "video" : "image", media: uploaded?.data?.media, text: file.name });
      setStatuses((current) => [{ id: Date.now(), text: file.name, mediaUrl: uploaded?.data?.media?.url, createdAt: new Date().toISOString() }, ...current]);
    } catch (error) { setCallStatus(error?.message || "Status media upload failed"); }
    event.target.value = "";
  };

  const startCall = async (kind) => {
    if (!navigator.mediaDevices?.getUserMedia) return setCallStatus(`${kind} calling is not supported in this browser.`);
    try {
      if (selected?.peerUserId) {
        setActiveCall({ direction: "outgoing", state: "calling", kind: kind.toLowerCase(), peerUserId: selected.peerUserId, contactName: selected.name });
        const stream = await createCall({ peerUserId: selected.peerUserId, kind: kind.toLowerCase(), onRemoteStream: setRemoteCallStream, onState: (next) => { setCallStatus(next); setActiveCall((current) => current ? { ...current, state: next } : current); } });
        setLocalCallStream(stream);
        setCallStatus(`${kind} call is connecting to ${selected.name}.`);
      } else {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: kind === "Video" });
        stream.getTracks().forEach((track) => track.stop());
        setCallStatus(`${kind} call permission granted. Select a synced contact to place a live call.`);
      }
    } catch {
      setCallStatus(`${kind} call permission was denied.`);
    }
  };

  const handleMessageAction = async (message, action, emoji) => {
    if (action === "react" && selected?.remoteId) { await reactToMessage(message.id, emoji).catch(() => {}); return; }
    if (selected?.remoteId && !String(message.id).startsWith("local")) await updateMessage(message.id, { action }).catch(() => {});
    if (action === "delete-for-me" || action === "delete-for-everyone") setMessages((current) => ({ ...current, [selected.id]: (current[selected.id] || []).filter((item) => item.id !== message.id) }));
  };
  const handleReply = (message) => setDraft(`Replying: ${message.text || "message"} `);
  const handleForward = async (message) => { if (selected?.remoteId) await forwardMessage(message.id, selected.remoteId).catch(() => {}); };

  const finishCall = (result = "completed") => { endCall(); setCallHistory((current) => [{ id: Date.now(), contactName: activeCall?.contactName || "Varnox contact", kind: activeCall?.kind || "audio", result, createdAt: new Date().toISOString() }, ...current].slice(0, 50)); setActiveCall(null); setLocalCallStream(null); setRemoteCallStream(null); };
  const acceptIncomingCall = async () => { if (!activeCall) return; try { const stream = await acceptCall({ peerUserId: activeCall.peerUserId, offer: activeCall.offer, kind: activeCall.kind, onRemoteStream: setRemoteCallStream, onState: (next) => setActiveCall((current) => current ? { ...current, state: next } : current) }); setLocalCallStream(stream); setActiveCall((current) => ({ ...current, state: "connected", direction: "active" })); } catch { finishCall("missed"); } };

  const logout = async () => { try { await logoutUser(); } finally { clearUser(); } };
  const addContact = (group = false) => {
    const id = Date.now();
    const name = group ? (window.prompt("Name your new group") || "New group") : "New contact";
    const contact = { id, name, isGroup: group, status: group ? "Group created" : "online", message: group ? "You created this group" : "Start a conversation", time: "Now", color: group ? "#f59e0b" : "#db2777" };
    if (group) createGroupApi({ title: name, memberIds: [] }).catch(() => {});
    setContacts((current) => [contact, ...current]); setSelectedId(id); setShowNewChat(false); setActiveTab("chats");
  };

  const renderMain = () => {
    if (activeTab === "camera") return <div className="flex h-full flex-col items-center justify-center gap-4 bg-[#111b21] p-8 text-center text-white"><FaCamera className="h-14 w-14 text-[#25d366]" /><h2 className="text-xl font-semibold">Camera</h2><p className="max-w-md text-sm text-white/70">Capture a photo or video to share with the current conversation.</p><button onClick={() => cameraInputRef.current?.click()} className="rounded-lg bg-[#128c7e] px-5 py-3 font-semibold">Open camera</button><input ref={cameraInputRef} type="file" accept="image/*,video/*" capture="environment" className="hidden" onChange={handleAttachment} /></div>;
    if (activeTab === "communities") return <CommunityPanel />;
    if (activeTab === "storage") return <StoragePanel />;
    if (activeTab === "admin") return <AdminPanel />;
    if (activeTab === "status") return <div className="h-full overflow-y-auto bg-[#f0f2f5] p-6 dark:bg-[#111b21]"><div className="mx-auto max-w-2xl"><div className="flex items-center justify-between"><div><h2 className="text-xl font-semibold">Status</h2><p className="text-sm text-[#667781] dark:text-[#aebac1]">Updates disappear after 24 hours.</p></div><button onClick={createStatus} className="rounded-lg bg-[#128c7e] px-4 py-2 text-sm font-semibold text-white"><FaPlus className="mr-2 inline" />Text status</button><button onClick={() => statusInputRef.current?.click()} className="rounded-lg border border-[#128c7e] px-4 py-2 text-sm font-semibold text-[#128c7e]"><FaImage className="mr-2 inline" />Photo/video</button><input ref={statusInputRef} type="file" accept="image/*,video/*" className="hidden" onChange={createStatusMedia} /></div><div className="mt-6 space-y-3">{statuses.length ? statuses.map((status) => <div key={status.id} className="rounded-xl bg-white p-4 shadow-sm dark:bg-[#202c33]">{status.mediaUrl && <img src={status.mediaUrl} alt="Status update" className="mb-3 max-h-64 rounded-lg object-cover" />}<p className="text-sm">{status.text}</p><p className="mt-2 text-xs text-[#667781]">{new Date(status.createdAt).toLocaleString()}</p></div>) : <EmptyPanel icon={FaSun} title="No status updates" description="Share a text update with your contacts." />}</div></div></div>;
    if (activeTab === "calls") return <div className="flex h-full flex-col items-center justify-center gap-4 p-8 text-center"><MdCall className="h-14 w-14 text-[#128c7e]" /><h2 className="text-xl font-semibold">Calls</h2><p className="max-w-md text-sm text-[#667781] dark:text-[#aebac1]">Start an audio or video call after granting browser media permission.</p><div className="flex gap-3"><button onClick={() => startCall("Audio")} className="rounded-lg bg-[#128c7e] px-4 py-2 font-semibold text-white"><FaPhone className="mr-2 inline" />Audio call</button><button onClick={() => startCall("Video")} className="rounded-lg border border-[#128c7e] px-4 py-2 font-semibold text-[#128c7e]"><FaVideo className="mr-2 inline" />Video call</button></div>{callStatus && <p className="max-w-lg rounded-lg bg-[#d9fdd3] p-3 text-sm text-[#075e54]">{callStatus}</p>}<div className="mt-4 w-full max-w-lg rounded-xl bg-white p-4 text-left shadow-sm dark:bg-[#202c33]"><h3 className="font-semibold">Recent calls</h3>{callHistory.length ? callHistory.slice(0, 8).map((call) => <div key={call.id} className="flex items-center justify-between border-b border-black/5 py-2 text-sm last:border-0 dark:border-white/5"><span>{call.contactName} · {call.kind === "video" ? "Video" : "Audio"}</span><span className={call.result === "missed" ? "text-red-500" : "text-[#667781]"}>{call.result === "missed" ? "Missed" : new Date(call.createdAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}</span></div>) : <p className="mt-2 text-xs text-[#667781]">No calls yet.</p>}</div></div>;
    if (activeTab === "settings") return <SettingsPanel user={user} theme={theme} toggleTheme={toggleTheme} onLogout={logout} />;
    return (
      <div className="flex h-full min-w-0 flex-1 flex-col bg-[#efeae2] dark:bg-[#0b141a]">
        {selected ? <>
          <header className="flex h-[68px] items-center gap-3 bg-[#f0f2f5] px-4 dark:bg-[#202c33]">
            <button className="rounded-full p-2 md:hidden" onClick={() => setSelectedId(null)}><FaArrowLeft /></button>
            <Avatar name={selected.name} color={selected.color} size="h-10 w-10" />
            <div className="min-w-0 flex-1"><p className="truncate font-semibold text-[#111b21] dark:text-[#e9edef]">{selected.name}</p><p className="truncate text-xs text-[#667781] dark:text-[#aebac1]">{typingUsers[`${selected.remoteId}:${selected.id}`] ? "typing..." : selected.status}</p></div>
            <button onClick={() => setChatSearch(window.prompt("Search within this chat", chatSearch) || "")} className="rounded-full p-2 text-[#54656f] hover:bg-black/5 dark:text-[#aebac1]"><FaSearch /></button><button onClick={() => startCall("Video")} className="rounded-full p-2 text-[#54656f] hover:bg-black/5 dark:text-[#aebac1]"><FaVideo /></button><button onClick={() => startCall("Audio")} className="rounded-full p-2 text-[#54656f] hover:bg-black/5 dark:text-[#aebac1]"><FaPhone /></button><button className="rounded-full p-2 text-[#54656f] hover:bg-black/5 dark:text-[#aebac1]"><FaEllipsisV /></button>
          </header>
          <div className="flex-1 overflow-y-auto bg-[#efeae2] p-4 dark:bg-[#0b141a] sm:p-8">
            <div className="mx-auto max-w-3xl space-y-2">{(messages[selected.id] || []).filter((message) => !chatSearch || String(message.text || "").toLowerCase().includes(chatSearch.toLowerCase())).map((message) => <MessageBubble key={message.id} message={message} onReply={handleReply} onForward={handleForward} onAction={handleMessageAction} onRead={(messageId) => selected.remoteId && markMessageRead(messageId).catch(() => {})} />)}</div>
          </div>
          <form onSubmit={sendMessage} className="flex items-center gap-2 bg-[#f0f2f5] p-3 dark:bg-[#202c33]"><button type="button" className="rounded-full p-2 text-[#54656f] dark:text-[#aebac1]"><FaSmile /></button><button type="button" onClick={() => attachmentInputRef.current?.click()} className="rounded-full p-2 text-[#54656f] dark:text-[#aebac1]"><FaPaperclip /></button><input ref={attachmentInputRef} type="file" accept="image/*,video/*,audio/*,.pdf,.doc,.docx" className="hidden" onChange={handleAttachment} /><input value={draft} onChange={(event) => { setDraft(event.target.value); if (selected?.remoteId) setTyping(selected.remoteId, Boolean(event.target.value)); }} onBlur={() => selected?.remoteId && setTyping(selected.remoteId, false)} placeholder="Type a message" className="min-w-0 flex-1 rounded-lg border-0 bg-white px-4 py-3 text-sm outline-none dark:bg-[#2a3942] dark:text-[#e9edef]" /><button type="submit" onClick={(event) => { if (!draft.trim()) { event.preventDefault(); toggleRecording(); } }} className={`rounded-full p-3 text-white hover:bg-[#0b6f63] ${isRecording ? "bg-red-600" : "bg-[#128c7e]"}`}>{draft.trim() ? <MdSend /> : <FaMicrophone />}</button></form>
        </> : <EmptyPanel icon={MdChat} title="Select a chat" description="Choose a conversation from the list to start messaging." />}
      </div>
    );
  };

  return <div className="flex h-screen w-screen overflow-hidden bg-[#f0f2f5] text-[#111b21] dark:bg-[#111b21] dark:text-[#e9edef]">
    <aside className="hidden w-[72px] flex-col items-center justify-between bg-[#075e54] py-4 text-white md:flex dark:bg-[#202c33]">
      <div className="flex flex-col items-center gap-3">{tabItems.map(({ id, icon: Icon }) => <button key={id} onClick={() => setActiveTab(id)} className={`rounded-xl p-3 ${activeTab === id ? "bg-white/20" : "text-white/70 hover:bg-white/10"}`} title={id}><Icon className="h-5 w-5" /></button>)}<button onClick={() => setActiveTab("settings")} className={`rounded-xl p-3 ${activeTab === "settings" ? "bg-white/20" : "text-white/70 hover:bg-white/10"}`} title="Settings"><FaCog /></button></div>
      <div className="flex flex-col items-center gap-2"><NotificationCenter /><button onClick={logout} className="rounded-xl p-3 text-white/70 hover:bg-red-500/30" title="Log out"><MdLogout className="h-5 w-5" /></button></div>
    </aside>
    <main className="flex min-w-0 flex-1 flex-col md:flex-row">{activeTab === "chats" && <section className={`${selectedId ? "hidden md:flex" : "flex"} w-full flex-col border-r border-[#d1d7db] bg-white dark:border-[#374045] dark:bg-[#111b21] md:w-[380px] lg:w-[420px]`}>
      <header className="bg-[#075e54] px-4 pb-3 pt-5 text-white dark:bg-[#202c33]"><div className="flex items-center justify-between"><h1 className="text-xl font-bold">Varnox</h1><div className="relative flex gap-1"><button onClick={() => setShowNewChat(true)} className="rounded-full p-2 hover:bg-white/10" title="New chat"><FaPlus /></button><button onClick={() => setShowMenu((value) => !value)} className="rounded-full p-2 hover:bg-white/10"><FaEllipsisV /></button>{showMenu && <div className="absolute right-0 top-11 z-20 w-44 rounded-lg bg-white py-1 text-sm text-[#111b21] shadow-xl dark:bg-[#233138] dark:text-[#e9edef]"><button onClick={() => setActiveTab("settings")} className="block w-full px-4 py-2 text-left hover:bg-black/5">Settings</button><button onClick={logout} className="block w-full px-4 py-2 text-left hover:bg-black/5">Log out</button></div>}</div></div><div className="mt-3 flex items-center gap-2 rounded-lg bg-white px-3 py-2 text-[#667781] dark:bg-[#2a3942]"><FaSearch className="h-3.5 w-3.5" /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search or start new chat" className="w-full bg-transparent text-sm outline-none dark:text-[#e9edef]" /></div></header>
      <div className="flex border-b border-[#e9edef] bg-white text-xs font-semibold uppercase tracking-wide text-[#667781] dark:border-[#374045] dark:bg-[#111b21] dark:text-[#aebac1]">{tabItems.filter((item) => item.id !== "camera").map(({ id, label }) => <button key={id} onClick={() => setActiveTab(id)} className="flex-1 px-2 py-3 hover:text-[#128c7e]">{label}</button>)}</div>
      <div className="flex-1 overflow-y-auto">{visibleContacts.map((contact) => <button key={contact.id} onClick={() => setSelectedId(contact.id)} className={`flex w-full items-center gap-3 border-b border-[#f0f2f5] px-4 py-3 text-left hover:bg-[#f5f6f6] dark:border-[#222e35] dark:hover:bg-[#202c33] ${selectedId === contact.id ? "bg-[#f0f2f5] dark:bg-[#2a3942]" : ""}`}><Avatar name={contact.name} color={contact.color} /><div className="min-w-0 flex-1"><div className="flex justify-between gap-3"><span className="truncate font-medium">{contact.name}</span><span className="whitespace-nowrap text-[11px] text-[#667781] dark:text-[#aebac1]">{contact.time}</span></div><p className="truncate text-sm text-[#667781] dark:text-[#aebac1]">{contact.message}</p></div></button>)}</div>
    </section>}
    <section className="min-w-0 flex-1">{renderMain()}</section></main>
    <nav className="fixed bottom-0 left-0 right-0 z-30 flex h-16 items-center justify-around border-t border-[#d1d7db] bg-white md:hidden dark:border-[#374045] dark:bg-[#202c33]">{[...tabItems, { id: "settings", label: "Settings", icon: FaCog }].map(({ id, label, icon: Icon }) => <button key={id} onClick={() => setActiveTab(id)} className={`flex flex-col items-center gap-1 px-2 py-1 text-[10px] ${activeTab === id ? "text-[#128c7e]" : "text-[#667781]"}`}><Icon className="h-4 w-4" />{label}</button>)}</nav>
    {showNewChat && <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/50 p-4"><div className="w-full max-w-sm rounded-xl bg-white p-5 shadow-2xl dark:bg-[#202c33]"><div className="flex items-center justify-between"><h2 className="font-semibold">New conversation</h2><button onClick={() => setShowNewChat(false)}><FaTimes /></button></div><p className="mt-2 text-sm text-[#667781] dark:text-[#aebac1]">Start a new chat or create a group from your contacts.</p><button onClick={addContact} className="mt-5 flex w-full items-center gap-3 rounded-lg bg-[#128c7e] px-4 py-3 text-left text-sm font-semibold text-white"><MdChat />New chat</button><button onClick={() => { addContact(true); setShowNewChat(false); }} className="mt-2 flex w-full items-center gap-3 rounded-lg border border-[#d1d7db] px-4 py-3 text-left text-sm font-semibold dark:border-[#374045]"><MdGroups />New group</button></div></div>}
    {activeCall && <CallOverlay state={activeCall.state} kind={activeCall.kind} contactName={activeCall.contactName} localStream={localCallStream} remoteStream={remoteCallStream} onAccept={acceptIncomingCall} onReject={() => finishCall("missed")} onHangup={() => finishCall("completed")} onReconnect={acceptIncomingCall} />}
  </div>;
}
