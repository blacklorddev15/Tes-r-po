const { server, app, io } = require("../app");

module.exports = server;
module.exports.default = server;
module.exports.app = app;
module.exports.io = io;
