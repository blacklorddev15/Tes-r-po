const dotenv = require("dotenv");
dotenv.config();

const express = require("express");
const cookieParser = require("cookie-parser");
const cors = require("cors");
const http = require("http");
const connectDB = require("./config/dbConnect");
const authRoute = require("./routes/authRoute");
const featureRoute = require("./routes/featureRoute");
const adminRoute = require("./routes/adminRoute");
const { ErrorLog } = require("./models/AdminOps");
const { initializeSocket } = require("./services/socketService");
require("./services/firebaseService");

const app = express();
const allowedOrigins = [
  process.env.FRONTEND_URL,
  process.env.PUBLIC_WEB_URL,
  "http://localhost:3000",
  "http://localhost:3001",
  "http://localhost:5173",
].filter(Boolean);

app.use(cors({
  origin: (origin, callback) => {
    if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
    return callback(new Error(`Origin not allowed by CORS: ${origin}`));
  },
  credentials: true,
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

app.get("/api/health", (req, res) => res.json({
  ok: true,
  service: "varnox-auth-api",
  mongoConfigured: Boolean(process.env.MONGO_URI),
  cloudinaryConfigured: Boolean(process.env.CLOUDINARY_CLOUD_NAME),
  ts: Date.now(),
}));

app.use(async (req, res, next) => {
  try {
    await connectDB();
    next();
  } catch (err) {
    res.status(503).json({ status: "error", message: "Database unavailable", error: err.message });
  }
});

app.use("/api/auth", authRoute);
app.use("/api", featureRoute);
app.use("/api/admin", adminRoute);
app.use((err, req, res, next) => {
  ErrorLog.create({ message: err.message, stack: err.stack, route: req.originalUrl, method: req.method, user: req.user?._id }).catch(() => {});
  return res.status(500).json({ status: "error", message: "Internal server error" });
});

const server = http.createServer(app);
const io = initializeSocket(server);
app.use((req, res, next) => { req.io = io; next(); });
module.exports = { app, server, io };
