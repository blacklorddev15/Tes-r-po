const express = require("express");
const authMiddleware = require("../middleware/authMiddleware");
const authController = require("../controllers/authController");
const { multerMiddleware } = require("../config/cloudinaryConfig");

const router = express.Router();

// Registration & email verification
router.post("/register", authController.register);
router.post("/verify-email", authController.verifyEmail);

// Login options
router.post("/login/email", authController.loginWithEmail);
router.post("/login/phone", authController.loginWithPhone);
router.post("/password-recovery", authController.requestPasswordReset);
router.post("/password-reset", authController.resetPassword);

// Firebase (kept for compatibility)
router.post("/verify-firebase-phone", authController.verifyFirebasePhone);

// Session
router.post("/logout", authController.logout);
router.get("/check-auth", authMiddleware, authController.checkAuthenticated);

// Protected profile setup used by the preserved registration flow
router.put("/update-profile", authMiddleware, multerMiddleware, authController.updateProfile);

module.exports = router;
