const bcrypt = require("bcryptjs");
const User = require("../models/User");
const PrivacySetting = require("../models/PrivacySetting");
const ContactBlock = require("../models/ContactBlock");
const response = require("../utils/responseHandler");
const mongoose = require("mongoose");

const validId = (value) => mongoose.Types.ObjectId.isValid(value) ? value : null;

exports.getPrivacy = async (req, res) => {
  const settings = await PrivacySetting.findOneAndUpdate({ user: req.user._id }, { $setOnInsert: { user: req.user._id } }, { upsert: true, new: true });
  return response(res, 200, "Privacy settings loaded", { settings });
};

exports.updatePrivacy = async (req, res) => {
  const allowed = ["lastSeen", "online", "profilePhoto", "about", "status", "readReceipts", "typingIndicators", "silenceUnknownCallers"];
  const updates = Object.fromEntries(Object.entries(req.body).filter(([key]) => allowed.includes(key)));
  const settings = await PrivacySetting.findOneAndUpdate({ user: req.user._id }, { $set: updates, $setOnInsert: { user: req.user._id } }, { upsert: true, new: true, runValidators: true });
  return response(res, 200, "Privacy settings updated", { settings });
};

exports.listBlocks = async (req, res) => response(res, 200, "Blocked contacts loaded", { blocks: await ContactBlock.find({ blocker: req.user._id }).populate("blocked", "username profilePicture about") });

exports.blockContact = async (req, res) => {
  const blocked = validId(req.body.userId);
  if (!blocked || String(blocked) === String(req.user._id)) return response(res, 400, "A valid different userId is required");
  const block = await ContactBlock.findOneAndUpdate({ blocker: req.user._id, blocked }, { reason: req.body.reason, reported: Boolean(req.body.reported) }, { upsert: true, new: true, setDefaultsOnInsert: true });
  return response(res, 201, "Contact blocked", { block });
};

exports.unblockContact = async (req, res) => {
  const blocked = validId(req.params.userId);
  if (!blocked) return response(res, 400, "Invalid user id");
  await ContactBlock.deleteOne({ blocker: req.user._id, blocked });
  return response(res, 200, "Contact unblocked");
};

exports.changePassword = async (req, res) => {
  if (!req.body.currentPassword || !req.body.newPassword || req.body.newPassword.length < 8) return response(res, 400, "Current password and a new password of at least 8 characters are required");
  const user = await User.findById(req.user._id).select("+password");
  if (!user?.password || !(await bcrypt.compare(req.body.currentPassword, user.password))) return response(res, 401, "Current password is incorrect");
  user.password = await bcrypt.hash(req.body.newPassword, 12);
  await user.save();
  return response(res, 200, "Password changed successfully");
};

exports.deleteAccount = async (req, res) => {
  if (req.body.confirmation !== "DELETE") return response(res, 400, "Type DELETE to confirm account deletion");
  const Conversation = require("../models/Conversation");
  const Message = require("../models/Message");
  const Status = require("../models/Status");
  const DeviceSession = require("../models/DeviceSession");
  const Notification = require("../models/Notification");
  await User.findByIdAndDelete(req.user._id);
  const conversations = await Conversation.find({ participants: req.user._id }).select("_id");
  await Message.deleteMany({ $or: [{ sender: req.user._id }, { conversation: { $in: conversations.map((item) => item._id) } }] });
  await Conversation.updateMany({ participants: req.user._id }, { $pull: { participants: req.user._id, admins: req.user._id } });
  await Status.deleteMany({ author: req.user._id });
  await DeviceSession.deleteMany({ user: req.user._id });
  await Notification.deleteMany({ $or: [{ recipient: req.user._id }, { actor: req.user._id }] });
  await PrivacySetting.deleteOne({ user: req.user._id });
  await ContactBlock.deleteMany({ $or: [{ blocker: req.user._id }, { blocked: req.user._id }] });
  res.clearCookie("auth_token");
  return response(res, 200, "Account deleted");
};


exports.exportAccountData = async (req, res) => {
  const Conversation = require("../models/Conversation");
  const Message = require("../models/Message");
  const Status = require("../models/Status");
  const Notification = require("../models/Notification");
  const [user, conversations, messages, statuses, notifications] = await Promise.all([
    User.findById(req.user._id).select("-password -emailOtp -emailOtpExpiry -phoneOtp -phoneOtpExpiry -passwordResetToken -passwordResetExpiry").lean(),
    Conversation.find({ participants: req.user._id }).lean(),
    Message.find({ sender: req.user._id }).lean(),
    Status.find({ author: req.user._id }).lean(),
    Notification.find({ recipient: req.user._id }).lean(),
  ]);
  res.setHeader("Content-Disposition", `attachment; filename=varnox-account-${req.user._id}.json`);
  return res.status(200).json({ exportedAt: new Date().toISOString(), user, conversations, messages, statuses, notifications });
};


exports.listSecurityEvents = async (req, res) => {
  const SecurityEvent = require("../models/SecurityEvent");
  return response(res, 200, "Security events loaded", { events: await SecurityEvent.find({ user: req.user._id }).sort({ createdAt: -1 }).limit(100).lean() });
};
