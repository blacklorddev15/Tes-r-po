const mongoose = require("mongoose");
const Community = require("../models/Community");
const Channel = require("../models/Channel");
const ChannelPost = require("../models/ChannelPost");
const BroadcastList = require("../models/BroadcastList");
const response = require("../utils/responseHandler");
const validId = (value) => mongoose.Types.ObjectId.isValid(value) ? value : null;

exports.createCommunity = async (req, res) => {
  if (!req.body.name?.trim()) return response(res, 400, "Community name is required");
  const community = await Community.create({ name: req.body.name.trim(), description: req.body.description, icon: req.body.icon, owner: req.user._id, admins: [req.user._id], members: [req.user._id] });
  return response(res, 201, "Community created", { community });
};
exports.listCommunities = async (req, res) => response(res, 200, "Communities loaded", { communities: await Community.find({ members: req.user._id }).sort({ updatedAt: -1 }) });
exports.createTopicGroup = async (req, res) => {
  const communityId = validId(req.params.communityId);
  if (!communityId || !req.body.name?.trim()) return response(res, 400, "Community and topic name are required");
  const community = await Community.findOne({ _id: communityId, members: req.user._id });
  if (!community) return response(res, 404, "Community not found");
  const Conversation = require("../models/Conversation");
  const topic = await Conversation.create({ kind: "group", title: req.body.name.trim(), description: req.body.description, participants: [req.user._id], admins: [req.user._id], createdBy: req.user._id });
  community.topicGroups.push(topic._id); await community.save();
  return response(res, 201, "Topic group created", { topic });
};
exports.createChannel = async (req, res) => {
  if (!req.body.name?.trim() || !req.body.handle?.trim()) return response(res, 400, "Channel name and handle are required");
  const channel = await Channel.create({ name: req.body.name.trim(), handle: req.body.handle.replace(/^@/, "").trim(), description: req.body.description, icon: req.body.icon, category: req.body.category, owner: req.user._id, admins: [req.user._id], followers: [req.user._id] });
  return response(res, 201, "Channel created", { channel });
};
exports.discoverChannels = async (req, res) => {
  const query = String(req.query.search || "").trim();
  const filter = { discoverable: true, moderation: { $ne: "blocked" }, ...(query ? { $or: [{ name: new RegExp(query, "i") }, { handle: new RegExp(query, "i") }, { description: new RegExp(query, "i") }] } : {}) };
  return response(res, 200, "Channels discovered", { channels: await Channel.find(filter).sort({ followers: -1, updatedAt: -1 }).limit(100) });
};
exports.followChannel = async (req, res) => { const channel = await Channel.findByIdAndUpdate(req.params.channelId, { $addToSet: { followers: req.user._id } }, { new: true }); return channel ? response(res, 200, "Channel followed", { channel }) : response(res, 404, "Channel not found"); };
exports.unfollowChannel = async (req, res) => { const channel = await Channel.findByIdAndUpdate(req.params.channelId, { $pull: { followers: req.user._id } }, { new: true }); return channel ? response(res, 200, "Channel unfollowed", { channel }) : response(res, 404, "Channel not found"); };
exports.createPost = async (req, res) => {
  const channel = await Channel.findOne({ _id: req.params.channelId, admins: req.user._id });
  if (!channel) return response(res, 403, "Only channel admins can publish");
  const post = await ChannelPost.create({ channel: channel._id, author: req.user._id, text: req.body.text, media: req.body.media, poll: req.body.poll, moderation: { status: channel.moderation === "review" ? "review" : "clear" } });
  return response(res, 201, "Channel post created", { post });
};
exports.listPosts = async (req, res) => response(res, 200, "Channel posts loaded", { posts: await ChannelPost.find({ channel: req.params.channelId, "moderation.status": { $ne: "blocked" } }).sort({ createdAt: -1 }).limit(100) });
exports.reactToPost = async (req, res) => { const post = await ChannelPost.findById(req.params.postId); if (!post) return response(res, 404, "Post not found"); post.reactions = post.reactions.filter((reaction) => String(reaction.user) !== String(req.user._id)); post.reactions.push({ user: req.user._id, emoji: String(req.body.emoji || "❤️").slice(0, 16) }); await post.save(); return response(res, 200, "Post reaction updated", { reactions: post.reactions }); };
exports.moderatePost = async (req, res) => { const post = await ChannelPost.findById(req.params.postId).populate("channel"); if (!post || !post.channel.admins.some((id) => String(id) === String(req.user._id))) return response(res, 403, "Only channel admins can moderate"); post.moderation = { status: req.body.status === "blocked" ? "blocked" : "clear", reviewedBy: req.user._id }; await post.save(); return response(res, 200, "Post moderation updated", { post }); };
exports.createBroadcast = async (req, res) => { if (!req.body.name?.trim()) return response(res, 400, "Broadcast name is required"); const list = await BroadcastList.create({ owner: req.user._id, name: req.body.name.trim(), recipients: (req.body.recipientIds || []).filter(validId) }); return response(res, 201, "Broadcast list created", { list }); };
exports.listBroadcasts = async (req, res) => response(res, 200, "Broadcast lists loaded", { lists: await BroadcastList.find({ owner: req.user._id }).populate("recipients", "username profilePicture") });
exports.sendBroadcast = async (req, res) => { const list = await BroadcastList.findOne({ _id: req.params.listId, owner: req.user._id }); if (!list) return response(res, 404, "Broadcast list not found"); const sentAt = new Date(); list.lastMessage = req.body.text; list.deliveries = list.recipients.map((recipient) => ({ recipient, sentAt })); await list.save(); return response(res, 201, "Broadcast queued", { list }); };
exports.markBroadcastRead = async (req, res) => { const list = await BroadcastList.findById(req.params.listId); if (!list) return response(res, 404, "Broadcast list not found"); const delivery = list.deliveries.find((item) => String(item.recipient) === String(req.user._id)); if (delivery) { delivery.readAt = new Date(); await list.save(); } return response(res, 200, "Broadcast marked read"); };
