const mongoose = require("mongoose");
const Conversation = require("../models/Conversation");
const GroupMember = require("../models/GroupMember");
const response = require("../utils/responseHandler");
const validId = (value) => mongoose.Types.ObjectId.isValid(value) ? value : null;

const adminMembership = (conversationId, userId) => GroupMember.findOne({ conversation: conversationId, user: userId, status: "active", role: { $in: ["owner", "admin"] } });

exports.getMembers = async (req, res) => {
  const conversationId = validId(req.params.conversationId);
  if (!conversationId) return response(res, 400, "Invalid conversation id");
  const access = await GroupMember.findOne({ conversation: conversationId, user: req.user._id, status: "active" });
  if (!access) return response(res, 403, "You are not a group member");
  return response(res, 200, "Group members loaded", { members: await GroupMember.find({ conversation: conversationId, status: { $ne: "removed" } }).populate("user", "username profilePicture about isOnline lastSeen") });
};

exports.addMember = async (req, res) => {
  const conversationId = validId(req.params.conversationId);
  const memberId = validId(req.body.userId);
  if (!conversationId || !memberId) return response(res, 400, "Valid conversation and user ids are required");
  if (!(await adminMembership(conversationId, req.user._id))) return response(res, 403, "Only group admins can add members");
  await Conversation.updateOne({ _id: conversationId, kind: "group" }, { $addToSet: { participants: memberId } });
  const member = await GroupMember.findOneAndUpdate({ conversation: conversationId, user: memberId }, { status: "active" }, { upsert: true, new: true, setDefaultsOnInsert: true });
  return response(res, 201, "Member added", { member });
};

exports.removeMember = async (req, res) => {
  const conversationId = validId(req.params.conversationId);
  const memberId = validId(req.params.userId);
  if (!conversationId || !memberId) return response(res, 400, "Valid conversation and user ids are required");
  if (!(await adminMembership(conversationId, req.user._id))) return response(res, 403, "Only group admins can remove members");
  await Conversation.updateOne({ _id: conversationId }, { $pull: { participants: memberId, admins: memberId } });
  const member = await GroupMember.findOneAndUpdate({ conversation: conversationId, user: memberId }, { status: "removed" }, { new: true });
  return response(res, 200, "Member removed", { member });
};

exports.leaveGroup = async (req, res) => {
  const conversationId = validId(req.params.conversationId);
  if (!conversationId) return response(res, 400, "Invalid conversation id");
  await Conversation.updateOne({ _id: conversationId }, { $pull: { participants: req.user._id, admins: req.user._id } });
  await GroupMember.updateOne({ conversation: conversationId, user: req.user._id }, { status: "left" });
  return response(res, 200, "You left the group");
};

exports.updateGroup = async (req, res) => {
  const conversationId = validId(req.params.conversationId);
  if (!conversationId) return response(res, 400, "Invalid conversation id");
  if (!(await adminMembership(conversationId, req.user._id))) return response(res, 403, "Only group admins can edit group information");
  const updates = Object.fromEntries(Object.entries(req.body).filter(([key]) => ["title", "icon", "description"].includes(key)));
  const conversation = await Conversation.findOneAndUpdate({ _id: conversationId, kind: "group" }, { $set: updates }, { new: true });
  return response(res, 200, "Group updated", { conversation });
};
