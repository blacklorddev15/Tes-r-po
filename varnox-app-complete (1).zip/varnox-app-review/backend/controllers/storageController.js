const mongoose = require("mongoose");
const crypto = require("crypto");
const ChatBackup = require("../models/ChatBackup");
const MediaAsset = require("../models/MediaAsset");
const MediaPreference = require("../models/MediaPreference");
const Conversation = require("../models/Conversation");
const Message = require("../models/Message");
const response = require("../utils/responseHandler");
const validId = (value) => mongoose.Types.ObjectId.isValid(value) ? value : null;

exports.exportChat = async (req, res) => {
  const conversation = validId(req.params.conversationId);
  if (!conversation) return response(res, 400, "Invalid conversation id");
  const access = await Conversation.findOne({ _id: conversation, participants: req.user._id }).lean();
  if (!access) return response(res, 404, "Conversation not found");
  const messages = await Message.find({ conversation }).sort({ createdAt: 1 }).lean();
  res.setHeader("Content-Disposition", `attachment; filename=varnox-chat-${conversation}.json`);
  return res.status(200).json({ exportedAt: new Date().toISOString(), conversation: access, messages });
};
exports.createBackup = async (req, res) => {
  const conversation = req.body.conversationId ? validId(req.body.conversationId) : null;
  const filter = conversation ? { conversation, sender: req.user._id } : { sender: req.user._id };
  const messages = await Message.find(filter).lean();
  const payload = JSON.stringify({ createdAt: new Date().toISOString(), messages });
  const backup = await ChatBackup.create({ user: req.user._id, scope: conversation ? "conversation" : "all", conversation, checksum: crypto.createHash("sha256").update(payload).digest("hex"), size: Buffer.byteLength(payload), encrypted: true });
  return response(res, 201, "Backup created", { backup, payload });
};
exports.listBackups = async (req, res) => response(res, 200, "Backups loaded", { backups: await ChatBackup.find({ user: req.user._id }).sort({ createdAt: -1 }).limit(50) });
exports.restoreBackup = async (req, res) => { if (!Array.isArray(req.body.messages)) return response(res, 400, "Backup messages are required"); const allowed = req.body.messages.filter((item) => item.conversationId && (item.text || item.media)).slice(0, 5000); return response(res, 200, "Backup validated for restore", { messageCount: allowed.length, note: "Restore requires destination conversation membership and is ready for a background import job." }); };
exports.storageUsage = async (req, res) => { const assets = await MediaAsset.find({ owner: req.user._id, deletedAt: { $exists: false } }).lean(); const byType = assets.reduce((all, asset) => { const type = asset.mimeType?.split("/")[0] || "other"; all[type] = (all[type] || 0) + asset.size; return all; }, {}); return response(res, 200, "Storage usage loaded", { totalBytes: assets.reduce((sum, asset) => sum + (asset.size || 0), 0), assetCount: assets.length, byType, largeFiles: assets.filter((asset) => asset.size > 10 * 1024 * 1024).sort((a, b) => b.size - a.size).slice(0, 100) }); };
exports.gallery = async (req, res) => response(res, 200, "Media gallery loaded", { assets: await MediaAsset.find({ owner: req.user._id, deletedAt: { $exists: false }, mimeType: { $regex: /^(image|video)\// } }).sort({ createdAt: -1 }).limit(500) });
exports.cleanupLarge = async (req, res) => { const maxBytes = Math.max(1, Number(req.body.maxBytes) || 10 * 1024 * 1024); const result = await MediaAsset.updateMany({ owner: req.user._id, size: { $gt: maxBytes }, deletedAt: { $exists: false } }, { $set: { deletedAt: new Date() } }); return response(res, 200, "Large media marked for cleanup", { deletedCount: result.modifiedCount }); };
exports.cleanupDuplicates = async (req, res) => { const assets = await MediaAsset.find({ owner: req.user._id, deletedAt: { $exists: false } }).sort({ createdAt: 1 }); const seen = new Set(); const duplicateIds = []; for (const asset of assets) { if (!asset.checksum || !seen.has(asset.checksum)) { if (asset.checksum) seen.add(asset.checksum); } else duplicateIds.push(asset._id); } const result = await MediaAsset.updateMany({ _id: { $in: duplicateIds } }, { $set: { deletedAt: new Date() } }); return response(res, 200, "Duplicate media marked for cleanup", { deletedCount: result.modifiedCount }); };
exports.getPreferences = async (req, res) => { const preferences = await MediaPreference.findOneAndUpdate({ user: req.user._id }, { $setOnInsert: { user: req.user._id } }, { upsert: true, new: true }); return response(res, 200, "Media preferences loaded", { preferences }); };
exports.updatePreferences = async (req, res) => { const allowed = ["autoDownloadImages", "autoDownloadVideos", "autoDownloadAudio", "autoDownloadDocuments", "compression", "saveToGallery"]; const updates = Object.fromEntries(Object.entries(req.body).filter(([key]) => allowed.includes(key))); const preferences = await MediaPreference.findOneAndUpdate({ user: req.user._id }, { $set: updates, $setOnInsert: { user: req.user._id } }, { upsert: true, new: true }); return response(res, 200, "Media preferences updated", { preferences }); };
