const mongoose = require("mongoose");
const Conversation = require("../models/Conversation");
const Message = require("../models/Message");
const Status = require("../models/Status");
const GroupMember = require("../models/GroupMember");
const DeviceSession = require("../models/DeviceSession");
const response = require("../utils/responseHandler");
const { createNotification } = require("../services/notificationService");

const id = (value) => mongoose.Types.ObjectId.isValid(value) ? value : null;
const userId = (req) => req.user._id;

exports.listConversations = async (req, res) => {
  try {
    const conversations = await Conversation.find({ participants: userId(req) })
      .populate("participants", "username profilePicture about isOnline lastSeen")
      .populate("lastMessage")
      .sort({ updatedAt: -1 }).lean();
    return response(res, 200, "Conversations loaded", { conversations });
  } catch (error) { return response(res, 500, "Failed to load conversations", { error: error.message }); }
};

exports.createDirectConversation = async (req, res) => {
  const participant = id(req.body.participantId);
  if (!participant) return response(res, 400, "A valid participantId is required");
  if (String(participant) === String(userId(req))) return response(res, 400, "You cannot start a conversation with yourself");
  try {
    let conversation = await Conversation.findOne({ kind: "direct", participants: { $all: [userId(req), participant] }, $expr: { $eq: [{ $size: "$participants" }, 2] } });
    if (!conversation) conversation = await Conversation.create({ kind: "direct", participants: [userId(req), participant], createdBy: userId(req) });
    return response(res, 200, "Conversation ready", { conversation });
  } catch (error) { return response(res, 500, "Failed to create conversation", { error: error.message }); }
};

exports.listMessages = async (req, res) => {
  const conversationId = id(req.params.conversationId);
  if (!conversationId) return response(res, 400, "Invalid conversation id");
  try {
    const conversation = await Conversation.findOne({ _id: conversationId, participants: userId(req) });
    if (!conversation) return response(res, 404, "Conversation not found");
    const messages = await Message.find({ conversation: conversationId, deletedForEveryoneAt: { $exists: false }, deletedFor: { $ne: userId(req) } }).populate("sender", "username profilePicture").sort({ createdAt: 1 }).limit(500).lean();
    return response(res, 200, "Messages loaded", { messages });
  } catch (error) { return response(res, 500, "Failed to load messages", { error: error.message }); }
};

exports.sendMessage = async (req, res) => {
  const conversationId = id(req.body.conversationId);
  if (!conversationId) return response(res, 400, "A valid conversationId is required");
  if (!req.body.text && !req.body.media && !req.body.location && !req.body.contactCard) return response(res, 400, "Message content is required");
  try {
    const conversation = await Conversation.findOne({ _id: conversationId, participants: userId(req) });
    if (!conversation) return response(res, 404, "Conversation not found");
    const message = await Message.create({ conversation: conversationId, sender: userId(req), text: req.body.text, contentType: req.body.contentType || "text", media: req.body.media, location: req.body.location, contactCard: req.body.contactCard, replyTo: id(req.body.replyTo), mentions: (req.body.mentions || []).filter(id) });
    conversation.lastMessage = message._id;
    await conversation.save();
    await Promise.all(conversation.participants.filter((participant) => String(participant) !== String(userId(req))).map((participant) => createNotification({ recipient: participant, actor: userId(req), type: "message", title: "New message", body: message.text || `New ${message.contentType} message`, conversation: conversation._id, message: message._id })));
    const populated = await Message.findById(message._id).populate("sender", "username profilePicture");
    return response(res, 201, "Message sent", { message: populated });
  } catch (error) { return response(res, 500, "Failed to send message", { error: error.message }); }
};

exports.updateMessage = async (req, res) => {
  const messageId = id(req.params.messageId);
  if (!messageId) return response(res, 400, "Invalid message id");
  try {
    const message = await Message.findOne({ _id: messageId, sender: userId(req) });
    if (!message) return response(res, 404, "Message not found or not owned by you");
    if (req.body.action === "delete-for-everyone") message.deletedForEveryoneAt = new Date();
    else if (req.body.action === "delete-for-me") message.deletedFor.push(userId(req));
    else if (req.body.action === "star") message.starredBy.addToSet(userId(req));
    else if (req.body.action === "pin") message.pinnedBy.addToSet(userId(req));
    else if (req.body.text !== undefined) { message.text = req.body.text; message.editedAt = new Date(); }
    else return response(res, 400, "Unsupported message action");
    await message.save();
    return response(res, 200, "Message updated", { message });
  } catch (error) { return response(res, 500, "Failed to update message", { error: error.message }); }
};

exports.reactToMessage = async (req, res) => {
  const messageId = id(req.params.messageId);
  if (!messageId || !req.body.emoji) return response(res, 400, "Message id and emoji are required");
  try {
    const message = await Message.findById(messageId);
    if (!message) return response(res, 404, "Message not found");
    message.reactions = message.reactions.filter((reaction) => String(reaction.user) !== String(userId(req)));
    message.reactions.push({ user: userId(req), emoji: String(req.body.emoji).slice(0, 16) });
    await message.save();
    return response(res, 200, "Reaction updated", { reactions: message.reactions });
  } catch (error) { return response(res, 500, "Failed to react to message", { error: error.message }); }
};

exports.createStatus = async (req, res) => {
  if (!req.body.text && !req.body.media) return response(res, 400, "Status content is required");
  try {
    const status = await Status.create({ author: userId(req), contentType: req.body.contentType || "text", text: req.body.text, media: req.body.media, visibility: req.body.visibility || "all", allowedViewers: (req.body.allowedViewers || []).filter(id), excludedViewers: (req.body.excludedViewers || []).filter(id), mentions: (req.body.mentions || []).filter(id), expiresAt: new Date(Date.now() + 86400000) });
    return response(res, 201, "Status created", { status });
  } catch (error) { return response(res, 500, "Failed to create status", { error: error.message }); }
};

exports.listStatuses = async (req, res) => {
  try {
    const statuses = await Status.find({ expiresAt: { $gt: new Date() } }).populate("author", "username profilePicture").sort({ createdAt: -1 }).lean();
    return response(res, 200, "Statuses loaded", { statuses });
  } catch (error) { return response(res, 500, "Failed to load statuses", { error: error.message }); }
};

exports.viewStatus = async (req, res) => {
  const statusId = id(req.params.statusId);
  if (!statusId) return response(res, 400, "Invalid status id");
  try {
    const status = await Status.findById(statusId);
    if (!status) return response(res, 404, "Status not found");
    status.viewers = status.viewers.filter((viewer) => String(viewer.user) !== String(userId(req)));
    status.viewers.push({ user: userId(req), viewedAt: new Date() });
    await status.save();
    return response(res, 200, "Status viewed", { viewedAt: new Date() });
  } catch (error) { return response(res, 500, "Failed to record status view", { error: error.message }); }
};

exports.createGroup = async (req, res) => {
  const members = [...new Set([String(userId(req)), ...(req.body.memberIds || []).filter(id).map(String)])].map((value) => new mongoose.Types.ObjectId(value));
  if (!req.body.title?.trim()) return response(res, 400, "Group name is required");
  try {
    const conversation = await Conversation.create({ kind: "group", title: req.body.title.trim(), icon: req.body.icon, description: req.body.description, participants: members, admins: [userId(req)], createdBy: userId(req) });
    await GroupMember.insertMany(members.map((member) => ({ conversation: conversation._id, user: member, role: String(member) === String(userId(req)) ? "owner" : "member", canEditInfo: String(member) === String(userId(req)), canAddMembers: String(member) === String(userId(req)) })));
    return response(res, 201, "Group created", { conversation });
  } catch (error) { return response(res, 500, "Failed to create group", { error: error.message }); }
};

exports.listDevices = async (req, res) => {
  const devices = await DeviceSession.find({ user: userId(req), revokedAt: { $exists: false } }).sort({ lastActiveAt: -1 }).lean();
  return response(res, 200, "Devices loaded", { devices });
};

exports.revokeDevice = async (req, res) => {
  const deviceId = id(req.params.deviceId);
  if (!deviceId) return response(res, 400, "Invalid device id");
  const device = await DeviceSession.findOneAndUpdate({ _id: deviceId, user: userId(req) }, { revokedAt: new Date() }, { new: true });
  if (!device) return response(res, 404, "Device not found");
  return response(res, 200, "Device logged out", { device });
};

exports.markMessageRead = async (req, res) => {
  const messageId = id(req.params.messageId);
  if (!messageId) return response(res, 400, "Invalid message id");
  try {
    const message = await Message.findById(messageId);
    if (!message) return response(res, 404, "Message not found");
    const existing = message.delivery.find((entry) => String(entry.user) === String(userId(req)));
    if (existing) existing.readAt = new Date();
    else message.delivery.push({ user: userId(req), deliveredAt: new Date(), readAt: new Date() });
    await message.save();
    return response(res, 200, "Message marked as read", { messageId, readAt: new Date() });
  } catch (error) { return response(res, 500, "Failed to mark message read", { error: error.message }); }
};


exports.forwardMessage = async (req, res) => {
  const messageId = id(req.params.messageId);
  const conversationId = id(req.body.conversationId);
  if (!messageId || !conversationId) return response(res, 400, "Message and destination conversation ids are required");
  try {
    const source = await Message.findById(messageId);
    const destination = await Conversation.findOne({ _id: conversationId, participants: userId(req) });
    if (!source || !destination) return response(res, 404, "Message or destination conversation not found");
    const forwarded = await Message.create({ conversation: conversationId, sender: userId(req), text: source.text, contentType: source.contentType, media: source.media, location: source.location, contactCard: source.contactCard, forwardedFrom: source._id });
    destination.lastMessage = forwarded._id;
    await destination.save();
    return response(res, 201, "Message forwarded", { message: forwarded });
  } catch (error) { return response(res, 500, "Failed to forward message", { error: error.message }); }
};
