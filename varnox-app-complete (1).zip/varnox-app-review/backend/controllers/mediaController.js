const crypto = require("crypto");
const { uploadOnCloudinary } = require("../config/cloudinaryConfig");
const response = require("../utils/responseHandler");
const MediaAsset = require("../models/MediaAsset");

const contentTypeFor = (mime = "") => {
  if (mime.startsWith("image/")) return "image";
  if (mime.startsWith("video/")) return "video";
  if (mime.startsWith("audio/")) return "audio";
  return "document";
};

exports.uploadMedia = async (req, res) => {
  if (!req.file) return response(res, 400, "A media file is required");
  try {
    const result = await uploadOnCloudinary(req.file);
    if (!result?.secure_url) return response(res, 502, "Media provider did not return a usable URL");
    const media = {
        url: result.secure_url,
        publicId: result.public_id,
        resourceType: result.resource_type,
        name: req.file.originalname,
        mimeType: req.file.mimetype,
        size: req.file.size,
        checksum: crypto.createHash("sha256").update(req.file.buffer).digest("hex"),
        contentType: contentTypeFor(req.file.mimetype),
      };
    await MediaAsset.create({ owner: req.user._id, url: media.url, publicId: media.publicId, name: media.name, mimeType: media.mimeType, size: media.size, checksum: media.checksum });
    return response(res, 201, "Media uploaded", { media });
  } catch (error) {
    return response(res, 502, "Media upload failed", { error: error.message });
  }
};
