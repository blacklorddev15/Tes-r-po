const mongoose = require("mongoose");
const Notification = require("../models/Notification");
const NotificationPreference = require("../models/NotificationPreference");
const response = require("../utils/responseHandler");
const validId = (value) => mongoose.Types.ObjectId.isValid(value) ? value : null;

exports.listNotifications = async (req, res) => {
  const limit = Math.min(Number(req.query.limit) || 50, 100);
  const notifications = await Notification.find({ recipient: req.user._id }).populate("actor", "username profilePicture").sort({ createdAt: -1 }).limit(limit).lean();
  const unreadCount = await Notification.countDocuments({ recipient: req.user._id, readAt: { $exists: false }, muted: false });
  return response(res, 200, "Notifications loaded", { notifications, unreadCount });
};
exports.markRead = async (req, res) => { const notificationId = validId(req.params.notificationId); if (!notificationId) return response(res, 400, "Invalid notification id"); await Notification.updateOne({ _id: notificationId, recipient: req.user._id }, { $set: { readAt: new Date() } }); return response(res, 200, "Notification marked read"); };
exports.markAllRead = async (req, res) => { await Notification.updateMany({ recipient: req.user._id, readAt: { $exists: false } }, { $set: { readAt: new Date() } }); return response(res, 200, "Notifications marked read"); };
exports.getPreferences = async (req, res) => { const preferences = await NotificationPreference.findOneAndUpdate({ user: req.user._id }, { $setOnInsert: { user: req.user._id } }, { upsert: true, new: true }); return response(res, 200, "Notification preferences loaded", { preferences }); };
exports.updatePreferences = async (req, res) => { const allowed = ["browserEnabled", "pushEnabled", "messageAlerts", "mentionAlerts", "replyAlerts", "reactionAlerts", "statusAlerts", "callAlerts", "groupAlerts"]; const updates = Object.fromEntries(Object.entries(req.body).filter(([key]) => allowed.includes(key))); const preferences = await NotificationPreference.findOneAndUpdate({ user: req.user._id }, { $set: updates, $setOnInsert: { user: req.user._id } }, { upsert: true, new: true }); return response(res, 200, "Notification preferences updated", { preferences }); };
exports.muteConversation = async (req, res) => { const conversation = validId(req.params.conversationId); if (!conversation) return response(res, 400, "Invalid conversation id"); const until = req.body.until ? new Date(req.body.until) : null; const preferences = await NotificationPreference.findOneAndUpdate({ user: req.user._id }, { $setOnInsert: { user: req.user._id }, $pull: { mutedConversations: { conversation } } }, { upsert: true, new: true }); preferences.mutedConversations.push({ conversation, until }); await preferences.save(); return response(res, 200, "Conversation muted", { preferences }); };
exports.unmuteConversation = async (req, res) => { const conversation = validId(req.params.conversationId); if (!conversation) return response(res, 400, "Invalid conversation id"); const preferences = await NotificationPreference.findOneAndUpdate({ user: req.user._id }, { $pull: { mutedConversations: { conversation } } }, { new: true }); return response(res, 200, "Conversation unmuted", { preferences }); };
