const jwt = require("jsonwebtoken");
const User = require("../models/User");

const parseCookies = (header = "") => Object.fromEntries(header.split(";").map((part) => part.trim().split("=")).filter(([key, value]) => key && value).map(([key, value]) => [key, decodeURIComponent(value)]));

function initializeSocket(server) {
  const { Server } = require("socket.io");
  const io = new Server(server, {
    cors: {
      origin: process.env.FRONTEND_URL || process.env.PUBLIC_WEB_URL || "http://localhost:5173",
      credentials: true,
    },
    transports: ["websocket", "polling"],
  });
  const onlineUsers = new Map();

  io.use(async (socket, next) => {
    try {
      const cookies = parseCookies(socket.handshake.headers.cookie || "");
      const token = cookies.auth_token || socket.handshake.auth?.token;
      if (!token) return next(new Error("Unauthorized"));
      const decoded = jwt.verify(token, process.env.JWT_SECRET || "default_jwt_secret_key");
      const user = await User.findById(decoded.userId).select("_id username profilePicture");
      if (!user) return next(new Error("Unauthorized"));
      socket.user = user;
      next();
    } catch { next(new Error("Unauthorized")); }
  });

  io.on("connection", async (socket) => {
    const uid = String(socket.user._id);
    const set = onlineUsers.get(uid) || new Set();
    set.add(socket.id);
    onlineUsers.set(uid, set);
    await User.findByIdAndUpdate(uid, { isOnline: true, lastSeen: new Date() });
    io.emit("presence:update", { userId: uid, isOnline: true, lastSeen: new Date().toISOString() });

    socket.on("conversation:join", (conversationId) => {
      if (conversationId) socket.join(`conversation:${conversationId}`);
    });
    socket.on("conversation:leave", (conversationId) => {
      if (conversationId) socket.leave(`conversation:${conversationId}`);
    });
    socket.on("typing:start", ({ conversationId }) => {
      if (conversationId) socket.to(`conversation:${conversationId}`).emit("typing:update", { conversationId, userId: uid, isTyping: true });
    });
    socket.on("typing:stop", ({ conversationId }) => {
      if (conversationId) socket.to(`conversation:${conversationId}`).emit("typing:update", { conversationId, userId: uid, isTyping: false });
    });
    socket.on("recording:start", ({ conversationId }) => {
      if (conversationId) socket.to(`conversation:${conversationId}`).emit("recording:update", { conversationId, userId: uid, isRecording: true });
    });
    socket.on("recording:stop", ({ conversationId }) => {
      if (conversationId) socket.to(`conversation:${conversationId}`).emit("recording:update", { conversationId, userId: uid, isRecording: false });
    });
    socket.on("message:created", ({ conversationId, message }) => {
      if (conversationId && message) socket.to(`conversation:${conversationId}`).emit("message:new", message);
    });
    socket.on("message:read", ({ conversationId, messageId }) => {
      if (conversationId && messageId) socket.to(`conversation:${conversationId}`).emit("message:read", { conversationId, messageId, userId: uid, readAt: new Date().toISOString() });
    });
    socket.on("call:signal", ({ peerUserId, signal }) => {
      const peers = onlineUsers.get(String(peerUserId)) || [];
      peers.forEach((peerSocketId) => io.to(peerSocketId).emit("call:signal", { fromUserId: uid, signal }));
    });
    socket.on("disconnect", async () => {
      const current = onlineUsers.get(uid);
      current?.delete(socket.id);
      if (!current?.size) {
        onlineUsers.delete(uid);
        const lastSeen = new Date();
        await User.findByIdAndUpdate(uid, { isOnline: false, lastSeen });
        io.emit("presence:update", { userId: uid, isOnline: false, lastSeen: lastSeen.toISOString() });
      }
    });
  });
  io.onlineUsers = onlineUsers;
  return io;
}

module.exports = { initializeSocket };
