const Notification = require("../models/Notification");
const NotificationPreference = require("../models/NotificationPreference");

async function createNotification({ recipient, actor, type, title, body, conversation, message, metadata }) {
  const preferences = await NotificationPreference.findOne({ user: recipient }).lean();
  const enabled = preferences?.[`${type}Alerts`] !== false;
  if (!enabled) return null;
  const muted = preferences?.mutedConversations?.some((item) => String(item.conversation) === String(conversation) && (!item.until || new Date(item.until) > new Date()));
  return Notification.create({ recipient, actor, type, title, body, conversation, message, metadata, muted: Boolean(muted) });
}

module.exports = { createNotification };
