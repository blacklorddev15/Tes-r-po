const response = require("../utils/responseHandler");
module.exports = (req, res, next) => { if (!req.user || !["admin", "moderator"].includes(req.user.role)) return response(res, 403, "Administrator or moderator access required"); next(); };
