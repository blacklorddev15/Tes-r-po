const mongoose = require("mongoose");

const channelSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 120 },
  handle: { type: String, required: true, unique: true, lowercase: true, index: true },
  description: { type: String, maxlength: 2000 },
  icon: String,
  owner: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  admins: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  followers: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  category: { type: String, index: true },
  discoverable: { type: Boolean, default: true },
  moderation: { type: String, enum: ["open", "review", "blocked"], default: "open" },
}, { timestamps: true });
module.exports = mongoose.models.Channel || mongoose.model("Channel", channelSchema);
