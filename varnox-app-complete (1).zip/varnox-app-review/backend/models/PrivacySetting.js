const mongoose = require("mongoose");

const privacySettingSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", unique: true, required: true },
  lastSeen: { type: String, enum: ["everyone", "contacts", "nobody"], default: "everyone" },
  online: { type: String, enum: ["everyone", "same-as-last-seen"], default: "everyone" },
  profilePhoto: { type: String, enum: ["everyone", "contacts", "nobody"], default: "everyone" },
  about: { type: String, enum: ["everyone", "contacts", "nobody"], default: "everyone" },
  status: { type: String, enum: ["everyone", "contacts", "nobody"], default: "contacts" },
  readReceipts: { type: Boolean, default: true },
  typingIndicators: { type: Boolean, default: true },
  silenceUnknownCallers: { type: Boolean, default: false },
}, { timestamps: true });

module.exports = mongoose.models.PrivacySetting || mongoose.model("PrivacySetting", privacySettingSchema);
