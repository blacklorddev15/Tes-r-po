const mongoose = require("mongoose");

const chatBackupSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  scope: { type: String, enum: ["all", "conversation"], default: "all" },
  conversation: { type: mongoose.Schema.Types.ObjectId, ref: "Conversation" },
  storageUrl: String,
  checksum: String,
  size: Number,
  encrypted: { type: Boolean, default: true },
  createdAt: { type: Date, default: Date.now },
}, { timestamps: true });
module.exports = mongoose.models.ChatBackup || mongoose.model("ChatBackup", chatBackupSchema);
