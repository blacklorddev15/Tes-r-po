const mongoose = require("mongoose");

const channelPostSchema = new mongoose.Schema({
  channel: { type: mongoose.Schema.Types.ObjectId, ref: "Channel", required: true, index: true },
  author: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  text: { type: String, maxlength: 65536 },
  media: { url: String, name: String, mimeType: String },
  poll: { question: String, options: [{ label: String, votes: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }] }], multiple: Boolean },
  reactions: [{ user: { type: mongoose.Schema.Types.ObjectId, ref: "User" }, emoji: String }],
  moderation: { status: { type: String, enum: ["clear", "review", "blocked"], default: "clear" }, reviewedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" } },
}, { timestamps: true });
module.exports = mongoose.models.ChannelPost || mongoose.model("ChannelPost", channelPostSchema);
