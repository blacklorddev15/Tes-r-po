const mongoose = require("mongoose");

const mediaPreferenceSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", unique: true, required: true },
  autoDownloadImages: { type: String, enum: ["always", "wifi", "never"], default: "wifi" },
  autoDownloadVideos: { type: String, enum: ["always", "wifi", "never"], default: "wifi" },
  autoDownloadAudio: { type: String, enum: ["always", "wifi", "never"], default: "wifi" },
  autoDownloadDocuments: { type: String, enum: ["always", "wifi", "never"], default: "never" },
  compression: { type: String, enum: ["data-saver", "standard", "original"], default: "standard" },
  saveToGallery: { type: Boolean, default: false },
}, { timestamps: true });
module.exports = mongoose.models.MediaPreference || mongoose.model("MediaPreference", mediaPreferenceSchema);
