const mongoose = require("mongoose");

const statusSchema = new mongoose.Schema({
  author: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  contentType: { type: String, enum: ["text", "image", "video", "gif", "audio"], default: "text" },
  text: { type: String, maxlength: 4096 },
  media: { url: String, mimeType: String, caption: String },
  visibility: { type: String, enum: ["all", "selected", "excluded"], default: "all" },
  allowedViewers: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  excludedViewers: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  viewers: [{ user: { type: mongoose.Schema.Types.ObjectId, ref: "User" }, viewedAt: Date, reaction: String }],
  mentions: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  expiresAt: { type: Date, index: true },
}, { timestamps: true });

statusSchema.index({ author: 1, createdAt: -1 });
statusSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });
module.exports = mongoose.models.Status || mongoose.model("Status", statusSchema);
