const mongoose = require("mongoose");

const mediaAssetSchema = new mongoose.Schema({
  owner: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  message: { type: mongoose.Schema.Types.ObjectId, ref: "Message" },
  url: { type: String, required: true },
  publicId: String,
  name: String,
  mimeType: String,
  size: { type: Number, default: 0 },
  checksum: { type: String, index: true },
  width: Number,
  height: Number,
  duration: Number,
  compressed: { type: Boolean, default: false },
  deletedAt: Date,
}, { timestamps: true });
mediaAssetSchema.index({ owner: 1, checksum: 1 });
module.exports = mongoose.models.MediaAsset || mongoose.model("MediaAsset", mediaAssetSchema);
