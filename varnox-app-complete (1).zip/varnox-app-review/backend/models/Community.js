const mongoose = require("mongoose");

const communitySchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 120 },
  description: { type: String, maxlength: 2000 },
  icon: String,
  owner: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  admins: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  members: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  announcementConversation: { type: mongoose.Schema.Types.ObjectId, ref: "Conversation" },
  topicGroups: [{ type: mongoose.Schema.Types.ObjectId, ref: "Conversation" }],
}, { timestamps: true });
module.exports = mongoose.models.Community || mongoose.model("Community", communitySchema);
