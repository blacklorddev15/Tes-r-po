const mongoose = require("mongoose");

const securityEventSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  type: { type: String, enum: ["login", "failed-login", "password-change", "password-reset", "device-linked", "device-revoked", "account-deleted"], required: true },
  ipAddress: String,
  userAgent: String,
  metadata: mongoose.Schema.Types.Mixed,
  suspicious: { type: Boolean, default: false },
}, { timestamps: true });
module.exports = mongoose.models.SecurityEvent || mongoose.model("SecurityEvent", securityEventSchema);
