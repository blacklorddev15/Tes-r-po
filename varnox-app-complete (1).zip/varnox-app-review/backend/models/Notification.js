const mongoose = require("mongoose");

const notificationSchema = new mongoose.Schema({
  recipient: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  actor: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  type: { type: String, enum: ["message", "mention", "reply", "reaction", "status", "call", "group", "channel", "system"], required: true },
  title: { type: String, maxlength: 160 },
  body: { type: String, maxlength: 500 },
  conversation: { type: mongoose.Schema.Types.ObjectId, ref: "Conversation" },
  message: { type: mongoose.Schema.Types.ObjectId, ref: "Message" },
  metadata: mongoose.Schema.Types.Mixed,
  readAt: Date,
  muted: { type: Boolean, default: false },
}, { timestamps: true });
notificationSchema.index({ recipient: 1, readAt: 1, createdAt: -1 });
module.exports = mongoose.models.Notification || mongoose.model("Notification", notificationSchema);
