const mongoose = require("mongoose");

const passkeySchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  credentialID: { type: Buffer, required: true, unique: true },
  publicKey: { type: Buffer, required: true },
  counter: { type: Number, default: 0 },
  transports: [String],
  deviceName: String,
  lastUsedAt: Date,
}, { timestamps: true });

module.exports = mongoose.models.Passkey || mongoose.model("Passkey", passkeySchema);
