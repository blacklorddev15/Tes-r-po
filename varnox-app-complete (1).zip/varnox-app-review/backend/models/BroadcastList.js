const mongoose = require("mongoose");

const broadcastListSchema = new mongoose.Schema({
  owner: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  name: { type: String, required: true, maxlength: 120 },
  recipients: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  lastMessage: String,
  deliveries: [{ recipient: { type: mongoose.Schema.Types.ObjectId, ref: "User" }, sentAt: Date, deliveredAt: Date, readAt: Date }],
}, { timestamps: true });
module.exports = mongoose.models.BroadcastList || mongoose.model("BroadcastList", broadcastListSchema);
