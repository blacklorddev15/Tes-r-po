const mongoose = require("mongoose");

const contactBlockSchema = new mongoose.Schema({
  blocker: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  blocked: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  reason: { type: String, maxlength: 500 },
  reported: { type: Boolean, default: false },
}, { timestamps: true });

contactBlockSchema.index({ blocker: 1, blocked: 1 }, { unique: true });
module.exports = mongoose.models.ContactBlock || mongoose.model("ContactBlock", contactBlockSchema);
