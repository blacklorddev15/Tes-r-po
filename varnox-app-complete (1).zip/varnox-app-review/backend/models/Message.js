const mongoose = require("mongoose");

const messageSchema = new mongoose.Schema({
  conversation: { type: mongoose.Schema.Types.ObjectId, ref: "Conversation", required: true, index: true },
  sender: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  text: { type: String, maxlength: 65536 },
  contentType: { type: String, enum: ["text", "image", "video", "audio", "document", "location", "contact", "poll", "event", "system"], default: "text" },
  media: { url: String, name: String, mimeType: String, size: Number, duration: Number, width: Number, height: Number, checksum: String },
  location: { latitude: Number, longitude: Number, label: String, liveUntil: Date },
  contactCard: { userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" }, displayName: String },
  replyTo: { type: mongoose.Schema.Types.ObjectId, ref: "Message" },
  forwardedFrom: { type: mongoose.Schema.Types.ObjectId, ref: "Message" },
  reactions: [{ user: { type: mongoose.Schema.Types.ObjectId, ref: "User" }, emoji: String }],
  mentions: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  delivery: [{ user: { type: mongoose.Schema.Types.ObjectId, ref: "User" }, deliveredAt: Date, readAt: Date }],
  editedAt: Date,
  deletedFor: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  deletedForEveryoneAt: Date,
  starredBy: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  pinnedBy: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  expiresAt: Date,
  moderation: { status: { type: String, enum: ["clear", "review", "blocked"], default: "clear" }, reviewedAt: Date },
}, { timestamps: true });

messageSchema.index({ conversation: 1, createdAt: -1 });
messageSchema.index({ text: "text" });
module.exports = mongoose.models.Message || mongoose.model("Message", messageSchema);
