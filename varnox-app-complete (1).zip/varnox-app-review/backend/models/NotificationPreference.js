const mongoose = require("mongoose");

const notificationPreferenceSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", unique: true, required: true },
  browserEnabled: { type: Boolean, default: true },
  pushEnabled: { type: Boolean, default: true },
  messageAlerts: { type: Boolean, default: true },
  mentionAlerts: { type: Boolean, default: true },
  replyAlerts: { type: Boolean, default: true },
  reactionAlerts: { type: Boolean, default: true },
  statusAlerts: { type: Boolean, default: true },
  callAlerts: { type: Boolean, default: true },
  groupAlerts: { type: Boolean, default: true },
  mutedConversations: [{ conversation: { type: mongoose.Schema.Types.ObjectId, ref: "Conversation" }, until: Date }],
}, { timestamps: true });
module.exports = mongoose.models.NotificationPreference || mongoose.model("NotificationPreference", notificationPreferenceSchema);
