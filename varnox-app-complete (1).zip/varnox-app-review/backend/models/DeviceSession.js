const mongoose = require("mongoose");

const deviceSessionSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  tokenHash: { type: String, required: true, unique: true },
  deviceName: String,
  platform: String,
  userAgent: String,
  ipAddress: String,
  lastActiveAt: { type: Date, default: Date.now },
  revokedAt: Date,
}, { timestamps: true });

module.exports = mongoose.models.DeviceSession || mongoose.model("DeviceSession", deviceSessionSchema);
