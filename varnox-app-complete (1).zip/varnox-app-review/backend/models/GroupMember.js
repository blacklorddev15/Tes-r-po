const mongoose = require("mongoose");

const groupMemberSchema = new mongoose.Schema({
  conversation: { type: mongoose.Schema.Types.ObjectId, ref: "Conversation", required: true, index: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  role: { type: String, enum: ["owner", "admin", "member"], default: "member" },
  status: { type: String, enum: ["active", "pending", "left", "removed"], default: "active" },
  canEditInfo: { type: Boolean, default: false },
  canSendMessages: { type: Boolean, default: true },
  canAddMembers: { type: Boolean, default: false },
  joinedAt: { type: Date, default: Date.now },
  mutedUntil: Date,
}, { timestamps: true });

groupMemberSchema.index({ conversation: 1, user: 1 }, { unique: true });
module.exports = mongoose.models.GroupMember || mongoose.model("GroupMember", groupMemberSchema);
