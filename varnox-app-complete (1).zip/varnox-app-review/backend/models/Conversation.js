const mongoose = require("mongoose");

const conversationSchema = new mongoose.Schema({
  kind: { type: String, enum: ["direct", "group"], default: "direct", index: true },
  title: { type: String, trim: true, maxlength: 120 },
  icon: String,
  description: { type: String, maxlength: 1024 },
  participants: [{ type: mongoose.Schema.Types.ObjectId, ref: "User", index: true }],
  admins: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  lastMessage: { type: mongoose.Schema.Types.ObjectId, ref: "Message" },
  archivedBy: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  pinnedBy: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  mutedBy: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  disappearingSeconds: { type: Number, default: null },
}, { timestamps: true });

conversationSchema.index({ participants: 1, updatedAt: -1 });
module.exports = mongoose.models.Conversation || mongoose.model("Conversation", conversationSchema);
