# BotDeck Pterodactyl Neon Worker

This package is an outbound-only worker for BotDeck. It polls hosting jobs and sends worker heartbeats/status updates to the private Neon Postgres database. It does not use Supabase or object storage. Its only inbound endpoint is the minimal `GET /health`; the website never calls the Pterodactyl worker directly, so no public worker API URL or tunnel is needed.

Supabase Auth remains in the separate website only. The trusted website verifies Supabase Auth sessions and uses its private Neon connection for application queries; the worker uses that same private Neon connection for job processing. Never place `DATABASE_URL` in browser code or a public repository.

## Requirements and setup

- Pterodactyl server/container running **Node.js 22 or newer**.
- `git` and npm in the container image. Python repositories also need `python3` and `python3-venv`.
- Persistent panel storage for the worker's local `data/` directory if local checkouts/logs should survive a restart of the same host.
- The private Neon `DATABASE_URL` and a stable `WORKER_ID`.

1. In Neon, run `neon/migrations/001_botdeck.sql` from the website ZIP **once** to initialize the database. Do not substitute a hand-created schema or rerun an edited one-shot schema over live data.
2. Set the same private Neon `DATABASE_URL` as a secret/environment variable in both the Vercel website and Pterodactyl worker. The website needs it for trusted server-side database access; the worker needs it to claim jobs and update status. Configure `WORKER_ID` in Pterodactyl, and use the same value when replacing the host. Configure values from `.env.example` through the Pterodactyl startup variables/secrets panel where possible, or use a private `.env` file that is never committed or published.
3. Create a Pterodactyl Node.js server with the required programs available, allocate a port for the health endpoint, and upload this package to its working directory.
4. Install the worker's own dependencies with `npm ci`, then set the Pterodactyl startup command to `npm start`.
5. Keep `ENABLE_REPO_EXECUTION=false` unless the host has deliberately accepted the risks described below and deployed a suitable per-repository isolation boundary.
6. The health endpoint listens on `PORT` (default `5000`). All other HTTP paths return 404.

Supabase Auth is website-only; do not configure a Supabase service-role key or Supabase Storage for the worker. There is no public API route to expose or tunnel to the worker.

## Job and data lifecycle

The worker uses one Neon client created from `neon(process.env.DATABASE_URL)` and calls the migration's `reconcile_worker`, `heartbeat_worker`, `claim_hosting_job`, `set_repository_status`, and `finish_hosting_job` functions. It reconciles its leases at startup, heartbeats every 30 seconds, and polls approximately every 3 seconds. Heartbeats extend active job leases while a job is running. Supported actions are `import`, `start`, `stop`, and `delete`.

The worker validates UUIDs and accepts only public GitHub HTTPS repository URLs without credentials, query strings, or fragments. Imports use a bounded shallow Git clone. A repository checkout lives locally under `data/repositories/<repository_uuid>`; local runtime logs are kept under `data/runtime-logs/`. Only a bounded UTF-8 log tail is saved in `public.repository_logs`; the migration caps `log_tail` at 65,536 bytes. The worker checks repository ownership when upserting the log row.

The public GitHub repository source is durable; working files are local to the host. The worker does not upload or download repository archives, and it does not preserve uncommitted local changes. Dependencies may be installed again when needed. Runtime processes and in-memory state are also local to the host.

## Host migration

The Vercel website and Neon database do not need a Pterodactyl URL. To move the worker:

1. Stop the old Pterodactyl worker first; do not run two live workers with the same `WORKER_ID`.
2. Deploy this package on the replacement server and configure the **same private `DATABASE_URL` and the same `WORKER_ID`**.
3. Start the replacement worker. It reconciles interrupted work, heartbeats to Neon, and claims queued jobs.
4. Local repository working copies, uncommitted files, local logs, and running processes do not transfer to the replacement host. On a new host, the next `import` or `start` job clones the public GitHub repository again. Running processes do not migrate; users must enqueue `start` again if they want a process launched on the new host. Operations remain queued while no worker is online.

## Repository runtimes and execution security

Repository code execution is **off by default**. The worker reports this setting in its database heartbeat, and only the literal `ENABLE_REPO_EXECUTION=true` enables Start jobs. With deliberate host opt-in, it supports:

- Node repositories with a `package.json` `scripts.start` entry. If runtime dependencies are declared and `node_modules/` is absent, it runs `npm ci --omit=dev --no-audit --no-fund` when a lockfile exists, otherwise `npm install --omit=dev --no-audit --no-fund`.
- Python repositories with `main.py`, `app.py`, or `bot.py`. If `requirements.txt` is present, it creates `.runtime-venv` and installs that file before starting the script.

Dependency managers may run package/build scripts. The install timeout is bounded by `MAX_DEPENDENCY_INSTALL_SECONDS` (default `600`). No repository-code install or execution happens while the global execution switch is false. Git clone, dependency, and runtime subprocesses receive explicit filtered environments and **never inherit `DATABASE_URL`**.

**Strong security warning: this worker is not an OS sandbox.** When execution is enabled, repository code and dependency lifecycle scripts run as the same Pterodactyl service account as the worker. Filtering the child environment does not create an OS security boundary: same-account code may inspect other files or processes, make network requests, or consume CPU, memory, process slots, and disk. Do not enable execution of untrusted, public multi-user repository code on a shared worker without a separate OS/container boundary per repository, least-privilege credentials, and enforced CPU/memory/disk/process/network limits. A shared Node.js process and a Pterodactyl container by themselves are not sufficient isolation.

## Configuration

See `.env.example` for placeholders. `DATABASE_URL` and `WORKER_ID` are required. Optional settings:

- `PORT` — health server port, default `5000`.
- `P_HOST_NAME` — heartbeat label; defaults to the OS hostname.
- `ENABLE_REPO_EXECUTION` — only the literal `true` enables Start jobs; default `false`.
- `MAX_RUNNING_PROCESSES` — number of simultaneous child processes, default `10`.
- `MAX_REPO_DOWNLOAD_SECONDS` — clone timeout, default `120`.
- `MAX_DEPENDENCY_INSTALL_SECONDS` — per dependency setup timeout, default `600`.

The health response is `GET /health` → `{"status":"ok"}`.
