require('dotenv').config();

const fs = require('node:fs');
const fsp = require('node:fs/promises');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');
const { spawn, execFile } = require('node:child_process');
const { promisify } = require('node:util');
const { once } = require('node:events');
const { neon } = require('@neondatabase/serverless');

const execFileAsync = promisify(execFile);
const ROOT = path.resolve(__dirname, '..');
const DATA_DIR = path.join(ROOT, 'data');
const REPOS_DIR = path.join(DATA_DIR, 'repositories');
const LOGS_DIR = path.join(DATA_DIR, 'runtime-logs');
const WORKER_HOME = path.join(DATA_DIR, '.worker-home');
const DATABASE_URL = process.env.DATABASE_URL;
const WORKER_ID = process.env.WORKER_ID;
const HOST_NAME = process.env.P_HOST_NAME || os.hostname();
const PORT = positiveInt(process.env.PORT, 5000);
const POLL_MS = 3000;
const HEARTBEAT_MS = 30000;
const CLONE_TIMEOUT_MS = positiveInt(process.env.MAX_REPO_DOWNLOAD_SECONDS, 120) * 1000;
const DEPENDENCY_INSTALL_TIMEOUT_MS = positiveInt(process.env.MAX_DEPENDENCY_INSTALL_SECONDS, 600) * 1000;
const MAX_RUNNING_PROCESSES = positiveInt(process.env.MAX_RUNNING_PROCESSES, 10);
const MAX_LOG_TAIL_BYTES = 65536;
const ENABLE_REPO_EXECUTION = process.env.ENABLE_REPO_EXECUTION === 'true';
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function positiveInt(value, fallback) {
  const number = Number(value);
  return Number.isSafeInteger(number) && number > 0 ? number : fallback;
}

if (!DATABASE_URL || !DATABASE_URL.trim()) {
  console.error('Startup failed: DATABASE_URL is required.');
  process.exit(1);
}
if (!WORKER_ID || !WORKER_ID.trim()) {
  console.error('Startup failed: WORKER_ID is required and must remain stable across host migration.');
  process.exit(1);
}

const sql = neon(process.env.DATABASE_URL);

for (const dir of [DATA_DIR, REPOS_DIR, LOGS_DIR, WORKER_HOME]) fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
const running = new Map();
let stopping = false;
let pollTimer;
let heartbeatTimer;
let pollInProgress = false;

function safeError(error) {
  let message = String(error?.stderr || error?.message || error || 'Unknown error').trim();
  for (const secret of [DATABASE_URL].filter(Boolean)) {
    message = message.split(secret).join('[redacted]');
  }
  message = message.replace(/(authorization\s*[:=]\s*bearer\s+)\S+/ig, '$1[redacted]');
  return (message || 'Unknown error').slice(-1600);
}

async function setRepositoryStatus(repoId, status, error = null) {
  await sql`SELECT public.set_repository_status(${repoId}, ${WORKER_ID}, ${status}, ${error})`;
}

async function finishJob(jobId, success, result = null, error = null) {
  const resultJson = result === null ? null : JSON.stringify(result);
  await sql`SELECT public.finish_hosting_job(${jobId}, ${WORKER_ID}, ${success}, ${resultJson}::jsonb, ${error})`;
}

function validUuid(value, label) {
  if (typeof value !== 'string' || !UUID_RE.test(value)) throw new Error(`Invalid ${label}.`);
  return value.toLowerCase();
}

function parseGithubRepo(value) {
  if (typeof value !== 'string' || value.includes('?') || value.includes('#')) {
    throw new Error('Repository URL must be https://github.com/owner/repo[.git] without a query or fragment.');
  }
  let url;
  try { url = new URL(value); } catch { throw new Error('Invalid GitHub repository URL.'); }
  if (url.protocol !== 'https:' || url.hostname.toLowerCase() !== 'github.com' || url.port || url.username || url.password || url.search || url.hash) {
    throw new Error('Only https://github.com/owner/repo[.git] URLs without query or fragment are accepted.');
  }
  const match = url.pathname.match(/^\/([A-Za-z0-9][A-Za-z0-9-]{0,38})\/([A-Za-z0-9_.-]+)(\.git)?\/?$/);
  if (!match) throw new Error('Use a repository URL like https://github.com/owner/repo or https://github.com/owner/repo.git.');
  const owner = match[1];
  const repo = match[2].replace(/\.git$/i, '');
  if (owner === '.' || owner === '..' || repo === '.' || repo === '..' || repo.length > 100) throw new Error('Invalid GitHub owner or repository name.');
  return { owner, repo, cloneUrl: `https://github.com/${owner}/${repo}.git` };
}

function repoDirectory(repoId) { return path.join(REPOS_DIR, repoId); }
function localLogPath(repoId) { return path.join(LOGS_DIR, `${repoId}.latest.log`); }

async function cloneRepository(job, dir) {
  const parsed = parseGithubRepo(job.repo_url);
  await fsp.rm(dir, { recursive: true, force: true });
  await fsp.mkdir(path.dirname(dir), { recursive: true, mode: 0o700 });
  try {
    await execFileAsync('git', ['clone', '--depth', '1', '--single-branch', parsed.cloneUrl, dir], {
      env: {
        PATH: process.env.PATH || '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
        HOME: WORKER_HOME,
        GIT_TERMINAL_PROMPT: '0',
        GIT_CONFIG_NOSYSTEM: '1',
      },
      timeout: CLONE_TIMEOUT_MS,
      maxBuffer: 2 * 1024 * 1024,
      windowsHide: true,
    });
  } catch (error) {
    await fsp.rm(dir, { recursive: true, force: true }).catch(() => {});
    throw new Error(`Git clone failed: ${safeError(error)}`);
  }
}

async function ensureCheckout(job) {
  const dir = repoDirectory(job.repository_id);
  try {
    const stat = await fsp.stat(dir);
    if (stat.isDirectory()) return dir;
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
  await cloneRepository(job, dir);
  return dir;
}

async function readLogTail(logPath) {
  let handle;
  try { handle = await fsp.open(logPath, 'r'); }
  catch (error) { if (error.code === 'ENOENT') return null; throw error; }
  try {
    const stat = await handle.stat();
    const length = Math.min(stat.size, MAX_LOG_TAIL_BYTES);
    const bytes = Buffer.alloc(length);
    if (length) await handle.read(bytes, 0, length, stat.size - length);
    let tail = bytes.toString('utf8');
    while (Buffer.byteLength(tail, 'utf8') > MAX_LOG_TAIL_BYTES) {
      const firstCodePoint = tail.codePointAt(0);
      tail = tail.slice(firstCodePoint > 0xffff ? 2 : 1);
    }
    return tail;
  } finally { await handle.close(); }
}

async function saveLogTail(ownerId, repoId) {
  const logPath = localLogPath(repoId);
  const tail = await readLogTail(logPath);
  if (tail === null) return false;
  const rows = await sql`
    INSERT INTO public.repository_logs (repository_id, log_tail)
    SELECT r.id, ${tail}
      FROM public.repositories AS r
     WHERE r.id = ${repoId}::uuid AND r.owner_id = ${ownerId}::uuid
    ON CONFLICT (repository_id) DO UPDATE
      SET log_tail = EXCLUDED.log_tail, updated_at = pg_catalog.now()
      WHERE EXISTS (
        SELECT 1 FROM public.repositories AS r
         WHERE r.id = EXCLUDED.repository_id AND r.owner_id = ${ownerId}::uuid
      )
    RETURNING repository_id`;
  if (!rows.length) throw new Error('Repository log upsert rejected: owner/repository mismatch or repository no longer exists.');
  return true;
}

async function findStartCommand(dir) {
  const packageJsonPath = path.join(dir, 'package.json');
  try {
    const pkg = JSON.parse(await fsp.readFile(packageJsonPath, 'utf8'));
    if (typeof pkg?.scripts?.start === 'string' && pkg.scripts.start.trim()) {
      return { kind: 'node', command: 'npm', args: ['start'], label: 'npm start', package: pkg };
    }
  } catch (error) {
    if (error.code !== 'ENOENT') throw new Error('Repository package.json is invalid JSON.');
  }
  for (const entry of ['main.py', 'app.py', 'bot.py']) {
    try {
      const stat = await fsp.stat(path.join(dir, entry));
      if (stat.isFile()) return { kind: 'python', command: 'python3', args: [entry], label: `python3 ${entry}`, entry };
    } catch (error) { if (error.code !== 'ENOENT') throw error; }
  }
  throw new Error('No supported entrypoint: provide package.json scripts.start or main.py, app.py, or bot.py.');
}

async function prepareDependencies(dir, start) {
  if (start.kind === 'node') {
    const pkg = start.package;
    const hasRuntimeDependencies = ['dependencies', 'optionalDependencies'].some(key => {
      const value = pkg[key];
      return value && typeof value === 'object' && !Array.isArray(value) && Object.keys(value).length > 0;
    });
    if (!hasRuntimeDependencies) return start;
    try {
      if ((await fsp.stat(path.join(dir, 'node_modules'))).isDirectory()) return start;
    } catch (error) { if (error.code !== 'ENOENT') throw error; }
    let hasLock = false;
    for (const name of ['package-lock.json', 'npm-shrinkwrap.json']) {
      try { if ((await fsp.stat(path.join(dir, name))).isFile()) { hasLock = true; break; } }
      catch (error) { if (error.code !== 'ENOENT') throw error; }
    }
    const args = [hasLock ? 'ci' : 'install', '--omit=dev', '--no-audit', '--no-fund'];
    await execFileAsync('npm', args, {
      cwd: dir,
      env: minimalChildEnvironment(dir),
      timeout: DEPENDENCY_INSTALL_TIMEOUT_MS,
      maxBuffer: 8 * 1024 * 1024,
      windowsHide: true,
    });
    return start;
  }
  if (start.kind === 'python') {
    try { await fsp.access(path.join(dir, 'requirements.txt')); }
    catch (error) { if (error.code === 'ENOENT') return start; throw error; }
    const venv = path.join(dir, '.runtime-venv');
    const python = path.join(venv, 'bin', 'python');
    try { await fsp.access(python); }
    catch (error) {
      if (error.code !== 'ENOENT') throw error;
      await execFileAsync('python3', ['-m', 'venv', '.runtime-venv'], {
        cwd: dir, env: minimalChildEnvironment(dir), timeout: DEPENDENCY_INSTALL_TIMEOUT_MS, maxBuffer: 8 * 1024 * 1024, windowsHide: true,
      });
      await execFileAsync(python, ['-m', 'pip', 'install', '--disable-pip-version-check', '-r', 'requirements.txt'], {
        cwd: dir, env: minimalChildEnvironment(dir), timeout: DEPENDENCY_INSTALL_TIMEOUT_MS, maxBuffer: 8 * 1024 * 1024, windowsHide: true,
      });
    }
    return { ...start, command: python };
  }
  return start;
}

function minimalChildEnvironment(dir) {
  return {
    PATH: process.env.PATH || '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
    HOME: path.join(dir, '.runtime-home'),
    NODE_ENV: 'production',
    PORT: '3000',
    PYTHONUNBUFFERED: '1',
  };
}

async function waitForExit(runtime, timeoutMs) {
  return Promise.race([
    runtime.exitPromise.then(() => true),
    new Promise(resolve => setTimeout(() => resolve(false), timeoutMs)),
  ]);
}

async function stopRuntime(repoId, runtime) {
  try { process.kill(-runtime.child.pid, 'SIGTERM'); }
  catch (error) { if (error.code !== 'ESRCH') throw error; }
  if (!(await waitForExit(runtime, 5000))) {
    try { process.kill(-runtime.child.pid, 'SIGKILL'); } catch (error) { if (error.code !== 'ESRCH') console.error(`Could not kill process group for ${repoId}: ${safeError(error)}`); }
    await waitForExit(runtime, 1500);
  }
  if (!runtime.exited) throw new Error(`Timed out waiting for repository process ${repoId} to stop.`);
}

async function finalizeRuntime(repoId, runtime, logStream, resolveExit) {
  if (runtime.finalizing) return;
  runtime.finalizing = true;
  logStream.end();
  await Promise.race([once(logStream, 'close').catch(() => {}), new Promise(resolve => setTimeout(resolve, 2000))]);
  runtime.exited = true;
  if (running.get(repoId) === runtime) running.delete(repoId);
  try { await saveLogTail(runtime.ownerId, repoId); }
  catch (error) { console.error(`Could not save runtime log tail for ${repoId}: ${safeError(error)}`); }
  try {
    const status = runtime.exitCode?.error ? 'error' : 'stopped';
    const detail = runtime.exitCode?.error || null;
    await setRepositoryStatus(repoId, status, detail);
  } catch (error) { console.error(`Could not update stopped status for ${repoId}: ${safeError(error)}`); }
  resolveExit(runtime.exitCode);
}

async function startRepository(job) {
  if (!ENABLE_REPO_EXECUTION) throw new Error('Repository execution is disabled; host must explicitly set ENABLE_REPO_EXECUTION=true.');
  if (running.has(job.repository_id)) throw new Error('Repository process is already running on this worker.');
  if (running.size >= MAX_RUNNING_PROCESSES) throw new Error(`Worker process quota reached (MAX_RUNNING_PROCESSES=${MAX_RUNNING_PROCESSES}).`);
  const dir = await ensureCheckout(job);
  await fsp.mkdir(path.join(dir, '.runtime-home'), { recursive: true, mode: 0o700 });
  const start = await prepareDependencies(dir, await findStartCommand(dir));
  const logStream = fs.createWriteStream(localLogPath(job.repository_id), { flags: 'a', mode: 0o600 });
  const child = spawn(start.command, start.args, {
    cwd: dir,
    env: minimalChildEnvironment(dir),
    shell: false,
    detached: true,
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  child.stdout.pipe(logStream);
  child.stderr.pipe(logStream);
  let resolveExit;
  const exitPromise = new Promise(resolve => { resolveExit = resolve; });
  const runtime = {
    child,
    exitPromise,
    ownerId: job.owner_id,
    startedAt: new Date().toISOString(),
    command: start.label,
    exited: false,
    exitCode: null,
  };
  running.set(job.repository_id, runtime);
  child.once('error', error => {
    runtime.exitCode = { error: safeError(error) };
    finalizeRuntime(job.repository_id, runtime, logStream, resolveExit).catch(err => console.error(`Runtime cleanup failed for ${job.repository_id}: ${safeError(err)}`));
  });
  child.once('exit', (code, signal) => {
    runtime.exitCode = { code, signal };
    finalizeRuntime(job.repository_id, runtime, logStream, resolveExit).catch(err => console.error(`Runtime cleanup failed for ${job.repository_id}: ${safeError(err)}`));
  });
  await setRepositoryStatus(job.repository_id, 'running', null);
  return { repository_id: job.repository_id, status: 'running', pid: child.pid, command: start.label };
}

async function stopRepository(job) {
  const runtime = running.get(job.repository_id);
  if (runtime) await stopRuntime(job.repository_id, runtime);
  await saveLogTail(job.owner_id, job.repository_id);
  await setRepositoryStatus(job.repository_id, 'stopped', null);
  return { repository_id: job.repository_id, status: 'stopped' };
}

async function deleteRepository(job) {
  const runtime = running.get(job.repository_id);
  if (runtime) await stopRuntime(job.repository_id, runtime);
  await fsp.rm(repoDirectory(job.repository_id), { recursive: true, force: true });
  await fsp.rm(localLogPath(job.repository_id), { force: true });
  return { repository_id: job.repository_id, status: 'deleted' };
}

async function processJob(rawJob) {
  if (!rawJob || typeof rawJob !== 'object') throw new Error('Job claim returned an invalid row.');
  const job = { ...rawJob };
  job.job_id = validUuid(job.job_id || job.id, 'job_id');
  job.owner_id = validUuid(job.owner_id, 'owner_id');
  job.repository_id = validUuid(job.repository_id, 'repository_id');
  if (!['import', 'start', 'stop', 'delete'].includes(job.action)) throw new Error(`Unsupported hosting job action: ${String(job.action)}`);
  let result;
  switch (job.action) {
    case 'import': {
      const parsed = parseGithubRepo(job.repo_url);
      await setRepositoryStatus(job.repository_id, 'cloning', null);
      await cloneRepository(job, repoDirectory(job.repository_id));
      await setRepositoryStatus(job.repository_id, 'stopped', null);
      result = { repository_id: job.repository_id, status: 'stopped', repo_name: job.repo_name || parsed.repo };
      break;
    }
    case 'start':
      await setRepositoryStatus(job.repository_id, 'starting', null);
      result = await startRepository(job);
      break;
    case 'stop':
      await setRepositoryStatus(job.repository_id, 'stopping', null);
      result = await stopRepository(job);
      break;
    case 'delete':
      await setRepositoryStatus(job.repository_id, 'deleting', null);
      result = await deleteRepository(job);
      break;
    default:
      throw new Error('Unsupported hosting job action.');
  }
  await finishJob(job.job_id, true, result, null);
}

async function claimAndProcess() {
  if (stopping || pollInProgress) return;
  pollInProgress = true;
  try {
    const rows = await sql`SELECT * FROM public.claim_hosting_job(${WORKER_ID})`;
    const job = rows[0] || null;
    if (!job) return;
    const claimedJobId = job.job_id || job.id;
    const jobId = typeof claimedJobId === 'string' && UUID_RE.test(claimedJobId) ? claimedJobId : null;
    try {
      await processJob(job);
    } catch (error) {
      const message = safeError(error);
      console.error(`Hosting job ${jobId || '(unknown)'} failed: ${message}`);
      if (jobId) {
        const repoId = typeof job.repository_id === 'string' && UUID_RE.test(job.repository_id) ? job.repository_id : null;
        if (repoId) {
          try { await setRepositoryStatus(repoId, 'error', message); }
          catch (statusError) { console.error(`Could not mark repository ${repoId} as failed: ${safeError(statusError)}`); }
        }
        try { await finishJob(jobId, false, null, message); }
        catch (finishError) { console.error(`Could not finish failed job ${jobId}: ${safeError(finishError)}`); }
      }
    }
  } catch (error) {
    console.error(`Worker poll failed: ${safeError(error)}`);
  } finally {
    pollInProgress = false;
    if (!stopping) pollTimer = setTimeout(claimAndProcess, POLL_MS);
  }
}

async function heartbeat() {
  if (stopping) return;
  try {
    await sql`SELECT public.heartbeat_worker(${WORKER_ID}, ${HOST_NAME}, ${ENABLE_REPO_EXECUTION})`;
  } catch (error) {
    console.error(`Worker heartbeat failed: ${safeError(error)}`);
  }
}

const server = http.createServer((request, response) => {
  if (request.method === 'GET' && request.url === '/health') {
    response.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
    response.end(JSON.stringify({ status: 'ok' }));
    return;
  }
  response.writeHead(404, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
  response.end(JSON.stringify({ error: 'Not found' }));
});

async function shutdown(signal) {
  if (stopping) return;
  stopping = true;
  console.log(`Received ${signal}; stopping worker and repository processes.`);
  clearTimeout(pollTimer);
  clearInterval(heartbeatTimer);
  server.close();
  for (const [repoId, runtime] of [...running.entries()]) {
    try {
      await stopRuntime(repoId, runtime);
      try { await saveLogTail(runtime.ownerId, repoId); }
      catch (error) { console.error(`Shutdown log-tail save failed for ${repoId}: ${safeError(error)}`); }
      await setRepositoryStatus(repoId, 'stopped', null);
    } catch (error) {
      console.error(`Shutdown cleanup failed for ${repoId}: ${safeError(error)}`);
    }
  }
  process.exit(0);
}

async function main() {
  await sql`SELECT * FROM public.reconcile_worker(${WORKER_ID})`;
  await heartbeat();
  server.listen(PORT, '0.0.0.0', () => console.log(`Pterodactyl Neon worker ${WORKER_ID} listening; health endpoint on port ${PORT}.`));
  heartbeatTimer = setInterval(heartbeat, HEARTBEAT_MS);
  pollTimer = setTimeout(claimAndProcess, 0);
}

process.once('SIGINT', () => { shutdown('SIGINT').catch(error => { console.error(`Shutdown failed: ${safeError(error)}`); process.exit(1); }); });
process.once('SIGTERM', () => { shutdown('SIGTERM').catch(error => { console.error(`Shutdown failed: ${safeError(error)}`); process.exit(1); }); });
main().catch(error => {
  console.error(`Worker startup failed: ${safeError(error)}`);
  process.exit(1);
});
