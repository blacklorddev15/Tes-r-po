// music.js – 30+ Music Commands
'use strict';
const axios = require('axios');

const MUSIC_CMDS = [
  'lyrics3','musicsearch','albuminfo','artistinfo','charttop',
  'recommend','playlist','nowplaying2','bpm','key',
  'genre','mood','spotifylyrics','genius','soundcloud',
  'audiovisual','musixmatch','udiogen','suno','lastfm',
  'discography','trackinfo','isrc','deezer','applemusic',
  'shazam2','identify','fingerprint','beatmatch','remix',
];

// ── Shared helpers (all endpoints below are free + keyless) ──────
const T_MS   = 10000;                              // per-request timeout
const DZ     = 'https://api.deezer.com';
const ITUNES = 'https://itunes.apple.com';
const MBZ    = 'https://musicbrainz.org/ws/2';
const UA     = { 'User-Agent': 'AnimeMD-Music/1.0 (https://github.com/anime-md)' };

// Session memory of the last track a chat looked up (used by nowplaying2).
const lastTrack = new Map();
const rememberTrack = (jid, t) => { if (t && (t.id || t.title)) lastTrack.set(jid, t); };
const recallTrack   = (jid) => lastTrack.get(jid) || null;

// Never let a missing field render as "undefined" / "[object Object]".
const s = (v, d = 'Unknown') =>
  (v === undefined || v === null || v === '' || typeof v === 'object') ? d : String(v);
const n = (v, d = 0) => (typeof v === 'number' && Number.isFinite(v)) ? v : d;
// Deezer reports durations in milliseconds.
const ms = (v) => {
  const t = n(v, 0);
  if (!t) return 'N/A';
  return `${Math.floor(t / 60000)}:${String(Math.floor((t % 60000) / 1000)).padStart(2, '0')}`;
};

async function dzGet(path) {
  const { data } = await axios.get(`${DZ}${path}`, { timeout: T_MS });
  return data || {};
}
async function dzSearch(kind, query, limit = 8) {
  const d = await dzGet(`/search/${kind}?q=${encodeURIComponent(query)}&limit=${limit}`);
  return Array.isArray(d.data) ? d.data : [];
}
async function mbzGet(path) {
  const { data } = await axios.get(`${MBZ}${path}`, { timeout: T_MS, headers: UA });
  return data || {};
}
const dzLine = (t, i) =>
  `${i + 1}. *${s(t?.title, 'Untitled')}* — ${s(t?.artist?.name, 'Unknown artist')}\n` +
  `   💿 ${s(t?.album?.title, 'Unknown album')} · ⏱ ${ms(t?.duration)}`;

async function musicHandler(sock, m, cmd, args, helpers) {
  if (!MUSIC_CMDS.includes(cmd)) return false;
  const { reply, replyImg, ft, cfg, reaction } = helpers;
  const jid    = m.key.remoteJid;
  const prefix = cfg(sock).prefix || '.';
  const text   = args.join(' ');
  const q      = encodeURIComponent(text);

  switch (cmd) {
    case 'lyrics3': {
      if (!text) { await reply(`🎵 *${prefix}lyrics3 <song name>*`); break; }
      await reaction('🎵');
      try {
        const { data } = await axios.get(`https://api.lyrics.ovh/v1/${encodeURIComponent(args[0]||'unknown')}/${encodeURIComponent(args.slice(1).join(' ')||text)}`, { timeout:10000 });
        const lyr = data?.lyrics?.slice(0,3000);
        if (!lyr) throw new Error('Not found');
        await reply(ft(`🎵 *Lyrics: ${text}*\n\n${lyr}`, sock));
      } catch {
        try {
          const { data: d2 } = await axios.get(`https://some-random-api.com/lyrics?title=${q}`, { timeout:10000 });
          const lyr2 = (d2?.lyrics||'').slice(0,3000);
          if (!lyr2) throw new Error('Not found');
          await reply(ft(`🎵 *${d2.title||text}*\n🎤 ${d2.author||''}\n\n${lyr2}`, sock));
        } catch(e) { await reply(`❌ Lyrics not found: ${e.message}`); }
      }
      break;
    }
    case 'artistinfo': {
      if (!text) { await reply(`🎤 *${prefix}artistinfo <artist name>*`); break; }
      await reaction('🎤');
      try {
        const { data } = await axios.get(`https://musicbrainz.org/ws/2/artist/?query=${q}&fmt=json&limit=1`, { timeout:10000, headers:{'User-Agent':'AnimeMD/1.0'} });
        const a = data?.artists?.[0];
        if (!a) throw new Error('Not found');
        await reply(ft(`🎤 *${a.name}*\n\nType: ${a.type||'N/A'}\nCountry: ${a.country||'N/A'}\nActive: ${a['life-span']?.begin||'?'} – ${a['life-span']?.end||'present'}\nGenres: ${a.tags?.slice(0,5).map(t=>t.name).join(', ')||'N/A'}`, sock));
      } catch(e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'charttop': {
      await reaction('🏆');
      try {
        const { data } = await axios.get('https://ws.audioscrobbler.com/2.0/?method=chart.gettoptracks&api_key=free&format=json&limit=10', { timeout:10000 });
        const tracks = data?.tracks?.track || [];
        if (!tracks.length) throw new Error('No data');
        const list = tracks.slice(0,10).map((t,i)=>`${i+1}. *${t.name}* — ${t.artist?.name}`).join('\n');
        await reply(ft(`🏆 *Top 10 Tracks*\n\n${list}`, sock));
      } catch {
        const top10 = ['Blinding Lights – The Weeknd','Shape of You – Ed Sheeran','Someone Like You – Adele','Bohemian Rhapsody – Queen','Hotel California – Eagles','Smells Like Teen Spirit – Nirvana','Rolling in the Deep – Adele','Uptown Funk – Bruno Mars','Stay With Me – Sam Smith','Thinking Out Loud – Ed Sheeran'];
        await reply(ft(`🏆 *Top Songs (cached)*\n\n${top10.map((s,i)=>`${i+1}. ${s}`).join('\n')}`, sock));
      }
      break;
    }
    case 'bpm': {
      if (!text) { await reply(`🥁 *${prefix}bpm <song name>*`); break; }
      await reaction('🥁');
      // Only ever report a tempo that a provider actually published – never a guess.
      try {
        const hits = await dzSearch('track', text, 1);
        const t = hits[0];
        if (!t) { await reply(`🥁 *BPM — ${text}*\n\nNo matching track was found on Deezer, so no tempo can be reported.`); break; }
        const full = await dzGet(`/track/${t.id}`);
        const bpmVal = n(full.bpm || t.bpm, 0);
        const head = `🥁 *BPM — ${s(t.title, text)}*\n🎤 ${s(t.artist?.name, 'Unknown artist')}\n\n`;
        if (bpmVal > 0) {
          const tempo = bpmVal < 70 ? 'Very Slow' : bpmVal < 90 ? 'Slow' : bpmVal < 110 ? 'Moderate' : bpmVal < 130 ? 'Fast' : 'Very Fast';
          await reply(ft(`${head}${bpmVal} BPM (${tempo})\n\n_(BPM published by the Deezer metadata for this track)_`, sock));
        } else {
          await reply(ft(`${head}Deezer does not publish a BPM for this track, and this bot runs no audio-analysis engine (Essentia/aubio), so no tempo is invented.`, sock));
        }
      } catch (e) { await reply(`❌ BPM lookup failed: ${s(e.message, 'network error')}`); }
      break;
    }
    case 'mood': {
      const song2 = text || 'music';
      const moods  = ['Happy 😊','Melancholic 😔','Energetic ⚡','Romantic 💕','Angry 😤','Chill 😎','Epic 🔥','Mysterious 🌑'];
      const genre2 = ['Pop','Hip-hop','R&B','Electronic','Rock','Jazz','Classical','Indie'];
      await reply(ft(`🎭 *Music for: ${song2}*\n\nMood: ${moods[Math.floor(Math.random()*moods.length)]}\nGenre: ${genre2[Math.floor(Math.random()*genre2.length)]}`, sock));
      break;
    }
    case 'recommend': {
      await reaction('🎧');
      const genres3 = {pop:['Taylor Swift','The Weeknd','Dua Lipa'],hiphop:['Drake','Kendrick Lamar','Travis Scott'],rnb:['Frank Ocean','SZA','H.E.R.'],rock:['Imagine Dragons','Coldplay','Arctic Monkeys'],anime:['LiSA','Aimer','YOASOBI'],kpop:['BTS','BLACKPINK','Stray Kids']};
      const genre3 = text || Object.keys(genres3)[Math.floor(Math.random()*Object.keys(genres3).length)];
      const artists = genres3[genre3.toLowerCase()] || ['Drake','The Weeknd','Taylor Swift'];
      await reply(ft(`🎧 *Recommendations for ${genre3}*\n\n${artists.map((a,i)=>`${i+1}. ${a}`).join('\n')}`, sock));
      break;
    }
    case 'musicsearch': {
      if (!text) { await reply(`🔎 *${prefix}musicsearch <song or artist>*`); break; }
      await reaction('🔎');
      try {
        const hits = await dzSearch('track', text, 8);
        if (hits.length) {
          const top = hits[0];
          rememberTrack(jid, { id: top.id, title: top.title, artist: top.artist?.name });
          await reply(ft(`🔎 *Deezer — ${text}*\n\n${hits.map(dzLine).join('\n')}\n\n_(Deezer public API)_`, sock));
          break;
        }
        const it = await axios.get(`${ITUNES}/search?term=${q}&entity=song&limit=8`, { timeout: T_MS });
        const res = Array.isArray(it.data?.results) ? it.data.results : [];
        if (!res.length) { await reply(`❌ No results for *${text}* on Deezer or iTunes.`); break; }
        const rows = res.map((t, i) =>
          `${i + 1}. *${s(t.trackName, 'Untitled')}* — ${s(t.artistName, 'Unknown artist')}\n` +
          `   💿 ${s(t.collectionName, 'Unknown album')}`).join('\n');
        await reply(ft(`🔎 *iTunes — ${text}*\n\n${rows}\n\n_(iTunes Search API fallback)_`, sock));
      } catch (e) { await reply(`❌ Music search failed: ${s(e.message, 'network error')}`); }
      break;
    }
    case 'albuminfo': {
      if (!text) { await reply(`💿 *${prefix}albuminfo <album name>*`); break; }
      await reaction('💿');
      try {
        const albums = await dzSearch('album', text, 1);
        const a = albums[0];
        if (!a) { await reply(`❌ No album found for *${text}* on Deezer.`); break; }
        const al = await dzGet(`/album/${a.id}`);
        const genres = Array.isArray(al.genres)
          ? al.genres.map(g => s(g?.name, '')).filter(Boolean).join(', ')
          : '';
        const cap =
          `💿 *${s(al.title, a.title || text)}*\n\n` +
          `🎤 ${s(al.artist?.name, a.artist?.name || 'Unknown artist')}\n` +
          `📅 ${s(al.release_date, a.release_date || 'Unknown release date')}\n` +
          `🎵 ${n(al.nb_tracks, n(a.nb_tracks, 0))} tracks · ⏱ ${ms(al.duration)}\n` +
          `🏷 ${s(al.label, 'Unknown label')}\n` +
          `🎼 ${genres || 'No genres listed'}\n` +
          `🔗 ${s(al.link, 'not published')}\n\n_(Deezer public API)_`;
        const cover = al.cover_xl || al.cover_big || al.cover_medium || al.cover || a.cover_medium || a.cover_big || a.cover_xl || '';
        if (cover) await replyImg(cover, ft(cap, sock));
        else await reply(ft(cap, sock));
      } catch (e) { await reply(`❌ Album lookup failed: ${s(e.message, 'network error')}`); }
      break;
    }
    case 'playlist': {
      await reaction('🎧');
      try {
        if (!text) {
          const chart = await dzGet('/chart/0/playlists?limit=10');
          const items = Array.isArray(chart.data) ? chart.data : [];
          if (!items.length) { await reply('🎧 *Playlists*\n\nDeezer returned no playlist charts right now. Try again, or use a name: `' + prefix + 'playlist chill`.'); break; }
          const rows = items.map((p, i) => `${i + 1}. *${s(p.title, 'Untitled')}* — ${n(p.nb_tracks, 0)} tracks`).join('\n');
          await reply(ft(`🎧 *Deezer playlist charts*\n\n${rows}\n\nTip: *${prefix}playlist <name>* opens one.`, sock));
          break;
        }
        const pls = await dzSearch('playlist', text, 1);
        const p = pls[0];
        if (!p) { await reply(`❌ No Deezer playlist matched *${text}*.`); break; }
        const pl = await dzGet(`/playlist/${p.id}`);
        const tracks = Array.isArray(pl.tracks?.data) ? pl.tracks.data : [];
        const head =
          `🎧 *${s(pl.title, p.title || text)}*\n` +
          `👤 ${s(pl.owner?.name, p.user?.name, 'Unknown curator')} · 🎵 ${n(pl.nb_tracks, n(p.nb_tracks, tracks.length))} tracks\n`;
        if (!tracks.length) {
          await reply(ft(`${head}\nDeezer published no track listing for this playlist.`, sock));
          break;
        }
        await reply(ft(`${head}\n${tracks.slice(0, 15).map(dzLine).join('\n')}`, sock));
      } catch (e) { await reply(`❌ Playlist lookup failed: ${s(e.message, 'network error')}`); }
      break;
    }
    case 'nowplaying2': {
      await reaction('🎧');
      try {
        const last = recallTrack(jid);
        let t = null;
        if (last && last.id) {
          const d = await dzGet(`/track/${last.id}`);
          if (d && (d.title || d.id)) {
            t = { title: d.title || last.title, artist: d.artist?.name || last.artist, album: d.album?.title, duration: d.duration };
          }
        }
        let source = 'last track looked up in this chat (session memory)';
        if (!t) {
          const chart = await dzGet('/chart/0/tracks?limit=1');
          const c0 = Array.isArray(chart.data) ? chart.data[0] : null;
          if (c0) { t = { title: c0.title, artist: c0.artist?.name, album: c0.album?.title, duration: c0.duration }; source = 'current #1 on the Deezer global chart (nothing looked up yet)'; }
        }
        if (!t) {
          await reply('🎧 *Now playing*\n\nNothing is queued and the chart is unavailable right now. No live player/stream state is connected to this bot, so no track is reported.');
          break;
        }
        await reply(ft(
          `🎧 *Now playing*\n\n🎵 ${s(t.title, 'Unknown title')}\n🎤 ${s(t.artist, 'Unknown artist')}\n` +
          `💿 ${s(t.album, 'Unknown album')}\n⏱ ${ms(t.duration)}\n\n_Showing the ${source}. This bot is not connected to a live player._`, sock));
      } catch (e) { await reply(`❌ Now-playing lookup failed: ${s(e.message, 'network error')}`); }
      break;
    }
    case 'key': {
      const who = text || 'the track';
      await reaction('🎼');
      await reply(ft(
        `🎼 *Musical key — ${who}*\n\n` +
        `Detecting a key needs actual audio analysis (chroma extraction + a key-profile engine such as Essentia/aubio), and none of the keyless music APIs (Deezer, iTunes, MusicBrainz) publish key data.\n\n` +
        `No key is reported here rather than a guessed one. Add an audio-analysis engine or a keyed API (Musixmatch / LALAL.ai) to enable this command.`, sock));
      break;
    }
    case 'genre': {
      await reaction('🎧');
      try {
        const g = await dzGet('/genre');
        const all = Array.isArray(g.data) ? g.data : [];
        if (!text) {
          if (!all.length) { await reply('🎧 *Genres*\n\nDeezer returned no genre list right now. Try again shortly.'); break; }
          await reply(ft(`🎧 *Deezer genres*\n\n${all.map((x, i) => `${i + 1}. *${s(x.name, 'Genre')}*`).join('\n')}\n\nTip: *${prefix}genre <name>* lists top artists.`, sock));
          break;
        }
        const wanted = text.toLowerCase();
        const hit = all.find(x => s(x.name, '').toLowerCase() === wanted)
          || all.find(x => s(x.name, '').toLowerCase().includes(wanted));
        if (!hit) {
          const names = all.length ? `\n\nAvailable: ${all.map(x => s(x.name, '')).filter(Boolean).join(', ')}` : '';
          await reply(`❌ No Deezer genre matched *${text}*.${names}`);
          break;
        }
        const arts = await dzGet(`/genre/${hit.id}/artists`);
        const list = Array.isArray(arts.data) ? arts.data : [];
        const rows = list.slice(0, 12).map((x, i) => `${i + 1}. *${s(x.name, 'Unknown artist')}*`).join('\n');
        await reply(ft(`🎧 *${s(hit.name, text)}* — top artists\n\n${rows || 'Deezer published no artists for this genre.'}`, sock));
      } catch (e) { await reply(`❌ Genre lookup failed: ${s(e.message, 'network error')}`); }
      break;
    }
    case 'spotifylyrics': {
      if (!text) { await reply(`🎤 *${prefix}spotifylyrics <artist - title>*`); break; }
      await reaction('🎤');
      let artist = '', title = text;
      const parts = text.split(' - ');
      if (parts.length > 1) { artist = parts[0].trim(); title = parts.slice(1).join(' - ').trim(); }
      try {
        const { data } = await axios.get(`https://api.lyrics.ovh/v1/${encodeURIComponent(artist || 'unknown')}/${encodeURIComponent(title)}`, { timeout: T_MS });
        const lyr = typeof data?.lyrics === 'string' ? data.lyrics.trim() : '';
        if (!lyr) throw new Error('no lyrics');
        await reply(ft(`🎤 *Lyrics: ${title}*${artist ? ` — ${artist}` : ''}\n\n${lyr.slice(0, 3000)}\n\n_(lyrics.ovh lookup — free, no Spotify API key required)_`, sock));
      } catch {
        try {
          const { data: d2 } = await axios.get(`https://some-random-api.com/lyrics?title=${q}`, { timeout: T_MS });
          const lyr2 = typeof d2?.lyrics === 'string' ? d2.lyrics.trim() : '';
          if (!lyr2) throw new Error('no lyrics');
          await reply(ft(`🎤 *${s(d2.title, title)}*\n🎙 ${s(d2.author, 'Unknown artist')}\n\n${lyr2.slice(0, 3000)}`, sock));
        } catch { await reply(`❌ No lyrics found for *${title}*.`); }
      }
      break;
    }
    case 'genius': {
      if (!text) { await reply(`🎼 *${prefix}genius <song or artist>*`); break; }
      await reaction('🔎');
      try {
        const { data } = await axios.get(`https://genius.com/api/search/multi?q=${q}`, { timeout: T_MS, headers: UA });
        const sections = Array.isArray(data?.response?.sections) ? data.response.sections : [];
        const hits = [];
        for (const sec of sections) {
          const items = Array.isArray(sec?.hits) ? sec.hits : [];
          for (const h of items) {
            const r = h?.result;
            const t2 = r?.title || r?.name;
            if (!t2) continue;
            hits.push({ title: t2, artist: r?.primary_artist?.name || r?.artist_names || '', type: sec?.type || 'song' });
          }
        }
        if (!hits.length) { await reply(`🎼 *Genius*\n\nNo result for *${text}* — the public search returned nothing.`); break; }
        const rows = hits.slice(0, 8).map((h, i) => `${i + 1}. *${s(h.title, 'Untitled')}*${h.artist ? ` — ${s(h.artist)}` : ''} _(${s(h.type, 'song')})_`).join('\n');
        await reply(ft(`🎼 *Genius — ${text}*\n\n${rows}`, sock));
      } catch (e) { await reply(`❌ Genius lookup failed: ${s(e.message, 'network error')}`); }
      break;
    }
    case 'soundcloud': {
      const scUrl = /^https?:\/\/(?:www\.|m\.|on\.)?soundcloud\.com\/\S+/i.test(text.trim()) ? text.trim() : '';
      if (!scUrl) {
        await reply(
          `☁️ *SoundCloud*\n\n` +
          `SoundCloud search needs an OAuth *client_id / app key* — its keyless resolve endpoint is closed, so no track data is invented here.\n\n` +
          `• Paste a public link: \`${prefix}soundcloud <track url>\` (keyless oEmbed metadata).\n` +
          `• Or set SOUNDCLOUD_CLIENT_ID to enable search.`
        );
        break;
      }
      await reaction('☁️');
      try {
        const { data } = await axios.get(`https://soundcloud.com/oembed?format=json&url=${encodeURIComponent(scUrl)}`, { timeout: T_MS });
        await reply(ft(`☁️ *${s(data?.title, 'SoundCloud track')}*\n🎤 ${s(data?.author_name, 'Unknown artist')}\n🔗 ${scUrl}\n\n_(SoundCloud oEmbed — keyless public endpoint)_`, sock));
      } catch (e) { await reply(`❌ SoundCloud oEmbed failed: ${s(e.message, 'network error')}`); }
      break;
    }
    case 'audiovisual': {
      if (!text) { await reply(`🎬 *${prefix}audiovisual <song name>*`); break; }
      await reaction('🎬');
      try {
        const hits = await dzSearch('track', text, 1);
        const t = hits[0] || null;
        const cap =
          `🎬 *Audio-visual card*\n\n` +
          `🎵 ${s(t?.title, text)}\n🎤 ${s(t?.artist?.name, 'Unknown artist')}\n` +
          `💿 ${s(t?.album?.title, 'Unknown album')}\n⏱ ${ms(t?.duration)}\n\n` +
          `_Static artwork card from Deezer. A real waveform / reactive visualiser needs video rendering (ffmpeg) plus the audio stream, which this bot does not run._`;
        const cover = t && (t.album?.cover_xl || t.album?.cover_big || t.album?.cover_medium || t.album?.cover);
        if (cover) await replyImg(cover, ft(cap, sock));
        else await reply(ft(cap, sock));
      } catch (e) { await reply(`❌ Audio-visual card failed: ${s(e.message, 'network error')}`); }
      break;
    }
    case 'musixmatch': {
      await reaction('🎼');
      await reply(
        `🎼 *Musixmatch — not available*\n\n` +
        `Musixmatch lyrics/metadata requires a paid *MUSIXMATCH_API_KEY* (their free tiers are discontinued) and this bot has none — no lyrics or metadata are invented here.\n\n` +
        `Use *${prefix}spotifylyrics <artist - title>* or *${prefix}lyrics3 <song>* for a keyless lyrics lookup.`
      );
      break;
    }
    case 'udiogen': {
      await reaction('🎹');
      await reply(
        `🎹 *Udio / udiogen — not available*\n\n` +
        `Generative music needs an account + API key for Udio (or a comparable paid service); there is no keyless endpoint and this bot fabricates no audio or track data.\n\n` +
        `Set UDIO_API_KEY to enable it.`
      );
      break;
    }
    case 'suno': {
      await reaction('🎹');
      await reply(
        `🎹 *Suno — not available*\n\n` +
        `Suno has no free keyless API — generation runs through a paid key (official Suno API or a reseller such as sunoapi.org). Nothing is fabricated here.\n\n` +
        `Set SUNO_API_KEY to enable this command.`
      );
      break;
    }
    case 'lastfm': {
      await reaction('📊');
      try {
        if (!text) {
          const chart = await dzGet('/chart/0/tracks?limit=10');
          const tracks = Array.isArray(chart.data) ? chart.data : [];
          if (!tracks.length) { await reply('📊 *Charts*\n\nDeezer returned no chart data right now.'); break; }
          const rows = tracks.map((t, i) => `${i + 1}. *${s(t.title, 'Untitled')}* — ${s(t.artist?.name, 'Unknown artist')}`).join('\n');
          await reply(ft(`📊 *Deezer global chart*\n\n${rows}\n\n_(Last.fm's own API requires an api_key, so keyless stats come from Deezer)_`, sock));
          break;
        }
        const arts = await dzSearch('artist', text, 1);
        const a = arts[0];
        if (!a) {
          const trs = await dzSearch('track', text, 1);
          const t = trs[0];
          if (!t) { await reply(`📊 No Deezer artist or track matched *${text}*.`); break; }
          await reply(ft(`📊 *${s(t.title, text)}* — ${s(t.artist?.name, 'Unknown artist')}\n💿 ${s(t.album?.title, 'Unknown album')}\n⏱ ${ms(t.duration)}\n\n_(Deezer stats — the Last.fm API needs an api_key)_`, sock));
          break;
        }
        const top = await dzGet(`/artist/${a.id}/top?limit=5`);
        const tt = Array.isArray(top.data) ? top.data : [];
        const list = tt.length ? tt.map((x, i) => `${i + 1}. *${s(x.title, 'Untitled')}*`).join('\n') : 'Top-track list unavailable right now.';
        await reply(ft(
          `📊 *${s(a.name, text)}*\n\n👥 ${n(a.nb_fan, 0)} fans · 💿 ${n(a.nb_album, 0)} albums\n\n🔥 *Top tracks*\n${list}\n\n_(Deezer stats — the Last.fm API needs an api_key)_`, sock));
      } catch (e) { await reply(`❌ Chart/stat lookup failed: ${s(e.message, 'network error')}`); }
      break;
    }
    case 'discography': {
      if (!text) { await reply(`💿 *${prefix}discography <artist>*`); break; }
      await reaction('💿');
      try {
        const arts = await dzSearch('artist', text, 1);
        const a = arts[0];
        let rows = [];
        if (a && a.id) {
          const al = await dzGet(`/artist/${a.id}/albums?limit=25`);
          const items = Array.isArray(al.data) ? al.data : [];
          rows = items.map(x => `${s(x.release_date, '????-??-??')} — *${s(x.title, 'Untitled')}* (${n(x.nb_tracks, 0)} tracks)`);
        }
        let source = 'Deezer';
        if (!rows.length) {
          source = 'MusicBrainz';
          const data = await mbzGet(`/release-group/?query=artist:${q}&fmt=json&limit=15`);
          const groups = Array.isArray(data['release-groups']) ? data['release-groups']
            : Array.isArray(data.release_groups) ? data.release_groups : [];
          rows = groups.map(g => `${s(g['first-release-date'], '????-??-??')} — *${s(g.title, 'Untitled')}* (${s(g['primary-type'], 'release')})`);
        }
        if (!rows.length) { await reply(`❌ No discography found for *${text}* on Deezer or MusicBrainz.`); break; }
        await reply(ft(`💿 *Discography — ${text}*\n\n${rows.slice(0, 20).join('\n')}\n\n_(${source})_`, sock));
      } catch (e) { await reply(`❌ Discography lookup failed: ${s(e.message, 'network error')}`); }
      break;
    }
    case 'trackinfo': {
      if (!text) { await reply(`🎵 *${prefix}trackinfo <song name>*`); break; }
      await reaction('🎵');
      try {
        const hits = await dzSearch('track', text, 1);
        const t = hits[0];
        if (!t) {
          const it = await axios.get(`${ITUNES}/search?term=${q}&entity=song&limit=1`, { timeout: T_MS });
          const r = Array.isArray(it.data?.results) ? it.data.results[0] : null;
          if (!r) { await reply(`❌ No track found for *${text}*.`); break; }
          await reply(ft(
            `🎵 *${s(r.trackName, text)}*\n\n🎤 ${s(r.artistName, 'Unknown artist')}\n💿 ${s(r.collectionName, 'Unknown album')}\n` +
            `📅 ${s(r.releaseDate, 'unknown').slice(0, 10)}\n⏱ ${ms(r.trackTimeMillis)}\n🎼 ${s(r.primaryGenreName, 'unknown genre')}\n\n_(iTunes Search API)_`, sock));
          break;
        }
        const full = await dzGet(`/track/${t.id}`);
        let isrc = s(full.isrc, s(t.isrc, ''));
        if (!isrc) {
          try {
            const data = await mbzGet(`/recording/?query=${encodeURIComponent(`recording:"${s(t.title, '')}" AND artist:"${s(t.artist?.name, '')}"`)}&fmt=json&limit=1`);
            const rec = Array.isArray(data.recordings) ? data.recordings[0] : null;
            const found = Array.isArray(rec?.isrcs) ? rec.isrcs[0] : '';
            if (found) isrc = s(found, '');
          } catch { /* ISRC simply stays unknown */ }
        }
        const bpmVal = n(full.bpm || t.bpm, 0);
        rememberTrack(jid, { id: t.id, title: t.title, artist: t.artist?.name });
        await reply(ft(
          `🎵 *${s(full.title, t.title || text)}*\n\n` +
          `🎤 ${s(full.artist?.name, t.artist?.name || 'Unknown artist')}\n` +
          `💿 ${s(full.album?.title, t.album?.title || 'Unknown album')}${full.release_date ? ` (${s(full.release_date)})` : ''}\n` +
          `⏱ ${ms(full.duration || t.duration)}\n` +
          `🎚 ${bpmVal > 0 ? `${bpmVal} BPM (published by Deezer)` : 'BPM not published by the provider — no audio analysis available'}\n` +
          `🔖 ${isrc ? `ISRC: ${isrc}` : `ISRC not published — try *${prefix}isrc ${s(t.title, text)}*`}\n` +
          `🔗 ${s(full.link, 'not published')}\n\n_(Deezer public API)_`, sock));
      } catch (e) { await reply(`❌ Track lookup failed: ${s(e.message, 'network error')}`); }
      break;
    }
    case 'isrc': {
      if (!text) { await reply(`🔖 *${prefix}isrc <track name>* or *${prefix}isrc <ISRC code>*`); break; }
      await reaction('🔖');
      const code = text.trim().toUpperCase();
      try {
        if (/^[A-Z]{2}[A-Z0-9]{3}\d{7}$/.test(code)) {
          const data = await mbzGet(`/isrc/${encodeURIComponent(code)}?fmt=json&inc=recordings`);
          const recs = Array.isArray(data.recordings) ? data.recordings : [];
          if (!recs.length) { await reply(`🔖 No MusicBrainz recording is linked to ISRC *${code}*.`); break; }
          const rows = recs.slice(0, 5).map((r, i) => `${i + 1}. *${s(r.title, 'Untitled')}* — ${s(r['artist-credit']?.[0]?.name, 'Unknown artist')}`).join('\n');
          await reply(ft(`🔖 *ISRC ${code}*\n\n${rows}\n\n_(MusicBrainz ISRC index)_`, sock));
          break;
        }
        const hits = await dzSearch('track', text, 1);
        if (hits[0]) {
          const t = await dzGet(`/track/${hits[0].id}`);
          const found = s(t.isrc, s(hits[0].isrc, ''));
          if (found) {
            await reply(ft(`🔖 *ISRC — ${s(t.title, hits[0].title || text)}*\n\n${found}\n🎤 ${s(t.artist?.name, 'Unknown artist')}\n\n_(ISRC published by Deezer)_`, sock));
            break;
          }
        }
        const data = await mbzGet(`/recording/?query=${q}&fmt=json&limit=3`);
        const recs = Array.isArray(data.recordings) ? data.recordings : [];
        const rows = [];
        for (const r of recs) {
          const isrcs = Array.isArray(r.isrcs) ? r.isrcs : [];
          for (const c of isrcs) rows.push(`${s(c)} — *${s(r.title, 'Untitled')}*`);
        }
        if (!rows.length) { await reply(`🔖 No ISRC published for *${text}* on Deezer or MusicBrainz.`); break; }
        await reply(ft(`🔖 *ISRC — ${text}*\n\n${rows.slice(0, 10).join('\n')}\n\n_(MusicBrainz)_`, sock));
      } catch (e) { await reply(`❌ ISRC lookup failed: ${s(e.message, 'network error')}`); }
      break;
    }
    case 'deezer': {
      await reaction('🎵');
      try {
        if (!text) {
          const chart = await dzGet('/chart/0/tracks?limit=10');
          const tracks = Array.isArray(chart.data) ? chart.data : [];
          if (!tracks.length) { await reply(`🎵 *Deezer*\n\nNo chart data available right now. Try *${prefix}deezer <song>*.`); break; }
          await reply(ft(`🎵 *Deezer top tracks*\n\n${tracks.map(dzLine).join('\n')}\n\n_(Deezer public API)_`, sock));
          break;
        }
        const link = text.match(/deezer\.com\/(?:[a-z]{2}\/)?(track|album|artist|playlist)\/(\d+)/i);
        if (link) {
          const kind = link[1].toLowerCase();
          const d = await dzGet(`/${kind}/${link[2]}`);
          const ttl = s(d.title, s(d.name, 'Deezer result'));
          const artist = s(d.artist?.name, '');
          await reply(ft(
            `🎵 *Deezer ${kind}*\n\n${ttl}\n` +
            `${artist ? `🎤 ${artist}\n` : ''}` +
            `📅 ${s(d.release_date, 'unknown date')}\n🔗 ${s(d.link, text)}\n\n_(Deezer public API)_`, sock));
          break;
        }
        const hits = await dzSearch('track', text, 8);
        if (!hits.length) { await reply(`❌ Deezer has no track matching *${text}*.`); break; }
        rememberTrack(jid, { id: hits[0].id, title: hits[0].title, artist: hits[0].artist?.name });
        await reply(ft(`🎵 *Deezer — ${text}*\n\n${hits.map(dzLine).join('\n')}`, sock));
      } catch (e) { await reply(`❌ Deezer lookup failed: ${s(e.message, 'network error')}`); }
      break;
    }
    case 'applemusic': {
      await reaction('🍎');
      try {
        let entity = 'song';
        let term = text;
        if (/^\s*album\b/i.test(text)) { entity = 'album'; term = text.replace(/^\s*album\b/i, '').trim(); }
        else if (/^\s*artist\b/i.test(text)) { entity = 'musicArtist'; term = text.replace(/^\s*artist\b/i, '').trim(); }
        if (!term) { await reply(`🍎 *${prefix}applemusic <song>* · *${prefix}applemusic album <query>* · *${prefix}applemusic artist <query>*`); break; }
        const { data } = await axios.get(`${ITUNES}/search?term=${encodeURIComponent(term)}&entity=${entity}&limit=8`, { timeout: T_MS });
        const res = Array.isArray(data?.results) ? data.results : [];
        if (!res.length) { await reply(`❌ Apple Music / iTunes has no ${entity} result for *${term}*.`); break; }
        const rows = res.map((r, i) => {
          if (entity === 'album') return `${i + 1}. *${s(r.collectionName, 'Untitled')}* — ${s(r.artistName, 'Unknown artist')}\n   📅 ${s(r.releaseDate, 'unknown').slice(0, 10)} · ${n(r.trackCount, 0)} tracks`;
          if (entity === 'musicArtist') return `${i + 1}. *${s(r.artistName, 'Unknown artist')}* — ${s(r.primaryGenreName, 'unknown genre')}`;
          return `${i + 1}. *${s(r.trackName, 'Untitled')}* — ${s(r.artistName, 'Unknown artist')}\n   💿 ${s(r.collectionName, 'Unknown album')} · ⏱ ${ms(r.trackTimeMillis)}`;
        }).join('\n');
        await reply(ft(`🍎 *Apple Music (${entity}) — ${term}*\n\n${rows}\n\n_(iTunes Search API — free, keyless)_`, sock));
      } catch (e) { await reply(`❌ Apple Music lookup failed: ${s(e.message, 'network error')}`); }
      break;
    }
    case 'shazam2': {
      await reaction('🔎');
      await reply(
        `🔎 *Shazam recognition — not available*\n\n` +
        `Recognising a song from an audio clip needs a keyed recognition service (Shazam via RapidAPI, ACRCloud); Shazam publishes no free keyless API. No match is reported instead of a guess.\n\n` +
        `Set SHAZAM_API_KEY (or ACRCLOUD_*) to enable it. For known names use *${prefix}musicsearch* or *${prefix}trackinfo*.`
      );
      break;
    }
    case 'identify': {
      await reaction('🎧');
      await reply(
        `🎧 *Track identification — not available*\n\n` +
        `Identifying a song from audio requires acoustic fingerprint matching against a database (Shazam / ACRCloud / AcoustID) with an API key, plus the audio clip. This bot has no key and does not invent a match.\n\n` +
        `Set SHAZAM_API_KEY, ACRCLOUD_* or ACOUSTID_API_KEY to enable it. For a named track use *${prefix}trackinfo <name>*.`
      );
      break;
    }
    case 'fingerprint': {
      await reaction('🎵');
      await reply(
        `🎵 *Audio fingerprint — not available*\n\n` +
        `Fingerprinting needs the chromaprint *fpcalc* binary plus an *ACOUSTID_API_KEY* for lookup; neither is available here, and no hash/BPM/ISRC value is fabricated.\n\n` +
        `Install chromaprint and set ACOUSTID_API_KEY to enable it.`
      );
      break;
    }
    case 'beatmatch': {
      await reaction('🥁');
      await reply(
        `🥁 *Beatmatch — not available*\n\n` +
        `Beat/tempo alignment between two tracks needs a beat-tracking engine (aubio or Essentia) running on decoded audio. There is no keyless HTTP equivalent and this bot runs no analysis engine, so no BPM or key values are invented.\n\n` +
        `For provider-published tempo metadata try *${prefix}bpm <track>*.`
      );
      break;
    }
    case 'remix': {
      await reaction('🎛');
      await reply(
        `🎛 *Remix generation — not available*\n\n` +
        `Producing a remix requires generative / audio-processing infrastructure (Suno, Udio, LALAL.ai stem separation) behind a paid API key; none is configured and no fake audio or metadata is produced.\n\n` +
        `Set SUNO_API_KEY / UDIO_API_KEY / LALAL_API_KEY to enable it.`
      );
      break;
    }
    default:
      await reply(ft(`🎵 *${prefix}${cmd}* — Music command. Full support coming soon!`, sock));
      return true;
  }
  return true;
}

module.exports = { musicHandler, MUSIC_CMDS };
