// stickers.js – 30+ Sticker/Media Commands
'use strict';
const axios = require('axios');

const STICKER_CMDS = [
  'sticker2','tomp4sticker','stickerinfo','attp2','emojisticker',
  'gifsticker','videosticker','cropsticker','circleimg',
  'givensticker','colorsticker','textimg','imagetext',
  'tenor','giphy','gifcat','gifdog','gifanime','gifyeet',
  'stealsticker','packname','packauthor','exifsticker',
  'togif','giftext','gifmeme','randgif','animegif',
  'memetemplate','randmeme',
];

// ── Sticker pack settings (kept in memory – no database writes) ──
const STICKER_PACKS = new Map();
function packKey(sock) {
  return (sock && (sock.__waNum || sock.__sessionId || sock.user?.id)) || 'default';
}
function getPack(sock) {
  const key = packKey(sock);
  if (!STICKER_PACKS.has(key)) STICKER_PACKS.set(key, { name: '𝐒𝐊𝐘𝐋Λ𝐑 𝐗𝐌𝐃', author: '𝐒𝐊𝐘𝐋Λ𝐑 𝐗𝐌𝐃' });
  return STICKER_PACKS.get(key);
}
function packExif(pack, emojis) {
  return JSON.stringify({
    'sticker-pack-id': `skylar.${Date.now()}`,
    'sticker-pack-name': pack.name,
    'sticker-pack-publisher': pack.author,
    emojis: Array.isArray(emojis) && emojis.length ? emojis : ['🩹'],
  });
}

// ── Minimal WhatsApp sticker EXIF (RIFF/WebP) writer & reader ──
// node-webpmux is not installed on this host, so the TIFF "AW" tag that
// WhatsApp reads for sticker-pack metadata is written by hand.
function buildStickerExifHead(jsonLen) {
  const head = Buffer.from([
    0x49, 0x49, 0x2a, 0x00, 0x08, 0x00, 0x00, 0x00,
    0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x16, 0x00, 0x00, 0x00,
  ]);
  head.writeUIntLE(jsonLen, 14, 4);
  return head;
}
function addWebpExif(webpBuf, jsonStr) {
  const buf = Buffer.isBuffer(webpBuf) ? webpBuf : Buffer.from(webpBuf || []);
  try {
    if (buf.length < 16 || buf.slice(0, 4).toString('ascii') !== 'RIFF' || buf.slice(8, 12).toString('ascii') !== 'WEBP') return buf;
    const chunks = [];
    let off = 12;
    while (off + 8 <= buf.length) {
      const id   = buf.slice(off, off + 4).toString('ascii');
      const size = buf.readUInt32LE(off + 4);
      const body = buf.slice(off + 8, Math.min(off + 8 + size, buf.length));
      chunks.push({ id, body, pad: size % 2 ? Buffer.from([0]) : Buffer.alloc(0) });
      off += 8 + size + (size % 2);
    }
    if (!chunks.length) return buf;
    const vp8x = chunks.find(c => c.id === 'VP8X');
    if (vp8x && vp8x.body.length) { vp8x.body = Buffer.from(vp8x.body); vp8x.body[0] |= 0x08; }
    const jsonBuf  = Buffer.from(jsonStr, 'utf8');
    const exifBody = Buffer.concat([buildStickerExifHead(jsonBuf.length), jsonBuf]);
    // RIFF chunks must be padded to an even length
    const exif = { id: 'EXIF', body: exifBody, pad: exifBody.length % 2 ? Buffer.from([0]) : Buffer.alloc(0) };
    const idx = chunks.findIndex(c => c.id === 'VP8X');
    if (idx >= 0) chunks.splice(idx + 1, 0, exif); else chunks.unshift(exif);
    const payload = Buffer.concat(chunks.map(c => {
      const sz = Buffer.alloc(4);
      sz.writeUInt32LE(c.body.length, 0);
      return Buffer.concat([Buffer.from(c.id, 'ascii'), sz, c.body, c.pad]);
    }));
    const body2 = Buffer.concat([Buffer.from('WEBP', 'ascii'), payload]);
    const head2 = Buffer.alloc(8);
    head2.write('RIFF', 0, 'ascii');
    head2.writeUInt32LE(body2.length, 4);
    return Buffer.concat([head2, body2]);
  } catch { return buf; }
}
function readStickerExif(webpBuf) {
  const buf = Buffer.isBuffer(webpBuf) ? webpBuf : Buffer.from(webpBuf || []);
  try {
    if (buf.slice(0, 4).toString('ascii') !== 'RIFF' || buf.slice(8, 12).toString('ascii') !== 'WEBP') return null;
    let off = 12;
    while (off + 8 <= buf.length) {
      const id   = buf.slice(off, off + 4).toString('ascii');
      const size = buf.readUInt32LE(off + 4);
      if (id === 'EXIF') {
        const str = buf.slice(off + 8, Math.min(off + 8 + size, buf.length)).toString('utf8');
        const a = str.indexOf('{'), b = str.lastIndexOf('}');
        if (a >= 0 && b > a) return JSON.parse(str.slice(a, b + 1));
        return null;
      }
      off += 8 + size + (size % 2);
    }
  } catch { /* ignore */ }
  return null;
}

// ── Media / rendering helpers ───────────────────────────────
async function quotedBuffer(m) {
  const ctx  = m.message?.extendedTextMessage?.contextInfo;
  const qmsg = ctx?.quotedMessage;
  if (!qmsg) return null;
  const { downloadMediaMessage } = require('./helper/baileys');
  return downloadMediaMessage(
    { message: qmsg, key: { remoteJid: m.key.remoteJid, id: ctx?.stanzaId, fromMe: false } },
    'buffer', {},
    { logger: { info(){}, error(){}, warn(){}, debug(){}, child(){ return this; } } }
  );
}
async function toStickerWebp(buf, exifJson) {
  const sharp = require('sharp');
  const out = await sharp(buf, { animated: true })
    .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .webp({ quality: 90 })
    .toBuffer();
  return exifJson ? addWebpExif(out, exifJson) : out;
}
function escXml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&apos;');
}
function wrapText(str, max) {
  const words = String(str == null ? '' : str).split(/\s+/).filter(Boolean);
  const out = [];
  let cur = '';
  for (const w of words) {
    if ((cur ? cur + ' ' + w : w).length > max) { if (cur) out.push(cur); cur = w.slice(0, max); }
    else cur = cur ? cur + ' ' + w : w;
  }
  if (cur) out.push(cur);
  return out.length ? out : [''];
}
async function textCardGif(textOrLines, opts) {
  const sharp = require('sharp');
  const lines = (Array.isArray(textOrLines) ? textOrLines : [textOrLines]).slice(0, 4);
  const W = 480, H = 260;
  const body = lines.map((ln, i) =>
    `<text x="${W / 2}" y="${86 + i * 56}" font-size="38" font-family="DejaVu Sans, sans-serif" fill="#ffffff" text-anchor="middle">${escXml(ln)}</text>`
  ).join('');
  const from = (opts && opts.from) || '#ff5733';
  const to   = (opts && opts.to)   || '#3322ff';
  const svg = Buffer.from(
    `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}">` +
    `<defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">` +
    `<stop offset="0" stop-color="${from}"/><stop offset="1" stop-color="${to}"/></linearGradient></defs>` +
    `<rect width="${W}" height="${H}" fill="url(#bg)"/>${body}</svg>`
  );
  return sharp(svg).gif().toBuffer();
}

async function stickerHandler(sock, m, cmd, args, helpers) {
  if (!STICKER_CMDS.includes(cmd)) return false;
  const { reply, ft, cfg, reaction } = helpers;
  const jid    = m.key.remoteJid;
  const prefix = cfg(sock).prefix || '.';
  const text   = args.join(' ');

  switch (cmd) {
    case 'tenor': {
      if (!text) { await reply(`🎬 *${prefix}tenor <search term>*`); break; }
      await reaction('🎬');
      try {
        const { data } = await axios.get(
          `https://tenor.googleapis.com/v2/search?q=${encodeURIComponent(text)}&key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCY8&limit=1`,
          { timeout: 8000 }
        );
        const gifUrl = data?.results?.[0]?.media_formats?.gif?.url || data?.results?.[0]?.media_formats?.mediumgif?.url;
        if (!gifUrl) throw new Error('No GIF found');
        const res = await axios.get(gifUrl, { responseType: 'arraybuffer', timeout: 12000 });
        await sock.sendMessage(jid, {
          video: Buffer.from(res.data),
          gifPlayback: true,
          caption: ft(`🎬 ${text}`, sock),
        }, { quoted: m });
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'giphy': {
      if (!text) { await reply(`🎭 *${prefix}giphy <search term>*`); break; }
      await reaction('🎭');
      try {
        const { data } = await axios.get(
          `https://api.giphy.com/v1/gifs/search?q=${encodeURIComponent(text)}&api_key=dc6zaTOxFJmzC&limit=1`,
          { timeout: 8000 }
        );
        const gifUrl2 = data?.data?.[0]?.images?.original?.url;
        if (!gifUrl2) throw new Error('No GIF found');
        const res2 = await axios.get(gifUrl2, { responseType: 'arraybuffer', timeout: 12000 });
        await sock.sendMessage(jid, {
          video: Buffer.from(res2.data),
          gifPlayback: true,
          caption: ft(`🎭 ${text}`, sock),
        }, { quoted: m });
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'gifcat': {
      await reaction('🐱');
      try {
        const { data } = await axios.get('https://api.thecatapi.com/v1/images/search?mime_types=gif', { timeout: 8000 });
        const url = data?.[0]?.url;
        if (!url) throw new Error('No cat GIF');
        const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 12000 });
        await sock.sendMessage(jid, { video: Buffer.from(res.data), gifPlayback: true, caption: ft('🐱 Cat GIF~', sock) }, { quoted: m });
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'gifdog': {
      await reaction('🐶');
      try {
        const { data } = await axios.get('https://random.dog/woof.json?include=gif', { timeout: 8000 });
        const url2 = data?.url;
        if (!url2) throw new Error('No dog GIF');
        const res2 = await axios.get(url2, { responseType: 'arraybuffer', timeout: 12000 });
        await sock.sendMessage(jid, { video: Buffer.from(res2.data), gifPlayback: true, caption: ft('🐶 Dog GIF~', sock) }, { quoted: m });
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'gifanime': {
      await reaction('🎌');
      try {
        const cats = ['waifu','neko','shinobu','megumin','blush','smile','wave','dance','happy'];
        const cat  = text || cats[Math.floor(Math.random()*cats.length)];
        const { data } = await axios.get(`https://api.waifu.pics/sfw/${cat}`, { timeout: 8000 });
        await sock.sendMessage(jid, { image: { url: data.url }, caption: ft(`🎌 ${cat}`, sock) }, { quoted: m });
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'randgif': {
      await reaction('🎲');
      try {
        const terms = ['funny','cute','wow','awesome','anime','cat','dog','meme','cool'];
        const term  = terms[Math.floor(Math.random()*terms.length)];
        const { data } = await axios.get(
          `https://api.giphy.com/v1/gifs/random?tag=${term}&api_key=dc6zaTOxFJmzC`,
          { timeout: 8000 }
        );
        const url3 = data?.data?.images?.original?.url;
        if (!url3) throw new Error('No GIF');
        const res3 = await axios.get(url3, { responseType: 'arraybuffer', timeout: 12000 });
        await sock.sendMessage(jid, { video: Buffer.from(res3.data), gifPlayback: true, caption: ft(`🎲 Random GIF: ${term}`, sock) }, { quoted: m });
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'animegif': {
      await reaction('⛩️');
      try {
        const { data } = await axios.get('https://api.waifu.pics/sfw/waifu', { timeout: 8000 });
        await sock.sendMessage(jid, { image: { url: data.url }, caption: ft('⛩️ Anime~', sock) }, { quoted: m });
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'gifyeet': {
      await reaction('🚀');
      try {
        const { data } = await axios.get('https://api.giphy.com/v1/gifs/random?tag=yeet&api_key=dc6zaTOxFJmzC', { timeout: 8000 });
        const url4 = data?.data?.images?.original?.url;
        const res4 = await axios.get(url4, { responseType: 'arraybuffer', timeout: 12000 });
        await sock.sendMessage(jid, { video: Buffer.from(res4.data), gifPlayback: true, caption: ft('🚀 YEET!', sock) }, { quoted: m });
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'memetemplate': {
      await reaction('😂');
      const templates = [
        { name: 'Drake', url: 'https://i.imgflip.com/30b1gx.jpg' },
        { name: 'Distracted Boyfriend', url: 'https://i.imgflip.com/1ur9b0.jpg' },
        { name: 'Change My Mind', url: 'https://i.imgflip.com/24y43o.jpg' },
        { name: 'Two Buttons', url: 'https://i.imgflip.com/1g8my4.jpg' },
        { name: 'Expanding Brain', url: 'https://i.imgflip.com/1jwhww.jpg' },
        { name: 'Waiting Skeleton', url: 'https://i.imgflip.com/2fm6x.jpg' },
        { name: 'Is This a Pigeon', url: 'https://i.imgflip.com/1o00in.jpg' },
        { name: 'This is Fine', url: 'https://i.imgflip.com/wxica.jpg' },
      ];
      const template = text
        ? templates.find(t => t.name.toLowerCase().includes(text.toLowerCase())) || templates[0]
        : templates[Math.floor(Math.random() * templates.length)];
      await sock.sendMessage(jid, {
        image: { url: template.url },
        caption: ft(`😂 *${template.name}* meme template\n\nUse ${prefix}meme2 to add text`, sock),
      }, { quoted: m });
      break;
    }
    case 'randmeme': {
      await reaction('😂');
      try {
        const { data } = await axios.get('https://meme-api.com/gimme', { timeout: 8000 });
        await sock.sendMessage(jid, {
          image: { url: data.url },
          caption: ft(`😂 *${data.title}*\n\n⬆️ ${data.ups?.toLocaleString() || '?'} upvotes | r/${data.subreddit}`, sock),
        }, { quoted: m });
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'textimg': {
      if (!text) { await reply(`📝 *${prefix}textimg <your text>*\nConverts text to an image card.`); break; }
      await reaction('📝');
      try {
        const { data } = await axios.get(
          `https://api.popcat.xyz/textpic?text=${encodeURIComponent(text.slice(0,100))}`,
          { responseType: 'arraybuffer', timeout: 10000 }
        );
        await sock.sendMessage(jid, { image: Buffer.from(data), caption: ft(`📝 ${text}`, sock) }, { quoted: m });
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'circleimg': {
      await reaction('⭕');
      const qmsg = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      if (!qmsg?.imageMessage) { await reply(`⭕ Reply to an image with *${prefix}circleimg*`); break; }
      try {
        const { downloadMediaMessage } = require('./helper/baileys');
        const buf = await downloadMediaMessage(
          { message: qmsg, key: { remoteJid: jid, id: m.message?.extendedTextMessage?.contextInfo?.stanzaId, fromMe: false } },
          'buffer', {},
          { logger: { info(){}, error(){}, warn(){}, debug(){}, child(){ return this; } } }
        );
        const sharp = require('sharp');
        const meta  = await sharp(buf).metadata();
        const size  = Math.min(meta.width||400, meta.height||400);
        const mask  = Buffer.from(`<svg><circle cx="${size/2}" cy="${size/2}" r="${size/2}"/></svg>`);
        const result = await sharp(buf)
          .resize(size, size, { fit: 'cover' })
          .composite([{ input: mask, blend: 'dest-in' }])
          .png()
          .toBuffer();
        await sock.sendMessage(jid, { image: result, caption: ft('⭕ Circle crop!', sock) }, { quoted: m });
      } catch { await reply(`❌ sharp not installed. Run: npm install sharp`); }
      break;
    }
    // ── STICKER BUILDERS ────────────────────────────────────
    case 'sticker2':
    case 'givensticker': {
      await reaction('🩹');
      const qmsgS = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      if (!qmsgS) { await reply(ft(`🩹 Reply to an image (or a sticker) with *${prefix}${cmd}* to turn it into a sticker.`, sock)); break; }
      if (qmsgS.videoMessage) { await reply(ft(`🎬 Video → sticker needs *ffmpeg*, which is not installed on this host. Convert the clip to a GIF and use *${prefix}gifsticker*.`, sock)); break; }
      if (!qmsgS.imageMessage && !qmsgS.stickerMessage) { await reply(ft(`🩹 The quoted message is not an image or a sticker. Reply to media with *${prefix}${cmd}*.`, sock)); break; }
      try {
        const bufS = await quotedBuffer(m);
        if (!bufS) throw new Error('could not download the quoted media');
        const packS = getPack(sock);
        const sticker = await toStickerWebp(bufS, packExif(packS, ['🩹']));
        await sock.sendMessage(jid, { sticker }, { quoted: m });
      } catch (e) { await reply(`❌ ${cmd} failed: ${e.message}`); }
      break;
    }

    case 'tomp4sticker': {
      await reaction('🎞️');
      const qmsgT = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      const urlT  = args.find(a => /^https?:\/\//i.test(a));
      if (!qmsgT && !urlT) { await reply(ft(`🎞️ Reply to an image with *${prefix}tomp4sticker* (or send *${prefix}tomp4sticker <image-url>*) to build a 512×512 sticker frame.`, sock)); break; }
      if (qmsgT && qmsgT.videoMessage) { await reply(ft(`🎞️ MP4 → sticker needs *ffmpeg* to extract frames, and ffmpeg is not installed on this host, so only still images can be processed here.`, sock)); break; }
      try {
        const sharp = require('sharp');
        let srcT;
        if (urlT) {
          const r = await axios.get(urlT, { responseType: 'arraybuffer', timeout: 12000 });
          srcT = Buffer.from(r.data || []);
        } else srcT = await quotedBuffer(m);
        if (!srcT || !srcT.length) throw new Error('could not download the media');
        const packT = getPack(sock);
        await sock.sendMessage(jid, { sticker: await toStickerWebp(srcT, packExif(packT, ['🎞️'])) }, { quoted: m });
      } catch (e) { await reply(`❌ tomp4sticker failed: ${e.message}`); }
      break;
    }

    case 'stickerinfo': {
      const qmsgI = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      if (!qmsgI?.stickerMessage) { await reply(ft(`🧾 Reply to a *sticker* with *${prefix}stickerinfo* to inspect its size, format and pack metadata.`, sock)); break; }
      await reaction('🧾');
      try {
        const sharp  = require('sharp');
        const bufI   = await quotedBuffer(m);
        const metaI  = await sharp(bufI, { animated: true }).metadata();
        const exifI  = readStickerExif(bufI);
        const fields = [
          `📦 Size: ${(bufI.length / 1024).toFixed(1)} KB`,
          `🖼️ Dimensions: ${metaI.width || '?'}×${metaI.height || '?'}`,
          `🧩 Format: ${String(metaI.format || 'unknown').toUpperCase()}`,
          `🎞️ Animated: ${metaI.pages && metaI.pages > 1 ? `yes (${metaI.pages} frames)` : 'no'}`,
        ];
        if (exifI) {
          if (exifI['sticker-pack-name']) fields.push(`🏷️ Pack: ${exifI['sticker-pack-name']}`);
          if (exifI['sticker-pack-publisher']) fields.push(`✍️ Author: ${exifI['sticker-pack-publisher']}`);
          if (Array.isArray(exifI.emojis) && exifI.emojis.length) fields.push(`😀 Emojis: ${exifI.emojis.join(' ')}`);
        } else fields.push('🏷️ Pack: no EXIF metadata embedded');
        await reply(ft(`🧾 *Sticker info*\n\n${fields.join('\n')}`, sock));
      } catch (e) { await reply(`❌ stickerinfo failed: ${e.message}`); }
      break;
    }

    case 'attp2': {
      if (!text) { await reply(ft(`🎨 *${prefix}attp2 <text>* — makes an animated text sticker.`, sock)); break; }
      await reaction('🎨');
      try {
        const { data } = await axios.get(
          `https://api.siputzx.my.id/api/sticker/attp?text=${encodeURIComponent(text.slice(0, 60))}`,
          { responseType: 'arraybuffer', timeout: 20000 }
        );
        const bufA = Buffer.from(data || []);
        if (!bufA.length) throw new Error('the sticker API returned an empty response');
        const packA = getPack(sock);
        await sock.sendMessage(jid, { sticker: addWebpExif(bufA, packExif(packA, ['🎨'])) }, { quoted: m });
      } catch (e) { await reply(`❌ attp2 failed: ${e.message}`); }
      break;
    }

    case 'emojisticker': {
      await reaction('😀');
      const found = text.match(/\p{Extended_Pictographic}/gu) || [];
      const e1    = found[0] || text.trim() || '😀';
      const e2    = found[1] || '';
      const packE = getPack(sock);
      try {
        const sharp = require('sharp');
        let srcE = null;
        if (e2) {
          const cp = (s) => Array.from(s).map(ch => ch.codePointAt(0).toString(16)).join('-');
          try {
            const r = await axios.get(
              `https://www.gstatic.com/android/keyboard/emojikitchen/20201001/u${cp(e1)}/u${cp(e1)}_u${cp(e2)}.png`,
              { responseType: 'arraybuffer', timeout: 12000 }
            );
            const cand = Buffer.from(r.data || []);
            if (cand.length > 100) srcE = cand;
          } catch { /* falls back to the locally rendered sticker below */ }
        }
        let sticker;
        if (srcE) {
          sticker = await toStickerWebp(srcE, packExif(packE, [e1, e2]));
        } else {
          const label = escXml(e1.length > 24 ? e1.slice(0, 24) : e1);
          const svg = Buffer.from(
            `<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512">` +
            `<rect width="512" height="512" fill="#111111"/>` +
            `<text x="256" y="300" font-size="200" font-family="Noto Color Emoji, DejaVu Sans, sans-serif" fill="#ffffff" text-anchor="middle">${label}</text>` +
            `</svg>`
          );
          sticker = await sharp(svg).resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } }).webp({ quality: 90 }).toBuffer();
          sticker = addWebpExif(sticker, packExif(packE, [e1]));
        }
        await sock.sendMessage(jid, { sticker }, { quoted: m });
      } catch (e) { await reply(`❌ emojisticker failed: ${e.message}`); }
      break;
    }

    case 'gifsticker': {
      await reaction('🎞️');
      const qmsgG = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      const urlG  = args.find(a => /^https?:\/\//i.test(a));
      if (!qmsgG && !urlG) { await reply(ft(`🎞️ Reply to a GIF (or send *${prefix}gifsticker <gif-url>*) to turn it into an animated sticker.`, sock)); break; }
      try {
        let srcG;
        if (urlG) {
          const r = await axios.get(urlG, { responseType: 'arraybuffer', timeout: 12000 });
          srcG = Buffer.from(r.data || []);
        } else srcG = await quotedBuffer(m);
        if (!srcG || !srcG.length) throw new Error('could not download the GIF');
        if (srcG.slice(0, 3).toString('ascii') !== 'GIF') {
          await reply(ft(`🎞️ That media is not a GIF. (MP4 video → sticker needs *ffmpeg*, which is not installed on this host.)`, sock));
          break;
        }
        const packG = getPack(sock);
        await sock.sendMessage(jid, { sticker: await toStickerWebp(srcG, packExif(packG, ['🎞️'])) }, { quoted: m });
      } catch (e) { await reply(`❌ gifsticker failed: ${e.message}`); }
      break;
    }

    case 'videosticker': {
      await reaction('🎬');
      const qmsgV = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      const urlV  = args.find(a => /^https?:\/\//i.test(a));
      if (!qmsgV && !urlV) { await reply(ft(`🎬 Reply to a short clip (or send *${prefix}videosticker <url>*) to make a sticker.`, sock)); break; }
      try {
        let srcV;
        if (urlV) {
          const r = await axios.get(urlV, { responseType: 'arraybuffer', timeout: 15000 });
          srcV = Buffer.from(r.data || []);
        } else srcV = await quotedBuffer(m);
        if (!srcV || !srcV.length) throw new Error('could not download the media');
        if (srcV.slice(0, 3).toString('ascii') !== 'GIF') {
          await reply(ft(`🎬 Video → sticker requires *ffmpeg* to extract frames, and ffmpeg is not installed on this host. Convert the clip to a GIF (then use *${prefix}gifsticker*) instead.`, sock));
          break;
        }
        const packV = getPack(sock);
        await sock.sendMessage(jid, { sticker: await toStickerWebp(srcV, packExif(packV, ['🎬'])) }, { quoted: m });
      } catch (e) { await reply(`❌ videosticker failed: ${e.message}`); }
      break;
    }

    case 'cropsticker': {
      await reaction('✂️');
      const qmsgC = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      if (!qmsgC?.imageMessage) { await reply(ft(`✂️ Reply to an image with *${prefix}cropsticker* to centre-crop it into a square sticker.`, sock)); break; }
      try {
        const sharp = require('sharp');
        const bufC  = await quotedBuffer(m);
        const metaC = await sharp(bufC).metadata();
        const size  = Math.min(metaC.width || 512, metaC.height || 512);
        const packC = getPack(sock);
        const cropped = await sharp(bufC)
          .resize(size, size, { fit: 'cover', position: 'centre' })
          .webp({ quality: 90 })
          .toBuffer();
        await sock.sendMessage(jid, { sticker: addWebpExif(cropped, packExif(packC, ['✂️'])) }, { quoted: m });
      } catch (e) { await reply(`❌ cropsticker failed: ${e.message}`); }
      break;
    }

    case 'colorsticker': {
      await reaction('🎨');
      const rawC = text.trim();
      try {
        const sharp  = require('sharp');
        const named  = ['red','blue','green','purple','orange','teal','pink','gold','black','white','cyan','magenta'];
        let color    = rawC.startsWith('#') ? rawC : (/^[0-9a-f]{3,8}$/i.test(rawC) ? `#${rawC}` : '');
        if (!color) color = named.includes(rawC.toLowerCase()) ? rawC.toLowerCase() : named[Math.floor(Math.random() * named.length)];
        const label  = escXml((rawC || color).slice(0, 18));
        const svg = Buffer.from(
          `<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512">` +
          `<rect width="512" height="512" fill="${color}"/>` +
          `<text x="256" y="286" font-size="64" font-family="DejaVu Sans, sans-serif" fill="#ffffff" text-anchor="middle">${label}</text>` +
          `</svg>`
        );
        const packCS = getPack(sock);
        const sticker = addWebpExif(await sharp(svg).webp({ quality: 90 }).toBuffer(), packExif(packCS, ['🎨']));
        await sock.sendMessage(jid, { sticker }, { quoted: m });
      } catch (e) { await reply(ft(`❌ *${rawC || '(empty)'}* is not a colour I can parse. Try *${prefix}colorsticker #ff5733* or a name like *red*.`, sock)); }
      break;
    }

    case 'imagetext': {
      if (!text) { await reply(ft(`🅰️ *${prefix}imagetext <text>* — reply to an image to write text on it.`, sock)); break; }
      await reaction('🅰️');
      const qmsgIT = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      if (!qmsgIT?.imageMessage) { await reply(ft(`🅰️ Reply to an image with *${prefix}imagetext ${text}*.`, sock)); break; }
      try {
        const sharp  = require('sharp');
        const bufIT  = await quotedBuffer(m);
        const metaIT = await sharp(bufIT).metadata();
        const W = metaIT.width || 512;
        const H = metaIT.height || 512;
        const lines = wrapText(text, 22).slice(0, 6);
        const size  = Math.max(18, Math.min(56, Math.floor(W / 14)));
        const tspans = lines.map((ln, i) => `<tspan x="${W / 2}" dy="${i === 0 ? 0 : Math.round(size * 1.2)}">${escXml(ln)}</tspan>`).join('');
        const baseY  = Math.max(size + 8, Math.floor(H - size * lines.length - 16));
        const overlay = Buffer.from(
          `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}">` +
          `<style>.c{font-family:DejaVu Sans, sans-serif;font-size:${size}px;fill:#ffffff;stroke:#000000;stroke-width:3;paint-order:stroke;text-anchor:middle}</style>` +
          `<text class="c" x="${W / 2}" y="${baseY}">${tspans}</text></svg>`
        );
        const out = await sharp(bufIT).composite([{ input: overlay }]).png().toBuffer();
        await sock.sendMessage(jid, { image: out, caption: ft(`🅰️ ${text}`, sock) }, { quoted: m });
      } catch (e) { await reply(`❌ imagetext failed: ${e.message}`); }
      break;
    }

    case 'stealsticker': {
      await reaction('🩹');
      const qmsgST = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      if (!qmsgST?.stickerMessage) { await reply(ft(`🩹 Reply to someone else's sticker with *${prefix}stealsticker* to re-pack it under your own pack name.`, sock)); break; }
      try {
        const bufST  = await quotedBuffer(m);
        if (!bufST) throw new Error('could not download the quoted sticker');
        const packST = getPack(sock);
        await sock.sendMessage(jid, { sticker: addWebpExif(bufST, packExif(packST, ['🩹'])) }, { quoted: m });
        await reply(ft(`🩹 Sticker stolen → pack *${packST.name}*`, sock));
      } catch (e) { await reply(`❌ stealsticker failed: ${e.message}`); }
      break;
    }

    case 'packname': {
      const packPN = getPack(sock);
      if (!text) {
        await reply(ft(`🏷️ *Sticker pack name:* ${packPN.name}\n\nChange it with *${prefix}packname <name>*\n_Kept in memory for this session only (no database writes)._`, sock));
        break;
      }
      packPN.name = text.slice(0, 60);
      await reply(ft(`✅ Sticker pack name set to *${packPN.name}*\n_Used by ${prefix}sticker2, ${prefix}cropsticker, ${prefix}gifsticker, ${prefix}stealsticker … (memory only)._`, sock));
      break;
    }

    case 'packauthor': {
      const packPA = getPack(sock);
      if (!text) {
        await reply(ft(`✍️ *Sticker pack author:* ${packPA.author}\n\nChange it with *${prefix}packauthor <name>*\n_Kept in memory for this session only (no database writes)._`, sock));
        break;
      }
      packPA.author = text.slice(0, 60);
      await reply(ft(`✅ Sticker pack author set to *${packPA.author}*\n_Used by ${prefix}sticker2, ${prefix}cropsticker, ${prefix}gifsticker, ${prefix}stealsticker … (memory only)._`, sock));
      break;
    }

    case 'exifsticker': {
      const packEX = getPack(sock);
      const qmsgEX = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      if (!qmsgEX?.stickerMessage) {
        await reply(ft(`🏷️ *Sticker metadata*\n\nPack name: ${packEX.name}\nPack author: ${packEX.author}\n\nReply to a sticker with *${prefix}exifsticker* to read its embedded EXIF pack data.`, sock));
        break;
      }
      await reaction('🏷️');
      try {
        const bufEX  = await quotedBuffer(m);
        const exifEX = readStickerExif(bufEX);
        if (!exifEX) { await reply(ft(`🏷️ This sticker has no WhatsApp EXIF pack metadata embedded.`, sock)); break; }
        const linesEX = [`📦 Pack id: ${exifEX['sticker-pack-id'] || 'n/a'}`];
        if (exifEX['sticker-pack-name']) linesEX.push(`🏷️ Pack name: ${exifEX['sticker-pack-name']}`);
        if (exifEX['sticker-pack-publisher']) linesEX.push(`✍️ Publisher: ${exifEX['sticker-pack-publisher']}`);
        if (Array.isArray(exifEX.emojis) && exifEX.emojis.length) linesEX.push(`😀 Emojis: ${exifEX.emojis.join(' ')}`);
        await reply(ft(`🏷️ *Sticker EXIF metadata*\n\n${linesEX.join('\n')}`, sock));
      } catch (e) { await reply(`❌ exifsticker failed: ${e.message}`); }
      break;
    }

    case 'togif': {
      await reaction('🎞️');
      const qmsgTG = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      if (!qmsgTG) { await reply(ft(`🎞️ Reply to a sticker or an image with *${prefix}togif* to convert it to a GIF.`, sock)); break; }
      if (qmsgTG.videoMessage) { await reply(ft(`🎬 Video → GIF requires *ffmpeg*, which is not installed on this host.`, sock)); break; }
      if (!qmsgTG.stickerMessage && !qmsgTG.imageMessage) { await reply(ft(`🎞️ Reply to a sticker or an image with *${prefix}togif*.`, sock)); break; }
      try {
        const sharp = require('sharp');
        const bufTG = await quotedBuffer(m);
        const gif   = await sharp(bufTG, { animated: true }).gif().toBuffer();
        await sock.sendMessage(jid, { video: gif, gifPlayback: true, caption: ft('🎞️ Converted to GIF', sock) }, { quoted: m });
      } catch (e) { await reply(`❌ togif failed: ${e.message}`); }
      break;
    }

    case 'giftext': {
      if (!text) { await reply(ft(`🎞️ *${prefix}giftext <text>* — renders your text on a GIF card.`, sock)); break; }
      await reaction('🎞️');
      try {
        const sharp = require('sharp');
        let gifBuf = null;
        try {
          const { data } = await axios.get(
            `https://api.siputzx.my.id/api/sticker/attp?text=${encodeURIComponent(text.slice(0, 60))}`,
            { responseType: 'arraybuffer', timeout: 15000 }
          );
          const cand = Buffer.from(data || []);
          if (cand.length > 100) gifBuf = await sharp(cand, { animated: true }).gif().toBuffer();
        } catch { /* falls back to a locally rendered card */ }
        let animated = false;
        if (!gifBuf) gifBuf = await textCardGif(wrapText(text, 18).slice(0, 4));
        else {
          const metaGT = await sharp(gifBuf, { animated: true }).metadata();
          animated = (metaGT.pages || 1) > 1;
        }
        if (animated) await sock.sendMessage(jid, { video: gifBuf, gifPlayback: true, caption: ft(`🎞️ ${text}`, sock) }, { quoted: m });
        else await sock.sendMessage(jid, { image: gifBuf, caption: ft(`🎞️ ${text}`, sock) }, { quoted: m });
      } catch (e) { await reply(`❌ giftext failed: ${e.message}`); }
      break;
    }

    case 'gifmeme': {
      const partsGM = String(text || '').split('|');
      const topGM   = (partsGM[0] || 'TOP TEXT').trim().toUpperCase();
      const botGM   = (partsGM[1] || 'BOTTOM TEXT').trim().toUpperCase();
      await reaction('😂');
      try {
        const sharp = require('sharp');
        let base = null;
        try {
          const { data: meme } = await axios.get('https://meme-api.com/gimme', { timeout: 8000 });
          if (meme && meme.url) {
            const r    = await axios.get(meme.url, { responseType: 'arraybuffer', timeout: 12000 });
            const cand = Buffer.from(r.data || []);
            if (cand.length > 100) base = await sharp(cand).resize(480, 480, { fit: 'cover' }).png().toBuffer();
          }
        } catch { /* falls back to a plain background */ }
        const W = 480, H = 480;
        const overlay = Buffer.from(
          `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}">` +
          `<style>.t{font-family:Impact, DejaVu Sans, sans-serif;font-size:44px;fill:#ffffff;stroke:#000000;stroke-width:2;paint-order:stroke;text-anchor:middle}</style>` +
          `<text class="t" x="${W / 2}" y="54">${escXml(topGM.slice(0, 22))}</text>` +
          `<text class="t" x="${W / 2}" y="${H - 24}">${escXml(botGM.slice(0, 22))}</text></svg>`
        );
        let out;
        if (base) out = await sharp(base).composite([{ input: overlay }]).gif().toBuffer();
        else {
          const bg = await sharp({ create: { width: W, height: H, channels: 4, background: '#1a1a2e' } }).png().toBuffer();
          out = await sharp(bg).composite([{ input: overlay }]).gif().toBuffer();
        }
        await sock.sendMessage(jid, { image: out, caption: ft(`😂 ${topGM} / ${botGM}`, sock) }, { quoted: m });
      } catch (e) { await reply(`❌ gifmeme failed: ${e.message}`); }
      break;
    }

    default:
      await reply(ft(`⚠️ *${prefix}${cmd}* — Reply to an image/video to use this command.`, sock));
      return false;
  }
  return true;
}

module.exports = { stickerHandler, STICKER_CMDS };
