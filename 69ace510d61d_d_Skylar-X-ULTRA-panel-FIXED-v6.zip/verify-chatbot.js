// ============================================================
//   verify-chatbot.js  --  chatbot gating + status features
// ------------------------------------------------------------
// Covers:
//   * trigger gate: replies only when TAGGED or REPLYING to the bot,
//     in groups AND DMs; silent otherwise
//   * ELITE endpoint success + failure paths
//   * per-message dedupe, mention stripping, command messages ignored
//   * status broadcast: auto view / auto like, LID participant
//     resolution, statusJidList, dedupe, and disabled = no-op
//
//   node verify-chatbot.js
// ============================================================
'use strict';

const fs   = require('fs');
const os   = require('os');
const path = require('path');

// ── 1. Stub the network ──────────────────────────────────────
const BOT_NUM   = '254700000000';
const BOT_JID   = `${BOT_NUM}@s.whatsapp.net`;
const OTHER_JID = '254711111111@s.whatsapp.net';
const GROUP_JID = '120363000000000000@g.us';
const SKYLAR_SITE = 'https://skylar-pairing.vercel.app';

let apiMode = 'ok';                 // 'ok' | 'fail'
const apiCalls = [];
const axios = require('axios');
axios.get = async (url) => {
  apiCalls.push(url);
  if (/eliteprotech-apis/.test(url)) {
    if (apiMode === 'fail') throw new Error('simulated upstream failure');
    return { data: { success: true, session: 'sess-1', response: 'Hello from the assistant.' }, status: 200 };
  }
  return { data: {}, status: 200 };
};
axios.post = async () => ({ data: {}, status: 200 });
axios.request = async () => ({ data: {}, status: 200 });
axios.create = () => axios;
global.fetch = async () => ({ ok: true, status: 200, json: async () => ({}), text: async () => '', arrayBuffer: async () => new ArrayBuffer(8) });

// ── 2. Stub socket ───────────────────────────────────────────
let sent = [];          // sendMessage calls that are visible messages
let reads = [];         // readMessages calls
let presence = [];      // sendPresenceUpdate calls

const baseSock = {
  user: { id: `${BOT_NUM}:1@s.whatsapp.net` },
  __waNum: BOT_NUM,
  __sessionId: `wa_chattest_${BOT_NUM}`,
  sendMessage: async (jid, content, opts) => {
    if (!(content && content.react && !content.text)) sent.push({ jid, content, opts });
    else sent.push({ jid, content, opts, isReaction: true });
    return { key: { id: 'MOCK_' + sent.length, remoteJid: jid }, message: content };
  },
  readMessages: async (keys) => { reads.push(keys); return true; },
  sendPresenceUpdate: async (type, jid) => { presence.push({ type, jid }); return true; },
  relayMessage: async (jid, message) => { sent.push({ jid, content: message, relayed: true }); return { key: { id: 'R' } }; },
};
const sock = new Proxy(baseSock, {
  get(t, p) {
    if (p in t) return t[p];
    if (typeof p === 'symbol') return undefined;
    return async () => ({ key: { id: 'MOCK' }, status: 200 });
  },
});

const messages = () => sent.filter(m => !m.isReaction);

// ── 3. Isolate on-disk state ─────────────────────────────────
const DB_DIR = path.join(__dirname, 'database');
const DB_SNAPSHOT = fs.mkdtempSync(path.join(os.tmpdir(), 'chat-db-'));
if (fs.existsSync(DB_DIR)) fs.cpSync(DB_DIR, DB_SNAPSHOT, { recursive: true });
const restore = () => {
  try {
    fs.rmSync(DB_DIR, { recursive: true, force: true });
    fs.cpSync(DB_SNAPSHOT, DB_DIR, { recursive: true });
    fs.rmSync(DB_SNAPSHOT, { recursive: true, force: true });
  } catch { /* best effort */ }
};
process.on('exit', restore);

function setSettings(extra = {}) {
  fs.writeFileSync(path.join(DB_DIR, 'settings.json'), JSON.stringify({
    [BOT_NUM]: { prefix: '.', mode: 'public', font: 0, botName: 'ULTRATEST', ...extra },
  }, null, 2));
}
function setChatbot(chats = []) {
  const data = {};
  for (const jid of chats) data[jid] = true;
  fs.writeFileSync(path.join(DB_DIR, 'chatbot_status.json'), JSON.stringify(data, null, 2));
}

// ── 4. Message builders ──────────────────────────────────────
const contexts = {
  plain:              {},
  mentionBot:         { mentionedJid: [BOT_JID] },
  replyToBot:         { participant: BOT_JID, quotedMessage: { conversation: 'bot said hi' } },
  replyToOther:       { participant: OTHER_JID, quotedMessage: { conversation: 'other said hi' } },
  replyToBotAlt:      { participant: `${BOT_NUM}:12@s.whatsapp.net`, quotedMessage: { conversation: 'bot said hi' } },
};

function msg({ body, group = false, name = 'plain', id = 'M' + Math.random().toString(36).slice(2, 9) }) {
  return {
    key: {
      remoteJid: group ? GROUP_JID : OTHER_JID,
      fromMe: false,
      id,
      participant: group ? OTHER_JID : undefined,
    },
    mtype: 'extendedTextMessage',
    message: { extendedTextMessage: { text: body, contextInfo: contexts[name] } },
    pushName: 'Tester',
  };
}

// ── 5. Assertions ────────────────────────────────────────────
const { handleMessage } = require('./case.js');
const results = [];
const check = (name, ok, detail = '') => results.push({ name, ok: !!ok, detail });
const reset = () => { sent = []; reads = []; presence = []; apiCalls.length = 0; };
const apiPrompt = () => {
  const hit = apiCalls.find(u => /eliteprotech-apis/.test(u));
  return hit ? decodeURIComponent(hit.split('prompt=')[1] || '') : null;
};

(async () => {
  // ══════════ CHATBOT GATING ══════════
  setSettings();
  setChatbot([]);
  reset();
  await handleMessage(sock, msg({ body: 'hello bot', group: true, name: 'mentionBot' }), { groupName: 'G' });
  check('chatbot OFF: tagged message -> no reply', messages().length === 0 && apiCalls.length === 0,
    `sends=${messages().length} api=${apiCalls.length}`);

  setChatbot([GROUP_JID]);
  reset();
  await handleMessage(sock, msg({ body: 'just chatting here', group: true, name: 'plain' }), { groupName: 'G' });
  check('GROUP plain (no tag) -> silent', messages().length === 0 && apiCalls.length === 0, `sends=${messages().length}`);

  reset();
  await handleMessage(sock, msg({ body: `@${BOT_NUM} what is up`, group: true, name: 'mentionBot' }), { groupName: 'G' });
  check('GROUP tagged -> one reply', messages().length === 1, `sends=${messages().length}`);
  check('GROUP tagged -> reply lands in the GROUP', messages()[0]?.jid === GROUP_JID, `jid=${messages()[0]?.jid}`);
  check('GROUP tagged -> mention stripped from prompt',
    apiPrompt() === 'what is up', `prompt=${JSON.stringify(apiPrompt())}`);
  check('GROUP tagged -> presence composing then paused',
    presence.some(p => p.type === 'composing') && presence.some(p => p.type === 'paused'),
    presence.map(p => p.type).join(','));

  reset();
  await handleMessage(sock, msg({ body: 'replying to the bot here', group: true, name: 'replyToBot' }), { groupName: 'G' });
  check('GROUP replying to bot -> one reply', messages().length === 1, `sends=${messages().length}`);

  reset();
  await handleMessage(sock, msg({ body: 'replying to the bot here', group: true, name: 'replyToBotAlt' }), { groupName: 'G' });
  check('GROUP reply to device-suffixed bot jid -> one reply', messages().length === 1, `sends=${messages().length}`);

  reset();
  await handleMessage(sock, msg({ body: 'replying to someone else', group: true, name: 'replyToOther' }), { groupName: 'G' });
  check('GROUP reply to another member -> silent', messages().length === 0, `sends=${messages().length}`);

  setChatbot([OTHER_JID]);
  reset();
  await handleMessage(sock, msg({ body: 'a plain message to you', group: false, name: 'plain' }), { groupName: '' });
  check('DM plain (chatbot on) -> silent (strict gate)', messages().length === 0, `sends=${messages().length}`);

  reset();
  await handleMessage(sock, msg({ body: 'answering your message', group: false, name: 'replyToBot' }), { groupName: '' });
  check('DM replying to bot -> one reply', messages().length === 1, `sends=${messages().length}`);
  check('DM reply lands in the DM', messages()[0]?.jid === OTHER_JID, `jid=${messages()[0]?.jid}`);

  reset();
  await handleMessage(sock, msg({ body: 'answering a mate', group: false, name: 'replyToOther' }), { groupName: '' });
  check('DM replying to another person -> silent', messages().length === 0, `sends=${messages().length}`);

  setChatbot([GROUP_JID]);
  reset();
  await handleMessage(sock, msg({ body: '.menu', group: true, name: 'mentionBot' }), { groupName: 'G' });
  const eliteHits = apiCalls.filter(u => /eliteprotech-apis/.test(u));
  check('command message never reaches the chatbot', eliteHits.length === 0,
    `eliteApi=${eliteHits.length} totalAxios=${apiCalls.length}`);

  reset();
  const dup = { body: `@${BOT_NUM} hello twice`, group: true, name: 'mentionBot', id: 'DUPLICATE_ID' };
  await handleMessage(sock, msg(dup), { groupName: 'G' });
  await handleMessage(sock, msg(dup), { groupName: 'G' });
  check('same message id processed once (dedupe)', messages().length === 1 && apiCalls.length === 1,
    `sends=${messages().length} api=${apiCalls.length}`);

  // ══════════ ELITE ENDPOINT PATHS ══════════
  reset();
  apiMode = 'fail';
  await handleMessage(sock, msg({ body: `@${BOT_NUM} are you there`, group: true, name: 'mentionBot' }), { groupName: 'G' });
  apiMode = 'ok';
  check('ELITE failure -> exactly one short error line',
    messages().length === 1 && /unavailable/i.test(messages()[0]?.content?.text || ''),
    `sends=${messages().length} text=${JSON.stringify(messages()[0]?.content?.text)}`);
  check('ELITE failure -> no fallback provider was tried',
    apiCalls.every(u => /eliteprotech-apis/.test(u)), apiCalls.join(' | ').slice(0, 120));

  reset();
  await handleMessage(sock, msg({ body: `@${BOT_NUM} ping`, group: true, name: 'mentionBot' }), { groupName: 'G' });
  check('ELITE success -> reply text passed through unchanged',
    messages()[0]?.content?.text === 'Hello from the assistant.',
    JSON.stringify(messages()[0]?.content?.text));
  check('reply is quoted to the triggering message', !!messages()[0]?.opts?.quoted);

  // ══════════ STATUS BROADCAST ══════════
  const statusMsg = (participant, id, extra = {}) => ({
    key: { remoteJid: 'status@broadcast', fromMe: false, id, participant, ...extra },
    mtype: 'imageMessage',
    message: { imageMessage: { caption: 'status' } },
    pushName: 'Poster',
  });

  setSettings({ autoViewStatus: false, autoLikeStatus: false });
  reset();
  await handleMessage(sock, statusMsg(OTHER_JID, 'ST1'), {});
  check('status: both off -> no read, no like',
    reads.length === 0 && messages().length === 0, `reads=${reads.length} sends=${messages().length}`);

  setSettings({ autoViewStatus: true, autoLikeStatus: false });
  reset();
  await handleMessage(sock, statusMsg(OTHER_JID, 'ST2'), {});
  check('status view on -> readMessages called once', reads.length === 1, `reads=${reads.length}`);
  check('status view on -> no reaction sent', messages().length === 0, `sends=${messages().length}`);
  check('status view -> key is normalised (status@broadcast + poster)',
    reads[0]?.[0]?.remoteJid === 'status@broadcast' && reads[0]?.[0]?.participant === OTHER_JID,
    JSON.stringify(reads[0]?.[0]));

  setSettings({ autoViewStatus: false, autoLikeStatus: true });
  reset();
  await handleMessage(sock, statusMsg(OTHER_JID, 'ST3'), {});
  const like = sent.find(m => m.content?.react);
  check('status like on -> one reaction sent', !!like, `sends=${sent.length}`);
  check('status like -> sent to status@broadcast', like?.jid === 'status@broadcast', `jid=${like?.jid}`);
  check('status like -> emoji ❤️', like?.content?.react?.text === '❤️', like?.content?.react?.text);
  check('status like -> statusJidList carries the poster',
    JSON.stringify(like?.opts?.statusJidList) === JSON.stringify([OTHER_JID]),
    JSON.stringify(like?.opts?.statusJidList));
  check('status like -> not viewed', reads.length === 0, `reads=${reads.length}`);

  setSettings({ autoViewStatus: true, autoLikeStatus: true });
  reset();
  await handleMessage(sock, statusMsg(OTHER_JID, 'ST4'), {});
  check('status both on -> view + like in one pass',
    reads.length === 1 && sent.filter(m => m.content?.react).length === 1,
    `reads=${reads.length} reacts=${sent.filter(m => m.content?.react).length}`);

  // LID participant: the alt/pn field must win over the raw LID
  reset();
  await handleMessage(sock, statusMsg('123456789012345@lid', 'ST5', { participantAlt: OTHER_JID }), {});
  check('status LID participant resolves to the real number',
    reads[0]?.[0]?.participant === OTHER_JID, JSON.stringify(reads[0]?.[0]?.participant));

  // duplicates and non-status traffic
  reset();
  await handleMessage(sock, statusMsg(OTHER_JID, 'ST6'), {});
  await handleMessage(sock, statusMsg(OTHER_JID, 'ST6'), {});
  check('status same id processed once', reads.length === 1, `reads=${reads.length}`);

  reset();
  await handleMessage(sock, { key: { remoteJid: 'status@broadcast', fromMe: false, id: 'ST7', participant: OTHER_JID },
    mtype: 'reactionMessage', message: { reactionMessage: { text: '❤️' } } }, {});
  check('status feed reaction ignored', reads.length === 0 && sent.length === 0,
    `reads=${reads.length} sends=${sent.length}`);


  // ── regressions found by the independent verifier ──────────
  setChatbot([GROUP_JID]);
  reset();
  await handleMessage(sock, msg({ body: `ping ${BOT_NUM} at noon`, group: true, name: 'plain' }), { groupName: 'G' });
  check('bare bot number in text (no @) -> silent', messages().length === 0 && apiCalls.length === 0,
    `sends=${messages().length} api=${apiCalls.length}`);

  reset();
  await handleMessage(sock, msg({ body: `@${BOT_NUM} hey there`, group: true, name: 'plain' }), { groupName: 'G' });
  check('hand-typed @number still triggers', messages().length === 1 && apiPrompt() === 'hey there',
    `sends=${messages().length} prompt=${JSON.stringify(apiPrompt())}`);

  // prefix-free chats: an unknown first word is conversation, not a command
  setSettings({ prefixfree: true });
  reset();
  await handleMessage(sock, msg({ body: `hello there @${BOT_NUM}`, group: true, name: 'plain' }), { groupName: 'G' });
  check('prefix-free: unknown word reaches the chatbot', messages().length === 1, `sends=${messages().length}`);

  reset();
  await handleMessage(sock, msg({ body: 'menu', group: true, name: 'plain' }), { groupName: 'G' });
  check('prefix-free: a real command still runs as a command', apiCalls.filter(u => /eliteprotech/.test(u)).length === 0,
    `eliteApi=${apiCalls.filter(u => /eliteprotech/.test(u)).length}`);
  setSettings();

  // captioned document reaches the chatbot as text
  reset();
  await handleMessage(sock, {
    key: { remoteJid: GROUP_JID, fromMe: false, id: 'DOC1', participant: OTHER_JID },
    mtype: 'documentMessage',
    message: { documentMessage: { caption: `@${BOT_NUM} summarise this`, contextInfo: { mentionedJid: [BOT_JID] } } },
    pushName: 'Tester',
  }, { groupName: 'G' });
  check('document caption triggers the chatbot', messages().length === 1, `sends=${messages().length}`);

  // ── report ─────────────────────────────────────────────────
  const failed = results.filter(r => !r.ok);
  console.log('\n============== CHATBOT + STATUS VERIFICATION ==============');
  for (const r of results) console.log(`${r.ok ? 'PASS' : 'FAIL'}  ${r.name}${r.detail ? `\n        ${r.detail}` : ''}`);
  console.log('-----------------------------------------------------------');
  console.log(`checks: ${results.length}   passed: ${results.length - failed.length}   failed: ${failed.length}`);
  console.log('===========================================================\n');
  process.exit(failed.length ? 1 : 0);
})().catch(e => { console.error('harness error:', e); process.exit(2); });
