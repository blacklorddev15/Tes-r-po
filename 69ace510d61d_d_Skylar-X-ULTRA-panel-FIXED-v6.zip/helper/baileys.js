// ============================================================
//   helper/baileys.js  –  single source for the Baileys build
// ------------------------------------------------------------
//   The project declares `blacklord-baileys` as its socket library,
//   but several modules used to hard-require `@whiskeysockets/baileys`,
//   which was never a declared dependency. Every media download
//   (sticker, toimg, vv, dev enc/dec, illusion filters) therefore threw
//   MODULE_NOT_FOUND at runtime.
//
//   This module resolves whichever Baileys build is actually installed
//   and exposes the media downloader with a safe fallback.
// ============================================================
'use strict';

const CANDIDATES = [
  'blacklord-baileys',
  '@whiskeysockets/baileys',
  'baileys',
  '@adiwajshing/baileys',
];

let lib = null;
let resolvedName = null;
const tried = [];

for (const name of CANDIDATES) {
  try {
    lib = require(name);
    resolvedName = name;
    break;
  } catch (e) {
    tried.push(`${name} (${e.code || e.message})`);
  }
}

if (!lib) {
  throw new Error(
    `[baileys] No Baileys package could be resolved. Tried: ${tried.join(', ')}. ` +
    `Install one of them (e.g. npm i blacklord-baileys) to enable media features.`
  );
}

// Some builds are transpiled ESM and keep everything under `default`.
const api = (lib && lib.default && typeof lib.default === 'object' && Object.keys(lib).length <= 1)
  ? lib.default
  : lib;

const loggerStub = {
  info() {}, error() {}, warn() {}, debug() {}, trace() {}, fatal() {},
  child() { return this; },
};

/**
 * Download media from a WhatsApp message.
 * Mirrors `downloadMediaMessage(message, type, options, ctx)` where
 * `message` is `{ message, key }`.
 */
async function downloadMediaMessage(message, type = 'buffer', options = {}, ctx = {}) {
  const context = { ...ctx, logger: (ctx && ctx.logger) || loggerStub };

  // Preferred: the build ships downloadMediaMessage directly.
  if (typeof api.downloadMediaMessage === 'function') {
    return api.downloadMediaMessage(message, type, options, context);
  }

  // Fallback: older builds only export the streaming downloader.
  const { downloadContentFromMessage } = api;
  if (typeof downloadContentFromMessage !== 'function') {
    throw new Error(`[baileys] ${resolvedName} exposes no media downloader`);
  }

  const inner = message?.message || {};
  const node = inner.imageMessage || inner.videoMessage || inner.audioMessage ||
               inner.documentMessage || inner.stickerMessage || inner;

  const kind = inner.imageMessage ? 'image'
    : inner.videoMessage ? 'video'
    : inner.audioMessage ? 'audio'
    : inner.documentMessage ? 'document'
    : inner.stickerMessage ? 'sticker'
    : 'image';

  const stream = await downloadContentFromMessage(node, kind);
  if (type === 'stream') return stream;

  const chunks = [];
  for await (const chunk of stream) chunks.push(chunk);
  return Buffer.concat(chunks);
}

module.exports = Object.assign({}, api, {
  downloadMediaMessage,
  __resolvedName: resolvedName,
});
