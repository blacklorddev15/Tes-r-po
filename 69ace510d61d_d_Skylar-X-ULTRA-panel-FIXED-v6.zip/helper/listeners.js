// ============================================================
//   helper/listeners.js  – ALL event listeners
//   antidelete, antilink, anticall, antimedia,
//   welcome/goodbye, group participant events
// ============================================================
'use strict';

const fs   = require('fs');
const path = require('path');

const { WAMessageStubType } = require('./baileys');
const REVOKE_STUB = WAMessageStubType?.REVOKE ?? 1;
const axios = require('axios');
const { readJSON, writeJSON, ensureDir } = require('./utils');
const { normNum, getGroupAdminInfo } = require('./groupAdmin');
const { retrieveMessage, getWaSettings, setWaSetting } = require('./function');
const { logInfo, logError, logWarn } = require('./logger');
const { generateWelcomeCard } = require('./welcomeImg');

const DB = (...f) => path.resolve(__dirname, '../database', ...f);
ensureDir(path.resolve(__dirname, '../database'));

// ── DB helpers ────────────────────────────────────────────────
function getDB(file) { return readJSON(DB(file), {}); }
function setDB(file, data) { writeJSON(DB(file), data); }
function getGroupFlag(file, jid)         { return !!(getDB(file)[jid]); }
function setGroupFlag(file, jid, val)    { const d = getDB(file); d[jid] = val; setDB(file, d); }

// ── Download media from baileys ───────────────────────────────
async function dlMedia(msgObj, keyObj) {
  const { downloadMediaMessage } = require('./baileys');
  return downloadMediaMessage(
    { message: msgObj, key: keyObj }, 'buffer', {},
    { logger: { info(){}, error(){}, warn(){}, debug(){}, child(){ return this; } } }
  );
}

// ── Blockquote formatting ─────────────────────────────────────
// Every recovered line is prefixed with "> " so WhatsApp renders the text as a
// quote block (same look as the bot's command replies).
function blockquoteText(txt) {
  return String(txt ?? '').split('\n').map(line => `> ${line}`).join('\n');
}

// ── Fetch image as buffer from URL ───────────────────────────
async function fetchImageBuffer(url) {
  if (!url) return null;
  try {
    const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 8000 });
    return Buffer.from(res.data);
  } catch { return null; }
}

// ════════════════════════════════════════════════════════════
//   ANTI-DELETE  –  100% complete, all types
// ════════════════════════════════════════════════════════════
// "Delete for everyone" does NOT arrive as `messages.delete` in this Baileys
// build. Utils/process-message.js delivers it as a `messages.update` carrying a
// REVOKE stub:
//   { key: {...}, update: { message: null, messageStubType: 1, key: <original key> } }
// `messages.delete` is only emitted for "delete for me" (chat-utils.js). So the
// revoke path has to be read from message updates, otherwise anti-delete never
// fires for the case that actually matters.
function revokedKeysFromUpdates(updates) {
  const keys = [];
  for (const u of updates || []) {
    const stub = u?.update?.messageStubType;
    if (stub === undefined || stub === null) continue;
    if (Number(stub) !== REVOKE_STUB && String(stub) !== 'REVOKE') continue;
    // `update.key` is the key of the deleted message; the outer key belongs to
    // the revoke protocol message itself.
    const k = u?.update?.key || u?.key;
    if (k?.id) keys.push(k);
  }
  return keys;
}

// ── Anti-delete capture (ELITE-PRO-V1 approach) ───────────────
// Ported from ELITE-PRO-V1 index.js. Every incoming message is mirrored to
// disk, so a deletion can still be recovered after the bot restarts -- the
// in-memory store alone loses everything on reboot. Files expire after
// 10 minutes and a sweeper prunes them, matching the reference's TTL.
const ANTI_DIR = path.resolve(__dirname, '../anti_delete');
const ANTI_TTL = 10 * 60 * 1000;
ensureDir(ANTI_DIR);

const antiSafe = (v) => String(v || '').replace(/[^\w@.\-]/g, '_');
const antiPath = (jid, id) => path.join(ANTI_DIR, `${antiSafe(jid)}_${antiSafe(id)}.json`);

function captureForAntiDelete(m) {
  try {
    if (!m?.key?.id || !m?.message) return;
    if (m.key.fromMe) return;
    if (m.key.remoteJid === 'status@broadcast') return;

    writeJSON(antiPath(m.key.remoteJid, m.key.id), {
      key: m.key, message: m.message, pushName: m.pushName || '', _ts: Date.now(),
    });
  } catch (e) {
    logError('AntiDelete', `capture failed: ${e.message}`);
  }
}

// Disk first (survives restarts), in-memory store as the fallback.
function loadStoredMessage(jid, id) {
  try {
    const fromDisk = readJSON(antiPath(jid, id), null);
    if (fromDisk?.message) return fromDisk;
  } catch { /* fall through */ }
  return retrieveMessage(jid, id);
}

function dropStoredMessage(jid, id) {
  try { fs.unlinkSync(antiPath(jid, id)); } catch { /* already gone */ }
}

const antiSweeper = setInterval(() => {
  try {
    const now = Date.now();
    for (const file of fs.readdirSync(ANTI_DIR)) {
      const p = path.join(ANTI_DIR, file);
      try {
        const content = readJSON(p, null);
        if (!content || now - (content._ts || 0) > ANTI_TTL) fs.unlinkSync(p);
      } catch { try { fs.unlinkSync(p); } catch {} }
    }
  } catch { /* directory missing */ }
}, 60 * 1000);
if (typeof antiSweeper.unref === 'function') antiSweeper.unref();

async function handleAntiDelete(sock, update) {
  const c = getWaSettings(sock.__waNum || '');
  if (!c.antidelete) return;

  // Deleted messages are delivered to the PAIRED NUMBER'S OWN DM
  // ("Message yourself") instead of being re-posted into the chat where the
  // deletion happened, so only the account owner sees the recovery.
  const selfNum = normNum(sock.__waNum || sock.user?.id || '');
  const inbox   = selfNum ? `${selfNum}@s.whatsapp.net` : null;

  const selfDigits = String(selfNum || '').replace(/\D/g, '');
  const isBot      = (jid) => !!selfDigits && String(jid || '').includes(selfDigits);

  for (const key of (update.keys || [])) {
    const data = loadStoredMessage(key.remoteJid, key.id);
    if (!data) continue;

    // Skip the account's own deletions. The event key normally carries
    // `fromMe`, but check the stored key as well so the guard holds even when
    // the update omits it.
    if (key.fromMe || data.key?.fromMe) continue;

    const sender = data.key.participant || data.key.remoteJid;
    const name   = data.pushName || normNum(sender);
    let   msg    = data.message;
    if (!msg) continue;

    // Also skip when the *deleter* is this account (reference behaviour: no
    // point reporting your own clean-up back to yourself).
    const deletedBy = key.participant || update?.participant || key.remoteJid;
    if (!key.fromMe && isBot(deletedBy) && isBot(sender)) continue;

    // Unwrap wrappers
    const WRAP = ['ephemeralMessage','viewOnceMessage','viewOnceMessageV2','viewOnceMessageV2Extension','documentWithCaptionMessage'];
    for (const w of WRAP) { if (msg[w]?.message) { msg = msg[w].message; break; } }

    const TYPE = Object.keys(msg).find(k =>
      !['senderKeyDistributionMessage','messageContextInfo','protocolMessage','reactionMessage'].includes(k)
    );
    if (!TYPE) continue;

    const srcJid     = key.remoteJid;
    const isGroupSrc = srcJid.endsWith('@g.us');
    let   srcLabel   = 'a private chat';
    if (isGroupSrc) {
      srcLabel = 'a group';
      try { const meta = await sock.groupMetadata(srcJid); srcLabel = meta?.subject || 'a group'; } catch {}
    } else {
      srcLabel = `DM with +${normNum(srcJid)}`;
    }

    logInfo('AntiDelete', `recovering ${TYPE} from ${name} -> ${inbox || srcJid}`);

    // Deliver to the paired number's DM; fall back to the source chat if the
    // DM send fails (e.g. no self-chat available), so nothing is ever lost.
    let dest   = inbox || srcJid;
    let inGroup = dest.endsWith('@g.us');

    const send = async (payload) => {
      const body = inGroup ? { ...payload, mentions: [sender] } : payload;
      try {
        return await sock.sendMessage(dest, body);
      } catch (e) {
        if (dest !== srcJid) {
          dest = srcJid;
          inGroup = true;
          return await sock.sendMessage(srcJid, { ...payload, mentions: [sender] });
        }
        throw e;
      }
    };

    // Note layout ported from ELITE-PRO-V1 (deleted-by / sender / chat), with
    // the whole block quoted so it reads as a blockquote in WhatsApp.
    const note = [
      '╭━━[ *× ANTI DELETE MESSAGES ×* ]━┉',
      `┣━ *Deleted:* @${normNum(sender)}`,
      '┣━',
      `┣━ *Sender:* *${name}*`,
      '┣━',
      `┣━ *Chat:* ${srcLabel}`,
      '╰━━━━━━━━━━━━━━━━━━━━┉',
    ].join('\n');
    const hdr = blockquoteText(note) + '\n\n';

    const notifyFail = async (label) => {
      try { await send({ text: `${hdr}🗑 Deleted ${label} [media unavailable]` }); } catch {}
    };

    try {
      // storeMessage() unwraps view-once wrappers, so the wrapper cases below
      // can never match. Use the recorded flag to label it correctly.
      if (data.viewOnce) {
        const buf = await dlMedia(msg, data.key).catch(() => null);
        if (TYPE === 'imageMessage' && buf)
          await send({ image: buf, caption: `${hdr}👁 Deleted View Once Image` });
        else if (TYPE === 'videoMessage' && buf)
          await send({ video: buf, caption: `${hdr}👁 Deleted View Once Video` });
        else
          await send({ text: `${hdr}👁 Deleted View Once [${TYPE.replace('Message', '')}]` });
        continue;
      }

      switch (TYPE) {

        case 'conversation':
        case 'extendedTextMessage': {
          const t = msg.conversation || msg.extendedTextMessage?.text || '';
          await send({ text: `${hdr}♻️ *Message:*\n${blockquoteText(t)}` });
          break;
        }

        case 'imageMessage': {
          const buf = await dlMedia(msg, data.key).catch(() => null);
          if (buf) await send({ image: buf, caption: `${hdr}${msg.imageMessage?.caption || ''}` });
          else await notifyFail('Image');
          break;
        }

        case 'videoMessage': {
          const buf = await dlMedia(msg, data.key).catch(() => null);
          if (buf) await send({ video: buf, caption: `${hdr}${msg.videoMessage?.caption || ''}` });
          else await notifyFail('Video');
          break;
        }

        case 'audioMessage': {
          const buf = await dlMedia(msg, data.key).catch(() => null);
          if (buf) {
            await send({ audio: buf, mimetype: 'audio/mp4', ptt: !!msg.audioMessage?.ptt });
            await send({ text: `${hdr}🎵 Deleted Audio` });
          } else await notifyFail('Audio');
          break;
        }

        case 'stickerMessage': {
          const buf = await dlMedia(msg, data.key).catch(() => null);
          if (buf) {
            await send({ sticker: buf });
            await send({ text: `${hdr}🌀 Deleted Sticker` });
          } else await notifyFail('Sticker');
          break;
        }

        case 'documentMessage':
        case 'documentWithCaptionMessage': {
          const docMsg = msg.documentMessage || msg.documentWithCaptionMessage?.message?.documentMessage;
          if (!docMsg) { await notifyFail('Document'); break; }
          const buf = await dlMedia({ documentMessage: docMsg }, data.key).catch(() => null);
          if (buf) {
            await send({ document: buf, fileName: docMsg.fileName || 'file', mimetype: docMsg.mimetype || 'application/octet-stream' });
            await send({ text: `${hdr}📄 Deleted Document` });
          } else await notifyFail('Document');
          break;
        }

        case 'contactMessage': {
          const vcard = msg.contactMessage?.vcard || '';
          await send({ contacts: { displayName: msg.contactMessage?.displayName || 'Contact', contacts: [{ vcard }] } });
          await send({ text: `${hdr}👤 Deleted Contact` });
          break;
        }

        case 'locationMessage': {
          const loc = msg.locationMessage;
          await send({ location: { degreesLatitude: loc?.degreesLatitude || 0, degreesLongitude: loc?.degreesLongitude || 0 } });
          await send({ text: `${hdr}📍 Deleted Location` });
          break;
        }

        case 'viewOnceMessage':
        case 'viewOnceMessageV2':
        case 'viewOnceMessageV2Extension': {
          const inner     = msg[TYPE]?.message || {};
          const innerType = Object.keys(inner).find(k => !['messageContextInfo'].includes(k));
          if (!innerType) { await send({ text: `${hdr}👁 Deleted View Once` }); break; }
          const buf = await dlMedia(inner, data.key).catch(() => null);
          if (innerType === 'imageMessage' && buf)
            await send({ image: buf, caption: `${hdr}👁 Deleted View Once Image` });
          else if (innerType === 'videoMessage' && buf)
            await send({ video: buf, caption: `${hdr}👁 Deleted View Once Video` });
          else
            await send({ text: `${hdr}👁 Deleted View Once [${innerType}]` });
          break;
        }

        case 'buttonsMessage':
        case 'templateMessage':
        case 'listMessage':
        case 'interactiveMessage':
        case 'buttonReplyMessage': {
          const b   = msg[TYPE];
          const txt = b?.contentText || b?.hydratedTemplate?.hydratedContentText || b?.description || b?.title || '[Interactive]';
          await send({ text: `${hdr}🗂 ${txt}` });
          break;
        }

        case 'pollCreationMessage':
        case 'pollCreationMessageV2':
        case 'pollCreationMessageV3': {
          const poll = msg[TYPE];
          await send({ text: `${hdr}📊 Deleted Poll: ${poll?.name || 'Unknown poll'}` });
          break;
        }

        default:
          await send({ text: `${hdr}🗑 Deleted [${TYPE.replace('Message', '')}]` });
          break;
      }
    } catch (e) {
      logError('AntiDelete', e.message);
      await notifyFail(TYPE.replace('Message', ''));
    }

    // Recovered -- the stored copy is no longer needed.
    dropStoredMessage(key.remoteJid, key.id);
  }
}

// ════════════════════════════════════════════════════════════
//   ANTILINK  –  full listener
// ════════════════════════════════════════════════════════════
const LINK_RE = /https?:\/\/|chat\.whatsapp\.com|t\.me\/|discord\.gg\/|bit\.ly\/|tinyurl\.com\//i;

async function checkAntilink(sock, m) {
  if (!m.key.remoteJid.endsWith('@g.us')) return;
  if (!getGroupFlag('antilink.json', m.key.remoteJid)) return;

  const body = [
    m.message?.conversation,
    m.message?.extendedTextMessage?.text,
    m.message?.imageMessage?.caption,
    m.message?.videoMessage?.caption,
  ].filter(Boolean).join(' ');

  if (!LINK_RE.test(body)) return;

  // Admins exempt
  const senderNum = normNum(m.key.participant || m.key.remoteJid);
  const { admins } = await getGroupAdminInfo(sock, m.key.remoteJid);
  if (admins.has(senderNum)) return;

  try { await sock.sendMessage(m.key.remoteJid, { delete: m.key }); } catch {}
  try {
    await sock.sendMessage(m.key.remoteJid, {
      text: `⚠️ @${senderNum} Links are not allowed here! Message deleted.`,
      mentions: [m.key.participant || m.key.remoteJid],
    });
  } catch {}
}

// ════════════════════════════════════════════════════════════
//   ANTIMEDIA  –  delete media from non-admins
// ════════════════════════════════════════════════════════════
async function checkAntiMedia(sock, m) {
  if (!m.key.remoteJid.endsWith('@g.us')) return;
  if (!getGroupFlag('antimedia.json', m.key.remoteJid)) return;

  const hasMedia = !!(
    m.message?.imageMessage || m.message?.videoMessage ||
    m.message?.audioMessage || m.message?.stickerMessage ||
    m.message?.documentMessage
  );
  if (!hasMedia) return;

  const senderNum = normNum(m.key.participant || m.key.remoteJid);
  const { admins } = await getGroupAdminInfo(sock, m.key.remoteJid);
  if (admins.has(senderNum)) return;

  try { await sock.sendMessage(m.key.remoteJid, { delete: m.key }); } catch {}
  try {
    await sock.sendMessage(m.key.remoteJid, {
      text: `🚫 @${senderNum} Media not allowed here.`,
      mentions: [m.key.participant || m.key.remoteJid],
    });
  } catch {}
}

// ════════════════════════════════════════════════════════════
//   ANTICALL
// ════════════════════════════════════════════════════════════
async function handleAntiCall(sock, call) {
  const c = getWaSettings(sock.__waNum || '');
  if (!c.anticall) return;
  for (const cCall of call) {
    if (cCall.status === 'offer') {
      try {
        await sock.rejectCall(cCall.id, cCall.from);
        await sock.sendMessage(cCall.from, { text: `❌ Sorry, I don't accept calls. Please text instead.` });
      } catch {}
    }
  }
}

// ════════════════════════════════════════════════════════════
//   WELCOME / GOODBYE  –  with generated image
// ════════════════════════════════════════════════════════════
// Track sent welcomes per session to avoid spam: jid+participant
const welcomeSent = new Set();

async function handleGroupParticipantsUpdate(sock, update) {
  const { id: groupJid, participants, action } = update;

  // WELCOME
  if (action === 'add' && getGroupFlag('welcome.json', groupJid)) {
    let groupPpUrl = null;
    try { groupPpUrl = await sock.profilePictureUrl(groupJid, 'image'); } catch {}

    let groupName = groupJid;
    try { const meta = await sock.groupMetadata(groupJid); groupName = meta.subject; } catch {}

    for (const participant of participants) {
      const dedupeKey = `${groupJid}:${participant}`;
      if (welcomeSent.has(dedupeKey)) continue;
      welcomeSent.add(dedupeKey);
      setTimeout(() => welcomeSent.delete(dedupeKey), 30000);

      const num  = normNum(participant);
      let ppUrl  = null;
      try { ppUrl = await sock.profilePictureUrl(participant, 'image'); } catch {}

      let pushName = num;
      try {
        const info = await sock.onWhatsApp(participant);
        if (info?.[0]?.name) pushName = info[0].name;
      } catch {}

      // Generate welcome card
      const cardBuf = await generateWelcomeCard({
        userName:   pushName,
        groupName,
        userPpUrl:  ppUrl,
        groupPpUrl,
      });

      const caption = `👋 *Welcome @${num}!*\n\nGlad to have you in *${groupName}*.\nPlease read the group rules and enjoy your stay! 🎉`;

      try {
        if (cardBuf) {
          await sock.sendMessage(groupJid, {
            image:    cardBuf,
            caption,
            mentions: [participant],
          });
        } else if (ppUrl) {
          // Fallback: fetch user profile pic and send as image (no canvas)
          try {
            const imgBuf = await fetchImageBuffer(ppUrl);
            if (imgBuf) {
              await sock.sendMessage(groupJid, {
                image:    imgBuf,
                caption,
                mentions: [participant],
              });
            } else {
              throw new Error('img fetch failed');
            }
          } catch {
            await sock.sendMessage(groupJid, {
              text:     caption,
              mentions: [participant],
            });
          }
        } else {
          // No profile pic at all – plain text welcome
          await sock.sendMessage(groupJid, {
            text:     caption,
            mentions: [participant],
          });
        }
      } catch (e) { logError('Welcome', e.message); }
    }
  }

  // GOODBYE
  if (action === 'remove' && getGroupFlag('goodbye.json', groupJid)) {
    let groupName = groupJid;
    try { const meta = await sock.groupMetadata(groupJid); groupName = meta.subject; } catch {}

    for (const participant of participants) {
      const num = normNum(participant);
      try {
        await sock.sendMessage(groupJid, {
          text:     `👋 *Goodbye @${num}!*\nWe'll miss you in *${groupName}*. Take care! 💜`,
          mentions: [participant],
        });
      } catch {}
    }
  }
}

// ── Exports for flag get/set (used by case.js commands) ──────
module.exports = {
  revokedKeysFromUpdates,
  captureForAntiDelete,
  blockquoteText,
  // listeners
  handleAntiDelete,
  checkAntilink,
  checkAntiMedia,
  handleAntiCall,
  handleGroupParticipantsUpdate,
  // flag helpers
  getGroupFlag,
  setGroupFlag,
};
