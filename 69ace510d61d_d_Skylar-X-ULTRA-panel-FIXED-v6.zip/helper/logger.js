// ============================================================
//   helper/logger.js  –  console output
// ------------------------------------------------------------
//   Style ported from June-Ultra (index.js -> global.log / lolcatjs
//   message banner), branded for this bot:
//     * every line carries a blue-bold  [ SKYLAR ULTRA ]  tag
//     * the per-message banner is drawn in rainbow (lolcat) and
//       uses the same field set as June's (Sent Time / Date /
//       Message Type / Sender Name / Chat ID / Group / Message)
//   lolcatjs is optional -- without it the banner prints uncoloured
//   instead of throwing.
// ============================================================
'use strict';

const chalk = require('chalk');

const lolcat = (() => {
  try { return require('lolcatjs'); } catch { return null; }
})();

const BRAND = 'SKYLAR ULTRA';
const BOX_TOP    = `┏━━━━━━━━━━━━━『  ${BRAND}  』━━━━━━━━━━━━━─`;
const BOX_BOTTOM = '┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━─ ⳹';

// ── The tagged logger (June's global.log) ────────────────────
//   log('text')                 -> [ SKYLAR ULTRA ] text
//   log('multi\nline', 'green')  -> tag on its own line, payload coloured
function skylarLog(msg, color = 'white', isErr = false) {
  const tag   = chalk.blue.bold(`[ ${BRAND} ]`);
  const paint = chalk[color] ? chalk[color](msg) : String(msg);
  const out   = isErr ? console.error : console.log;

  if (String(msg).includes('\n') || String(msg).includes('════')) out(tag, paint);
  else out(`${tag} ${paint}`);
}
global.log = skylarLog;

// ── Rainbow banner (June draws its message box with lolcat) ──
function banner(lines, rainbow = true) {
  const block = [BOX_TOP, ...lines, BOX_BOTTOM].join('\n');
  if (rainbow && lolcat && typeof lolcat.fromString === 'function') {
    try { lolcat.fromString(block); return; } catch { /* fall through */ }
  }
  console.log(block);
}

// ── Message type helpers ─────────────────────────────────────
const icons = {
  text: '💬', image: '🖼 ', video: '🎥', audio: '🎵', sticker: '🌀',
  document: '📄', location: '📍', contact: '👤', reaction: '❤️', poll: '📊',
  viewOnce: '👁 ', unknown: '❓',
};

function getMsgType(msg) {
  if (!msg) return 'unknown';
  if (msg.conversation || msg.extendedTextMessage)    return 'text';
  if (msg.imageMessage)     return 'image';
  if (msg.videoMessage)     return 'video';
  if (msg.audioMessage)     return 'audio';
  if (msg.stickerMessage)   return 'sticker';
  if (msg.documentMessage)  return 'document';
  if (msg.locationMessage)  return 'location';
  if (msg.contactMessage)   return 'contact';
  if (msg.reactionMessage)  return 'reaction';
  if (msg.pollCreationMessage) return 'poll';
  if (msg.viewOnceMessage || msg.viewOnceMessageV2) return 'viewOnce';
  return 'unknown';
}

function getMsgText(msg) {
  if (!msg) return '';
  return (
    msg.conversation ||
    msg.extendedTextMessage?.text ||
    msg.imageMessage?.caption ||
    msg.videoMessage?.caption ||
    msg.documentMessage?.caption ||
    msg.reactionMessage?.text ||
    msg.pollCreationMessage?.name ||
    msg.locationMessage ? `[${msg.locationMessage?.degreesLatitude?.toFixed(4)}, ${msg.locationMessage?.degreesLongitude?.toFixed(4)}]` :
    msg.contactMessage?.displayName ||
    ''
  );
}

function logMessage(m, chatMeta = {}) {
  try {
    const raw      = m.message;
    let realMsg    = raw;
    const wrappers = ['ephemeralMessage', 'viewOnceMessage', 'viewOnceMessageV2', 'viewOnceMessageV2Extension'];
    for (const w of wrappers) { if (realMsg?.[w]?.message) realMsg = realMsg[w].message; }

    const type   = getMsgType(realMsg);
    const icon   = icons[type] || icons.unknown;
    const text   = getMsgText(realMsg).slice(0, 300);
    const sender = String(m.key.participant || m.key.remoteJid || '').split('@')[0].split(':')[0].replace(/\D/g, '');
    const name   = m.pushName || sender;
    const jid    = m.key.remoteJid || '';
    const isGrp  = jid.endsWith('@g.us');
    const isChan = jid.endsWith('@newsletter');
    const tz     = process.env.TZ || 'Africa/Nairobi';

    const ts       = new Date(Number(m.messageTimestamp || 0) * 1000);
    const timeStr  = ts.toLocaleTimeString('en-GB', { timeZone: tz, hour12: false });
    const dayStr   = ts.toLocaleDateString('en-GB', { timeZone: tz, weekday: 'long' });
    const dateStr  = ts.toLocaleDateString('en-GB', { timeZone: tz });

    const lines = [
      `»  Sent Time: ${dayStr}, ${timeStr}`,
      `»  Date: ${dateStr}`,
      `»  Message Type: ${icon} ${type}`,
      `»  Sender Name: ${name}`,
      `»  Chat ID: ${jid.split('@')[0]}`,
    ];
    if (isGrp) {
      lines.push(`»  Group: ${chatMeta.groupName || '(unknown)'}`);
      lines.push(`»  Group JID: ${jid.split('@')[0]}`);
    } else {
      lines.push(`»  Chat: ${isChan ? 'CHANNEL' : 'DM'}`);
    }
    if (text) lines.push(`»  Message: ${text}`);

    banner(lines);
  } catch { /* logging must never take the bot down */ }
}

const logInfo    = (label, msg) => skylarLog(`[INFO]  ${label}${msg ? ` – ${msg}` : ''}`, 'cyan');
const logSuccess = (label, msg) => skylarLog(`[OK]    ${label}${msg ? ` – ${msg}` : ''}`, 'green');
const logWarn    = (label, msg) => skylarLog(`[WARN]  ${label}${msg ? ` – ${msg}` : ''}`, 'yellow', true);
const logError   = (label, msg) => skylarLog(`[ERR]   ${label}${msg ? ` – ${msg}` : ''}`, 'red', true);
const logSession = (sessionId, status) => {
  const dot = status === 'connected' ? '🟢' : status === 'reconnecting' ? '🟡' : '🔴';
  skylarLog(`session : ${sessionId} ${dot} ${status}`, 'white');
};

module.exports = {
  BRAND, skylarLog, banner,
  logMessage, logInfo, logSuccess, logWarn, logError, logSession,
  getMsgType, getMsgText,
};
