// games.js – 30+ Mini-Game Commands
'use strict';
const fs   = require('fs');
const path = require('path');

const DB  = path.resolve(__dirname, 'database/games.json');
const load = () => { try { return JSON.parse(fs.readFileSync(DB,'utf8')); } catch { return {}; } };
const save = d => fs.writeFileSync(DB, JSON.stringify(d,null,2));
const uid  = m => (m.key.participant||m.key.remoteJid).split('@')[0];

const GAMES_CMDS = [
  'tictactoe','rps2','quiz','typerace','hangman',
  'wordle','numberguess','akinator2','trivia2','riddle2',
  'memory','reaction','fasttype','scramble','anagram',
  'truthordare','neverhaveiever2','wouldyourather2',
  '8ball','fortune2','astrology','personatest','iq',
  'rank','xp','daily2','streak','badge',
  'leaderboard2','achievement2',
];
const TRIVIA_Q = [
  {q:'What is the capital of Japan?',a:'tokyo',opts:['Beijing','Tokyo','Seoul','Bangkok']},
  {q:'How many sides does a hexagon have?',a:'6',opts:['5','6','7','8']},
  {q:'Who painted the Mona Lisa?',a:'da vinci',opts:['Picasso','Da Vinci','Monet','Raphael']},
  {q:'What is the fastest land animal?',a:'cheetah',opts:['Lion','Cheetah','Horse','Leopard']},
  {q:'What gas do plants absorb?',a:'co2',opts:['Oxygen','CO2','Nitrogen','Hydrogen']},
  {q:'In what year did WW2 end?',a:'1945',opts:['1943','1944','1945','1946']},
  {q:'What is the largest planet?',a:'jupiter',opts:['Saturn','Jupiter','Uranus','Neptune']},
  {q:'What is H2O?',a:'water',opts:['Salt','Water','Acid','Oxygen']},
  {q:'Who wrote Harry Potter?',a:'rowling',opts:['Tolkien','Rowling','Martin','King']},
  {q:'What color is the sky?',a:'blue',opts:['Green','Blue','Red','Yellow']},
];

const RIDDLES = [
  {q:'I have hands but can\'t clap. What am I?',a:'clock'},
  {q:'The more you take, the more you leave behind. What am I?',a:'footsteps'},
  {q:'What has a head, a tail, but no body?',a:'coin'},
  {q:'I speak without a mouth and hear without ears. What am I?',a:'echo'},
  {q:'What can travel around the world while staying in a corner?',a:'stamp'},
  {q:'What gets wetter as it dries?',a:'towel'},
  {q:'What has cities but no houses, mountains but no trees, water but no fish?',a:'map'},
  {q:'Forward I am heavy, backwards I am not. What am I?',a:'ton'},
];

const SCRAMBLE_WORDS = ['𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶','MANGA','RAMEN','SUSHI','TOKYO','SAKURA','NINJA','SAMURAI','KATANA','KAWAII'];

// ── helpers for the persistent mini-games below ─────────────
const TTT_LINES = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
const tttWinner = b => {
  for (const [a,c,d] of TTT_LINES) if (b[a] && b[a]===b[c] && b[c]===b[d]) return b[a];
  return b.every(v=>v) ? 'draw' : null;
};
const tttBoard = b => [0,3,6].map(r => b.slice(r,r+3).map((v,i)=> v || String(r+i+1)).join(' | ')).join('\n');

const WORDLE_WORDS = ['MANGO','LEMON','TIGER','CLOUD','PIANO','RIVER','SUGAR','BRAIN','LIGHT','DREAM','STONE','HOUSE'];
const TYPERACE_PHRASES = [
  'the quick brown fox jumps over the lazy dog',
  'never gonna give you up never gonna let you down',
  'coding at midnight hits different',
  'anime is life and life is anime',
  'keep calm and drink coffee',
];
const ANAGRAM_WORDS = ['ELEPHANT','CHOCOLATE','ADVENTURE','KEYBOARD','UNIVERSE','MOUNTAIN','DINOSAUR','TELEPHONE'];
const h31     = seed => { let h = 0; for (let i = 0; i < seed.length; i++) h = Math.imul(31,h) + seed.charCodeAt(i) | 0; return Math.abs(h); };
const dayKey  = () => new Date().toISOString().slice(0,10);
const wordleEval = (guess, answer) => {
  const res  = Array(guess.length).fill('⬛');
  const pool = answer.split('');
  for (let i=0;i<guess.length;i++) if (guess[i]===answer[i]) { res[i]='🟩'; pool[i]=null; }
  for (let i=0;i<guess.length;i++) if (res[i]==='⬛') {
    const k = pool.indexOf(guess[i]);
    if (k !== -1) { res[i]='🟨'; pool[k]=null; }
  }
  return res.join('');
};

// Akinator character set + question tree (self-contained, no network)
const AKI_QS = [
  { key:'fictional', q:'Is your character fictional?' },
  { key:'anime',     q:'Is your character from an anime or manga?' },
  { key:'male',      q:'Is your character male?' },
  { key:'powers',    q:'Does your character have superpowers?' },
  { key:'human',     q:'Is your character human?' },
];
const AKI_CHARS = [
  { n:'Naruto',       a:{ fictional:'yes', anime:'yes', male:'yes', powers:'yes', human:'yes' } },
  { n:'Goku',         a:{ fictional:'yes', anime:'yes', male:'yes', powers:'yes', human:'no'  } },
  { n:'Pikachu',      a:{ fictional:'yes', anime:'yes', male:'no',  powers:'yes', human:'no'  } },
  { n:'Mickey Mouse', a:{ fictional:'yes', anime:'no',  male:'yes', powers:'no',  human:'no'  } },
  { n:'SpongeBob',    a:{ fictional:'yes', anime:'no',  male:'yes', powers:'no',  human:'no'  } },
  { n:'Elon Musk',    a:{ fictional:'no',  anime:'no',  male:'yes', powers:'no',  human:'yes' } },
  { n:'Taylor Swift', a:{ fictional:'no',  anime:'no',  male:'no',  powers:'no',  human:'yes' } },
];

async function gamesHandler(sock, m, cmd, args, helpers) {
  if (!GAMES_CMDS.includes(cmd)) return false;
  const { reply, ft, cfg, reaction } = helpers;
  const jid    = m.key.remoteJid;
  const prefix = cfg(sock).prefix || '.';
  const text   = args.join(' ');
  const sender = uid(m);
  const data   = load();

  switch (cmd) {
    case 'trivia2': {
      await reaction('🧠');
      const q    = TRIVIA_Q[Math.floor(Math.random()*TRIVIA_Q.length)];
      const opts = q.opts.map((o,i)=>`${i+1}. ${o}`).join('\n');
      // Store answer in game state
      if (!data.trivia) data.trivia = {};
      data.trivia[jid] = { answer: q.a, expires: Date.now()+30000 };
      save(data);
      await reply(ft(`🧠 *Trivia!*\n\n${q.q}\n\n${opts}\n\nReply with the number or answer in *30 seconds*!`, sock));
      break;
    }
    case 'riddle2': {
      await reaction('🔮');
      const r = RIDDLES[Math.floor(Math.random()*RIDDLES.length)];
      if (!data.riddle) data.riddle = {};
      data.riddle[jid] = { answer: r.a, expires: Date.now()+60000 };
      save(data);
      await reply(ft(`🔮 *Riddle!*\n\n_${r.q}_\n\nReply with the answer in *60 seconds*!`, sock));
      break;
    }
    case 'scramble': {
      await reaction('🔤');
      const word = SCRAMBLE_WORDS[Math.floor(Math.random()*SCRAMBLE_WORDS.length)];
      const scrambled = word.split('').sort(()=>Math.random()-0.5).join('');
      if (!data.scramble) data.scramble = {};
      data.scramble[jid] = { answer: word.toLowerCase(), expires: Date.now()+30000 };
      save(data);
      await reply(ft(`🔤 *Word Scramble!*\n\nUnscramble: *${scrambled}*\n\nReply with the answer in *30 seconds*!`, sock));
      break;
    }
    case 'numberguess': {
      await reaction('🎲');
      const num = Math.floor(Math.random()*100)+1;
      if (!data.guess) data.guess = {};
      data.guess[jid] = { number: num, tries: 5, expires: Date.now()+120000 };
      save(data);
      await reply(ft(`🎲 *Number Guess!*\n\nI'm thinking of a number between 1-100.\nYou have *5 tries*!\n\nUse *${prefix}guess <number>*`, sock));
      break;
    }
    case 'hangman': {
      await reaction('🎭');
      const words2 = ['JAVASCRIPT','TYPESCRIPT','NODEJS','EXPRESS','MONGODB','PYTHON','FLUTTER','ANDROID','FIREBASE','CLOUDFLARE'];
      const word2  = words2[Math.floor(Math.random()*words2.length)];
      const blanks = '_'.repeat(word2.length).split('').join(' ');
      if (!data.hangman) data.hangman = {};
      data.hangman[jid] = { word: word2, guessed: [], tries: 6, expires: Date.now()+300000 };
      save(data);
      await reply(ft(`🎭 *Hangman!*\n\n${blanks}\n\nLength: ${word2.length} letters\nTries left: 6\n\nUse *${prefix}guess <letter>*`, sock));
      break;
    }
    case 'rps2': {
      const choices = ['rock','paper','scissors'];
      const userChoice = args[0]?.toLowerCase();
      if (!choices.includes(userChoice)) { await reply(ft(`✊ *${prefix}rps2 rock/paper/scissors*`, sock)); break; }
      const botChoice  = choices[Math.floor(Math.random()*3)];
      const emoji      = { rock:'✊', paper:'✋', scissors:'✌️' };
      let result4;
      if (userChoice===botChoice) result4 = '🤝 Draw!';
      else if ((userChoice==='rock'&&botChoice==='scissors')||(userChoice==='paper'&&botChoice==='rock')||(userChoice==='scissors'&&botChoice==='paper')) result4 = '🎉 You win!';
      else result4 = '❌ You lose!';
      await reply(ft(`✊ *Rock Paper Scissors*\n\nYou: ${emoji[userChoice]} ${userChoice}\nBot: ${emoji[botChoice]} ${botChoice}\n\n${result4}`, sock));
      break;
    }
    case '8ball': {
      if (!text) { await reply(`🎱 *${prefix}8ball <question>*`); break; }
      const answers = ['It is certain ✅','Without a doubt ✅','Yes definitely ✅','You may rely on it ✅','Most likely ✅','Outlook good 🟡','Ask again later 🟡','Cannot predict now 🟡','Don\'t count on it ❌','My reply is no ❌','My sources say no ❌','Outlook not so good ❌','Very doubtful ❌'];
      await reply(ft(`🎱 *8-Ball*\n\n❓ ${text}\n\n💬 ${answers[Math.floor(Math.random()*answers.length)]}`, sock));
      break;
    }
    case 'iq': {
      const target2 = text || 'you';
      let h = 0;
      for (let i = 0; i < (sender+target2).length; i++) h = Math.imul(31,h)+(sender+target2).charCodeAt(i)|0;
      const iq = 70 + Math.abs(h) % 80;
      const level = iq>130?'🧠 Genius!':iq>110?'✨ Above average':iq>90?'😊 Average':iq>70?'😐 Below average':'🤔 Hmm...';
      await reply(ft(`🧠 *IQ Test: ${target2}*\n\nIQ: *${iq}*\n${level}`, sock));
      break;
    }
    case 'truthordare': {
      const truths  = ['What\'s your biggest fear?','Who was your first crush?','What\'s the most embarrassing thing you\'ve done?','What\'s your biggest secret?','When did you last lie?'];
      const dares   = ['Send a voice note singing for 10 seconds','Change your WhatsApp status to something embarrassing for 1 hour','Text your crush right now','Do 20 pushups','Call someone and say "I love you"'];
      const choice2 = Math.random()>0.5 ? 'Truth' : 'Dare';
      const list2   = choice2==='Truth' ? truths : dares;
      await reply(ft(`🎭 *Truth or Dare*\n\n${choice2==='Truth'?'🤔 TRUTH:':'💪 DARE:'}\n\n${list2[Math.floor(Math.random()*list2.length)]}`, sock));
      break;
    }
    case 'neverhaveiever2': {
      const statements = ['Never have I ever sent a text to the wrong person','Never have I ever pretended to be busy to avoid someone','Never have I ever lied about my age','Never have I ever stalked someone\'s social media for hours','Never have I ever faked being sick to skip work/school','Never have I ever cheated on a test','Never have I ever ghosted someone','Never have I ever cried watching an anime'];
      await reply(ft(`🍹 *Never Have I Ever*\n\n${statements[Math.floor(Math.random()*statements.length)]}\n\n_Drink if you have! 🤭_`, sock));
      break;
    }
    case 'wouldyourather2': {
      const questions = [['Have unlimited money but no friends','Have amazing friends but no money'],['Be able to fly','Be able to become invisible'],['Know how you die','Know when you die'],['Live in the past','Live in the future'],['Be famous but hated','Unknown but loved'],['Never use social media again','Never watch TV/Netflix again']];
      const q2 = questions[Math.floor(Math.random()*questions.length)];
      await reply(ft(`🤔 *Would You Rather*\n\nA: ${q2[0]}\n\nOR\n\nB: ${q2[1]}\n\nReply A or B!`, sock));
      break;
    }
    case 'personatest': {
      const personas = ['You are a chaotic thinker who thrives on creativity and hates routine.','You are a quiet observer who sees things others miss.','You are a social butterfly who lights up every room.','You are a strategic planner who always thinks 10 steps ahead.','You are a dreamer who lives between reality and imagination.','You are a natural leader who people gravitate toward.'];
      await reply(ft(`🌟 *Persona Reading*\n\n${personas[Math.floor(Math.random()*personas.length)]}`, sock));
      break;
    }
    case 'quiz': {
      const q3 = TRIVIA_Q[Math.floor(Math.random()*TRIVIA_Q.length)];
      await reply(ft(`📝 *Quick Quiz*\n\n${q3.q}\n\n${q3.opts.map((o,i)=>`${String.fromCharCode(65+i)}. ${o}`).join('\n')}`, sock));
      break;
    }
    case 'rank': {
      if (!data.xp) data.xp = {};
      const u  = data.xp[sender] || { xp:0, level:1 };
      const progress = Math.floor((u.xp / (u.level*100)) * 10);
      const bar2 = '█'.repeat(progress) + '░'.repeat(10-progress);
      await reply(ft(`⭐ *Your Rank*\n\n🏆 Level: ${u.level}\n📊 XP: ${u.xp}/${u.level*100}\n${bar2}`, sock));
      break;
    }
    case 'xp': {
      if (!data.xp) data.xp = {};
      if (!data.xp[sender]) data.xp[sender] = { xp:0, level:1 };
      data.xp[sender].xp += 10;
      if (data.xp[sender].xp >= data.xp[sender].level*100) {
        data.xp[sender].level++;
        data.xp[sender].xp = 0;
        save(data);
        await reply(ft(`🎉 *Level Up!* You are now Level ${data.xp[sender].level}!`, sock));
      } else {
        save(data);
        await reply(ft(`+10 XP! Total: ${data.xp[sender].xp}/${data.xp[sender].level*100}`, sock));
      }
      break;
    }
    case 'tictactoe': {
      await reaction('🎮');
      if (!data.ttt) data.ttt = {};
      let g = data.ttt[jid];
      if (!g || Date.now()-(g.at||0) > 30*60*1000) {
        g = { board: Array(9).fill(''), at: Date.now() };
        data.ttt[jid] = g;
        save(data);
        await reply(ft(`🎮 *Tic-Tac-Toe — New Game*\n\n${tttBoard(g.board)}\n\nYou are ❌ X. Play with *${prefix}tictactoe <1-9>*`, sock));
        break;
      }
      const mv = parseInt(args[0]);
      if (!mv || mv < 1 || mv > 9) {
        await reply(ft(`🎮 *Tic-Tac-Toe*\n\n${tttBoard(g.board)}\n\nPlay with *${prefix}tictactoe <1-9>*`, sock));
        break;
      }
      const sq = mv-1;
      if (g.board[sq]) { await reply(ft(`❌ Square ${mv} is taken!\n\n${tttBoard(g.board)}`, sock)); break; }
      g.board[sq] = 'X';
      let w = tttWinner(g.board);
      if (!w) {
        const free = g.board.map((v,i)=> v ? -1 : i).filter(i=>i>=0);
        if (free.length) g.board[free[Math.floor(Math.random()*free.length)]] = 'O';
        w = tttWinner(g.board);
      }
      g.at = Date.now();
      if (w) {
        delete data.ttt[jid];
        save(data);
        const res = w==='X' ? '🎉 *You win!*' : w==='O' ? '🤖 *Bot wins!*' : '🤝 *Draw!*';
        await reply(ft(`🎮 *Tic-Tac-Toe*\n\n${tttBoard(g.board)}\n\n${res}\n\nNew game: *${prefix}tictactoe*`, sock));
      } else {
        save(data);
        await reply(ft(`🎮 *Tic-Tac-Toe*\n\n${tttBoard(g.board)}\n\nYour move: *${prefix}tictactoe <1-9>*`, sock));
      }
      break;
    }
    case 'typerace': {
      await reaction('⌨️');
      if (!data.typerace) data.typerace = {};
      const tr = data.typerace[jid];
      const nowT = Date.now();
      if (!tr || nowT > (tr.expires||0)) {
        const phrase = TYPERACE_PHRASES[Math.floor(Math.random()*TYPERACE_PHRASES.length)];
        data.typerace[jid] = { phrase, expires: nowT+45000 };
        save(data);
        await reply(ft(`⌨️ *Type Race!*\n\nType this within 45 seconds:\n\n_${phrase}_\n\nUse *${prefix}typerace <the phrase>*`, sock));
        break;
      }
      if (!text) { await reply(ft(`⌨️ Type this:\n\n_${tr.phrase}_\n\nUse *${prefix}typerace <the phrase>*`, sock)); break; }
      if (text.trim().toLowerCase() === tr.phrase.toLowerCase()) {
        delete data.typerace[jid];
        if (!data.xp) data.xp = {};
        const u = data.xp[sender] || { xp:0, level:1 };
        u.xp += 25;
        if (u.xp >= u.level*100) { u.level++; u.xp = 0; }
        data.xp[sender] = u;
        save(data);
        await reply(ft(`✅ *Correct!* +25 XP (Level ${u.level})`, sock));
      } else {
        delete data.typerace[jid];
        save(data);
        await reply(ft(`❌ Not quite! The phrase was:\n_${tr.phrase}_\n\nTry again with *${prefix}typerace*`, sock));
      }
      break;
    }
    case 'wordle': {
      await reaction('🟩');
      if (!data.wordle) data.wordle = {};
      let wg = data.wordle[jid];
      if (!wg || Date.now() > (wg.expires||0)) {
        wg = { word: WORDLE_WORDS[Math.floor(Math.random()*WORDLE_WORDS.length)], rows: [], expires: Date.now()+15*60*1000 };
        data.wordle[jid] = wg;
        save(data);
        await reply(ft(`🟩 *Wordle!*\n\nGuess the *5-letter* word. You have *6* tries.\n\n⬛⬛⬛⬛⬛\n\nUse *${prefix}wordle <5-letter word>*`, sock));
        break;
      }
      const guess = (args[0]||'').toUpperCase();
      if (!/^[A-Z]{5}$/.test(guess)) {
        await reply(ft(`🟩 *Wordle* (${wg.rows.length}/6)\n\n${wg.rows.map(r=>r.pat+'  '+r.g).join('\n') || '⬛⬛⬛⬛⬛'}\n\nGuess a *5-letter word*: *${prefix}wordle <word>*`, sock));
        break;
      }
      wg.rows.push({ g: guess, pat: wordleEval(guess, wg.word) });
      const won  = guess === wg.word;
      const over = won || wg.rows.length >= 6;
      if (over) delete data.wordle[jid];
      save(data);
      const board = wg.rows.map(r=>r.pat+'  '+r.g).join('\n');
      if (won)        await reply(ft(`🟩 *Wordle* — solved in ${wg.rows.length}/6!\n\n${board}`, sock));
      else if (over)  await reply(ft(`🟥 *Wordle* — out of tries. The word was *${wg.word}*.\n\n${board}`, sock));
      else            await reply(ft(`🟩 *Wordle* (${wg.rows.length}/6)\n\n${board}\n\nKeep guessing: *${prefix}wordle <word>*`, sock));
      break;
    }
    case 'akinator2': {
      await reaction('🧞');
      if (!data.aki) data.aki = {};
      let ak = data.aki[jid];
      const ans = (args[0]||'').toLowerCase();
      if (!ak || Date.now()-(ak.at||0) > 30*60*1000) {
        ak = { pool: AKI_CHARS.map(c=>c.n), step: 0, at: Date.now() };
        data.aki[jid] = ak;
        save(data);
        await reply(ft(`🧞 *Akinator*\n\nThink of a character and answer *yes* or *no*.\n\n*Q1.* ${AKI_QS[0].q}\n\nReply: *${prefix}akinator2 yes* or *${prefix}akinator2 no*`, sock));
        break;
      }
      if (!['yes','no'].includes(ans)) {
        await reply(ft(`🧞 *Akinator* — Q${ak.step+1}: ${AKI_QS[ak.step].q}\n\nReply: *${prefix}akinator2 yes* or *${prefix}akinator2 no*`, sock));
        break;
      }
      const key = AKI_QS[ak.step].key;
      ak.pool = ak.pool.filter(n => {
        const c = AKI_CHARS.find(x=>x.n===n);
        const tag = c && c.a ? c.a[key] : 'no';
        return ans==='yes' ? tag==='yes' : tag!=='yes';
      });
      if (!ak.pool.length) ak.pool = AKI_CHARS.map(c=>c.n);
      ak.step++;
      ak.at = Date.now();
      if (ak.step >= AKI_QS.length || ak.pool.length === 1) {
        const guess = ak.pool[0];
        const steps = ak.step;
        delete data.aki[jid];
        save(data);
        await reply(ft(`🧞 *Akinator*\n\nAfter ${steps} question(s), I think you are thinking of... *${guess}*! 🎯\n\nPlay again: *${prefix}akinator2*`, sock));
      } else {
        save(data);
        await reply(ft(`🧞 *Akinator* — Q${ak.step+1}: ${AKI_QS[ak.step].q}\n\nReply: *${prefix}akinator2 yes* or *${prefix}akinator2 no*`, sock));
      }
      break;
    }
    case 'memory': {
      await reaction('🧠');
      if (!data.memory) data.memory = {};
      const mem = data.memory[jid];
      const input = (args[0]||'').trim();
      if (!mem || Date.now() > (mem.expires||0)) {
        const seq = Array.from({length:3}, () => Math.floor(Math.random()*10));
        data.memory[jid] = { seq, score: 0, expires: Date.now()+120000 };
        save(data);
        await reply(ft(`🧠 *Memory Game*\n\nMemorise: *${seq.join(' ')}*\n\nRepeat it with *${prefix}memory <digits>*`, sock));
        break;
      }
      if (!/^\d+$/.test(input)) {
        await reply(ft(`🧠 Repeat this sequence: *${mem.seq.join(' ')}*\n\nUse *${prefix}memory <digits>*`, sock));
        break;
      }
      const digits = input.split('').map(Number);
      const good = digits.length===mem.seq.length && digits.every((d,i)=>d===mem.seq[i]);
      if (!good) {
        const score = mem.score;
        const was   = mem.seq.join(' ');
        delete data.memory[jid];
        save(data);
        await reply(ft(`❌ Wrong! You cleared *${score}* round(s).\nThe sequence was *${was}*.\n\nPlay again: *${prefix}memory*`, sock));
        break;
      }
      mem.score++;
      mem.seq = [...mem.seq, Math.floor(Math.random()*10)];
      mem.expires = Date.now()+120000;
      save(data);
      await reply(ft(`✅ Correct! Round ${mem.score} cleared.\n\nNext: *${mem.seq.join(' ')}*\n\nRepeat: *${prefix}memory <digits>*`, sock));
      break;
    }
    case 'reaction': {
      if (!data.rxt) data.rxt = {};
      const rx = data.rxt[jid];
      const sub = (args[0]||'').toLowerCase();
      if (!rx || Date.now()-(rx.at||0) > 60000) {
        data.rxt[jid] = { at: Date.now() };
        save(data);
        await reply(ft(`⚡ *Reaction Test*\n\nGet ready...\n\nType *${prefix}reaction go* as fast as you can!`, sock));
        break;
      }
      if (sub === 'go') {
        const ms = Date.now() - rx.at;
        delete data.rxt[jid];
        save(data);
        const rating = ms<400?'⚡ Superhuman!':ms<800?'🔥 Very fast':ms<1500?'😊 Decent':'🐢 Slow';
        await reply(ft(`⚡ *Reaction: ${ms} ms*\n\n${rating}`, sock));
        break;
      }
      await reply(ft(`⚡ Type *${prefix}reaction go* to finish the reaction test!`, sock));
      break;
    }
    case 'fasttype': {
      await reaction('🏁');
      if (!data.fasttype) data.fasttype = {};
      const f = data.fasttype[jid];
      const nowF = Date.now();
      if (!f || nowF > (f.expires||0)) {
        const phrase = TYPERACE_PHRASES[Math.floor(Math.random()*TYPERACE_PHRASES.length)];
        data.fasttype[jid] = { phrase, started: nowF, expires: nowF+60000 };
        save(data);
        await reply(ft(`🏁 *Fast Type!*\n\nType this as fast as you can:\n\n_${phrase}_\n\nUse *${prefix}fasttype <the phrase>*`, sock));
        break;
      }
      if (!text) { await reply(ft(`🏁 Type this:\n\n_${f.phrase}_\n\nUse *${prefix}fasttype <the phrase>*`, sock)); break; }
      const secs = Math.max(0.1, (nowF - f.started)/1000);
      const okType = text.trim().toLowerCase() === f.phrase.toLowerCase();
      delete data.fasttype[jid];
      if (okType) {
        const wpm = Math.round((f.phrase.split(' ').length / secs) * 60);
        if (!data.xp) data.xp = {};
        const u = data.xp[sender] || { xp:0, level:1 };
        u.xp += 20;
        if (u.xp >= u.level*100) { u.level++; u.xp = 0; }
        data.xp[sender] = u;
        save(data);
        await reply(ft(`✅ *Correct!* ${secs.toFixed(1)}s — about *${wpm} WPM*\n+20 XP`, sock));
      } else {
        save(data);
        await reply(ft(`❌ Wrong text! Expected:\n_${f.phrase}_\n\nTry again with *${prefix}fasttype*`, sock));
      }
      break;
    }
    case 'anagram': {
      await reaction('🔀');
      if (!data.anagram) data.anagram = {};
      const an = data.anagram[jid];
      if (!an || Date.now() > (an.expires||0)) {
        const word = ANAGRAM_WORDS[Math.floor(Math.random()*ANAGRAM_WORDS.length)];
        let mixed = word;
        for (let i=0;i<12 && mixed===word;i++) mixed = word.split('').sort(()=>Math.random()-0.5).join('');
        data.anagram[jid] = { word, expires: Date.now()+90000 };
        save(data);
        await reply(ft(`🔀 *Anagram!*\n\nUnscramble: *${mixed}*\n\nHint: *${word.length}* letters\nUse *${prefix}anagram <word>*`, sock));
        break;
      }
      const guess2 = text.trim().toUpperCase();
      if (!guess2) { await reply(ft(`🔀 Unscramble the word — use *${prefix}anagram <word>*`, sock)); break; }
      if (guess2 === an.word) {
        delete data.anagram[jid];
        if (!data.xp) data.xp = {};
        const u = data.xp[sender] || { xp:0, level:1 };
        u.xp += 15;
        if (u.xp >= u.level*100) { u.level++; u.xp = 0; }
        data.xp[sender] = u;
        save(data);
        await reply(ft(`✅ *Correct!* The word was *${an.word}*.\n+15 XP`, sock));
      } else {
        save(data);
        await reply(ft(`❌ Not it — try again: *${prefix}anagram <word>*`, sock));
      }
      break;
    }
    case 'fortune2': {
      const fseed    = sender + dayKey();
      const fortunes = ['A golden opportunity is heading your way.','Someone you least expect will surprise you today.','Your patience will pay off very soon.','A small act of kindness returns multiplied.','Big changes are closer than they appear.','Trust your gut — it has been right lately.','An old friend will bring good news.','Money flows to you when you stop chasing it.'];
      const luck     = h31(fseed) % 101;
      const luckyNum = (h31(fseed+'num') % 99) + 1;
      await reply(ft(`🥠 *Daily Fortune*\n\n_"${fortunes[h31(fseed+'f') % fortunes.length]}"_\n\n🍀 Luck: ${luck}%\n🔢 Lucky number: ${luckyNum}`, sock));
      break;
    }
    case 'astrology': {
      const signs2 = ['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces'];
      const moods  = ['bold and restless','calm and grounded','curious and chatty','emotional and caring','dramatic and magnetic','analytical and sharp','balanced but torn','intense and focused','adventurous and blunt','ambitious and cold','dreamy and original','intuitive and soft'];
      const lines  = ['A surprise message changes your mood.','Focus on one task instead of ten.','Someone is quietly rooting for you.','Money matters need a second look.','Rest more — your energy is being tested.','A bold move pays off today.','Keep your plans to yourself for now.','Say yes to the thing you keep avoiding.'];
      const subject = (text || sender).trim();
      const sIdx    = h31(subject.toLowerCase()) % 12;
      const seed    = signs2[sIdx] + dayKey();
      await reply(ft(`♈ *Astrology: ${subject}*\n\n🔮 Sign: *${signs2[sIdx]}*\n✨ Mood: ${moods[sIdx]}\n🍀 Day score: ${h31(seed) % 101}%\n\n_"${lines[h31(seed+'l') % lines.length]}"_`, sock));
      break;
    }
    case 'daily2': {
      if (!data.daily2) data.daily2 = {};
      const rec = data.daily2[sender] || { last: 0, streak: 0 };
      const nowD = Date.now();
      const cd   = 24*60*60*1000;
      if (nowD - (rec.last||0) < cd) {
        const leftD = Math.ceil((cd - (nowD - (rec.last||0)))/3600000);
        await reply(ft(`⏰ Games daily already claimed!\n🔥 Streak: ${rec.streak||0} day(s)\nNext in ~${leftD}h`, sock));
        break;
      }
      rec.streak = (rec.last && nowD-rec.last < 2*cd) ? (rec.streak||0)+1 : 1;
      rec.last   = nowD;
      data.daily2[sender] = rec;
      if (!data.xp) data.xp = {};
      const u2 = data.xp[sender] || { xp:0, level:1 };
      const bonus = 50 + (rec.streak-1)*25;
      u2.xp += bonus;
      let leveled = false;
      if (u2.xp >= u2.level*100) { u2.level++; u2.xp = 0; leveled = true; }
      data.xp[sender] = u2;
      save(data);
      await reply(ft(`🎁 *Daily Games Bonus!*\n\n+${bonus} XP\n🔥 Streak: ${rec.streak} day(s)\n⭐ Level ${u2.level}${leveled?' (level up!)':''}`, sock));
      break;
    }
    case 'streak': {
      const recS = (data.daily2||{})[sender];
      const xpS  = (data.xp||{})[sender] || { xp:0, level:1 };
      const lastS = recS ? new Date(recS.last).toISOString().slice(0,10) : 'never';
      await reply(ft(`🔥 *Your Streak*\n\n📅 Last daily: ${lastS}\n🔥 Streak: ${recS?.streak||0} day(s)\n⭐ Level: ${xpS.level} (${xpS.xp}/${xpS.level*100} XP)\n\nClaim with *${prefix}daily2*`, sock));
      break;
    }
    case 'badge': {
      const xpB = (data.xp||{})[sender] || { xp:0, level:1 };
      const stB = ((data.daily2||{})[sender]?.streak) || 0;
      const badges = [
        ['🥉 Newcomer', xpB.level >= 1],
        ['🥈 Regular', xpB.level >= 3],
        ['🥇 Veteran', xpB.level >= 5],
        ['🔥 Streak Starter', stB >= 3],
        ['💎 Streak Master', stB >= 7],
      ];
      await reply(ft(`🏅 *Badges: ${sender}*\n\n${badges.map(([n,has])=> `${has?'✅':'🔒'} ${n}`).join('\n')}`, sock));
      break;
    }
    case 'leaderboard2': {
      const entries = Object.entries(data.xp||{})
        .map(([id,u]) => ({ id, level: u.level||1, xp: u.xp||0, total:(u.level||1)*100 + (u.xp||0) }))
        .sort((a,b)=>b.total-a.total).slice(0,10);
      const listLb = entries.map((e,i)=>`${i+1}. +${e.id} — Lv ${e.level} (${e.xp} XP)`).join('\n');
      await reply(ft(`🏆 *Games Leaderboard*\n\n${listLb || 'No players yet — play ' + prefix + 'xp'}`, sock));
      break;
    }
    case 'achievement2': {
      const xpA = (data.xp||{})[sender] || { xp:0, level:1 };
      const stA = ((data.daily2||{})[sender]?.streak) || 0;
      const ach = [
        ['🎮 First Steps — earn any XP', xpA.level >= 1],
        ['🧠 Quiz Whiz — reach level 3', xpA.level >= 3],
        ['🏆 Grandmaster — reach level 10', xpA.level >= 10],
        ['📅 3-Day Streak', stA >= 3],
        ['🗓️ 7-Day Streak', stA >= 7],
      ];
      await reply(ft(`🎖️ *Achievements: ${sender}*\n\n${ach.map(([n,un])=> `${un?'✅':'🔒'} ${n}`).join('\n')}`, sock));
      break;
    }
    default: return false;
  }
  return true;
}

module.exports = { gamesHandler, GAMES_CMDS };
