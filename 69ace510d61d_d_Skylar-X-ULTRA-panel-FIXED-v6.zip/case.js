// ============================================================
//   case.js  v5  –  WhatsApp commands  (switch/case)
// ============================================================
'use strict';

const fs    = require('fs');
const path  = require('path');
const axios = require('axios');
const { exec } = require('child_process');

const settings = require('./settings');
const { convertFont, formatUptime, getDateTime, normalizeJid, readJSON, writeJSON, ensureDir } = require('./helper/utils');
const { logMessage, logInfo, logError } = require('./helper/logger');
const {
  getWaSettings, setWaSetting,
  addPremium, removePremium, isPremium,
  storeMessage, retrieveMessage, numOf,
} = require('./helper/function');
const { normNum, getTargetJid, getGroupAdminInfo } = require('./helper/groupAdmin');
const { getGroupFlag, setGroupFlag, captureForAntiDelete } = require('./helper/listeners');
const { devHandler, DEV_CMDS }       = require('./dev-commands');
const { reactionHandler, REACTION_CMDS } = require('./helper/reactions');
const { scrapsHandler,  SCRAPS_CMDS }  = require('./scraps');
const { illusionHandler, ILLUSION_CMDS } = require('./illusion');
const { socialHandler,  SOCIAL_CMDS }  = require('./social');
const { aiHandler,      AI_CMDS }      = require('./ai');
const { economyHandler, ECON_CMDS }    = require('./economy');
const { toolsHandler,   TOOLS_CMDS }   = require('./tools');
const { stickerHandler, STICKER_CMDS } = require('./stickers');
const { musicHandler,   MUSIC_CMDS }   = require('./music');
const { gamesHandler,   GAMES_CMDS }   = require('./games');
const { adminHandler,   ADMIN_CMDS }   = require('./admin');
const { arabicHandler,  ARABIC_CMDS }  = require('./arabic');

// ════════════════════════════════════════════════════════════
//   NEWSLETTER FORWARDING  – replies carry the "Forwarded" tag
//   from the SKYLAR X ULTRA channel
// ════════════════════════════════════════════════════════════
const NEWSLETTER_JID  = '120363407629340544@newsletter';
const NEWSLETTER_NAME = 'SKYLAR X ULTRA';

const NEWSLETTER_CONTEXT = {
  forwardingScore: 999,
  isForwarded: true,
  forwardedNewsletterMessageInfo: {
    newsletterJid: NEWSLETTER_JID,
    newsletterName: NEWSLETTER_NAME,
    serverMessageId: -1,
  },
};

function addNewsletterContext(messageContent) {
  return {
    ...messageContent,
    contextInfo: { ...(messageContent.contextInfo || {}), ...NEWSLETTER_CONTEXT },
  };
}

// ════════════════════════════════════════════════════════════
//   INTERACTIVE BUTTONS  –  blacklord-bttns
//   https://github.com/blacklorddev15/blacklord-btns
// ════════════════════════════════════════════════════════════
const SKYLAR_SITE = 'https://skylar-pairing.vercel.app';

// Build + relay a native-flow buttons message the way this codebase already
// does it elsewhere (see the interactive blocks further down this file).
//
// Why not just use blacklord-bttns' sendButtons()? Its own README documents
//   viewOnce?: boolean  // default true -- REQUIRED by current WhatsApp clients
//                       // to render native-flow buttons correctly
// but the implementation never applies it ("interactiveMessage goes at the top
// level"). Without the viewOnceMessage wrapper current WhatsApp clients accept
// the send and then silently drop the buttons -- no error, no button.
async function sendInteractiveButtons(sock, jid, { title, text, footer, buttons, quoted, contextInfo, imageMessage } = {}) {
  const { generateWAMessageFromContent, proto } = require('./helper/baileys');
  if (!proto) throw new Error('baileys proto unavailable');

  // An image header lets one interactive message carry media + body + button
  // at once. The caller passes an already-uploaded imageMessage (see
  // menuHeaderImage below); without one the header stays text-only.
  const header = proto.Message.InteractiveMessage.Header.fromObject({
    title: String(title || ''),
    hasMediaAttachment: !!imageMessage,
  });
  if (imageMessage) header.imageMessage = imageMessage;

  const interactive = proto.Message.InteractiveMessage.fromObject({
    body:   proto.Message.InteractiveMessage.Body.fromObject({ text: String(text || '') }),
    footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: String(footer || '') }),
    header,
    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
      messageVersion: 1,
      buttons: (buttons || []).map(b => ({
        name: b.name,
        buttonParamsJson: b.buttonParamsJson || JSON.stringify(b.params || {}),
      })),
    }),
    ...(contextInfo ? { contextInfo } : {}),
  });

  const msg = await generateWAMessageFromContent(jid, {
    viewOnceMessage: {
      message: {
        messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
        interactiveMessage: interactive,
      },
    },
  }, { quoted, userJid: sock.user?.id });

  await sock.relayMessage(msg.key.remoteJid, msg.message, {
    messageId: msg.key.id,
    additionalNodes: [{
      tag: 'biz',
      attrs: {},
      content: [{
        tag: 'interactive',
        attrs: { type: 'native_flow', v: '1' },
        content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }],
      }],
    }],
  });

  return msg;
}

// ════════════════════════════════════════════════════════════
//   MENU HEADER IMAGE  –  uploaded once, reused across .menu calls
// ------------------------------------------------------------
// The menu image rides inside the interactive message as the *header*
// media, so the menu is a single message (image + full list + button).
// WhatsApp media is addressed per upload, so the uploaded imageMessage is
// cached and reused -- without the cache every .menu would pay a media
// round trip before the menu appears.
// ════════════════════════════════════════════════════════════
const MENU_HEADER_TTL = 30 * 60 * 1000;   // 30 minutes
let _menuHeader = { key: null, imageMessage: null, at: 0 };

async function loadImageBuffer(src) {
  if (typeof src !== 'string' || !src) return null;
  if (src.startsWith('data:')) {
    const b64 = src.split(',')[1];
    return b64 ? Buffer.from(b64, 'base64') : null;
  }
  if (src.startsWith('http')) {
    const res = await axios.get(src, { responseType: 'arraybuffer', timeout: 12000 });
    return Buffer.from(res.data);
  }
  return fs.readFileSync(src);
}

async function menuHeaderImage(sock, src) {
  if (_menuHeader.key === src && _menuHeader.imageMessage &&
      Date.now() - _menuHeader.at < MENU_HEADER_TTL) {
    return _menuHeader.imageMessage;
  }

  const { prepareWAMessageMedia } = require('./helper/baileys');
  const buf = await loadImageBuffer(src);
  // A truncated fetch is worse than no image at all -- the client would
  // render a broken header -- so require a plausible image size.
  if (!buf || buf.length < 200) return null;

  const media = await prepareWAMessageMedia({ image: buf }, { upload: sock.waUploadToServer });
  const imageMessage = media && media.imageMessage;
  if (!imageMessage) return null;

  _menuHeader = { key: src, imageMessage, at: Date.now() };
  return imageMessage;
}

let _bttns;
function bttns() {
  if (_bttns !== undefined) return _bttns;
  try {
    // blacklord-bttns is ESM; Node >=22 can require() it directly.
    _bttns = require('blacklord-bttns');
  } catch (e) {
    console.log('[buttons] blacklord-bttns unavailable:', e.message);
    _bttns = false;
  }
  return _bttns;
}

const DB = (...f) => path.resolve(__dirname, 'database', ...f);
ensureDir(path.resolve(__dirname, 'database'));

// ════════════════════════════════════════════════════════════
//   STICKER COMMANDS STORAGE
// ════════════════════════════════════════════════════════════
const stickerCmdsFile = path.join(__dirname, 'database', 'sticker_commands.json');

function getStickerCommands() {
    try {
        return JSON.parse(fs.readFileSync(stickerCmdsFile, 'utf8'));
    } catch {
        return {};
    }
}

function setStickerCommand(hash, command) {
    const data = getStickerCommands();
    if (!command) delete data[hash];
    else data[hash] = command;
    fs.writeFileSync(stickerCmdsFile, JSON.stringify(data, null, 2));
}

// ════════════════════════════════════════════════════════════
//   CHATBOT STATUS PERSISTENCE
// ════════════════════════════════════════════════════════════
const chatbotStatusFile = path.join(__dirname, 'database', 'chatbot_status.json');

function getChatbotStatus(chatJid) {
    try {
        const data = JSON.parse(fs.readFileSync(chatbotStatusFile, 'utf8'));
        return data[chatJid] || false;
    } catch {
        return false;
    }
}
function setChatbotStatus(chatJid, status) {
    let data = {};
    try { data = JSON.parse(fs.readFileSync(chatbotStatusFile, 'utf8')); } catch {}
    data[chatJid] = status;
    fs.writeFileSync(chatbotStatusFile, JSON.stringify(data, null, 2));
}

// ════════════════════════════════════════════════════════════
//   POLL STORAGE  (one active poll per chat)
// ════════════════════════════════════════════════════════════
const pollsFile = path.join(__dirname, 'database', 'polls.json');

function loadPolls() {
  try { return JSON.parse(fs.readFileSync(pollsFile, 'utf8')); } catch { return {}; }
}
function savePolls(data) {
  try { fs.writeFileSync(pollsFile, JSON.stringify(data, null, 2)); } catch {}
}
function getPoll(chatJid) { return loadPolls()[chatJid] || null; }
function setPoll(chatJid, poll) {
  const all = loadPolls();
  all[chatJid] = poll;
  savePolls(all);
}
function clearPoll(chatJid) {
  const all = loadPolls();
  delete all[chatJid];
  savePolls(all);
}

// Called from the socket's `messages.update` event with Baileys poll updates.
function handlePollVotes(updates) {
  let changed = false;
  const all = loadPolls();

  for (const update of updates || []) {
    const pollUpdates = update?.update?.pollUpdates || update?.pollUpdates || [];
    for (const pu of pollUpdates) {
      const pollKey = pu?.pollUpdateMessageKey || {};
      const chatJid = pollKey.remoteJid || update?.key?.remoteJid;
      const poll    = all[chatJid];
      if (!poll) continue;

      const voter = normNum(pollKey.participant || pollKey.remoteJid || '');
      if (!voter) continue;

      poll.votes = poll.votes || {};
      const selected = pu?.vote?.selectedOptions || [];

      if (selected.length) {
        const idx = poll.options.indexOf(selected[0]?.name);
        if (idx !== -1) { poll.votes[voter] = idx; changed = true; }
      } else if (pu?.vote === null && poll.votes[voter] !== undefined) {
        delete poll.votes[voter];   // vote retracted
        changed = true;
      }
    }
  }

  if (changed) savePolls(all);
  return changed;
}

// ════════════════════════════════════════════════════════════
//   SHARED HELPERS
// ════════════════════════════════════════════════════════════

function cfg(sock) {
  const waNum = sock.__waNum || (sock.user?.id ? normNum(sock.user.id) : 'default');
  return getWaSettings(waNum);
}

function ft(txt, sock) { return convertFont(String(txt), cfg(sock).font || 0); }

function getQuoted(m) {
  const ctx = m.message?.extendedTextMessage?.contextInfo;
  if (!ctx?.quotedMessage) return { qMsg: null, qType: null, qKey: null };
  const qMsg  = ctx.quotedMessage;
  const qType = Object.keys(qMsg).find(k => !['senderKeyDistributionMessage','messageContextInfo'].includes(k));
  const qKey  = {
    remoteJid:   m.key.remoteJid,
    id:          ctx.stanzaId,
    fromMe:      false,
    participant: ctx.participant,
  };
  return { qMsg, qType, qKey };
}

async function dlMedia(msgObj, keyObj) {
  const { downloadMediaMessage } = require('./helper/baileys');
  return downloadMediaMessage(
    { message: msgObj, key: keyObj }, 'buffer', {},
    { logger: { info(){}, error(){}, warn(){}, debug(){}, child(){ return this; } } }
  );
}
// ─── Auto‑Read Helper ──────────────────────────────────────
async function autoReadMessage(sock, messageKey) {
    try {
        await sock.readMessages([messageKey]);
        return true;
    } catch (err) {
        // silently fail
        return false;
    }
}
// Some upstream APIs return plain text, others JSON. Interpolating a JSON
// body directly produced replies like "🔗 [object Object]".
function asPlainText(v) {
  if (v === null || v === undefined) return '';
  if (typeof v === 'string') return v;
  if (Buffer.isBuffer(v)) return v.toString('utf8');
  if (typeof v === 'object') {
    return v.url || v.shorturl || v.result || v.text || v.message || JSON.stringify(v);
  }
  return String(v);
}

async function getBuffer(url) {
  const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 15000 });
  return Buffer.from(res.data);
}

async function runAutoFollow(sock) {
  for (const nl of (settings.AUTO_FOLLOW_NEWSLETTERS || [])) {
    try { await sock.newsletterFollow(nl); } catch (e) { process.stdout.write('[autofollow] ' + nl + ' => ' + e.message + '\n'); }
  }
  for (const link of (settings.AUTO_JOIN_GROUPS || [])) {
    try {
      const code = link.split('chat.whatsapp.com/')[1];
      if (code) await sock.groupAcceptInvite(code);
    } catch (e) { process.stdout.write('[autojoin] ' + link + ' => ' + e.message + '\n'); }
  }
}

// ── Command list for dynamic menu (optional) ──────────────
const CMDS = {
  Owner:     ['setprefix','setowner','setbotname','setmenuimg','setbotimg','setfonts','public','self','addprem','delprem','antidelete','iphonemode','autoviewstatus','autolikestatus','anticall','block','unblock','listblocked','broadcast','pair','delpair'],
  Group:     ['promote','demote','kick','mute','unmute','tagall','tagadmins','grouplink','revoke','groupinfo','setgname','setgdesc','hidetag','warn','resetwarn','warnings','antilink','antimedia','welcome','goodbye','lock','unlock','everyone','admins','listgroups','members','approveall','rejectall','checkpending','disap','antimention','antispam','antibot','slowmode','poll','endpoll','approve','setwelcomemsg','setgoodbyemsg','kickinactive','mutelist','softban','kickall'],
  Utility:   ['sticker','toimg','vv','qr','weather','tr','uploadstatus','setmypp','getpp','tts','tourl','ocr','shorten','friends','play','playdoc','idch','lyrics','imagine','carbon','instagram','tiktok','facebook','twitter','pinterest','spotify','ytmp4','base64','unbase64','whois','reversegif','attp','emojimix','checkban','screenshot'],
  Fun:       ['joke','fact','quote','dare','truth','riddle','roast','ship','coinflip','dice','magic8','horoscope','meme','cat','dog','waifu','anime','trivia','compliment','bored','rps','math','typeracer','neverhaveiever','wouldyourather'],
  Reactions: REACTION_CMDS,
  Scraps:    SCRAPS_CMDS,
  Illusion:  ILLUSION_CMDS,
  Social:    SOCIAL_CMDS,
  AI:        AI_CMDS,
  Economy:   ECON_CMDS,
  Tools:     TOOLS_CMDS,
  Stickers:  STICKER_CMDS,
  Music:     MUSIC_CMDS,
  Games:     GAMES_CMDS,
  Admin:     ADMIN_CMDS,
  Arabic:    ARABIC_CMDS,
  Developer: DEV_CMDS,
};

// ── Every command this bot answers to ────────────────────────
// CMDS covers the menu lists; commands implemented directly in this file's
// switch (aliases, utilities) are read back out of the source so the set stays
// accurate without a second hand-maintained list. Used by prefix-free mode to
// tell "a command was typed" apart from "someone is just talking".
const DIRECT_CMDS = (() => {
  try {
    const src  = fs.readFileSync(__filename, 'utf8');
    // Anchor on the real dispatch switch -- matched at line start so this very
    // helper (which contains the same text mid-line) cannot be picked up.
    const hits  = [...src.matchAll(/^ {2}switch \(cmd\) \{/gm)];
    const body  = hits.length ? src.slice(hits[hits.length - 1].index) : '';
    const set  = new Set();
    for (const m of body.matchAll(/case\s+'([^']+)'\s*:/g)) set.add(m[1]);
    // ignore cases that only exist inside block comments
    for (const m of body.matchAll(/\/\*([\s\S]*?)\*\//g)) {
      for (const c of m[1].matchAll(/case\s+'([^']+)'\s*:/g)) set.delete(c[1]);
    }
    return set;
  } catch {
    return new Set();
  }
})();

const KNOWN_COMMANDS = new Set([
  ...Object.values(CMDS).filter(Array.isArray).flat(),
  ...DIRECT_CMDS,
]);

// ════════════════════════════════════════════════════════════
//   NEW: CHATBOT AI LOGIC
// ------------------------------------------------------------
// NOTE: the chatbot no longer routes through anything in this block. It now
// uses the ELITE endpoint exclusively (see the CHATBOT section further down).
// chatMemory / extractUserInfo / the aiProviders chain below are kept because
// they are self-contained and may be wired back in later, but nothing calls
// them any more -- safe to delete if you want the file trimmed.
// ════════════════════════════════════════════════════════════
const chatMemory = { messages: new Map(), userInfo: new Map() };
// ── AI providers (unused by the chatbot -- retained, see note above) ──
// The original four endpoints (zellapi.autos, hercai.onrender.com and two on
// discardapi.dpdns.org) are all dead -- verified live: 000 / 503 / 503 / 503.
// These replacements were wired in before the ELITE port.
const AI_TIMEOUT_MS = 15000;

function aiProviders(prompt) {
  const providers = [];

  const groqKey = process.env.GROQ_API_KEY || settings.GROQ_API_KEY;
  if (groqKey) providers.push({
    name: 'Groq',
    url : 'https://api.groq.com/openai/v1/chat/completions',
    init: {
      method : 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${groqKey}` },
      body   : JSON.stringify({ model: 'llama-3.1-8b-instant', max_tokens: 200, messages: [{ role: 'user', content: prompt }] }),
    },
    parse: (d) => d?.choices?.[0]?.message?.content,
  });

  const orKey = process.env.OPENROUTER_API_KEY || settings.OPENROUTER_API_KEY;
  if (orKey) providers.push({
    name: 'OpenRouter',
    url : 'https://openrouter.ai/api/v1/chat/completions',
    init: {
      method : 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${orKey}` },
      body   : JSON.stringify({ model: 'meta-llama/llama-3.1-8b-instruct', max_tokens: 200, messages: [{ role: 'user', content: prompt }] }),
    },
    parse: (d) => d?.choices?.[0]?.message?.content,
  });

  const openaiKey = process.env.OPENAI_API_KEY || settings.OPENAI_API_KEY;
  if (openaiKey) providers.push({
    name: 'OpenAI',
    url : 'https://api.openai.com/v1/chat/completions',
    init: {
      method : 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${openaiKey}` },
      body   : JSON.stringify({ model: 'gpt-4o-mini', max_tokens: 200, messages: [{ role: 'user', content: prompt }] }),
    },
    parse: (d) => d?.choices?.[0]?.message?.content,
  });

  // Keyless — works with no configuration at all
  providers.push({
    name: 'Pollinations',
    url : 'https://text.pollinations.ai/openai',
    init: {
      method : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body   : JSON.stringify({ model: 'openai', messages: [{ role: 'user', content: prompt }] }),
    },
    parse: (d) => d?.choices?.[0]?.message?.content,
  });

  providers.push({
    name : 'Pollinations(text)',
    url  : `https://text.pollinations.ai/${encodeURIComponent(prompt.slice(0, 1500))}`,
    init : { method: 'GET' },
    text : true,
    parse: (t) => t,
  });

  return providers;
}

// ── Local fallback responder ────────────────────────────────
// Used only when every AI provider is unreachable (no key configured, or all
// upstreams down). Deliberately small and transparent: it answers common
// social openers so the chatbot is never silent, and says so honestly for
// anything it cannot handle.
const LOCAL_PATTERNS = [
  { re: /^(hi|hello|hey+|yo|habari|mambo|salam|hola)\b/i, reply: 'Hey! 👋 How can I help you today?' },
  { re: /\b(good\s*(morning|afternoon|evening|night))\b/i, reply: 'Good day to you too! 😊' },
  { re: /\bhow are you\b|\bhow\s+are\s+u\b|\buko aje\b/i, reply: "I'm good, thanks for asking! How about you? 🙂" },
  { re: /\b(thanks|thank you|asante|shukran)\b/i, reply: 'You\'re welcome! 😊' },
  { re: /\b(bye|goodbye|kwaheri)\b/i, reply: 'See you later! 👋' },
  { re: /\b(who are you|what is your name|your name)\b/i, reply: 'I\'m the assistant on this number — happy to chat.' },
  { re: /\b(help|menu|commands)\b/i, reply: 'Send the menu command to see everything I can do.' },
  { re: /\b(time|date)\b/i, reply: () => `It\'s ${new Date().toLocaleString()}.` },
];

function localChatbotReply(text) {
  const t = String(text || '').trim();
  if (!t) return null;
  for (const p of LOCAL_PATTERNS) {
    if (p.re.test(t)) return typeof p.reply === 'function' ? p.reply() : p.reply;
  }
  return null;
}

// A plain-text provider can answer with an upstream error page; don't ship that
// to the user as if it were a reply.
const AI_BAD_TEXT = /reached its budget|rate limit|too many requests|invalid api key|unauthoriz|quota exceeded/i;
function usableAiText(t) {
  if (typeof t !== 'string') return false;
  const v = t.trim();
  if (!v) return false;
  if (AI_BAD_TEXT.test(v.slice(0, 160))) return false;
  if (v.startsWith('<!DOCTYPE') || v.startsWith('<html')) return false;
  if (v.startsWith('{"code"') || v.startsWith('{"error"')) return false;
  return true;
}

function extractUserInfo(userMessage) {
  const info = {};
  const low = userMessage.toLowerCase();
  if (low.includes("my name is")) info.name = userMessage.split(/my name is/i)[1]?.trim().split(" ")[0];
  if (low.includes("i am") && low.includes("years old")) info.age = userMessage.match(/\d+/)?.[0];
  if (low.includes("i live in") || low.includes("i am from")) {
    info.location = userMessage.split(/(?:i live in|i am from)/i)[1]?.trim().split(/[.,!?]/)[0];
  }
  return info;
}

async function getAIResponse(userMessage, userContext, botName) {
  const prompt = `You are a casual, friendly human chatting on WhatsApp. Always reply in English only.

RULES:
1. Always respond in English only.
2. Keep responses short, 1-2 lines max.
3. Be casual and natural.
4. Use emojis naturally.
5. Never reveal you are an AI or bot.

Your name is ${botName}.

Previous conversation:
${userContext.messages.join("\n")}

User info:
${JSON.stringify(userContext.userInfo, null, 2)}

User: ${userMessage}
You:`.trim();

  const providers = aiProviders(prompt);
  if (!providers.length) return null;

  const callOne = async (api) => {
    const controller = new AbortController();
    const timeoutId  = setTimeout(() => controller.abort(), AI_TIMEOUT_MS);
    try {
      const response = await fetch(api.url, { ...(api.init || {}), signal: controller.signal });
      if (!response.ok) { console.log('[AI]', api.name, '-> HTTP', response.status); return null; }

      const data   = api.text ? await response.text() : await response.json();
      const result = api.parse(data);
      if (!result) { console.log('[AI]', api.name, '-> empty'); return null; }
      if (!usableAiText(result)) { console.log('[AI]', api.name, '-> unusable/upstream error'); return null; }

      const cleaned = result
        .trim()
        .replace(/winks/g, "😉")
        .replace(/eye roll/g, "🙄")
        .replace(/shrug/g, "🤷‍♂️")
        .replace(/raises eyebrow/g, "🤨")
        .replace(/smiles/g, "😊")
        .replace(/laughs/g, "😂")
        .replace(/cries/g, "😢")
        .replace(/thinks/g, "🤔")
        .replace(/sleeps/g, "😴")
        .replace(/google/gi, botName)
        .replace(/a large language model/gi, "just a person")
        .replace(/Remember:.*$/g, "")
        .replace(/IMPORTANT:.*$/g, "")
        .replace(/^[A-Z\s]+:.*$/gm, "")
        .replace(/^[•-]\s.*$/gm, "")
        .replace(/^✅.*$/gm, "")
        .replace(/^❌.*$/gm, "")
        .replace(/\n\s*\n/g, "\n")
        .trim();

      if (!cleaned) return null;
      console.log('[AI] answered by', api.name);
      return cleaned;
    } catch (e) {
      console.log('[AI]', api.name, '->', e.name === 'AbortError' ? 'timeout' : e.message);
      return null;
    } finally {
      clearTimeout(timeoutId);
    }
  };

  // Race the providers: the first usable answer wins, so one slow or dead
  // upstream can't hold the reply back.
  return await new Promise((resolve) => {
    let pending = providers.length;
    let settled = false;
    for (const api of providers) {
      callOne(api)
        .then((r) => { if (r && !settled) { settled = true; resolve(r); } })
        .catch(() => {})
        .finally(() => { if (--pending === 0 && !settled) { settled = true; resolve(null); } });
    }
  });
}

// ════════════════════════════════════════════════════════════
//   CHATBOT  –  AI auto-reply
// ------------------------------------------------------------
// Pipeline ported from ELITE-PRO-V1 (index.js -> handleChatbot):
//   per-message dedupe, rolling per-sender history, composing presence,
//   GET <ELITE endpoint>?prompt=… , quoted reply, idle memory cleanup.
//
// Two deliberate differences from the original:
//   1. the bot answers only when it is TAGGED (@bot) or when the incoming
//      message is a REPLY to one of its own messages -- in groups and in
//      DMs alike. Untriggered chatter is ignored silently.
//   2. the ELITE endpoint is the only provider on this path; if it fails,
//      one short error line goes out instead of falling back elsewhere.
// ════════════════════════════════════════════════════════════
const ELITE_CHATBOT_API   = 'https://eliteprotech-apis.zone.id/deepai';
const CHATBOT_TIMEOUT_MS  = 30000;
const CHATBOT_DEDUPE_MS   = 60000;
const CHATBOT_HISTORY_MAX = 15;                    // turns kept per sender
const CHATBOT_MEMORY_TTL  = 30 * 60 * 1000;        // idle memory is dropped
const CHATBOT_ERROR_LINE  = '❌ The assistant is unavailable right now — please try again.';

const chatbotProcessed = new Set();
const chatbotHistory   = {};   // sender -> ['User: …', 'Bot: …']
const chatbotLastSeen  = {};

// Housekeeping copied from the reference: forget idle conversations.
const chatbotSweeper = setInterval(() => {
  const now = Date.now();
  for (const user of Object.keys(chatbotLastSeen)) {
    if (now - chatbotLastSeen[user] > CHATBOT_MEMORY_TTL) {
      delete chatbotHistory[user];
      delete chatbotLastSeen[user];
    }
  }
}, 10 * 60 * 1000);
if (typeof chatbotSweeper.unref === 'function') chatbotSweeper.unref();

// Every JID form this bot can be addressed as.
function chatbotSelfJids(botNumber, botJid) {
  return [...new Set([
    botJid,
    botNumber && `${botNumber}@s.whatsapp.net`,
    botNumber && `${botNumber}@whatsapp.net`,
  ].filter(Boolean).map(normalizeJid))];
}

// Trigger = the bot is tagged, or the message replies to one of its messages.
function chatbotTrigger(m, text, botNumber, botJid) {
  const ctx = m.message?.extendedTextMessage?.contextInfo
    || m.message?.imageMessage?.contextInfo
    || m.message?.videoMessage?.contextInfo
    || m.message?.documentMessage?.contextInfo
    || m.message?.audioMessage?.contextInfo
    || m.message?.stickerMessage?.contextInfo
    || {};

  const self = chatbotSelfJids(botNumber, botJid);

  const tagged = (ctx.mentionedJid || [])
    .map(normalizeJid)
    .some(j => self.includes(j));

  const repliedToBot = !!ctx.participant && self.includes(normalizeJid(ctx.participant));

  // A hand-typed "@2547…" carries no mentionedJid entry. The "@" is required:
  // a bare bot number sitting in ordinary text is not a tag -- without this,
  // "ping 254700000000 at noon" counted as being tagged.
  const digits = String(botNumber || '').replace(/\D/g, '');
  const taggedInText = digits ? new RegExp(`@${digits}(?!\\d)`).test(text) : false;

  return { tagged: tagged || taggedInText, repliedToBot, digits };
}

async function handleChatbot(sock, m, body, sender, isGroup, pushname, botNumber, botJid, reply) {
  const chatJid = isGroup ? m.key.remoteJid : sender;
  if (!getChatbotStatus(chatJid)) return false;
  if (m.key.fromMe) return false;
  if (m.key.remoteJid === 'status@broadcast') return false;

  const text = String(body || '').trim();
  if (!text) return false;

  const prefix = cfg(sock).prefix || settings.DEFAULT_PREFIX || '.';
  if (text.startsWith(prefix)) return false;      // a command, not conversation

  // ── Tag / reply gate ──────────────────────────────────────
  const { tagged, repliedToBot, digits } = chatbotTrigger(m, text, botNumber, botJid);
  if (!tagged && !repliedToBot) return false;     // not addressed -> stay silent

  let prompt = text;
  if (tagged && digits) prompt = prompt.replace(new RegExp(`@?${digits}`, 'g'), '').trim();
  if (!prompt) return false;

  // ── One reply per incoming message ────────────────────────
  const dedupeKey = `${m.key.remoteJid}:${m.key.id}`;
  if (chatbotProcessed.has(dedupeKey)) return false;
  chatbotProcessed.add(dedupeKey);
  setTimeout(() => chatbotProcessed.delete(dedupeKey), CHATBOT_DEDUPE_MS);

  // ── Rolling per-sender history ────────────────────────────
  // The reference builds a prompt from this transcript but only sends the raw
  // text (its endpoint keeps the session server-side), so parity means sending
  // the text alone. The transcript is kept trimmed for the same TTL so it is
  // ready if you ever want it included in the prompt.
  chatbotHistory[sender] = chatbotHistory[sender] || [];
  chatbotHistory[sender].push(`User: ${prompt}`);
  if (chatbotHistory[sender].length > CHATBOT_HISTORY_MAX) chatbotHistory[sender].shift();
  chatbotLastSeen[sender] = Date.now();

  // Answer in the chat the bot was addressed in -- a group stays in the group.
  const target = m.key.remoteJid;

  let response = null;
  try {
    await sock.sendPresenceUpdate('composing', target);
    const res = await axios.get(`${ELITE_CHATBOT_API}?prompt=${encodeURIComponent(prompt)}`, {
      headers: { Accept: '*/*', 'User-Agent': 'Mozilla/5.0' },
      timeout: CHATBOT_TIMEOUT_MS,
    });
    response = res?.data?.success && res?.data?.response ? String(res.data.response).trim() : null;
    if (!response) logError('Chatbot', `unusable reply: ${JSON.stringify(res?.data).slice(0, 160)}`);
  } catch (e) {
    logError('Chatbot', e.message);
  } finally {
    try { await sock.sendPresenceUpdate('paused', target); } catch {}
  }

  const out = response || CHATBOT_ERROR_LINE;
  chatbotHistory[sender].push(`Bot: ${out}`);
  if (chatbotHistory[sender].length > CHATBOT_HISTORY_MAX) chatbotHistory[sender].shift();

  try {
    await sock.sendMessage(target, { text: out }, { quoted: m });
  } catch (e) {
    logError('Chatbot', `send failed: ${e.message}`);
  }

  return !!response;
}

// ════════════════════════════════════════════════════════════
//   STATUS BROADCAST  –  auto view / auto like
// ------------------------------------------------------------
// Ported from the ELITE-PRO-V1 status watcher, which is the working
// reference for this Baileys family. Two details matter:
//   * the incoming status key can carry a LID participant, which is not a
//     valid status target -- the poster has to be resolved to a real
//     @s.whatsapp.net address first;
//   * a status reaction is only delivered when the target is listed in
//     `statusJidList` -- without it the reaction is accepted and dropped.
// ════════════════════════════════════════════════════════════
const processedStatus = new Set();
const STATUS_DEDUPE_TTL = 5 * 60 * 1000;   // never view/like the same status twice

function resolveStatusTarget(m) {
  const candidates = [
    m?.key?.participantAlt, m?.key?.participantPn,
    m?.participantAlt, m?.participantPn,
    m?.key?.participant, m?.participant, m?.sender,
  ].filter(Boolean).map(String);

  for (const jid of candidates) if (jid.endsWith('@s.whatsapp.net')) return jid;
  return candidates[0] || null;
}

async function handleStatusBroadcast(sock, m, c) {
  try {
    if (m.key.fromMe) return;
    if (!c.autoViewStatus && !c.autoLikeStatus) return;

    const msg = m.message || {};
    // Reactions/protocol traffic on the status feed are not status updates.
    if (msg.reactionMessage || msg.protocolMessage) return;

    const target = resolveStatusTarget(m);
    if (!target) return;

    const id = m.key.id;
    if (!id || processedStatus.has(id)) return;
    processedStatus.add(id);
    setTimeout(() => processedStatus.delete(id), STATUS_DEDUPE_TTL);

    const statusKey = { remoteJid: 'status@broadcast', id, fromMe: false, participant: target };

    if (c.autoViewStatus) {
      try {
        await sock.readMessages([statusKey]);
        logInfo('Status', `viewed status from ${normNum(target)}`);
      } catch (e) {
        logError('Status', `view failed for ${normNum(target)}: ${e.message}`);
      }
    }

    if (c.autoLikeStatus) {
      const emoji = c.autoLikeStatusEmoji || '❤️';
      try {
        await sock.sendMessage(
          'status@broadcast',
          { react: { text: emoji, key: statusKey } },
          { statusJidList: [target] }
        );
        logInfo('Status', `reacted ${emoji} to status from ${normNum(target)}`);
      } catch (e) {
        logError('Status', `like failed for ${normNum(target)}: ${e.message}`);
      }
    }
  } catch (e) {
    logError('Status', e.message);
  }
}

// ════════════════════════════════════════════════════════════
//   PLAY  –  audio / video / document picker
// ------------------------------------------------------------
// The reference (.play) fetched and sent the audio straight away. Here the
// command instead offers the three formats as quick-reply buttons; the tap
// comes back as the button id (PLAY_AUDIO|…), which is routed to
// handlePlayChoice. Downloads use the same providers as the reference:
// eliteprotech /ytmp3 for audio, neosoft /downloader/youtube?type=mp4 for video.
// ════════════════════════════════════════════════════════════
const bq = (txt) => String(txt ?? '').split('\n').map(line => `> ${line}`).join('\n');

async function fetchBuffer(url, timeout = 90000) {
  const res = await axios.get(url, {
    responseType: 'arraybuffer',
    timeout,
    maxContentLength: 200 * 1024 * 1024,
    maxBodyLength: 200 * 1024 * 1024,
  });
  return Buffer.from(res.data);
}

// The menu's cta_url button renders on this account, but a card built from
// quick_reply buttons shows no buttons on some WhatsApp builds. The picker
// therefore also accepts a numbered reply -- 1 audio / 2 video / 3 document --
// tracked per chat for 10 minutes.
const PLAY_WAIT_MS = 10 * 60 * 1000;
const playWaiting  = new Map();   // chatJid -> { videoUrl, msgId, at }

const PLAY_SAFE = (s) => String(s || 'media').replace(/[\\/:*?"<>|]/g, '').trim().slice(0, 80) || 'media';

async function handlePlayChoice(sock, m, kind, videoUrl) {
  const jid = m.key.remoteJid;
  const react = async (emoji) => {
    try { await sock.sendMessage(jid, { react: { text: emoji, key: m.key } }); } catch {}
  };

  await react(kind === 'VIDEO' ? '🎬' : kind === 'DOC' ? '📄' : '🎵');

  try {
    if (kind === 'VIDEO') {
      const { data } = await axios.get(
        `https://api.neosoft.best/api/downloader/youtube?url=${encodeURIComponent(videoUrl)}&type=mp4`,
        { timeout: 90000 }
      );
      if (!data?.status || !data?.download) throw new Error('video service unavailable');

      const title = data.title || 'video';
      const buf   = await fetchBuffer(data.download);
      await sock.sendMessage(jid, {
        video: buf,
        mimetype: 'video/mp4',
        fileName: `${PLAY_SAFE(title)}.mp4`,
        caption: bq(`🎬 *${title}*`),
      }, { quoted: m });
    } else {
      const { data } = await axios.get(
        `https://eliteprotech-apis.zone.id/ytmp3?url=${encodeURIComponent(videoUrl)}`,
        { timeout: 90000 }
      );
      const dl = data?.download;
      if (!data?.status || !dl?.downloadUrl) throw new Error('audio service unavailable');

      const title = dl.title || 'audio';
      const buf   = await fetchBuffer(dl.downloadUrl);

      if (kind === 'DOC') {
        await sock.sendMessage(jid, {
          document: buf,
          mimetype: 'audio/mpeg',
          fileName: `${PLAY_SAFE(title)}.mp3`,
          caption: bq(`📄 *${title}*`),
        }, { quoted: m });
      } else {
        await sock.sendMessage(jid, {
          audio: buf,
          mimetype: 'audio/mpeg',
          fileName: `${PLAY_SAFE(title)}.mp3`,
          ptt: false,
        }, { quoted: m });
      }
    }
    await react('✅');
  } catch (e) {
    logError('Play', e.message);
    await react('❌');
    try { await sock.sendMessage(jid, { text: bq(`❌ Download failed: ${e.message}`) }, { quoted: m }); } catch {}
  }
}

// ════════════════════════════════════════════════════════════
//   MAIN HANDLER (FULLY CORRECTED)
// ════════════════════════════════════════════════════════════
async function handleMessage(sock, m, chatMeta = {}) {

  // ── Resolve waNum ─────────────────────────────────────────
  const waNum = sock.__waNum || (sock.user?.id ? normNum(sock.user.id) : 'default');
  if (!sock.__waNum && sock.user?.id) sock.__waNum = normNum(sock.user.id);
  const c    = getWaSettings(waNum);
  const mode = c.mode || 'public';

  logMessage(m, chatMeta);
  storeMessage(m);
  // Anti-delete also mirrors the message to disk (ELITE-PRO-V1 approach) so a
  // deletion can still be recovered after a restart.
  if (c.antidelete) captureForAntiDelete(m);

  // ── Status broadcast ──────────────────────────────────────
  if (m.key.remoteJid === 'status@broadcast') {
    await handleStatusBroadcast(sock, m, c);
    return;
  }

  // ── Auto‑Read Chats ──────────────────────────────────────
  if (c.autoRead && m.key.remoteJid !== 'status@broadcast') {
    await autoReadMessage(sock, m.key);
  }

  // ── Body – mtype-based ────────────────────────────────────
  const mtype = m.mtype || Object.keys(m.message || {})[0] || '';
  const body = (
    mtype === 'conversation'              ? m.message.conversation :
    mtype === 'imageMessage'              ? m.message.imageMessage.caption :
    mtype === 'videoMessage'              ? m.message.videoMessage.caption :
    mtype === 'extendedTextMessage'       ? m.message.extendedTextMessage.text :
    mtype === 'documentMessage'           ? m.message.documentMessage.caption :
    mtype === 'buttonsResponseMessage'    ? m.message.buttonsResponseMessage.selectedButtonId :
    mtype === 'listResponseMessage'       ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
    mtype === 'templateButtonReplyMessage'? m.message.templateButtonReplyMessage.selectedId :
    mtype === 'interactiveResponseMessage'? (() => { try { return JSON.parse(m.message.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson || '{}').id || ''; } catch { return ''; } })() :
    mtype === 'messageContextInfo'        ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text || '') :
    m.message?.conversation || m.message?.extendedTextMessage?.text || ''
  );

  // ── Core vars ─────────────────────────────────────────────
  const from         = m.key.remoteJid;
  const jid          = from;
  const isGroup      = from.endsWith('@g.us');
  const botNumber    = normNum(sock.user?.id || '');
  const botJid       = botNumber + '@s.whatsapp.net';
  const sender       = m.key.fromMe
    ? botNumber + '@s.whatsapp.net'
    : (m.key.participant || m.key.remoteJid);
  const senderNumber = sender.split('@')[0];
  const pushname     = m.pushName || 'No Name';

  // ── Declare command variables ─────────────────────────────
  let cmd, args, text;

  // ════════════════════════════════════════════════════════════
  //   1) STICKER COMMAND DETECTION (runs BEFORE prefix)
  // ════════════════════════════════════════════════════════════
  if (mtype === 'stickerMessage') {
    const sticker = m.message.stickerMessage;
    let hashBytes = sticker.fileSha256;
    if (hashBytes) {
      const buffer = Buffer.isBuffer(hashBytes) ? hashBytes : Buffer.from(hashBytes);
      const hash = buffer.toString('base64');
      const stickerCommands = getStickerCommands();
      if (stickerCommands[hash]) {
        cmd = stickerCommands[hash];
        args = [];
        text = '';
      }
    }
  }

  // ════════════════════════════════════════════════════════════
  // ── Play format buttons (Audio / Video / Document) ────────
  // A quick-reply tap arrives with its id as the body, so route it before any
  // command/chatbot handling.
  const playTap = /^PLAY_(AUDIO|VIDEO|DOC)\|(\S+)$/i.exec(String(body || '').trim());
  if (playTap) {
    await handlePlayChoice(sock, m, playTap[1].toUpperCase(), playTap[2]);
    return;
  }

  // Fallback for clients that render no quick_reply buttons: a numbered reply
  // after a play card. In groups it must quote the card; in a DM a bare number
  // is enough (one pending card per chat).
  {
    const pending = playWaiting.get(jid);
    if (pending && Date.now() - pending.at >= PLAY_WAIT_MS) playWaiting.delete(jid);

    if (pending && playWaiting.has(jid)) {
      const trimmed = String(body || '').trim();
      const choice = /^(1|audio|mp3|song)$/i.test(trimmed)  ? 'AUDIO'
        : /^(2|video|mp4)$/i.test(trimmed)                  ? 'VIDEO'
        : /^(3|doc|docs|document|file)$/i.test(trimmed)     ? 'DOC' : null;

      const ctxId  = m.message?.extendedTextMessage?.contextInfo?.stanzaId
        || m.message?.imageMessage?.contextInfo?.stanzaId || null;
      const quotes = !!ctxId && !!pending.msgId && ctxId === pending.msgId;
      const allowed = quotes || (!isGroup && !ctxId);

      if (choice && allowed) {
        playWaiting.delete(jid);
        await handlePlayChoice(sock, m, choice, pending.videoUrl);
        return;
      }
    }
  }

  //   2) PREFIX / PREFIX‑FREE PARSING (if cmd not set by sticker)
  // ════════════════════════════════════════════════════════════
  const storedPrefix = c.prefix || settings.DEFAULT_PREFIX || '.';
  // `prefix` is referenced throughout the command handlers below (usage hints,
  // copy-code buttons, menus). It was never declared, so every one of those
  // commands died with "ReferenceError: prefix is not defined".
  const prefix = storedPrefix;
  const hasPrefix = body.startsWith(storedPrefix);
  const isPrefixFree = c.prefixfree === true;

  // ── IMPORTANT: define `reply` BEFORE we need it ────────────
  const blockquote = (txt) => txt.split('\n').map(line => '> ' + line).join('\n');

  // Accepts both reply('text') and reply(sock, m, 'text') call styles.
  const resolveText = (a1, a2, a3) => {
    if (typeof a1 === 'string' || typeof a1 === 'number') return a1;
    if (a3 !== undefined && a3 !== null) return a3;
    if (typeof a2 === 'string' || typeof a2 === 'number') return a2;
    return a1;
  };

  const reply = async (a1, a2, a3) => {
    const txt = resolveText(a1, a2, a3);
    const out = ft(String(txt), sock);
    const c2 = cfg(sock);

    if (c2.iphoneMode) {
      return sock.sendMessage(jid, { text: out }, { quoted: m });
    }

    let title = '💖 PRINCESS 💖';
    const rawText = m.text || m.message?.conversation || m.message?.extendedTextMessage?.text || '';
    if (rawText) {
      const prefix = c2.prefix || settings.DEFAULT_PREFIX || '.';
      const trimmed = rawText.trim();
      const cmdPart = trimmed.startsWith(prefix) ? trimmed.slice(prefix.length) : trimmed;
      const firstWord = cmdPart.split(/\s+/)[0] || '';
      if (firstWord) {
        title = `🌸 ${firstWord.toUpperCase()} 🌸`;
      }
    }

    const top = `╭━━•›ꪶ ཻུ۪۪ꦽꦼ̷⸙〘  ${title} 〙 ꪶ ཻུ۪۪ꦽꦼ̷⸙‹━•⩵꙰ཱི࿐`;
    const footer = `╰━━•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙‹•━•⩵꙰ཱི࿐`;
    const lines = out.split('\n');
    const indented = lines.map(line => `├◆ ${line}`).join('\n');
    const boxed = `${top}\n${indented}\n${footer}`;
    const quotedBox = blockquote(boxed);   // every reply renders as a blockquote

    // Single message only – the separate banner is gone.
    await sock.sendMessage(jid, addNewsletterContext({ text: quotedBox }), { quoted: m });
  };

  // ── replyImg helper ───────────────────────────────────────
  // Accepts both replyImg(bufOrUrl, caption) and replyImg(sock, m, bufOrUrl, caption).
  const replyImg = async (a1, a2, a3, a4) => {
    let src, cap;
    if (typeof a1 === 'string' || Buffer.isBuffer(a1)) {
      src = a1;
      cap = a2;
    } else {
      src = a3;
      cap = a4 !== undefined && a4 !== null ? a4 : a2;
    }
    if (src === undefined || src === null || src === '') return reply(cap || '❌ No image.');

    const c2 = cfg(sock);
    const captionText = typeof cap === 'string' ? cap : String(cap ?? '');
    if (c2.iphoneMode) return sock.sendMessage(jid, { text: ft(captionText || '[Image]', sock) }, { quoted: m });

    const field = Buffer.isBuffer(src) ? { image: src } : { image: { url: String(src) } };
    try {
      return await sock.sendMessage(jid, { ...field, caption: ft(captionText, sock) }, { quoted: m });
    } catch {
      // Bad image URL – fall back to text so a broken link never kills the command
      return sock.sendMessage(jid, { text: ft(captionText || String(src), sock) }, { quoted: m });
    }
  };

  // ── NOW check for no command ──────────────────────────────
  if (!cmd && !hasPrefix && !isPrefixFree) {
    console.log('[HANDLER] No command, calling chatbot...');
    const handled = await handleChatbot(sock, m, body, sender, isGroup, pushname, botNumber, botJid, reply);
    if (handled) return;
    return;
  }

  if (!cmd) {
    if (hasPrefix) {
      const parts = body.slice(storedPrefix.length).trim().split(/\s+/);
      cmd = parts[0]?.toLowerCase();
      args = parts.slice(1);
      text = args.join(' ');
    } else if (isPrefixFree) {
      const parts = body.trim().split(/\s+/);
      cmd = parts[0]?.toLowerCase();
      args = parts.slice(1);
      text = args.join(' ');
      // In prefix-free mode the first word is normally taken as a command. If
      // it is not a command at all, the message is conversation -- without
      // this the chatbot was unreachable whenever prefix-free was on.
      if (cmd && !KNOWN_COMMANDS.has(cmd)) {
        console.log(`[HANDLER] Prefix-free, "${cmd}" is not a command, calling chatbot...`);
        const handled = await handleChatbot(sock, m, body, sender, isGroup, pushname, botNumber, botJid, reply);
        if (handled) return;
        return;
      }

      if (!cmd) {
        console.log('[HANDLER] Prefix-free, no command word, calling chatbot...');
        const handled = await handleChatbot(sock, m, body, sender, isGroup, pushname, botNumber, botJid, reply);
        if (handled) return;
        return;
      }
    }
  }

  // ── Anti‑view‑once (auto‑forward to owner) ─────────────────
  if (c.antiviewonce) {
    let inner = m.message;
    let isViewOnce = false;
    const viewOnceTypes = ['viewOnceMessage', 'viewOnceMessageV2', 'viewOnceMessageV2Extension'];
    for (const type of viewOnceTypes) {
      if (inner?.[type]?.message) {
        inner = inner[type].message;
        isViewOnce = true;
        break;
      }
    }

    if (isViewOnce) {
      const imgMsg = inner.imageMessage;
      const vidMsg = inner.videoMessage;
      const audMsg = inner.audioMessage;

      if (imgMsg || vidMsg || audMsg) {
        try {
          const ownerFile = DB('owner.json');
          let kontributor = [];
          try { kontributor = JSON.parse(fs.readFileSync(ownerFile, 'utf8')); } catch { kontributor = []; }
          if (!kontributor.length) {
            if (settings.SUDO_NUMBER) kontributor.push(String(settings.SUDO_NUMBER));
          }
          const ownerNumber = kontributor[0] || botNumber;
          const ownerJid = ownerNumber.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

          if (sender === ownerJid) return;

          const mediaObj = imgMsg ? { imageMessage: imgMsg } :
                           vidMsg ? { videoMessage: vidMsg } :
                           { audioMessage: audMsg };
          const buf = await dlMedia(mediaObj, m.key);

          const chatType = isGroup ? `group ${groupName}` : 'private DM';
          const caption = `📩 View‑once from ${senderNumber} (${pushname}) in ${chatType}`;

          if (imgMsg) await sock.sendMessage(ownerJid, { image: buf, caption });
          else if (vidMsg) await sock.sendMessage(ownerJid, { video: buf, caption });
          else if (audMsg) await sock.sendMessage(ownerJid, { audio: buf, mimetype: 'audio/mpeg', ptt: false });

        } catch (e) {
          console.error('Anti‑view‑once error:', e);
        }
        return;
      }
    }
  }

  // If still no cmd, exit
  if (!cmd) return;

  // ── isOwner ───────────────────────────────────────────────
  const ownerFile = DB('owner.json');
  let kontributor = [];
  try { kontributor = JSON.parse(fs.readFileSync(ownerFile, 'utf8')); } catch { kontributor = []; }
  if (!kontributor.length) {
    if (settings.SUDO_NUMBER) kontributor.push(String(settings.SUDO_NUMBER));
    if (c.owner)              kontributor.push(String(c.owner));
  }
  const _isOwner = [botNumber, ...kontributor]
    .map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
    .includes(sender);
  const isBot = botNumber === senderNumber;

  // ── Self mode gate ────────────────────────────────────────
  if (mode === 'self' && !_isOwner && !isBot) return;

  // ── Group metadata & admin flags ──────────────────────────
  const groupMetadata = isGroup ? await sock.groupMetadata(jid).catch(() => ({})) : {};
  const groupName     = isGroup ? groupMetadata.subject || '' : '';
  const participants  = isGroup ? (groupMetadata.participants || []).map(p => {
    let admin = null;
    if (p.admin === 'superadmin') admin = 'superadmin';
    else if (p.admin === 'admin') admin = 'admin';
    return { id: p.id || null, jid: p.jid || p.id || null, admin, full: p };
  }) : [];
  const groupOwner    = isGroup ? participants.find(p => p.admin === 'superadmin')?.jid || '' : '';
  const groupAdmins   = participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin').map(p => p.jid || p.id);
  const isBotAdmins   = isGroup ? groupAdmins.includes(botNumber + '@s.whatsapp.net') || groupAdmins.includes(botNumber) : false;
  const isAdmins      = isGroup ? groupAdmins.includes(sender) : false;
  const isGroupOwner  = isGroup ? groupOwner === sender : false;

  // ── Styled quoted objects ─────────────────────────────────
  const qpayment = {
    key: { remoteJid: '0@s.whatsapp.net', fromMe: false, id: 'ownername', participant: '0@s.whatsapp.net' },
    message: {
      requestPaymentMessage: {
        currencyCodeIso4217: 'USD',
        amount1000: 999999999,
        requestFrom: '0@s.whatsapp.net',
        noteMessage: { extendedTextMessage: { text: settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD' } },
        expiryTimestamp: 999999999,
        amount: { value: 91929291929, offset: 1000, currencyCode: 'INR' },
      },
    },
  };

  const qchanel = {
    key: { remoteJid: 'status@broadcast', fromMe: false, participant: '0@s.whatsapp.net' },
    message: {
      newsletterAdminInviteMessage: {
        newsletterJid: '120363408083191758@newsletter',
        newsletterName: settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD',
        jpegThumbnail: '',
        caption: settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD',
        inviteExpiration: Date.now() + 1814400000,
      },
    },
  };

  const qkontak = {
    key: {
      participant: '0@s.whatsapp.net',
      ...(jid ? { remoteJid: 'status@broadcast' } : {}),
    },
    message: {
      contactMessage: {
        displayName: settings.CREDITS || 'james',
        vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:${settings.CREDITS || 'james'}\nEND:VCARD`,
        sendEphemeral: true,
      },
    },
  };

  const qtext = {
    key: { fromMe: false, participant: '0@s.whatsapp.net', ...(jid ? { remoteJid: '0@s.whatsapp.net' } : {}) },
    message: { extendedTextMessage: { text: `✨ ${settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD'}` } },
  };

  // ── Log incoming message ──────────────────────────────────
  if (m.message) {
    process.stdout.write('--------------------\n');
    process.stdout.write(`▢ New Message\n`);
    process.stdout.write(
      `   ▢ Date   : ${new Date().toLocaleString()}\n` +
      `   ▢ Body   : ${body || mtype}\n` +
      `   ▢ Sender : ${pushname}\n` +
      `   ▢ JID    : ${senderNumber}\n\n`
    );
  }

  // ── reaction helper ───────────────────────────────────────
  // Accepts reaction('✅') and react(sock, m, '✅') call styles.
  const reaction = async (a1, a2, a3) => {
    const emoji = typeof a1 === 'string' ? a1 : (a3 !== undefined ? a3 : a2);
    try { await sock.sendMessage(jid, { react: { text: emoji, key: m.key } }); } catch {}
  };
  const react = reaction;

  // ── Guard helpers ─────────────────────────────────────────
  const needGroup  = () => { if (!isGroup) { reply('❌ Group only.'); return true; } return false; };
  const needAdmin  = () => {
    if (isAdmins || _isOwner) return false;
    reply('❌ Admins only.');
    return true;
  };
  const needBotAdm = () => {
    if (isBotAdmins) return false;
    reply('❌ Add bot as group admin first.');
    return true;
  };
  const needOwner  = () => { if (!_isOwner) { reply('❌ Owner only.'); return true; } return false; };

  // ════════════════════════════════════════════════════════════
  //   SWITCH (COMMANDS)
  // ════════════════════════════════════════════════════════════
  switch (cmd) {

    // ── Chatbot toggle ──────────────────────────────────────
    case 'chatbot': {
      if (!_isOwner) return reply('❌ Owner only!');

      const sub = args[0]?.toLowerCase();
      const chatJid = isGroup ? jid : sender;

      if (!sub || (sub !== 'on' && sub !== 'off')) {
        return reply(
          `🤖 *CHATBOT SETUP*\n\n` +
          `• ${storedPrefix}chatbot on  - Enable chatbot in this chat\n` +
          `• ${storedPrefix}chatbot off - Disable chatbot\n\n` +
          (isGroup
            ? `When enabled, I'll reply only when mentioned (@${botNumber}) or replied to.`
            : `When enabled, I'll reply only when you reply to one of my messages.`)
        );
      }

      const currently = getChatbotStatus(chatJid);

      if (sub === 'on') {
        if (currently) return reply('⚠️ Chatbot is already enabled.');
        setChatbotStatus(chatJid, true);
        await reply(
          isGroup
            ? `✅ Chatbot enabled! Mention me (@${botNumber}) or reply to my messages to chat.`
            : `✅ Chatbot enabled! Reply to one of my messages and I'll answer.`
        );
      } else { // off
        if (!currently) return reply('⚠️ Chatbot is already disabled.');
        setChatbotStatus(chatJid, false);
        await reply('❌ Chatbot disabled for this chat.');
      }
      break;
    }

    // ── Add your other commands here ──────────────────────
    // ...

 
    // ══════════════════════════════════════════════════════
    //   GENERAL
    // ══════════════════════════════════════════════════════
case 'prefixfree':
case 'setprefixfree': {
  if (!_isOwner) return reply('❌ Owner only.');

  // Toggle or set explicitly
  let newState;
  if (args.length === 0) {
    // Toggle
    newState = !c.prefixfree;
  } else {
    const arg = args[0].toLowerCase();
    if (arg === 'on' || arg === 'true' || arg === '1') newState = true;
    else if (arg === 'off' || arg === 'false' || arg === '0') newState = false;
    else return reply('❌ Invalid argument. Use `on`/`off` or leave empty to toggle.');
  }

  // Save the setting
  await setWaSetting(waNum, 'prefixfree', newState);
  // Update local c for immediate use (optional)
  c.prefixfree = newState;

  reply(`✅ Prefix‑free mode is now **${newState ? 'ON' : 'OFF'}**.`);
  break;
}case 'setsticker': {
    if (needOwner()) break;

    const { qMsg, qType } = getQuoted(m);
    if (qType !== 'stickerMessage') {
        await reply(
`Usage: Reply to a sticker with:
.setsticker <command>
Example: .setsticker menu
To remove: .setsticker -remove`
        );
        break;
    }

    const commandName = args[0]?.toLowerCase();
    if (!commandName) {
        await reply('❌ Provide a command name.\nExample: `.setsticker menu`');
        break;
    }

    const sticker = qMsg.stickerMessage;
    let hashBytes = sticker.fileSha256;
    if (!hashBytes) {
        await reply('❌ Could not read sticker hash.');
        break;
    }
    const buffer = Buffer.isBuffer(hashBytes) ? hashBytes : Buffer.from(hashBytes);
    const hashBase64 = buffer.toString('base64');

    if (commandName === '-remove') {
        setStickerCommand(hashBase64, null);
        await reply(`✅ Sticker command removed.`);
    } else {
        setStickerCommand(hashBase64, commandName);
        await reply(`✅ Sticker command set to: .${commandName}\nHash: ${hashBase64.slice(0, 16)}…`);
    }
    break;
}

case 'liststickers': {
    if (needOwner()) break;
    const map = getStickerCommands();
    const entries = Object.entries(map);
    if (!entries.length) {
        await reply('📋 No sticker commands set.');
        break;
    }
    const list = entries.map(([hash, cmd], i) => `${i+1}. ${hash.slice(0, 16)}… → .${cmd}`).join('\n');
    await reply(`📋 Sticker commands:\n${list}`);
    break;
}case 'vv': {
    const { qMsg, qType, qKey } = getQuoted(m);
    if (!qMsg) {
        await reply(
`Usage: Reply to a view‑once message`
        );
        break;
    }
    let inner = qMsg;
    for (const w of ['viewOnceMessage','viewOnceMessageV2','viewOnceMessageV2Extension']) {
        if (inner[w]?.message) { inner = inner[w].message; break; }
    }
    const voImg = inner.imageMessage;
    const voVid = inner.videoMessage;
    if (!voImg && !voVid) {
        await reply(`❌ Not a view‑once message.`);
        break;
    }
    try {
        const src = voImg ? { imageMessage: voImg } : { videoMessage: voVid };
        const buf = await dlMedia(src, qKey);
        if (voImg) {
            // Assumes replyImg() sends an image
            await replyImg(buf, '👁 Revealed');
        } else if (!cfg(sock).iphoneMode) {
            await sock.sendMessage(jid, { video: buf, caption: '👁 Revealed' }, { quoted: qchanel });
        } else {
            await reply(`👁 View‑once video revealed.`);
        }
    } catch (e) {
        await reply(`❌ Error: ${e.message}`);
    }
    break;
}case 'vv2':
case 'waaah':
case 'nice':
case '😂': {
    // Get quoted message (view‑once media)
    const quotedMsg = m.quoted ? m.quoted : (() => {
        const ctx = m.message?.extendedTextMessage?.contextInfo;
        if (ctx?.quotedMessage) {
            const qMsg = ctx.quotedMessage;
            const qType = Object.keys(qMsg).find(k => !['senderKeyDistributionMessage','messageContextInfo'].includes(k));
            return { message: qMsg, msg: qMsg[qType], type: qType };
        }
        return null;
    })();

    const userJid = sender; // user's private chat JID

    if (!quotedMsg) {
        await sock.sendMessage(userJid, { text: 'Usage: Reply to a view‑once media with .vv2' });
        break;
    }

    // Unwrap view‑once container
    let innerMsg = quotedMsg.message || quotedMsg;
    for (const w of ['viewOnceMessage','viewOnceMessageV2','viewOnceMessageV2Extension']) {
        if (innerMsg[w]?.message) {
            innerMsg = innerMsg[w].message;
            break;
        }
    }

    const imgMsg = innerMsg.imageMessage;
    const vidMsg = innerMsg.videoMessage;
    const audMsg = innerMsg.audioMessage;

    if (!imgMsg && !vidMsg && !audMsg) {
        await sock.sendMessage(userJid, { text: '❌ Not a view‑once message.' });
        break;
    }

    // Download media
    try {
        let mediaBuffer;
        let mediaType = '';
        let caption = '';

        if (imgMsg) {
            mediaBuffer = await dlMedia({ imageMessage: imgMsg }, m.key);
            mediaType = 'image';
            caption = '🔓 View‑Once Image\nFrom: ' + senderNumber;
        } else if (vidMsg) {
            mediaBuffer = await dlMedia({ videoMessage: vidMsg }, m.key);
            mediaType = 'video';
            caption = '🔓 View‑Once Video\nFrom: ' + senderNumber;
        } else if (audMsg) {
            mediaBuffer = await dlMedia({ audioMessage: audMsg }, m.key);
            mediaType = 'audio';
            caption = '🔓 View‑Once Audio\nFrom: ' + senderNumber;
        }

        // Send media to user's DM
        if (mediaType === 'image') {
            await sock.sendMessage(userJid, { image: mediaBuffer, caption: caption });
        } else if (mediaType === 'video') {
            await sock.sendMessage(userJid, { video: mediaBuffer, caption: caption });
        } else if (mediaType === 'audio') {
            await sock.sendMessage(userJid, { audio: mediaBuffer, mimetype: 'audio/mpeg', ptt: false });
        }

        // Success confirmation
        await sock.sendMessage(userJid, { text: `✅ ${mediaType.toUpperCase()} delivered to your DM.` });
    } catch (err) {
        console.error('View-once error:', err);
        await sock.sendMessage(userJid, { text: '❌ Failed to process view‑once media.' });
    }
    break;
}
case 'skylar':
case 'tony':
case 'menu': {
  try {
    // 1. Reaction (safely)
    if (typeof reaction === 'function') await reaction('🌹');

    // 2. Date / time / uptime
    const { date, time } = (typeof getDateTime === 'function') ? getDateTime() : {};
    const up = (typeof formatUptime === 'function')
      ? formatUptime(Date.now() - (global.botStartTime || Date.now()))
      : 'unknown';

    // 3. Command list – safe iteration
    let section = '';
    if (CMDS && typeof CMDS === 'object') {
      for (const [cat, list] of Object.entries(CMDS)) {
        // ✅ FIX: skip categories that are not arrays
        if (!Array.isArray(list)) continue;
        section += `\n*•━══〘${cat.toUpperCase()}  〙══━•*\n`;
        section += list.map(x => `> ❍ ${x}`).join('\n') + '\n';
      }
    }

    // 4. Build menu text (using your ft() function)
    const menuText = ft(
`
•━═〘 🌹𝐒𝐊𝐘𝐋Λ𝐑 𝐗 𝐔𝐋𝐓𝐑𝐀🌹 〙═━•

> ╭═━⪩ 〘 SYSTEM INFO 〙•━•⩵꙰ཱི࿐
> │⫹⫺ 𝗕𝗢𝗧:〖🌹𝐒𝐊𝐘𝐋Λ𝐑 𝐗🌹〗
> │⫹⫺ 𝗗𝗘𝗩: skylar
> │⫹⫺ 𝗩𝗘𝗥𝗦𝗜𝗢𝗡: 𝐕𝐈𝐒𝐈𝐎𝐍 𝟐.𝟎
> │⫹⫺ 𝗠𝗢𝗗𝗘: 𝒔𝒆𝒍𝒇
> │⫹⫺ 𝗣𝗟𝗔𝗧𝗙𝗢𝗥𝗠: 𝒍𝒊𝒏𝒖𝒙
> │⫹⫺ 𝗨𝗣𝗧𝗜𝗠𝗘: ${up}
> │⫹⫺ 𝗢𝗪𝗡𝗘𝗥: skylar
> ╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐

        〘𝐒𝐊𝐘𝐋Λ𝐑 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒〙 
${section}
> ┗❐━ ━ ━ ━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐
`,
      sock
    );

    // 5. ONE message: header image + full command list + button.
    //
    // The image, the whole list and the button ride inside a single
    // interactive message -- image as the header media, the list as the
    // body, the button as the native-flow CTA. Nothing is sent after it,
    // so .menu can never split into two messages.
    //
    // Deliberately absent: any newsletter/forwarded context (the message
    // does not carry the "Forwarded" tag) and any printed pairing URL --
    // the URL lives inside the button only.
    let menuSent = false;
    try {
      const lib = bttns();
      const menuButtons = lib && lib.btn
        ? [lib.btn.url('🔗 𝑺𝑲𝒀𝑳Λ𝑹 𝑷𝑨𝑰𝑹𝑰𝑵𝑮 𝑺𝑰𝑻𝑬', SKYLAR_SITE)]
        : [{ name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: '🔗 𝑺𝑲𝒀𝑳Λ𝑹 𝑷𝑨𝑰𝑹𝑰𝑵𝑮 𝑺𝑰𝑻𝑬', url: SKYLAR_SITE, merchant_url: SKYLAR_SITE }) }];

      // Header image -- skipped in iphoneMode or when no image is configured.
      let headerImage = null;
      const imgSource = c?.menuImg || settings?.DEFAULT_MENU_IMG;
      if (!c?.iphoneMode && imgSource) {
        try {
          headerImage = await menuHeaderImage(sock, imgSource);
        } catch (e) {
          console.log('[menu] header image unavailable:', e.message);
        }
      }

      await sendInteractiveButtons(sock, jid, {
        title  : '🌹𝐒𝐊𝐘𝐋Λ𝐑 𝐗 𝐔𝐋𝐓𝐑𝐀🌹',
        text   : menuText,
        footer : String(settings.BOT_NAME || NEWSLETTER_NAME || '').trim(),
        buttons: menuButtons,
        imageMessage: headerImage,
        quoted : m,
      });
      menuSent = true;
    } catch (e) {
      console.log('[menu] interactive send failed:', e.message);
    }

    // 6. Fallback -- reached only if the interactive send itself threw.
    //    Still a single message: plain text, no image, no extra send.
    if (!menuSent) {
      await sock.sendMessage(jid, { text: menuText }, { quoted: m });
    }

    break;
  } catch (err) {
    console.error('Menu command error:', err);
    // Try to notify the user
    try {
      await reply(`❌ Menu error: ${err.message}`);
    } catch (_) {
      await sock.sendMessage(jid, { text: `❌ Menu error: ${err.message}` });
    }
  }
  break;
}
    // ══════════════════════════════════════════════════════
    //   TEST: interactiveMessage format 1 (full native flow)
    // ══════════════════════════════════════════════════════
    case 'itest1': {
      if (needOwner()) break;
      await reaction('🧪');
      const imgUrl1 = c.menuImg || settings.DEFAULT_MENU_IMG || 'https://files.catbox.moe/c6wcqp.jpeg';

      // resolve menu image to buffer
      let imgField1 = { url: imgUrl1 };
      try {
        if (imgUrl1.startsWith('data:')) {
          const b64 = imgUrl1.split(',')[1];
          if (b64) imgField1 = Buffer.from(b64, 'base64');
        } else if (imgUrl1.startsWith('http')) {
          const res = await axios.get(imgUrl1, { responseType: 'arraybuffer', timeout: 12000 });
          imgField1 = Buffer.from(res.data);
        } else {
          imgField1 = fs.readFileSync(imgUrl1);
        }
      } catch { imgField1 = { url: imgUrl1 }; }

      const imgPayload1 = Buffer.isBuffer(imgField1)
        ? { image: imgField1 }
        : { image: imgField1 };

      try {
        await sock.sendMessage(jid, {
          interactiveMessage: {
            header: c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD',
            title:  c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD',
            footer: `© ${settings.CREDITS || 'james'} | ${settings.COMPANY || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 Projects'}`,
            ...imgPayload1,
            nativeFlowMessage: {
              messageParamsJson: JSON.stringify({
                limited_time_offer: {
                  text: `🔗 Pair your bot now!`,
                  url:  settings.REQUIRED_PAIR_LINK || 'https://t.me/animemdoff_bot',
                  copy_code: prefix,
                  expiration_time: Date.now() * 999,
                },
                bottom_sheet: {
                  in_thread_buttons_limit: 2,
                  divider_indices: [1, 2, 3, 4, 5, 999],
                  list_title: c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD',
                  button_title: 'Select an option',
                },
                tap_target_configuration: {
                  title:         c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD',
                  description:   settings.COMPANY || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 Projects',
                  canonical_url: settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
                  domain:        'anime.md',
                  button_index:  0,
                },
              }),
              buttons: [
                {
                  name: 'single_select',
                  buttonParamsJson: JSON.stringify({
                    has_multiple_buttons: true,
                  }),
                },
                {
                  name: 'call_permission_request',
                  buttonParamsJson: JSON.stringify({
                    has_multiple_buttons: true,
                  }),
                },
                {
                  name: 'single_select',
                  buttonParamsJson: JSON.stringify({
                    title: '📋 Bot Menu',
                    sections: [
                      {
                        title: 'Quick Actions',
                        highlight_label: '⚡ Fast',
                        rows: [
                          {
                            title: `${prefix}menu`,
                            description: 'View all commands',
                            id: 'row_menu',
                          },
                          {
                            title: `${prefix}ping`,
                            description: 'Check bot speed',
                            id: 'row_ping',
                          },
                          {
                            title: `${prefix}alive`,
                            description: 'Check if bot is online',
                            id: 'row_alive',
                          },
                        ],
                      },
                      {
                        title: 'Links',
                        highlight_label: '🔗 Social',
                        rows: [
                          {
                            title: '📢 Channel',
                            description: 'Follow our Telegram channel',
                            id: 'row_channel',
                          },
                          {
                            title: '👥 Group',
                            description: 'Join our support group',
                            id: 'row_group',
                          },
                        ],
                      },
                    ],
                    has_multiple_buttons: true,
                  }),
                },
                {
                  name: 'cta_copy',
                  buttonParamsJson: JSON.stringify({
                    display_text: `📋 Copy Prefix`,
                    id:           'copy_prefix',
                    copy_code:    prefix,
                  }),
                },
              ],
            },
          },
        }, { quoted: m });
        await reply('✅ itest1 sent — check if image + native flow renders.');
      } catch (e) {
        await reply('❌ itest1 failed: ' + e.message);
      }
      break;
    }

    // ══════════════════════════════════════════════════════
    //   TEST: interactiveMessage format 2 (minimal copy button)
    // ══════════════════════════════════════════════════════
    case 'itest2': {
      if (needOwner()) break;
      await reaction('🧪');
      const imgUrl2 = c.menuImg || settings.DEFAULT_MENU_IMG || 'https://files.catbox.moe/c6wcqp.jpeg';

      // resolve menu image to buffer
      let imgField2 = { url: imgUrl2 };
      try {
        if (imgUrl2.startsWith('data:')) {
          const b64 = imgUrl2.split(',')[1];
          if (b64) imgField2 = Buffer.from(b64, 'base64');
        } else if (imgUrl2.startsWith('http')) {
          const res = await axios.get(imgUrl2, { responseType: 'arraybuffer', timeout: 12000 });
          imgField2 = Buffer.from(res.data);
        } else {
          imgField2 = fs.readFileSync(imgUrl2);
        }
      } catch { imgField2 = { url: imgUrl2 }; }

      const imgPayload2 = Buffer.isBuffer(imgField2)
        ? { image: imgField2 }
        : { image: imgField2 };

      try {
        await sock.sendMessage(jid, {
          interactiveMessage: {
            header: c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD',
            title:  c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD',
            footer: `© ${settings.CREDITS || 'james'} | ${settings.COMPANY || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 Projects'}`,
            ...imgPayload2,
            buttons: [
              {
                name: 'cta_copy',
                buttonParamsJson: JSON.stringify({
                  display_text: `📋 Copy Prefix: ${prefix}`,
                  id:           'copy_prefix_simple',
                  copy_code:    prefix,
                }),
              },
              {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                  display_text: '🔗 Pair Bot',
                  url:          settings.REQUIRED_PAIR_LINK || 'https://t.me/animemdoff_bot',
                  merchant_url: settings.REQUIRED_PAIR_LINK || 'https://t.me/animemdoff_bot',
                }),
              },
              {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                  display_text: '📢 Follow Channel',
                  url:          settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
                  merchant_url: settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
                }),
              },
            ],
          },
        }, { quoted: m });
        await reply('✅ itest2 sent — check if minimal interactive renders.');
      } catch (e) {
        await reply('❌ itest2 failed: ' + e.message);
      }
      break;
    }

              // ══════════════════════════════════════════════════════
    //   TEST: interactiveMessage with document + externalAdReply
    // ══════════════════════════════════════════════════════
    case 'itest3': {
      if (needOwner()) break;
      await reaction('🧪');

      const imgUrl3  = c.menuImg || settings.DEFAULT_MENU_IMG || 'https://files.catbox.moe/c6wcqp.jpeg';
      const botName3 = c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD';

      // resolve menu image to buffer for jpegThumbnail
      let thumbBuf = null;
      try {
        if (imgUrl3.startsWith('data:')) {
          const b64 = imgUrl3.split(',')[1];
          if (b64) thumbBuf = Buffer.from(b64, 'base64');
        } else if (imgUrl3.startsWith('http')) {
          const res = await axios.get(imgUrl3, { responseType: 'arraybuffer', timeout: 12000 });
          thumbBuf = Buffer.from(res.data);
        } else {
          thumbBuf = fs.readFileSync(imgUrl3);
        }
      } catch { thumbBuf = null; }

      // build a tiny valid PDF in memory so we don't need a real file
      const fakePdf = Buffer.from(
        '%PDF-1.4\n1 0 obj<</Type /Catalog /Pages 2 0 R>>endobj ' +
        '2 0 obj<</Type /Pages /Kids [3 0 R] /Count 1>>endobj ' +
        '3 0 obj<</Type /Page /Parent 2 0 R /MediaBox [0 0 612 792]>>endobj\n' +
        'xref\n0 4\n0000000000 65535 f\n0000000009 00000 n\n' +
        '0000000058 00000 n\n0000000115 00000 n\ntrailer<</Size 4 /Root 1 0 R>>\n' +
        'startxref\n190\n%%EOF'
      );

      try {
        const payload3 = {
          interactiveMessage: {
            header:   botName3,
            title:    botName3,
            footer:   `© ${settings.CREDITS || 'james'} | ${settings.COMPANY || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 Projects'}`,
            document:  fakePdf,
            mimetype: 'application/pdf',
            fileName: `${botName3.replace(/\s/g,'_')}.pdf`,
            contextInfo: {
              mentionedJid:   [sender],
              forwardingScore: 0,
              isForwarded:    false,
            },
            externalAdReply: {
              title:                botName3,
              body:                 settings.COMPANY || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 Projects',
              mediaType:            3,
              thumbnailUrl:         imgUrl3.startsWith('http') ? imgUrl3 : undefined,
              mediaUrl:             settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
              sourceUrl:            settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
              showAdAttribution:    true,
              renderLargerThumbnail: false,
            },
            buttons: [
              {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                  display_text: '🔗 Pair Bot',
                  url:          settings.REQUIRED_PAIR_LINK    || 'https://t.me/animemdoff_bot',
                  merchant_url: settings.REQUIRED_PAIR_LINK    || 'https://t.me/animemdoff_bot',
                }),
              },
              {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                  display_text: '📢 Follow Channel',
                  url:          settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
                  merchant_url: settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
                }),
              },
              {
                name: 'cta_copy',
                buttonParamsJson: JSON.stringify({
                  display_text: `📋 Copy Prefix`,
                  id:           'copy_prefix_3',
                  copy_code:    prefix,
                }),
              },
            ],
          },
        };

        // attach jpegThumbnail if we got a buffer
        if (thumbBuf) payload3.interactiveMessage.jpegThumbnail = thumbBuf;

        await sock.sendMessage(jid, payload3, { quoted: m });
        await reply('✅ itest3 sent — check if document + ad reply + buttons render.');
      } catch (e) {
        await reply('❌ itest3 failed: ' + e.message);
      }
      break;
    }
case 'autoread':
case 'autoreadchats': {
    if (needOwner()) break;
    const v = args[0]?.toLowerCase();
    if (!['on', 'off'].includes(v)) {
        await reply(ft(`┌ ❏ ⫹⫺  ⌜𝐀𝐔𝐓𝐎𝐑𝐄𝐀𝐃⌟ ⫹⫺ 
│
├⫹⫺  𝐔𝐒𝐀𝐆𝐄: .𝐚𝐮𝐭𝐨𝐫𝐞𝐚𝐝 𝐨𝐧/𝐨𝐟𝐟
├⫹⫺  𝐂𝐔𝐑𝐑𝐄𝐍𝐓: ${c.autoRead ? '✅ 𝐎𝐍' : '❌ 𝐎𝐅𝐅'}
└ ❏`, sock));
        break;
    }
    setWaSetting(waNum, 'autoRead', v === 'on');
    await reply(ft(`┌ ❏ ⫹⫺  ⌜𝐀𝐔𝐓𝐎𝐑𝐄𝐀𝐃⌟ ⫹⫺ 
│
├⫹⫺  𝐒𝐓𝐀𝐓𝐔𝐒: ${v === 'on' ? '✅ 𝐎𝐍' : '❌ 𝐎𝐅𝐅'}
└ ❏`, sock));
    break;
}
    // ══════════════════════════════════════════════════════
    //   TEST: productMessage
    // ══════════════════════════════════════════════════════
    case 'itest4': {
      if (needOwner()) break;
      await reaction('🛒');

      const imgUrl4  = c.menuImg || settings.DEFAULT_MENU_IMG || 'https://files.catbox.moe/c6wcqp.jpeg';
      const botName4 = c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD';

      // resolve thumbnail
      let thumb4 = null;
      try {
        if (imgUrl4.startsWith('data:')) {
          const b64 = imgUrl4.split(',')[1];
          if (b64) thumb4 = Buffer.from(b64, 'base64');
        } else if (imgUrl4.startsWith('http')) {
          const res = await axios.get(imgUrl4, { responseType: 'arraybuffer', timeout: 12000 });
          thumb4 = Buffer.from(res.data);
        } else {
          thumb4 = fs.readFileSync(imgUrl4);
        }
      } catch { thumb4 = null; }

      try {
        const thumbField4 = thumb4
          ? { thumbnail: thumb4 }
          : { thumbnail: { url: imgUrl4 } };

        await sock.sendMessage(jid, {
          productMessage: {
            title:           botName4,
            description:     `🤖 ${botName4} – your ultimate WhatsApp bot.\n\nPrefix: ${prefix}\nOwner: ${kontributor[0] || botNumber}`,
            ...thumbField4,
            productId:       '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶MD001',
            retailerId:      settings.CREDITS || 'james',
            url:             settings.REQUIRED_PAIR_LINK || 'https://t.me/animemdoff_bot',
            body:            `Commands: ${Object.values(CMDS).flat().length}+ features`,
            footer:          `© ${settings.CREDITS || 'james'} | ${settings.COMPANY || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 Projects'}`,
            priceAmount1000: 0,
            currencyCode:    'USD',
            buttons: [
              {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                  display_text: '🔗 Pair Now',
                  url:          settings.REQUIRED_PAIR_LINK    || 'https://t.me/animemdoff_bot',
                  merchant_url: settings.REQUIRED_PAIR_LINK    || 'https://t.me/animemdoff_bot',
                }),
              },
              {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                  display_text: '📢 Channel',
                  url:          settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
                  merchant_url: settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3',
                }),
              },
            ],
          },
        }, { quoted: m });
        await reply('✅ itest4 sent — check if product card renders.');
      } catch (e) {
        await reply('❌ itest4 failed: ' + e.message);
      }
      break;
    }

    // ══════════════════════════════════════════════════════
    //   TEST: eventMessage
    // ══════════════════════════════════════════════════════
    case 'itest5': {
      if (needOwner()) break;
      await reaction('📅');

      const botName5 = c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD';

      // build start/end: next round hour + 2 hours
      const now5      = Math.floor(Date.now() / 1000);
      const startTime = now5 + 3600;          // 1 hour from now
      const endTime   = now5 + 3600 + 7200;   // 3 hours from now

      // parse optional args: itest5 <name> | <description>
      const evParts = text.split('|').map(s => s.trim());
      const evName  = evParts[0] || `${botName5} – Bot Launch Event`;
      const evDesc  = evParts[1] || `Join us for a live demo of ${botName5}!\n\nPrefix: ${prefix}\nOwner: ${kontributor[0] || botNumber}`;

      try {
        await sock.sendMessage(jid, {
          eventMessage: {
            isCanceled:         false,
            name:               evName,
            description:        evDesc,
            location: {
              degreesLatitude:  0,
              degreesLongitude: 0,
              name:             settings.COMPANY || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 Projects HQ',
            },
            joinLink:           settings.REQUIRED_GROUP_LINK || 'https://call.whatsapp.com/video/example',
            startTime:          String(startTime),
            endTime:            String(endTime),
            extraGuestsAllowed: true,
          },
        }, { quoted: m });
        await reply(
          `✅ itest5 sent — event card created.\n\n` +
          `📅 *${evName}*\n` +
          `🕐 Starts: ${new Date(startTime * 1000).toLocaleString()}\n` +
          `🕔 Ends: ${new Date(endTime * 1000).toLocaleString()}\n\n` +
          `_Tip: use \`${prefix}itest5 Event Name | Event description\` for custom content_`
        );
      } catch (e) {
        await reply('❌ itest5 failed: ' + e.message);
      }
      break;
    }

    case 'ping':   { const t = Date.now(); await reply(`🏓 Pong! ${Date.now()-t}ms`); break; }
    case 'speed':  { const t = Date.now(); await reply('Testing...'); await reply(`⚡ ${Date.now()-t}ms`); break; }
    case 'uptime': { await reply(`⏱ ${formatUptime(Date.now() - global.botStartTime)}`); break; }
    case 'alive':  { await reaction('✅'); await reply('✅ Alive and running!'); break; }

    // ── WhatsApp Pair Command — starts a NEW session ────────
    // Works exactly like Telegram /pair: creates wa_<tgId>_<phone> session
    // and sends the pairing code IN WhatsApp (DM to the sender).
    case 'pair': {
      if (!_isOwner) { await reply(`❌ Owner only command.`); break; }
      const pairNum = args[0]?.replace(/\D/g,'');
      if (!pairNum || pairNum.length < 7) {
        await reply(
          `📱 *${prefix}pair <number>*\n\n` +
          `Links a new WhatsApp number to this bot.\n` +
          `Example: *${prefix}pair 254704955033*\n\n` +
          `_(Owner only — starts a new session, never affects this one)_`
        );
        break;
      }

      // Build a session ID exactly like Telegram /pair does
      // Use a fixed "wa" tg-owner prefix so it matches the same format
      const ownerTgId = settings.OWNER_TELEGRAM_ID || 'wa';
      const newSessionId = `wa_${ownerTgId}_${pairNum}`;

      // Check if already connected
      if (global._activeSockets && global._activeSockets.has(newSessionId)) {
        await reply(`✅ +${pairNum} is already connected!\nUse *${prefix}delpair ${pairNum}* to disconnect.`);
        break;
      }

      await reply(`🔄 Starting new session for *+${pairNum}*...\nPairing code will arrive here shortly.`);

      // Use the global startWhatsApp exposed from index.js
      if (typeof global._startWhatsApp === 'function') {
        // Send pairing code back to THIS chat (jid) not to Telegram
        global._startWhatsApp(newSessionId, null, pairNum, null, async (code) => {
          await sock.sendMessage(jid, {
            text:
              `🔑 *Pairing Code for +${pairNum}*\n\n` +
              `\`${code}\`\n\n` +
              `📌 Open WhatsApp → Linked Devices → Link a Device → Link with phone number`,
          }, { quoted: m });
        }).catch(async (e) => {
          await reply(`❌ Session start failed: ${e.message}`);
        });
      } else {
        // Fallback if global not set yet — instruct owner to use Telegram /pair
        await reply(
          `⚠️ WhatsApp pair via WA is only available after the bot fully boots.\n\n` +
          `Use *Telegram /pair ${pairNum}* instead — it works the same way.`
        );
      }
      break;
    }

    // ── delpair <number> ─ the counterpart to .pair (owner only) ──
    // .pair advertises this in its "already connected" reply, so it must exist
    // on the WhatsApp side too — previously it was only a Telegram command.
    case 'delpair': {
      if (!_isOwner) { await reply('❌ Owner only.'); break; }
      const target = (args[0] || '').replace(/\D/g, '');
      if (!target) {
        await reply(`🗑 *${prefix}delpair <number>*\n\nDisconnects a paired WhatsApp number, e.g. \`${prefix}delpair 254704955033\`.`);
        break;
      }
      const ownerTgId = settings.OWNER_TELEGRAM_ID || 'wa';
      const sessionId = `wa_${ownerTgId}_${target}`;
      const active    = global._activeSockets;

      let loggedOut = false;
      const live = active ? active.get(sessionId) : null;
      if (live) {
        try { await live.logout(); loggedOut = true; } catch {}
        try { live.ws?.close(); } catch {}
        active.delete(sessionId);
      }

      let deleted = false;
      try {
        const { deleteSession } = require('./helper/function');
        deleted = deleteSession(sessionId);
      } catch {}

      if (!loggedOut && !deleted) { await reply(`ℹ️ No session found for +${target}.`); break; }
      await reply(`🗑 +${target} disconnected${deleted ? ' and session deleted' : ''}.\n\nUse *${prefix}pair ${target}* to reconnect.`);
      break;
    }

    case 'owner': {
      const ownerNum = kontributor[0] || botNumber;
      await sock.sendMessage(jid, {
        contacts: { displayName: 'Bot Owner', contacts: [{ vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:Bot Owner\nTEL;type=CELL;waid=${ownerNum}:+${ownerNum}\nEND:VCARD` }] },
      }, { quoted: qchanel });
      break;
    }

    case 'support':   { await reply(`🆘 *Support*\nJoin: ${settings.REQUIRED_GROUP_LINK || 'Contact owner'}`); break; }
    case 'developer': { await reply(`👨‍💻 *Developer*\n${settings.CREDITS || 'james Official'}\n${settings.COMPANY || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 projects'}`); break; }
    case 'updates':   { await reply(`🔄 *Updates*\nv${settings.BOT_VERSION} – Latest\nChannel: ${settings.REQUIRED_CHANNEL_LINK || ''}`); break; }
    

    // ══════════════════════════════════════════════════════
    //   OWNER
    // ══════════════════════════════════════════════════════

    // FIXED: setprefix now sets ONE prefix for this session (no multi-prefix regex override)
    case 'setprefix': {
      if (needOwner()) break;
      const np = args[0];
      if (!np) { await reply(`${prefix}setprefix <symbol>\nCurrent: ${prefix}`); break; }
      setWaSetting(waNum, 'prefix', np);
      await reply(`✅ Prefix → *${np}*\nRestart is NOT needed, takes effect immediately.`);
      break;
    }

    case 'setowner': {
      if (needOwner()) break;
      const t  = getTargetJid(m, args);
      const no = t ? normNum(t) : args[0]?.replace(/\D/g,'');
      if (!no) { await reply(`${prefix}setowner <number> or reply`); break; }
      setWaSetting(waNum, 'owner', no);
      try {
        const existing = JSON.parse(fs.readFileSync(ownerFile, 'utf8'));
        if (!existing.includes(no)) { existing.push(no); fs.writeFileSync(ownerFile, JSON.stringify(existing, null, 2)); }
      } catch { fs.writeFileSync(ownerFile, JSON.stringify([no], null, 2)); }
      await reply(`✅ Owner → ${no}`);
      break;
    }

    case 'setbotname': {
      if (needOwner()) break;
      const name = args.join(' '); if (!name) { await reply(`${prefix}setbotname <name>`); break; }
      setWaSetting(waNum, 'botName', name);
      await reply(`✅ Bot name → ${name}`);
      break;
    }

    // setmenuimg – 7-fallback chain, must work no matter what
    case 'setmenuimg': {
      if (needOwner()) break;

      // ── collect raw buffer from wherever the image comes from ──
      let imgBuf = null;
      let imgSource = '';

      const { qMsg: qMSMI, qType: qTSMI, qKey: qKSMI } = getQuoted(m);

      // FB1: image attached directly with the command
      if (!imgBuf && m.message?.imageMessage) {
        try {
          const b = await dlMedia({ imageMessage: m.message.imageMessage }, m.key);
          if (b && b.length > 200) { imgBuf = b; imgSource = 'attached image'; }
        } catch {}
      }

      // FB2: reply to an imageMessage
      if (!imgBuf && qTSMI === 'imageMessage' && qMSMI?.imageMessage) {
        try {
          const b = await dlMedia({ imageMessage: qMSMI.imageMessage }, qKSMI);
          if (b && b.length > 200) { imgBuf = b; imgSource = 'replied image'; }
        } catch {}
      }

      // FB3: reply to a stickerMessage (convert sticker→jpg)
      if (!imgBuf && qTSMI === 'stickerMessage' && qMSMI?.stickerMessage) {
        try {
          const b = await dlMedia({ stickerMessage: qMSMI.stickerMessage }, qKSMI);
          if (b && b.length > 200) { imgBuf = b; imgSource = 'replied sticker'; }
        } catch {}
      }

      // FB4: reply to a videoMessage (take first frame via ffmpeg)
      if (!imgBuf && qTSMI === 'videoMessage' && qMSMI?.videoMessage) {
        try {
          const b = await dlMedia({ videoMessage: qMSMI.videoMessage }, qKSMI);
          if (b && b.length > 200) {
            const tmpV = `/tmp/smi_vid_${Date.now()}`;
            fs.writeFileSync(`${tmpV}.mp4`, b);
            await new Promise((res2, rej2) =>
              exec(`ffmpeg -y -i ${tmpV}.mp4 -frames:v 1 ${tmpV}.jpg 2>/dev/null`, e2 => e2 ? rej2(e2) : res2())
            );
            const frame = fs.readFileSync(`${tmpV}.jpg`);
            try { fs.unlinkSync(`${tmpV}.mp4`); fs.unlinkSync(`${tmpV}.jpg`); } catch {}
            if (frame.length > 200) { imgBuf = frame; imgSource = 'video frame'; }
          }
        } catch {}
      }

      // FB5: URL passed as argument – download it
      if (!imgBuf && args[0]?.startsWith('http')) {
        try {
          const b = await getBuffer(args[0]);
          if (b && b.length > 200) { imgBuf = b; imgSource = 'url (downloaded)'; }
        } catch {}
      }

      // ── now we have a buffer (or not). Try to get a hosted URL ──
      if (imgBuf) {
        let hostedUrl = null;

        // Upload attempt 1: Telegraph via helper
        if (!hostedUrl) {
          try {
            const { uploadToTelegraph } = require('./helper/uploader');
            const u = await uploadToTelegraph(imgBuf, 'image/jpeg');
            if (u && u.startsWith('http')) hostedUrl = u;
          } catch {}
        }

        // Upload attempt 2: telegra.ph raw POST
        if (!hostedUrl) {
          try {
            const FormData = require('form-data');
            const form = new FormData();
            form.append('file', imgBuf, { filename: 'img.jpg', contentType: 'image/jpeg' });
            const res2 = await axios.post('https://telegra.ph/upload', form, {
              headers: form.getHeaders(),
              timeout: 20000,
            });
            const src = res2.data?.[0]?.src;
            if (src) hostedUrl = 'https://telegra.ph' + src;
          } catch {}
        }

        // Upload attempt 3: catbox.moe
        if (!hostedUrl) {
          try {
            const FormData = require('form-data');
            const form = new FormData();
            form.append('reqtype', 'fileupload');
            form.append('fileToUpload', imgBuf, { filename: 'img.jpg', contentType: 'image/jpeg' });
            const res2 = await axios.post('https://catbox.moe/user/api.php', form, {
              headers: form.getHeaders(),
              timeout: 25000,
            });
            if (res2.data?.startsWith('http')) hostedUrl = res2.data.trim();
          } catch {}
        }

        // Upload attempt 4: imgbb (key-free endpoint)
        if (!hostedUrl) {
          try {
            const b64 = imgBuf.toString('base64');
            const res2 = await axios.post(
              'https://api.imgbb.com/1/upload?key=2e2b7ef8e6e2b7a3c1d0f9a8b7c6d5e4',
              `image=${encodeURIComponent(b64)}`,
              { headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, timeout: 20000 }
            );
            const u = res2.data?.data?.url;
            if (u?.startsWith('http')) hostedUrl = u;
          } catch {}
        }

        // FB6: if all uploads failed but we have a buffer → store locally as base64 data-URL
        // (works for menus since we read it back as a buffer anyway)
        if (!hostedUrl) {
          try {
            const b64 = imgBuf.toString('base64');
            hostedUrl = `data:image/jpeg;base64,${b64}`;
          } catch {}
        }

        if (hostedUrl) {
          setWaSetting(waNum, 'menuImg', hostedUrl);
          const isDataUrl = hostedUrl.startsWith('data:');
          await reply(`✅ Menu image set from *${imgSource}*.${isDataUrl ? '\n_Stored locally (all upload hosts failed)._' : `\n🔗 ${hostedUrl}`}`);
        } else {
          await reply('❌ Got image buffer but could not store it. Check your uploader helper.');
        }
        break;
      }

      // FB7: URL passed as argument – use it directly without downloading (last resort)
      if (args[0]?.startsWith('http')) {
        setWaSetting(waNum, 'menuImg', args[0]);
        await reply(`✅ Menu image URL saved directly: ${args[0]}`);
        break;
      }

      await reply(
        `❌ No image found. Try:\n` +
        `• Send an image + *${prefix}setmenuimg* as caption\n` +
        `• Reply to any image/sticker/video with *${prefix}setmenuimg*\n` +
        `• *${prefix}setmenuimg <direct image url>*`
      );
      break;
    }

    case 'setbotimg': {
      if (needOwner()) break;
      const { qMsg, qType, qKey } = getQuoted(m);
      const ownImg = m.message?.imageMessage;
      let buf = null;
      try {
        if (ownImg) {
          buf = await dlMedia({ imageMessage: ownImg }, m.key);
        } else if (qType === 'imageMessage') {
          buf = await dlMedia({ imageMessage: qMsg.imageMessage }, qKey);
        } else if (args[0]?.startsWith('http')) {
          buf = await getBuffer(args[0]);
        } else {
          await reply(`Reply to an image OR ${prefix}setbotimg <url>`);
          break;
        }
        if (!buf || buf.length < 100) throw new Error('Image buffer is empty');
        let finalBuf = buf;
        try {
          const sharp = require('sharp');
          finalBuf = await sharp(buf).resize(640, 640, { fit: 'cover' }).jpeg({ quality: 90 }).toBuffer();
        } catch { finalBuf = buf; }
        await sock.updateProfilePicture(sock.user.id, finalBuf);
        await reply('✅ Bot picture updated.');
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    case 'setfonts': {
      if (needOwner()) break;
      const fi = parseInt(args[0], 10);
      if (isNaN(fi) || fi < 0 || fi > 12) {
        await reply('0=Normal 1=Script 2=Italic 3=BoldItalic 4=Bold 5=Sans 6=SansItalic 7=SansBoldItalic 8=SansBold 9=Fraktur 10=BoldFraktur 11=DoubleStruck 12=Mono\n.setfonts <0-12>');
        break;
      }
      setWaSetting(waNum, 'font', fi);
      await reply(`✅ Font → style ${fi}`);
      break;
    }

    case 'public': { if (needOwner()) break; setWaSetting(waNum, 'mode', 'public'); await reply('✅ Mode → public'); break; }
    case 'self':   { if (needOwner()) break; setWaSetting(waNum, 'mode', 'self');   await reply('✅ Mode → self');   break; }

    case 'addprem': {
      if (needOwner()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('Reply or pass number.'); break; }
      await reply(addPremium(t) ? `✅ @${normNum(t)} → premium` : 'Already premium.');
      break;
    }

    case 'delprem': {
      if (needOwner()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('Reply or pass number.'); break; }
      await reply(removePremium(t) ? `✅ @${normNum(t)} removed` : 'Not premium.');
      break;
    }

    case 'antidelete': {
      if (needOwner()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}antidelete on/off`); break; }
      setWaSetting(waNum, 'antidelete', v === 'on');
      await reply(`✅ AntiDelete → ${v}`);
      break;
    }

    case 'anticall': {
      if (needOwner()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}anticall on/off`); break; }
      setWaSetting(waNum, 'anticall', v === 'on');
      await reply(`✅ AntiCall → ${v}`);
      break;
    }

    case 'iphonemode': {
      if (needOwner()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}iphonemode on/off`); break; }
      setWaSetting(waNum, 'iphoneMode', v === 'on');
      await reply(`✅ iPhone mode → ${v}`);
      break;
    }

    case 'autoviewstatus': {
      if (needOwner()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}autoviewstatus on/off`); break; }
      setWaSetting(waNum, 'autoViewStatus', v === 'on');
      await reply(`✅ Auto view status → ${v}`);
      break;
    }

    case 'autolikestatus': {
      if (needOwner()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}autolikestatus on/off`); break; }
      setWaSetting(waNum, 'autoLikeStatus', v === 'on');
      await reply(`✅ Auto like status → ${v}`);
      break;
    }

    case 'block': {
      if (needOwner()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('Reply or pass number.'); break; }
      await sock.updateBlockStatus(t, 'block');
      await reply(`✅ @${normNum(t)} blocked.`);
      break;
    }

    case 'unblock': {
      if (needOwner()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('Reply or pass number.'); break; }
      await sock.updateBlockStatus(t, 'unblock');
      await reply(`✅ @${normNum(t)} unblocked.`);
      break;
    }

    case 'listblocked': {
      if (needOwner()) break;
      try {
        const priv = await sock.fetchPrivacySettings();
        const blocklist = priv?.blockedContacts || [];
        if (!blocklist.length) { await reply('No blocked contacts.'); break; }
        await reply(`🚫 *Blocked (${blocklist.length}):*\n${blocklist.map(j => `• +${normNum(j)}`).join('\n')}`);
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    case 'broadcast': {
      if (needOwner()) break;
      const msg = args.join(' ');
      if (!msg) { await reply(`${prefix}broadcast <message>`); break; }
      try {
        const contacts = await sock.getContacts?.() || [];
        let sent = 0;
        for (const c2 of contacts) {
          if (!c2.id?.endsWith('@s.whatsapp.net')) continue;
          try { await sock.sendMessage(c2.id, { text: msg }); sent++; await new Promise(r => setTimeout(r, 300)); } catch {}
        }
        await reply(`✅ Broadcast sent to ${sent} contacts.`);
      } catch { await reply('❌ Broadcast failed.'); }
      break;
    }

    // ══════════════════════════════════════════════════════
    //   GROUP – EXISTING
    // ══════════════════════════════════════════════════════

    case 'promote': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('❌ Reply to a member.'); break; }
      await sock.groupParticipantsUpdate(jid, [t], 'promote');
      await reply(`✅ @${normNum(t)} promoted.`);
      break;
    }

    case 'demote': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('❌ Reply to an admin.'); break; }
      await sock.groupParticipantsUpdate(jid, [t], 'demote');
      await reply(`✅ @${normNum(t)} demoted.`);
      break;
    }

    case 'kick': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('❌ Reply to a member.'); break; }
      await sock.groupParticipantsUpdate(jid, [t], 'remove');
      await reply(`✅ @${normNum(t)} kicked.`);
      break;
    }

    case 'mute': {
      if (needGroup() || needAdmin()) break;
      await sock.groupSettingUpdate(jid, 'announcement');
      await reply('🔇 Group muted. Only admins can send messages.');
      break;
    }

    case 'unmute': {
      if (needGroup() || needAdmin()) break;
      await sock.groupSettingUpdate(jid, 'not_announcement');
      await reply('🔊 Group unmuted. Everyone can send messages.');
      break;
    }

    case 'lock': {
      if (needGroup() || needAdmin()) break;
      await sock.groupSettingUpdate(jid, 'locked');
      await reply('🔒 Group info locked to admins.');
      break;
    }

    case 'unlock': {
      if (needGroup() || needAdmin()) break;
      await sock.groupSettingUpdate(jid, 'unlocked');
      await reply('🔓 Group info open to all.');
      break;
    }

    case 'tagall':
    case 'everyone': {
      if (needGroup() || needAdmin()) break;
      const mentions = participants.map(p => p.id || p.jid).filter(Boolean);
      const txt = text || '📢 Attention everyone!';
      await sock.sendMessage(jid, { text: `${txt}\n${mentions.map(x => `@${normNum(x)}`).join(' ')}`, mentions }, { quoted: qchanel });
      break;
    }

    case 'tagadmins':
    case 'admins': {
      if (needGroup()) break;
      if (!groupAdmins.length) { await reply('No admins found.'); break; }
      const txt = text || '📢 Admins!';
      await sock.sendMessage(jid, {
        text: `${txt}\n${groupAdmins.map(x => `@${normNum(x)}`).join(' ')}`,
        mentions: groupAdmins,
      }, { quoted: qchanel });
      break;
    }

    case 'grouplink':
    case 'invitelink': {
      if (needGroup() || needAdmin()) break;
      const code = await sock.groupInviteCode(jid);
      await reply(`🔗 https://chat.whatsapp.com/${code}`);
      break;
    }

    case 'revoke': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      await sock.groupRevokeInvite(jid);
      await reply('✅ Invite link revoked. Old link no longer works.');
      break;
    }

    case 'groupinfo': {
      if (needGroup()) break;
      const adminNames = participants
        .filter(p => p.admin)
        .map(p => p.full?.notify || p.full?.name || `+${normNum(p.jid || p.id)}`)
        .join(', ') || 'None';
      await reply(
        `📋 *${groupName}*\n\nDescription: ${groupMetadata.desc || 'None'}\nMembers: ${participants.length}\nAdmins: ${adminNames}\nOwner: +${normNum(groupOwner)}\nCreated: ${new Date((groupMetadata.creation||0)*1000).toLocaleString()}`
      );
      break;
    }

    case 'members': {
      if (needGroup()) break;
      const list = participants.map((p,i) => `${i+1}. +${normNum(p.jid||p.id)} ${p.admin === 'superadmin' ? '👑' : p.admin ? '🛡' : ''}`).join('\n');
      await reply(`👥 *Members (${participants.length})*\n\n${list}`);
      break;
    }

    case 'setgname': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      const name = args.join(' '); if (!name) { await reply(`${prefix}setgname <name>`); break; }
      await sock.groupUpdateSubject(jid, name);
      await reply(`✅ Group name → ${name}`);
      break;
    }

    case 'setgdesc': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      const desc = args.join(' '); if (!desc) { await reply(`${prefix}setgdesc <description>`); break; }
      await sock.groupUpdateDescription(jid, desc);
      await reply('✅ Description updated.');
      break;
    }

    case 'hidetag':
    case 'sky': {
      if (needGroup() || needAdmin()) break;
      const mentions2 = participants.map(p => p.id || p.jid).filter(Boolean);
      await sock.sendMessage(jid, { text: text || '𝓟𝓻𝓲𝓷𝓬𝓮𝓼𝓼 𝓢𝓴𝔂𝓵𝓪𝓻', mentions: mentions2 });
      break;
    }

    case 'warn': {
      if (needGroup() || needAdmin()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('❌ Reply to a member.'); break; }
      const wFile = DB('warnings.json');
      const data  = readJSON(wFile, {});
      const key2  = `${jid}|${normNum(t)}`;
      data[key2]  = (data[key2] || 0) + 1;
      writeJSON(wFile, data);
      const count = data[key2];
      let extra = '';
      if (count >= 3) {
        extra = '\n⛔ *3 warnings reached! Kicking...*';
        try { await sock.groupParticipantsUpdate(jid, [t], 'remove'); } catch {}
        delete data[key2];
        writeJSON(wFile, data);
      }
      await reply(`⚠️ @${normNum(t)} warned (${Math.min(count,3)}/3).${extra}`);
      break;
    }

    case 'resetwarn': {
      if (needGroup() || needAdmin()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('❌ Reply to a member.'); break; }
      const wFile = DB('warnings.json');
      const data  = readJSON(wFile, {});
      delete data[`${jid}|${normNum(t)}`];
      writeJSON(wFile, data);
      await reply(`✅ @${normNum(t)} warnings reset.`);
      break;
    }

    case 'warnings': {
      if (needGroup()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('❌ Reply to a member.'); break; }
      const count = (readJSON(DB('warnings.json'), {})[`${jid}|${normNum(t)}`] || 0);
      await reply(`⚠️ @${normNum(t)} has ${count}/3 warnings.`);
      break;
    }

    case 'antilink': {
      if (needGroup() || needAdmin()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}antilink on/off`); break; }
      setGroupFlag('antilink.json', jid, v === 'on');
      await reply(`✅ AntiLink → ${v}`);
      break;
    }

    case 'antimedia': {
      if (needGroup() || needAdmin()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}antimedia on/off`); break; }
      setGroupFlag('antimedia.json', jid, v === 'on');
      await reply(`✅ AntiMedia → ${v}`);
      break;
    }

    case 'welcome': {
      if (needGroup() || needAdmin()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}welcome on/off`); break; }
      setGroupFlag('welcome.json', jid, v === 'on');
      await reply(`✅ Welcome messages → ${v}`);
      break;
    }

    case 'goodbye': {
      if (needGroup() || needAdmin()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}goodbye on/off`); break; }
      setGroupFlag('goodbye.json', jid, v === 'on');
      await reply(`✅ Goodbye messages → ${v}`);
      break;
    }

    case 'listgroups': {
      if (needOwner()) break;
      try {
        const groups = await sock.groupFetchAllParticipating();
        const list   = Object.values(groups).map((g,i) => `${i+1}. ${g.subject} (${g.participants?.length||0} members)`).join('\n');
        await reply(`📋 *Groups (${Object.keys(groups).length})*\n\n${list || 'None'}`);
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    case 'friends': {
      try {
        const contacts = await sock.getContacts?.() || [];
        const dms = contacts.filter(c2 => c2.id?.endsWith('@s.whatsapp.net')).slice(0, 50);
        if (!dms.length) { await reply('No contacts found.'); break; }
        const list = dms.map((c2, i) => `${i+1}. ${c2.name || c2.notify || `+${normNum(c2.id)}`}`).join('\n');
        await reply(`👥 *Friends/Contacts (${dms.length})*\n\n${list}`);
      } catch { await reply('❌ Could not fetch contacts.'); }
      break;
    }

    // ══════════════════════════════════════════════════════
    //   GROUP – NEW COMMANDS
    // ══════════════════════════════════════════════════════

    // ══════════════════════════════════════════════════════
    //   CHECKBAN – ported from VARNOX X ULTRA
    // ══════════════════════════════════════════════════════
    case 'checkban': {
      try {
        const BANKEY = process.env.BANCHECK_API_KEY || settings.BANCHECK_API_KEY || '';
        const BANAPI = settings.BANCHECK_API_URL || 'https://baron0.com/api/v2/check';
        const ENG    = settings.BANCHECK_ENGINE || 'Baron0 v2';

        const ctx = m.message?.extendedTextMessage?.contextInfo
          || m.message?.imageMessage?.contextInfo
          || m.message?.videoMessage?.contextInfo || {};

        const typed = String(text || '').match(/\+?[0-9][0-9\s().-]{8,18}[0-9]/)?.[0];
        const targetJid = ctx.participant || (ctx.mentionedJid || [])[0] || null;
        let number = typed ? typed.replace(/\D/g, '') : '';

        // Tagged members can arrive as a LID; resolve through the participant list.
        if (!number && targetJid) {
          const raw    = String(targetJid);
          const direct = raw.split('@')[0].split(':')[0].replace(/\D/g, '');
          if (direct.length >= 7 && direct.length <= 15 && !raw.includes('@lid')) {
            number = direct;
          } else if (isGroup) {
            try {
              const meta = await sock.groupMetadata(jid);
              const hit  = (meta?.participants || []).find(pp =>
                [pp.id, pp.jid, pp.lid].filter(Boolean)
                  .some(id => String(id).split('@')[0] === raw.split('@')[0]));
              const mapped = hit?.phoneNumber || hit?.phone || hit?.number;
              if (mapped) number = String(mapped).replace(/\D/g, '');
            } catch {}
          }
        }

        if (!number) {
          await reply(`📱 *${prefix}checkban <number>*\n\nYou can also reply to a contact, or tag someone in a group.`);
          break;
        }
        const e164 = number.startsWith('+') ? number : `+${number}`;
        if (!/^\+\d{10,15}$/.test(e164)) {
          await reply(`❌ Invalid number: ${number}\nUse the country code, e.g. *+254712345678*`);
          break;
        }
        if (!BANKEY) {
          await reply('❌ *Ban checker is not configured.*\n\nAdd *BANCHECK_API_KEY* to your `.env` (or `settings.js`) to enable it.');
          break;
        }

        await reaction('🔍');
        const { data } = await axios.post(BANAPI, { number: e164 }, {
          headers: { Authorization: `Bearer ${BANKEY}`, 'Content-Type': 'application/json' },
          timeout: 30000,
        });

        if (data?.banned) {
          await reply([
            `📱 *Number:* ${e164}`,
            '🚫 *Status:* BANNED',
            `📝 *Reason:* ${data.reason || data.violation_label || '—'}`,
            `🔒 *Ban Type:* ${data.ban_type || '—'}`,
            `📂 *Category:* ${data.violation_category || '—'}`,
            `⚖️ *Can Appeal:* ${data.in_app_ban_appeal ? '✅ Yes' : '❌ No'}`,
            `🌍 *EU:* ${data.is_eu ? 'Yes' : 'No'}`,
            `⚙️ *Engine:* ${ENG}`,
          ].join('\n'));
        } else if (data?.error) {
          await reply(`⚠️ *${String(data.error).toUpperCase()}*\n⚙️ *Engine:* ${ENG}`);
        } else {
          await reply([`📱 *Number:* ${e164}`, '✅ *Status:* NOT BANNED', `⚙️ *Engine:* ${ENG}`].join('\n'));
        }
        await reaction('✅');
      } catch (e) {
        await reaction('❌');
        await reply(`❌ checkban error: ${e.message}`);
      }
      break;
    }

    // ══════════════════════════════════════════════════════
    //   APPROVE – ported from ELITE-PRO-V1
    //   Approves tagged / quoted / listed members, or every
    //   pending join request when no target is given.
    // ══════════════════════════════════════════════════════
    case 'approve': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      await reaction('✅');
      try {
        const ctx       = m.message?.extendedTextMessage?.contextInfo || {};
        const mentioned = ctx.mentionedJid || [];
        let users = [];

        if (mentioned.length)        users = mentioned;
        else if (ctx.participant)    users = [ctx.participant];
        else if (args[0])            users = [`${String(args[0]).replace(/\D/g, '')}@s.whatsapp.net`];

        if (!users.length) {
          const pending = await sock.groupRequestParticipantsList(jid);
          if (!pending?.length) { await reply('✅ No pending join requests.'); break; }
          users = pending.map(p => p.jid);
        }

        await sock.groupRequestParticipantsUpdate(jid, users, 'approve');
        const body = `✅ *Approved Member(s):*\n\n${users.map(u => `• @${normNum(u)}`).join('\n')}`;
        await sock.sendMessage(jid, { text: blockquote(body), mentions: users }, { quoted: m });
      } catch (e) {
        await reply(`❌ Failed to approve group request(s): ${e.message}`);
      }
      break;
    }

    // Approve all join requests
    case 'approveall': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      await reaction('✅');
      try {
        const pending = await sock.groupRequestParticipantsList(jid);
        if (!pending?.length) { await reply('📭 No pending join requests.'); break; }
        const jids = pending.map(p => p.jid);
        await sock.groupRequestParticipantsUpdate(jid, jids, 'approve');
        await reply(`✅ Approved *${jids.length}* pending request(s).`);
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    // Check pending join requests
    case 'checkpending': {
      if (needGroup() || needAdmin()) break;
      try {
        const pending = await sock.groupRequestParticipantsList(jid);
        if (!pending?.length) { await reply('📭 No pending join requests.'); break; }
        const list = pending.map((p, i) => `${i+1}. +${normNum(p.jid)}`).join('\n');
        await reply(`📋 *Pending Requests (${pending.length})*\n\n${list}`);
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    // Reject all join requests
    case 'rejectall': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      await reaction('❌');
      try {
        const pending = await sock.groupRequestParticipantsList(jid);
        if (!pending?.length) { await reply('📭 No pending join requests.'); break; }
        const jids = pending.map(p => p.jid);
        await sock.groupRequestParticipantsUpdate(jid, jids, 'reject');
        await reply(`🚫 Rejected *${jids.length}* pending request(s).`);
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    // Disapprove / remove member
    case 'disap': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      let tRaw = getTargetJid(m, args);
      // also accept raw number in args
      if (!tRaw && args[0]) {
        const cleaned = args[0].replace(/[^0-9]/g, '');
        if (cleaned.length >= 7) tRaw = cleaned + '@s.whatsapp.net';
      }
      if (!tRaw) { await reply(`❌ Reply to a member or: ${prefix}disap <number>`); break; }
      // normalise to full JID for admin check
      const tFull = tRaw.includes('@') ? tRaw : normNum(tRaw) + '@s.whatsapp.net';
      const adminNorms = groupAdmins.map(a => (a.includes('@') ? a : a + '@s.whatsapp.net'));
      if (adminNorms.includes(tFull)) { await reply('❌ Cannot remove an admin.'); break; }
      try {
        await sock.groupParticipantsUpdate(jid, [tFull], 'remove');
        await reply(`🚫 @${normNum(tFull)} has been disapproved and removed.`);
      } catch (e) { await reply('❌ disap failed: ' + e.message); }
      break;
    }

    // Anti-mention (protect members from mass mentions / mention spam)
    case 'antimention': {
      if (needGroup() || needAdmin()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}antimention on/off`); break; }
      setGroupFlag('antimention.json', jid, v === 'on');
      await reply(`✅ AntiMention → ${v}\n_Members who mass-mention will be warned._`);
      break;
    }

    // Anti-spam (too many messages in short time → warn/kick)
    case 'antispam': {
      if (needGroup() || needAdmin()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}antispam on/off`); break; }
      setGroupFlag('antispam.json', jid, v === 'on');
      await reply(`✅ AntiSpam → ${v}\n_Members sending >5 msgs in 5s will be warned._`);
      break;
    }

    // Anti-bot (blocks other bot commands from non-owners)
    case 'antibot': {
      if (needGroup() || needAdmin()) break;
      const v = args[0]?.toLowerCase();
      if (!['on','off'].includes(v)) { await reply(`${prefix}antibot on/off`); break; }
      setGroupFlag('antibot.json', jid, v === 'on');
      await reply(`✅ AntiBot → ${v}\n_Bot commands from non-admin members will be deleted._`);
      break;
    }

    // Slow mode – set message cooldown
    case 'slowmode': {
      if (needGroup() || needAdmin()) break;
      const secs = parseInt(args[0]);
      if (!args[0] || args[0] === 'off') {
        const sm = readJSON(DB('slowmode.json'), {});
        delete sm[jid];
        writeJSON(DB('slowmode.json'), sm);
        await reply('✅ Slow mode disabled.');
        break;
      }
      if (isNaN(secs) || secs < 1 || secs > 3600) { await reply(`${prefix}slowmode <seconds 1-3600> | off`); break; }
      const sm = readJSON(DB('slowmode.json'), {});
      sm[jid] = secs;
      writeJSON(DB('slowmode.json'), sm);
      await reply(`⏱ Slow mode → *${secs}s* between messages per member.`);
      break;
    }

    // Soft-ban: mute a specific member (remove then re-add – they can't send until re-added)
    case 'softban': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      const t = getTargetJid(m, args); if (!t) { await reply('❌ Reply to a member.'); break; }
      if (groupAdmins.includes(t)) { await reply('❌ Cannot soft-ban an admin.'); break; }
      try {
        await sock.groupParticipantsUpdate(jid, [t], 'remove');
        await new Promise(r => setTimeout(r, 2000));
        await sock.groupParticipantsUpdate(jid, [t], 'add');
        await reply(`🔇 @${normNum(t)} soft-banned (removed & re-added, messages reset).`);
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    // Kick all non-admins
    case 'kickall': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      if (!_isOwner) { await reply('❌ Owner only.'); break; }
      const nonAdmins = participants.filter(p => !p.admin).map(p => p.jid || p.id).filter(Boolean);
      if (!nonAdmins.length) { await reply('No non-admin members to kick.'); break; }
      await reply(`⚠️ Kicking *${nonAdmins.length}* members...`);
      let done = 0;
      for (const t of nonAdmins) {
        try { await sock.groupParticipantsUpdate(jid, [t], 'remove'); done++; await new Promise(r => setTimeout(r, 500)); } catch {}
      }
      await reply(`✅ Kicked *${done}/${nonAdmins.length}* members.`);
      break;
    }

    // Set custom welcome message
    case 'setwelcomemsg': {
      if (needGroup() || needAdmin()) break;
      const msg = args.join(' ');
      if (!msg) { await reply(`${prefix}setwelcomemsg <message>\nUse {name} for member name, {group} for group name.`); break; }
      const wm = readJSON(DB('welcomemsgs.json'), {});
      wm[jid] = msg;
      writeJSON(DB('welcomemsgs.json'), wm);
      await reply(`✅ Welcome message set:\n${msg}`);
      break;
    }

    // Set custom goodbye message
    case 'setgoodbyemsg': {
      if (needGroup() || needAdmin()) break;
      const msg = args.join(' ');
      if (!msg) { await reply(`${prefix}setgoodbyemsg <message>\nUse {name} for member name, {group} for group name.`); break; }
      const gm = readJSON(DB('goodbyemsgs.json'), {});
      gm[jid] = msg;
      writeJSON(DB('goodbyemsgs.json'), gm);
      await reply(`✅ Goodbye message set:\n${msg}`);
      break;
    }

    // Mute list – see who has been muted via softban
    case 'mutelist': {
      if (needGroup() || needAdmin()) break;
      const ml = readJSON(DB('mutedmembers.json'), {});
      const list2 = (ml[jid] || []);
      if (!list2.length) { await reply('No muted members.'); break; }
      await reply(`🔇 *Muted Members (${list2.length})*\n${list2.map((j2,i) => `${i+1}. +${normNum(j2)}`).join('\n')}`);
      break;
    }

    // Kick inactive members (no messages in X days tracked via DB)
    case 'kickinactive': {
      if (needGroup() || needAdmin() || needBotAdm()) break;
      if (!_isOwner) { await reply('❌ Owner only.'); break; }
      const days = parseInt(args[0]) || 7;
      const actFile = DB('activity.json');
      const act = readJSON(actFile, {});
      const cutoff = Date.now() - days * 86400000;
      const inactive = participants
        .filter(p => !p.admin)
        .map(p => p.jid || p.id)
        .filter(pjid => {
          const key3 = `${jid}|${normNum(pjid)}`;
          return !act[key3] || act[key3] < cutoff;
        });
      if (!inactive.length) { await reply(`✅ No inactive members (>${days} days) found.`); break; }
      await reply(`⚠️ Kicking *${inactive.length}* members inactive for >${days} days...`);
      let done2 = 0;
      for (const t of inactive) {
        try { await sock.groupParticipantsUpdate(jid, [t], 'remove'); done2++; await new Promise(r => setTimeout(r, 500)); } catch {}
      }
      await reply(`✅ Kicked *${done2}* inactive members.`);
      break;
    }

    // ══════════════════════════════════════════════════════
    //   UTILITY – EXISTING
    // ══════════════════════════════════════════════════════

    case 'sticker': {
      await reaction('🎨');
      const { qMsg, qType, qKey } = getQuoted(m);
      const imgMsg = m.message?.imageMessage || (qType === 'imageMessage' ? qMsg?.imageMessage : null);
      const vidMsg = m.message?.videoMessage  || (qType === 'videoMessage' ? qMsg?.videoMessage  : null);
      const stickerSrc = imgMsg ? { imageMessage: imgMsg } : vidMsg ? { videoMessage: vidMsg } : null;
      const stickerKey = imgMsg
        ? (m.message?.imageMessage ? m.key : qKey)
        : m.message?.videoMessage ? m.key : qKey;
      if (!stickerSrc) { await reply(`Reply to an image or video with ${prefix}sticker`); break; }
      try {
        const buf = await dlMedia(stickerSrc, stickerKey);
        const tmp = `/tmp/stk_${Date.now()}`;
        fs.writeFileSync(`${tmp}.in`, buf);
        await new Promise((res, rej) =>
          exec(`ffmpeg -y -i ${tmp}.in -vf "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2" -loop 0 ${tmp}.webp 2>/dev/null`, e => e ? rej(e) : res())
        );
        const webp = fs.readFileSync(`${tmp}.webp`);
        await sock.sendMessage(jid, { sticker: webp }, { quoted: qchanel });
        try { fs.unlinkSync(`${tmp}.in`); fs.unlinkSync(`${tmp}.webp`); } catch {}
      } catch { await reply('❌ Sticker failed. Make sure ffmpeg is installed.'); }
      break;
    }

    case 'toimg': {
      const { qMsg, qType, qKey } = getQuoted(m);
      const sm = m.message?.stickerMessage || (qType === 'stickerMessage' ? qMsg?.stickerMessage : null);
      if (!sm) { await reply('Reply to a sticker.'); break; }
      const srcKey = m.message?.stickerMessage ? m.key : qKey;
      try {
        const buf = await dlMedia({ stickerMessage: sm }, srcKey);
        await replyImg(buf, '🖼 Sticker → Image');
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    case 'vv': {
      const { qMsg, qType, qKey } = getQuoted(m);
      if (!qMsg) { await reply('Reply to a view-once message.'); break; }
      let inner = qMsg;
      for (const w of ['viewOnceMessage','viewOnceMessageV2','viewOnceMessageV2Extension']) {
        if (inner[w]?.message) { inner = inner[w].message; break; }
      }
      const voImg = inner.imageMessage;
      const voVid = inner.videoMessage;
      if (!voImg && !voVid) { await reply('Not a view-once message.'); break; }
      try {
        const src = voImg ? { imageMessage: voImg } : { videoMessage: voVid };
        const buf = await dlMedia(src, qKey);
        if (voImg) await replyImg(buf, '👁 Revealed');
        else if (!cfg(sock).iphoneMode) await sock.sendMessage(jid, { video: buf, caption: '👁 Revealed' }, { quoted: qchanel });
        else await reply('👁 View Once revealed [video]');
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    case 'qr': {
      if (!text) { await reply(`${prefix}qr <text>`); break; }
      await replyImg(`https://api.qrserver.com/v1/create-qr-code/?size=512x512&data=${encodeURIComponent(text)}`, `🔲 QR: ${text}`);
      break;
    }

    case 'weather': {
      const city = text; if (!city) { await reply(`${prefix}weather <city>`); break; }
      try {
        const r = await axios.get(`https://wttr.in/${encodeURIComponent(city)}?format=4&m`, { timeout: 8000 });
        await reply(`🌤 *${city}*\n${asPlainText(r.data)}`);
      } catch { await reply('❌ Weather fetch failed.'); }
      break;
    }

    case 'tr': {
      const lang = args[0]; const txt2 = args.slice(1).join(' ');
      if (!lang || !txt2) { await reply(`${prefix}tr <lang> <text>\nExample: ${prefix}tr es Hello World`); break; }
      try {
        const r = await axios.get(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(txt2)}&langpair=en|${lang}`, { timeout: 8000 });
        await reply(`🌐 (${lang}) ${r.data.responseData.translatedText}`);
      } catch { await reply('❌ Translation failed.'); }
      break;
    }

    case 'uploadstatus': {
      if (needOwner()) break;
      const { qMsg, qType, qKey } = getQuoted(m);
      try {
        if (qType === 'imageMessage') {
          const buf = await dlMedia({ imageMessage: qMsg.imageMessage }, qKey);
          await sock.sendMessage('status@broadcast', { image: buf, caption: qMsg.imageMessage?.caption || '' });
        } else if (qType === 'videoMessage') {
          const buf = await dlMedia({ videoMessage: qMsg.videoMessage }, qKey);
          await sock.sendMessage('status@broadcast', { video: buf, caption: qMsg.videoMessage?.caption || '' });
        } else {
          const t2 = text || qMsg?.conversation || qMsg?.extendedTextMessage?.text || '';
          if (!t2) { await reply('Provide text or reply to media.'); break; }
          await sock.sendMessage('status@broadcast', { text: t2 }, { backgroundColor: '#128C7E', font: 3 });
        }
        await reply('✅ Status uploaded.');
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    case 'setmypp': {
      const { qMsg, qType, qKey } = getQuoted(m);
      const ownImg = m.message?.imageMessage;
      let buf = null;
      try {
        if (ownImg) {
          buf = await dlMedia({ imageMessage: ownImg }, m.key);
        } else if (qType === 'imageMessage') {
          buf = await dlMedia({ imageMessage: qMsg.imageMessage }, qKey);
        } else if (args[0]?.startsWith('http')) {
          buf = await getBuffer(args[0]);
        } else { await reply(`Reply to an image or ${prefix}setmypp <url>`); break; }
        if (!buf || buf.length < 100) throw new Error('Image buffer empty');
        let finalBuf = buf;
        try {
          const sharp = require('sharp');
          finalBuf = await sharp(buf).resize(640, 640, { fit: 'cover' }).jpeg({ quality: 90 }).toBuffer();
        } catch { finalBuf = buf; }
        await sock.updateProfilePicture(jid, finalBuf);
        await reply('✅ Profile picture updated.');
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    case 'getpp': {
      const t = getTargetJid(m, args);
      const target = t || `${botNumber}@s.whatsapp.net`;
      try {
        const ppUrl = await sock.profilePictureUrl(target, 'image');
        const r = await axios.get(ppUrl, { responseType: 'arraybuffer', timeout: 10000 });
        await replyImg(Buffer.from(r.data), `🖼 +${normNum(target)}`);
      } catch { await reply('❌ No profile picture or privacy restricted.'); }
      break;
    }

    case 'tts': {
      if (!text) { await reply(`${prefix}tts <text>`); break; }
      if (text.length >= 300) { await reply('❌ Max 300 characters.'); break; }
      await reply('⏳ Generating voice...');
      try {
        const { data } = await axios.post(
          'https://tiktok-tts.weilnet.workers.dev/api/generation',
          { text, voice: 'id_001' },
          { timeout: 15000 }
        );
        if (!data?.data) throw new Error('No audio returned');
        await sock.sendMessage(jid, {
          audio: Buffer.from(data.data, 'base64'),
          mimetype: 'audio/mp4',
        }, { quoted: qchanel });
      } catch (e) { await reply('❌ TTS failed: ' + e.message); }
      break;
    }

    case 'ocr': {
      const { qMsg, qType, qKey } = getQuoted(m);
      const imgMsg = m.message?.imageMessage || (qType === 'imageMessage' ? qMsg?.imageMessage : null);
      if (!imgMsg) { await reply('Reply to an image.'); break; }
      try {
        const srcKey = m.message?.imageMessage ? m.key : qKey;
        const buf    = await dlMedia({ imageMessage: imgMsg }, srcKey);
        const b64    = buf.toString('base64');
        const r      = await axios.post('https://api.ocr.space/parse/image',
          `base64Image=data:image/jpeg;base64,${b64}&language=eng`,
          { headers: { apikey: 'helloworld', 'Content-Type': 'application/x-www-form-urlencoded' }, timeout: 15000 }
        );
        const txt2 = r.data?.ParsedResults?.[0]?.ParsedText || 'No text found.';
        await reply(`📝 OCR:\n${txt2}`);
      } catch { await reply('❌ OCR failed.'); }
      break;
    }

    case 'shorten': {
      const url = args[0];
      if (!url?.startsWith('http')) { await reply(`${prefix}shorten <url>`); break; }
      try {
        const r = await axios.get(`https://is.gd/create.php?format=simple&url=${encodeURIComponent(url)}`, { timeout: 8000 });
        await reply(`🔗 ${asPlainText(r.data)}`);
      } catch { await reply('❌ Failed.'); }
      break;
    }

    case 'tourl': {
      await reaction('📄');
      const { qMsg: qMsgTU, qType: qTypeTU, qKey: qKeyTU } = getQuoted(m);
      const MEDIA_TYPES = ['imageMessage','videoMessage','stickerMessage','audioMessage','documentMessage'];
      const mediaTypeTU = MEDIA_TYPES.find(t2 => qMsgTU?.[t2]);
      if (!qMsgTU || !mediaTypeTU) {
        await reply(`❌ Reply to an image, video, sticker, or audio with ${prefix}tourl`);
        break;
      }
      try {
        const buf = await dlMedia(qMsgTU, qKeyTU);
        if (!buf) throw new Error('Media download failed');
        const { uploadToTelegraph } = require('./helper/uploader');
        const mimeMap = {
          imageMessage: 'image/jpeg',
          videoMessage: 'video/mp4',
          stickerMessage: 'image/webp',
          audioMessage: 'audio/mp4',
          documentMessage: qMsgTU.documentMessage?.mimetype || 'application/octet-stream',
        };
        const link = await uploadToTelegraph(buf, mimeMap[mediaTypeTU]);
        if (!link) throw new Error('Upload failed');

        const { generateWAMessageFromContent, proto } = require('./helper/baileys');
        const msg = await generateWAMessageFromContent(jid, {
          viewOnceMessage: {
            message: {
              interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body: proto.Message.InteractiveMessage.Body.fromObject({
                  text: `✅ Converted to link!\nExpires: Never\n\n${link}`,
                }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: '' }),
                header: proto.Message.InteractiveMessage.Header.fromObject({
                  title: '[ ! ] INFORMATION',
                  subtitle: '',
                  hasMediaAttachment: false,
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                  buttons: [{
                    name: 'cta_copy',
                    buttonParamsJson: JSON.stringify({ display_text: 'Copy Link!', copy_code: link }),
                  }],
                }),
                contextInfo: { mentionedJid: [sender] },
              }),
            },
          },
        }, { quoted: qchanel });
        await sock.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
      } catch (e) {
        logError('tourl', e.message);
        await reply('❌ ' + e.message);
      }
      break;
    }

    // ══════════════════════════════════════════════════════
    //   PLAY – FIXED (multi-API fallback chain)
    // ══════════════════════════════════════════════════════

    // ── PLAY: pick audio / video / document ────────────────
    case 'play': {
      if (!text) { await reply(`🎵 *${prefix}play <song name or YouTube link>*\nExample: *${prefix}play Faded*`); break; }
      await reaction('🎵');
      try {
        const yts   = require('yt-search');
        const isUrl = /youtu/i.test(text);
        let video   = null;

        if (!isUrl) {
          const search = await yts(text);
          video = search.videos?.[0] || (search.all || []).find(v => v.type === 'video');
          if (!video) { await reply(`❌ No results found for *${text}*`); break; }
        }

        const videoUrl = isUrl ? text : video.url;
        const title    = video?.title || 'YouTube audio';

        const meta = [
          `🎵 *${title}*`,
          video?.timestamp ? `⏱ ${video.timestamp}` : '',
          video?.views ? `👁 ${Number(video.views).toLocaleString('en-US')}` : '',
          video?.ago ? `📅 ${video.ago}` : '',
        ].filter(Boolean).join('\n');

        // The thumbnail rides along as the interactive header image.
        let headerImage = null;
        if (video?.thumbnail) {
          try { headerImage = await menuHeaderImage(sock, video.thumbnail); } catch {}
        }

        const lib = bttns();
        const mk  = (label, id) => (lib && lib.btn && lib.btn.reply)
          ? lib.btn.reply(label, id)
          : { name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: label, id }) };

        const sentCard = await sendInteractiveButtons(sock, jid, {
          title  : '🌹 SKYLAR X ULTRA MUSIC',
          text   : `${bq(meta)}\n\n> *Choose a format below* 👇\n> *Or reply 1 = Audio · 2 = Video · 3 = Document*`,
          footer : String(settings.BOT_NAME || NEWSLETTER_NAME || '').trim(),
          buttons: [
            mk('🎵 Audio',    `PLAY_AUDIO|${videoUrl}`),
            mk('🎬 Video',    `PLAY_VIDEO|${videoUrl}`),
            mk('📄 Document', `PLAY_DOC|${videoUrl}`),
          ],
          imageMessage: headerImage,
          quoted : m,
        });

        // Remember the card so a numbered reply can stand in for a tap on
        // clients that render no quick_reply buttons.
        playWaiting.set(jid, { videoUrl, msgId: sentCard?.key?.id || null, at: Date.now() });
      } catch (e) {
        logError('Play', e.message);
        await reply(`❌ Play failed: ${e.message}`);
      }
      break;
    }
    case 'playdoc': {
      const query2 = text;
      if (!query2) { await reply(`🎵 ${prefix}playdoc <song name>`); break; }
      await reaction('⬇️');
      try {
        const yts = require('yt-search');
        const search = await yts(query2);
        const video = search.videos?.[0] || search.all?.[0];
        if (!video) throw new Error('No results found');
        const { data } = await axios.get(
          `https://api.privatezia.biz.id/api/downloader/ytmp3?url=${encodeURIComponent(video.url)}`,
          { timeout: 20000 }
        );
        if (!data?.status) throw new Error('API failed');
        const dlUrl = data.result?.downloadUrl || data.url;
        if (!dlUrl) throw new Error('No download URL');
        await reply(`⬇️ Downloading *${video.title}*...`);
        const dlRes = await axios.get(dlUrl, { responseType: 'arraybuffer', timeout: 30000 });
        const buf   = Buffer.from(dlRes.data);
        const fname = video.title.replace(/[^\w\s]/g, '').trim() + '.mp3';
        await sock.sendMessage(jid, {
          document: buf,
          mimetype: 'audio/mpeg',
          caption:  ft(`🎵 ${video.title}\n© ${settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD'}`, sock),
          fileName: fname,
        }, { quoted: qchanel });
      } catch (e) { await reply('❌ Failed: ' + e.message); }
      break;
    }

    // ── YouTube Video Download ────────────────────────────
    case 'ytmp4': {
      if (!text) { await reply(`${prefix}ytmp4 <YouTube link or title>`); break; }
      await reaction('🎬');
      await reply('⏳ Processing video...');
      try {
        const yts = require('yt-search');
        const isUrl = text.includes('youtu');
        let videoUrl = text;
        let videoTitle = 'video';
        if (!isUrl) {
          const search = await yts(text);
          const v = search.videos?.[0];
          if (!v) throw new Error('No results');
          videoUrl = v.url;
          videoTitle = v.title;
        }
        const { data } = await axios.get(
          `https://api.privatezia.biz.id/api/downloader/ytmp4?url=${encodeURIComponent(videoUrl)}`,
          { timeout: 25000 }
        );
        const dlUrl = data?.result?.downloadUrl || data?.url;
        if (!dlUrl) throw new Error('No video URL');
        await sock.sendMessage(jid, {
          video: { url: dlUrl },
          caption: ft(`🎬 ${videoTitle}`, sock),
          fileName: videoTitle.replace(/[^\w\s]/g,'').trim() + '.mp4',
        }, { quoted: qchanel });
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    // ── Lyrics ───────────────────────────────────────────
    case 'lyrics': {
      if (!text) { await reply(`${prefix}lyrics <song name>`); break; }
      await reaction('🎤');
      try {
        const { data } = await axios.get(
          `https://some-random-api.com/lyrics?title=${encodeURIComponent(text)}`,
          { timeout: 10000 }
        );
        if (!data?.lyrics) throw new Error('Not found');
        const lrc = data.lyrics.length > 3000 ? data.lyrics.slice(0, 3000) + '...' : data.lyrics;
        await reply(`🎤 *${data.title}*\n👤 ${data.author}\n\n${lrc}`);
      } catch { await reply('❌ Lyrics not found. Try a different song title.'); }
      break;
    }

    // ── Instagram downloader ──────────────────────────────
    case 'instagram':
    case 'ig': {
      const igUrl = args[0];
      if (!igUrl?.includes('instagram.com')) { await reply(`${prefix}instagram <post/reel url>`); break; }
      await reaction('📸');
      try {
        const { data } = await axios.get(
          `https://api.ootaizumi.web.id/downloader/instagram?url=${encodeURIComponent(igUrl)}`,
          { timeout: 20000 }
        );
        if (!data?.status || !data.result?.url) throw new Error('Failed');
        const r = data.result;
        if (r.type === 'video') {
          await sock.sendMessage(jid, { video: { url: r.url }, caption: ft(r.caption || '📸 Instagram', sock) }, { quoted: qchanel });
        } else {
          await replyImg(r.url, r.caption?.slice(0,200) || '📸 Instagram');
        }
      } catch (e) { await reply('❌ Instagram download failed: ' + e.message); }
      break;
    }

    // ── TikTok downloader ────────────────────────────────
    case 'tiktok':
    case 'tt': {
      const ttUrl = args[0];
      if (!ttUrl?.includes('tiktok.com')) { await reply(`${prefix}tiktok <tiktok video url>`); break; }
      await reaction('🎵');
      try {
        const { data } = await axios.get(
          `https://api.ootaizumi.web.id/downloader/tiktok?url=${encodeURIComponent(ttUrl)}`,
          { timeout: 20000 }
        );
        if (!data?.status || !data.result?.video) throw new Error('Failed');
        const r = data.result;
        await sock.sendMessage(jid, { video: { url: r.video }, caption: ft(r.title || '🎵 TikTok', sock) }, { quoted: qchanel });
      } catch (e) { await reply('❌ TikTok download failed: ' + e.message); }
      break;
    }

    // ── Facebook downloader ──────────────────────────────
    case 'facebook':
    case 'fb': {
      const fbUrl = args[0];
      if (!fbUrl?.includes('facebook.com') && !fbUrl?.includes('fb.watch')) { await reply(`${prefix}facebook <facebook video url>`); break; }
      await reaction('📘');
      try {
        const { data } = await axios.get(
          `https://api.ootaizumi.web.id/downloader/facebook?url=${encodeURIComponent(fbUrl)}`,
          { timeout: 20000 }
        );
        if (!data?.status) throw new Error('Failed');
        const r = data.result;
        const videoUrl = r?.sd || r?.hd || r?.video;
        if (!videoUrl) throw new Error('No video URL');
        await sock.sendMessage(jid, { video: { url: videoUrl }, caption: ft('📘 Facebook', sock) }, { quoted: qchanel });
      } catch (e) { await reply('❌ Facebook download failed: ' + e.message); }
      break;
    }

    // ── Twitter/X downloader ─────────────────────────────
    case 'twitter':
    case 'x': {
      const twUrl = args[0];
      if (!twUrl?.includes('twitter.com') && !twUrl?.includes('x.com')) { await reply(`${prefix}twitter <tweet/video url>`); break; }
      await reaction('🐦');
      try {
        const { data } = await axios.get(
          `https://api.ootaizumi.web.id/downloader/twitter?url=${encodeURIComponent(twUrl)}`,
          { timeout: 20000 }
        );
        if (!data?.status) throw new Error('Failed');
        const r = data.result;
        const videoUrl = r?.video || r?.url;
        if (!videoUrl) throw new Error('No URL');
        await sock.sendMessage(jid, { video: { url: videoUrl }, caption: ft('🐦 Twitter/X', sock) }, { quoted: qchanel });
      } catch (e) { await reply('❌ Twitter download failed: ' + e.message); }
      break;
    }

    // ── Pinterest downloader ──────────────────────────────
    case 'pinterest': {
      const pinUrl = args[0];
      if (!pinUrl?.includes('pinterest')) { await reply(`${prefix}pinterest <pinterest url>`); break; }
      await reaction('📌');
      try {
        const { data } = await axios.get(
          `https://api.ootaizumi.web.id/downloader/pinterest?url=${encodeURIComponent(pinUrl)}`,
          { timeout: 20000 }
        );
        if (!data?.status) throw new Error('Failed');
        const r = data.result;
        if (r?.video) {
          await sock.sendMessage(jid, { video: { url: r.video }, caption: '📌 Pinterest' }, { quoted: qchanel });
        } else if (r?.image) {
          await replyImg(r.image, '📌 Pinterest');
        } else throw new Error('No media found');
      } catch (e) { await reply('❌ Pinterest download failed: ' + e.message); }
      break;
    }

    // ── Spotify track info ────────────────────────────────
    case 'spotify': {
      if (!text) { await reply(`${prefix}spotify <track name>`); break; }
      await reaction('🎧');
      try {
        const { data } = await axios.get(
          `https://some-random-api.com/others/spotify?q=${encodeURIComponent(text)}`,
          { timeout: 10000 }
        );
        if (!data?.title) throw new Error('Not found');
        const bar = `▓`.repeat(Math.floor((data.duration_ms/100)/60000 * 20)).padEnd(20,'░');
        await replyImg(
          data.album_art,
          `🎧 *${data.title}*\n👤 ${data.artists?.join(', ') || 'Unknown'}\n💿 ${data.album}\n⏱ ${Math.floor(data.duration_ms/60000)}:${String(Math.floor((data.duration_ms%60000)/1000)).padStart(2,'0')}\n\n[${bar}]`
        );
      } catch { await reply('❌ Spotify track not found.'); }
      break;
    }

    // ── Base64 encode/decode ──────────────────────────────
    case 'base64': {
      if (!text) { await reply(`${prefix}base64 <text>`); break; }
      await reply(`📦 *Base64 Encoded:*\n${Buffer.from(text).toString('base64')}`);
      break;
    }

    case 'unbase64': {
      if (!text) { await reply(`${prefix}unbase64 <base64 string>`); break; }
      try {
        const decoded = Buffer.from(text, 'base64').toString('utf8');
        await reply(`📦 *Decoded:*\n${decoded}`);
      } catch { await reply('❌ Invalid base64 string.'); }
      break;
    }

    // ── Whois / number info ──────────────────────────────
    case 'whois': {
      const t = getTargetJid(m, args);
      if (!t) { await reply(`${prefix}whois @mention`); break; }
      try {
        const ppUrl = await sock.profilePictureUrl(t, 'image').catch(() => null);
        const pp = ppUrl ? ppUrl : 'No profile picture';
        const isOnWa = await sock.onWhatsApp(t).catch(() => []);
        const status = isOnWa?.[0]?.exists ? '✅ On WhatsApp' : '❌ Not on WhatsApp';
        const info = `👤 *+${normNum(t)}*\n\n${status}\nPP: ${pp}`;
        if (ppUrl) await replyImg(ppUrl, info);
        else await reply(info);
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    // ── Reverse GIF ──────────────────────────────────────
    case 'reversegif': {
      const { qMsg: qMRG, qType: qTRG, qKey: qKRG } = getQuoted(m);
      const gifMsg = m.message?.videoMessage || (qTRG === 'videoMessage' ? qMRG?.videoMessage : null);
      if (!gifMsg) { await reply('Reply to a GIF/video.'); break; }
      await reaction('🔁');
      try {
        const srcKey = m.message?.videoMessage ? m.key : qKRG;
        const buf = await dlMedia({ videoMessage: gifMsg }, srcKey);
        const tmp = `/tmp/rgif_${Date.now()}`;
        fs.writeFileSync(`${tmp}.mp4`, buf);
        await new Promise((res, rej) =>
          exec(`ffmpeg -y -i ${tmp}.mp4 -vf reverse -af areverse ${tmp}_rev.mp4 2>/dev/null`, e => e ? rej(e) : res())
        );
        const revBuf = fs.readFileSync(`${tmp}_rev.mp4`);
        await sock.sendMessage(jid, { video: revBuf, gifPlayback: true, caption: '🔁 Reversed GIF' }, { quoted: qchanel });
        try { fs.unlinkSync(`${tmp}.mp4`); fs.unlinkSync(`${tmp}_rev.mp4`); } catch {}
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    // ── Animated text sticker (attp) ─────────────────────
    case 'attp': {
      if (!text) { await reply(`${prefix}attp <text>`); break; }
      await reaction('✨');
      try {
        const { data } = await axios.get(
          `https://api.siputzx.my.id/api/sticker/attp?text=${encodeURIComponent(text)}`,
          { responseType: 'arraybuffer', timeout: 15000 }
        );
        const buf = Buffer.from(data);
        await sock.sendMessage(jid, { sticker: buf }, { quoted: qchanel });
      } catch (e) { await reply('❌ attp failed: ' + e.message); }
      break;
    }

    // ── Emoji mixer ─────────────────────────────────────
    case 'emojimix': {
      if (args.length < 2) { await reply(`${prefix}emojimix <emoji1> <emoji2>\nExample: ${prefix}emojimix 😀 🔥`); break; }
      try {
        const e1 = encodeURIComponent(args[0]);
        const e2 = encodeURIComponent(args[1]);
        const url = `https://www.gstatic.com/android/keyboard/emojikitchen/20201001/${e1}/${e1}_${e2}.png`;
        await replyImg(url, `${args[0]} + ${args[1]}`);
      } catch { await reply('❌ Emoji mix not found.'); }
      break;
    }

    // ══════════════════════════════════════════════════════
    //   SCRIPT / REPO – with 2 open buttons
    // ══════════════════════════════════════════════════════
/*
    case 'script':
    case 'repo': {
      await reaction('🔗');
      const upSec = Math.floor(process.uptime());
      const d = Math.floor(upSec / 86400);
      const h = Math.floor((upSec % 86400) / 3600);
      const mn = Math.floor((upSec % 3600) / 60);
      const s = upSec % 60;
      const runtime = `${d}d ${h}h ${mn}m ${s}s`;

      const { generateWAMessageFromContent, prepareWAMessageMedia, proto } = require('./helper/baileys');

      // Try to attach menu image as thumbnail
      const menuImgUrl = c.menuImg || settings.DEFAULT_MENU_IMG;
      let imgField = {};
      if (menuImgUrl) {
        try {
          const imgBuf = await getBuffer(menuImgUrl);
          imgField = await prepareWAMessageMedia({ image: imgBuf }, { upload: sock.waUploadToServer });
        } catch {}
      }

      const repoText = ft(
`╭─ ⌬ 𝗕𝗼𝘁 𝗜𝗻𝗳𝗼 ⌬
│ • Name    : ${c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD'}
│ • Owner   : ${kontributor[0] || botNumber}
│ • Version  : ${settings.BOT_VERSION || '1.0'}
│ • Prefix   : ${prefix}
│ • Runtime  : ${runtime}
╰─────────────`, sock);

      const pairUrl    = settings.REQUIRED_PAIR_LINK    || 'https://t.me/animemdoff_bot';
      const channelUrl = settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3';

      try {
        const msg = await generateWAMessageFromContent(jid, {
          ephemeralMessage: {
            message: {
              messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
              interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body:   proto.Message.InteractiveMessage.Body.fromObject({ text: repoText }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: `© ${settings.CREDITS || 'james'}` }),
                header: proto.Message.InteractiveMessage.Header.fromObject({
                  title: c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD',
                  hasMediaAttachment: !!imgField.imageMessage,
                  ...imgField,
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                  buttons: [
                    {
                      name: 'cta_url',
                      buttonParamsJson: JSON.stringify({
                        display_text: '🔗 Pair Bot',
                        url: pairUrl,
                        merchant_url: pairUrl,
                      }),
                    },
                    {
                      name: 'cta_url',
                      buttonParamsJson: JSON.stringify({
                        display_text: '📢 Follow Channel',
                        url: channelUrl,
                        merchant_url: channelUrl,
                      }),
                    },
                  ],
                }),
                contextInfo: {},
              }),
            },
          },
        }, { quoted: qchanel });
        await sock.relayMessage(jid, msg.message, { messageId: msg.key.id });
      } catch {
        // Fallback to plain reply if interactive fails
        await reply(repoText + `\n\n🔗 Pair: ${pairUrl}\n📢 Channel: ${channelUrl}`);
      }
      break;
    }*/

    case 'idch':
    case 'cekidch': {
      const chLink = args[0];
      if (!chLink) { await reply(`Usage: ${prefix}idch <channel link>`); break; }
      if (!chLink.includes('https://whatsapp.com/channel/')) {
        await reply('❌ Must be a valid WhatsApp channel link');
        break;
      }
      try {
        const inviteCode = chLink.split('https://whatsapp.com/channel/')[1];
        const res = await sock.newsletterMetadata('invite', inviteCode);
        const verified = res.verification === 'VERIFIED' ? 'Yes ✅' : 'No ❌';
        const teks = ft(
`📢 *Channel Info*

🆔 ID: ${res.id}
📛 Name: ${res.name}
👥 Followers: ${res.subscribers}
🔘 Status: ${res.state}
✅ Verified: ${verified}`, sock);

        const { generateWAMessageFromContent, proto } = require('./helper/baileys');
        const msg = await generateWAMessageFromContent(jid, {
          viewOnceMessage: {
            message: {
              messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
              interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body:   proto.Message.InteractiveMessage.Body.fromObject({ text: teks }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: 'by 𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD' }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                  buttons: [{
                    name: 'cta_copy',
                    buttonParamsJson: JSON.stringify({ display_text: 'Copy ID', copy_code: res.id }),
                  }],
                }),
              }),
            },
          },
        }, { quoted: qchanel });
        await sock.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
      } catch (e) { await reply('❌ ' + e.message); }
      break;
    }

    // ══════════════════════════════════════════════════════
    //   FUN – EXISTING
    // ══════════════════════════════════════════════════════

    case 'joke': {
      try { const r = await axios.get('https://official-joke-api.appspot.com/random_joke',{timeout:6000}); await reply(`😂 ${r.data.setup}\n\n${r.data.punchline}`); }
      catch { await reply('❌ No jokes.'); }
      break;
    }
    case 'fact': {
      try { const r = await axios.get('https://uselessfacts.jsph.pl/random.json?language=en',{timeout:6000}); await reply(`💡 ${r.data.text}`); }
      catch { await reply('❌ No facts.'); }
      break;
    }
    case 'quote': {
      try { const r = await axios.get('https://zenquotes.io/api/random',{timeout:6000}); await reply(`🌟 "${r.data[0].q}"\n– ${r.data[0].a}`); }
      catch { await reply('❌ No quotes.'); }
      break;
    }
    case 'dare': {
      const d=['Tell your most embarrassing secret.','Do 20 push-ups now.','Text your crush right now.','Sing a song aloud.','Change your status to something silly for 1hr.','Send a voice note of you barking.','Do your best celebrity impression.'];
      await reply(`🔥 Dare: ${d[Math.floor(Math.random()*d.length)]}`);
      break;
    }
    case 'truth': {
      const t2=['Whats your biggest regret?','Have you ever lied to your best friend?','What is your guilty pleasure?','Who is your secret crush?','What embarrassing thing have you done?','What is a secret you have never told anyone?','Who do you secretly dislike in this group?'];
      await reply(`💬 Truth: ${t2[Math.floor(Math.random()*t2.length)]}`);
      break;
    }
    case 'riddle': {
      const r=[{q:'What has keys but no locks?',a:'A keyboard'},{q:'What gets wetter as it dries?',a:'A towel'},{q:'I speak without a mouth. What am I?',a:'An echo'},{q:'The more you take the more you leave behind.',a:'Footsteps'},{q:'What has hands but cant clap?',a:'A clock'},{q:'I have cities, but no houses live there.',a:'A map'}];
      const pick=r[Math.floor(Math.random()*r.length)];
      await reply(`🧩 *Riddle:* ${pick.q}\n\n_Answer: ${pick.a}_`);
      break;
    }
    case 'roast': {
      const r=['You are the human equivalent of a participation trophy.','If brains were gas, you would not have enough to power an ants motorcycle.','You are not stupid; you just have bad luck thinking.','You bring everyone so much joy when you leave the room.','You are proof that evolution can go in reverse.'];
      const t2=getTargetJid(m,args); const name=t2?`@${normNum(t2)}`:'you'; const mentions=t2?[t2]:[];
      await sock.sendMessage(jid,{text:ft(`🔥 ${r[Math.floor(Math.random()*r.length)].replace('You',name)}`,sock),mentions},{quoted:qchanel});
      break;
    }
    case 'ship': {
      const t1=sender; const t2=getTargetJid(m,args);
      const pct=Math.floor(Math.random()*101); const bar='█'.repeat(Math.floor(pct/10))+'░'.repeat(10-Math.floor(pct/10));
      await reply(`💘 Ship Meter\n\n@${normNum(t1)} ❤️ ${t2?'@'+normNum(t2):'???'}\n\n[${bar}] ${pct}%`);
      break;
    }
    case 'coinflip': { await reply(`🪙 ${Math.random()>0.5?'Heads!':'Tails!'}`); break; }
    case 'dice': { const sides=parseInt(args[0])||6; await reply(`🎲 d${sides}: *${Math.floor(Math.random()*sides)+1}*`); break; }
    case 'magic8': {
      const a=['Yes, definitely!','Without a doubt.','Outlook good.','My sources say no.','Cannot predict now.','Don\'t count on it.','Signs point to yes.','Very doubtful.','It is certain.','Ask again later.'];
      await reply(`🎱 ${a[Math.floor(Math.random()*a.length)]}`);
      break;
    }
    case 'horoscope': {
      const signs=['aries','taurus','gemini','cancer','leo','virgo','libra','scorpio','sagittarius','capricorn','aquarius','pisces'];
      const sign=args[0]?.toLowerCase();
      if(!signs.includes(sign)){await reply(`${prefix}horoscope <sign>\nSigns: ${signs.join(', ')}`);break;}
      try{const r=await axios.post(`https://aztro.sameerkumar.website/?sign=${sign}&day=today`,{},{timeout:8000});await reply(`⭐ *${sign.toUpperCase()}*\n\n${r.data.description}\n\n🍀 Lucky # ${r.data.lucky_number}\n💜 Mood: ${r.data.mood}`);}
      catch{await reply('❌ Failed.');}
      break;
    }
    case 'meme': {
      try{const r=await axios.get('https://meme-api.com/gimme',{timeout:8000});await replyImg(r.data.url,`😂 ${r.data.title}`);}
      catch{await reply('❌ No memes.');}
      break;
    }
    case 'cat': {
      try{const r=await axios.get('https://api.thecatapi.com/v1/images/search',{timeout:8000});await replyImg(r.data[0].url,'🐱 Meow!');}
      catch{await reply('❌ No cats.');}
      break;
    }
    case 'dog': {
      try{const r=await axios.get('https://dog.ceo/api/breeds/image/random',{timeout:8000});await replyImg(r.data.message,'🐶 Woof!');}
      catch{await reply('❌ No dogs.');}
      break;
    }
    case 'waifu': {
      try{const r=await axios.get('https://api.waifu.pics/sfw/waifu',{timeout:8000});await replyImg(r.data.url,'🌸 Waifu!');}
      catch{await reply('❌ No waifu.');}
      break;
    }
    case 'anime': {
      try{const r=await axios.get('https://api.jikan.moe/v4/random/anime',{timeout:8000});const a=r.data.data;await replyImg(a.images?.jpg?.image_url,`🎌 *${a.title}*\nEpisodes: ${a.episodes||'?'}\nScore: ${a.score||'?'}\n${(a.synopsis||'').slice(0,200)}`);}
      catch{await reply('❌ Failed.');}
      break;
    }
    case 'trivia': {
      try{
        const r=await axios.get('https://opentdb.com/api.php?amount=1&type=multiple',{timeout:8000});
        const q=r.data.results[0];
        const ans=[...q.incorrect_answers,q.correct_answer].sort(()=>Math.random()-0.5);
        await reply(`❓ *${q.question.replace(/&quot;/g,'"').replace(/&#039;/g,"'")}*\n\n${ans.map((a,i)=>`${i+1}. ${a}`).join('\n')}\n\n_Answer: ${q.correct_answer}_`);
      }catch{await reply('❌ No trivia.');}
      break;
    }
    case 'compliment': {
      const c2=['You are absolutely brilliant!','Your smile brightens everyone\'s day.','You are stronger than you think.','Your kindness is rare and beautiful.','You make the world a better place!','You have an amazing energy!'];
      const t2=getTargetJid(m,args); const name=t2?`@${normNum(t2)}`:'you'; const mentions=t2?[t2]:[];
      await sock.sendMessage(jid,{text:ft(`💐 ${c2[Math.floor(Math.random()*c2.length)].replace('You',name)}`,sock),mentions},{quoted:qchanel});
      break;
    }
    case 'bored': {
      try{const r=await axios.get('https://www.boredapi.com/api/activity/',{timeout:6000});await reply(`🎯 ${r.data.activity}\nType: ${r.data.type} | Participants: ${r.data.participants}`);}
      catch{await reply('❌ Failed.');}
      break;
    }

    // ── NEW FUN COMMANDS ──────────────────────────────────

    // Rock Paper Scissors
    case 'rps': {
      const choices = ['🪨 Rock','📄 Paper','✂️ Scissors'];
      const valid = ['rock','paper','scissors','r','p','s'];
      const map = {r:'rock',p:'paper',s:'scissors'};
      const raw = args[0]?.toLowerCase();
      const pick = map[raw] || raw;
      if (!['rock','paper','scissors'].includes(pick)) {
        await reply(`${prefix}rps rock/paper/scissors`); break;
      }
      const botPick = ['rock','paper','scissors'][Math.floor(Math.random()*3)];
      const wins = {rock:'scissors',paper:'rock',scissors:'paper'};
      const result = pick === botPick ? '🤝 Draw!' : wins[pick] === botPick ? '🏆 You win!' : '😈 Bot wins!';
      await reply(`Your choice: ${pick}\nBot choice: ${botPick}\n\n${result}`);
      break;
    }

    // Math quiz
    case 'math': {
      const ops = ['+','-','×'];
      const op = ops[Math.floor(Math.random()*ops.length)];
      const a2 = Math.floor(Math.random()*50)+1;
      const b2 = Math.floor(Math.random()*50)+1;
      const ans2 = op==='+' ? a2+b2 : op==='-' ? a2-b2 : a2*b2;
      if (!text) {
        const mathQ = readJSON(DB('mathq.json'), {});
        mathQ[jid] = { ans: ans2, ts: Date.now() };
        writeJSON(DB('mathq.json'), mathQ);
        await reply(`🧮 Quick Math!\n\n*${a2} ${op} ${b2} = ?*\n\nReply with the answer (30s to answer)`);
        break;
      }
      // Check answer
      const mathQ = readJSON(DB('mathq.json'), {});
      const q2 = mathQ[jid];
      if (!q2 || Date.now() - q2.ts > 30000) { await reply('❌ No active math question or time expired.'); break; }
      const userAns = parseInt(text.trim());
      if (userAns === q2.ans) {
        delete mathQ[jid];
        writeJSON(DB('mathq.json'), mathQ);
        await reply(`✅ Correct! The answer was *${q2.ans}* 🎉`);
      } else {
        await reply(`❌ Wrong! The correct answer was *${q2.ans}*`);
      }
      break;
    }

    // Never have I ever
    case 'neverhaveiever': {
      const nhi=[
        'Never have I ever lied to get out of trouble.',
        'Never have I ever eaten food off the floor.',
        'Never have I ever googled myself.',
        'Never have I ever faked being sick.',
        'Never have I ever cried at a movie.',
        'Never have I ever broken a bone.',
        'Never have I ever stayed awake for 24+ hours.',
      ];
      await reply(`🙈 ${nhi[Math.floor(Math.random()*nhi.length)]}\n\n_React 🖐 if you HAVE, 👇 if you HAVEN'T_`);
      break;
    }

    // Would you rather
    case 'wouldyourather': {
      const wyr=[
        ['be able to fly','be invisible'],
        ['speak every language','play every instrument'],
        ['have no internet for a month','no phone for a month'],
        ['always be hot','always be cold'],
        ['know the future','change the past'],
        ['be famous for a day','be unknown forever'],
      ];
      const pick2 = wyr[Math.floor(Math.random()*wyr.length)];
      await reply(`🤔 *Would you rather...*\n\n🅰️ ${pick2[0]}\n\n— OR —\n\n🅱️ ${pick2[1]}\n\n_Reply A or B!_`);
      break;
    }

    // ══════════════════════════════════════════════════════
    //   CREDITS – multi-card developer carousel
    // ══════════════════════════════════════════════════════
   /* case 'credits':
    case 'tennor': {
      await reaction('🌟');
      try {
        const {
          generateWAMessageFromContent,
          prepareWAMessageMedia,
          proto,
        } = require('./helper/baileys');

        // ── Helper: download + upload image for a card header ──
        const makeImgField = async (url) => {
          try {
            const buf = await getBuffer(url);
            return await prepareWAMessageMedia({ image: buf }, { upload: sock.waUploadToServer });
          } catch { return {}; }
        };

        // ── Card definitions ──
        // Each card: { img, title, body, buttons[] }
        const cardDefs = [
          {
            img:   'https://files.catbox.moe/ocgi20.jpg',
            title: '𝗚𝗶𝗱𝗱𝘆 𝗧𝗲𝗻𝗻𝗼𝗿',
            body: [
              '• horny dev',
              '• married',
              '• rude',
              '• arrested for being sexy',
              '• JavaScript coder',
              '• efootball player',
              '• chelsea fan',
              '• UoN student',
              '• Proud Luo',
            ].join('\n'),
            buttons: [
              { display_text: '📱 WhatsApp',    url: 'https://wa.me/254756182478' },
              { display_text: '✈️ Telegram',    url: 'https://t.me/tennormodzdev' },
              { display_text: '📢 TG Channel',  url: 'https://t.me/+jh4yhoD_XQs2MThk' },
              { display_text: '📣 WA Channel',  url: 'https://whatsapp.com/channel/0029VbAWe2uIHphDEiz3Vh2r' },
            ],
          },
          {
            img:   'https://files.catbox.moe/ee0lj9.jpg',
            title: '𝗝𝗮𝗺𝗲𝘀 𝗢𝗳𝗳𝗶𝗰𝗶𝗮𝗹',
            body: [
              '• fullstack developer',
              '• anime creator',
              '• proud Kikuyu',
              '• Naxeex games player',
              '• mini militia player',
            ].join('\n'),
            buttons: [
              { display_text: '📱 WhatsApp',   url: `https://wa.me/${kontributor[0] || settings.SUDO_NUMBER || '254704955033'}` },
              { display_text: '✈️ Telegram',   url: 'https://t.me/shenxidev' },
              { display_text: '📢 TG Channel', url: 'https://t.me/jamesBotz3' },
              { display_text: '👥 TG Group',   url: 'https://t.me/shenqidi' },
            ],
          },
          {
            img:   'https://files.catbox.moe/ee0lj9.jpg',
            title: '𝗔𝗻𝗶𝗺𝗲 𝗠𝗗 𝗕𝗼𝘁',
            body: [
              `• Powered by @whiskeysockets/baileys`,
              `• Version: ${settings.BOT_VERSION || '1.0'}`,
              `• Prefix: ${prefix}`,
              `• Library: Node.js`,
              `• Company: ${settings.COMPANY || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 Projects'}`,
              `• Made with ❤️ by the team`,
            ].join('\n'),
            buttons: [
              { display_text: '🔗 Pair Bot',      url: settings.REQUIRED_PAIR_LINK    || 'https://t.me/animemdoff_bot' },
              { display_text: '📢 Follow Channel', url: settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3' },
              { display_text: '👥 Support Group',  url: settings.REQUIRED_GROUP_LINK   || 'https://t.me/shenqidi' },
            ],
          },
          {
            img:   'https://files.catbox.moe/ee0lj9.jpg',
            title: '*ᴜɴᴋɴᴏᴡɴ ᴅᴇᴠ* ',
            body: [
              '• ғᴏᴜɴᴅᴇʀ ᴏғ ᴢᴇɴᴛʀɪx ᴛᴇᴄʜ',
              '• ʙᴀʀᴄᴀ ғᴀɴ',
              '• ʙᴏᴛ ᴅᴇᴠ',
              '• ᴄᴜᴛᴇsᴛ 😂😂',
            ].join('\n'),
            buttons: [
              { display_text: '📱 WhatsApp', url: 'https://wa.me/2349057467015' },
              { display_text: '✈️ Telegram', url: 't.me/UNKNOWN_IS_NO_MORE' },
         { display_text: '✈️ Whatsapp channel', url: 'https://whatsapp.com/channel/0029VbCjCq80LKZ4i4iWHq22' },
            ],
          },
{
            img:   'https://i.imghippo.com/files/BFi4775wA.jpg',
            title: '𝐌ꝛ 𝐍𝚯𝐗 𝚸𝚪𝚰𝚳𝚵𝚵𝚵 𝚯𝐅𝐅𝚰𝐂𝐈𝚫𝐋',
            body: [
              '• NOX HOSTING ☁️ | founder',
              '• PRIMEEE TECH | owner',
              '• BOT/SITE WEB developer',
              '• JUST A CHILL BOY 💳',
            ].join('\n'),
            buttons:  [
              { display_text: 'FREEPANEL BOT', url: 'https://t.me/NoxFreepanelbot?start=ref_7083149358' },
              { display_text: 'CHANNEL', url: 'https://whatsapp.com/channel/0029VbAHTYE7oQhXHhEVrS47' },
            
            { display_text: ' WhatsApp CONTACT', url: 'https://wa.me/message/L3752HTRQ3YPI1' },
              { display_text: '✈️ TG-CONTACT', url: 'https://t.me/noxdm' },
            ],
          },
          {
            img:   'https://files.catbox.moe/ee0lj9.jpg',
            title: 'Mzazi Tech Inc',
            body: [
              '• Next.js pro',
              '• Mzazi Nameless bot owner',
              '• proud Kisii',
              '• Single But married',
              '• Bugger mkisii',
            ].join('\n'),
            buttons: [
              { display_text: '📱 WhatsApp',   url: `https://wa.me/${kontributor[0] || settings.SUDO_NUMBER || '254750611309'}` },
              { display_text: '✈️ Telegram',   url: 'https://t.me/shenxidev' },
              { display_text: '📢 TG Channel', url: 'https://t.me/jamesBotz3' },
              { display_text: '👥 TG Group',   url: 'https://t.me/mzazidev' },
            ],
          },
          
        ];

        // ── Build all card image fields in parallel ──
        const imgFields = await Promise.all(cardDefs.map(cd => makeImgField(cd.img)));

        // ── Build proto cards ──
        const cards = cardDefs.map((cd, i) => ({
          header: proto.Message.InteractiveMessage.Header.fromObject({
            title: cd.title,
            hasMediaAttachment: !!imgFields[i]?.imageMessage,
            ...(imgFields[i] || {}),
          }),
          body: proto.Message.InteractiveMessage.Body.fromObject({ text: cd.body }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
            buttons: cd.buttons.map(b => ({
              name: 'cta_url',
              buttonParamsJson: JSON.stringify({ display_text: b.display_text, url: b.url, merchant_url: b.url }),
            })),
          }),
        }));

        const creditMsg = await generateWAMessageFromContent(jid, {
          ephemeralMessage: {
            message: {
              messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
              interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body:    proto.Message.InteractiveMessage.Body.fromObject({ text: ` *${c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD'} — Developer Credits*` }),
                footer:  proto.Message.InteractiveMessage.Footer.fromObject({ text: `© ${settings.CREDITS || 'james'} • ${settings.COMPANY || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 Projects'}` }),
                header:  proto.Message.InteractiveMessage.Header.fromObject({ title: '', hasMediaAttachment: false }),
                contextInfo: {},
                carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards }),
              }),
            },
          },
        }, { quoted: qchanel });

        await sock.relayMessage(jid, creditMsg.message, { messageId: creditMsg.key.id });
      } catch (e) {
        // plain fallback
        await reply(
          `🌟 *${c.botName || settings.BOT_NAME || '𝑱𝑨𝑳𝑰𝑨 × 𝑫𝑰𝑬𝑮𝑶 MD'} — Credits*\n\n` +
          `👨‍💻 *Giddy Tennor* — JavaScript dev, UoN student, Proud Luo\n` +
          `👨‍💻 *James Official* — Fullstack dev, anime creator, Proud Kikuyu\n\n` +
          `📢 Channel: ${settings.REQUIRED_CHANNEL_LINK || 'https://t.me/jamesBotz3'}\n` +
          `🔗 Pair: ${settings.REQUIRED_PAIR_LINK || 'https://t.me/animemdoff_bot'}`
        );
      }
      break;
    }
*/
    // ══════════════════════════════════════════════════════════
    //   CARBON  – code → pretty image
    // ══════════════════════════════════════════════════════════
    case 'carbon': {
      const { qMsg } = getQuoted(m);
      const code = (text || '').trim() || (qMsg?.conversation || qMsg?.extendedTextMessage?.text || '').trim();
      if (!code) { await reply(`🎨 *${prefix}carbon <code>*\n\nOr reply to a message containing code.`); break; }
      await reaction('🎨');
      const lang = (args[0] || '').startsWith('#') ? args[0].slice(1) : 'javascript';
      const src  = (args[0] || '').startsWith('#') ? text.split(/\s+/).slice(1).join(' ') : code;
      const url  = `https://carbonara-42.vercel.app/api/rest/carbon?code=${encodeURIComponent(src)}&language=${encodeURIComponent(lang)}&backgroundColor=rgba(0,0,0,1)`;
      await replyImg(url, `🎨 *Carbon* · ${src.split('\n').length} line(s)`);
      break;
    }

    // ══════════════════════════════════════════════════════════
    //   IMAGINE  – free keyless text-to-image
    // ══════════════════════════════════════════════════════════
    case 'imagine': {
      if (!text) { await reply(`🎨 *${prefix}imagine <prompt>*`); break; }
      await reaction('🎨');
      const seed = Math.floor(Math.random() * 1e6);
      const url  = `https://image.pollinations.ai/prompt/${encodeURIComponent(text)}?width=1024&height=1024&nologo=true&seed=${seed}`;
      await replyImg(url, `🎨 *${text}*`);
      break;
    }

    // ══════════════════════════════════════════════════════════
    //   TYPE RACER
    // ══════════════════════════════════════════════════════════
    case 'typeracer': {
      if (!global.__typeRaces) global.__typeRaces = new Map();
      const phrases = [
        'the quick brown fox jumps over the lazy dog',
        'pack my box with five dozen liquor jugs',
        'how vexingly quick daft zebras jump',
        'the five boxing wizards jump quickly',
        'sphinx of black quartz judge my vow',
      ];
      const state = global.__typeRaces.get(jid);
      if (!text || !state) {
        const phrase = phrases[Math.floor(Math.random() * phrases.length)];
        global.__typeRaces.set(jid, { phrase, started: Date.now() });
        await reply(`🏁 *TYPE RACER*\n\nSend this exact text back:\n\n\`${phrase}\`\n\nThen: *${prefix}typeracer <the text above>*`);
        break;
      }
      if (text.trim().toLowerCase() !== state.phrase.toLowerCase()) {
        await reply(`❌ That's not the phrase.\n\nExpected:\n\`${state.phrase}\``);
        break;
      }
      global.__typeRaces.delete(jid);
      const secs = Math.max((Date.now() - state.started) / 1000, 0.01);
      const wpm  = Math.round((state.phrase.split(' ').length / secs) * 60);
      await reply(`🏆 *Finished!*\n\n⏱ Time: ${secs.toFixed(2)}s\n⚡ Speed: ${wpm} WPM`);
      break;
    }

    // ══════════════════════════════════════════════════════════
    //   POLLS  – native WhatsApp poll + persistent tally
    // ══════════════════════════════════════════════════════════
    case 'poll': {
      if (needGroup()) break;
      if (needAdmin()) break;
      const parts = text.split('|').map(s => s.trim()).filter(Boolean);
      if (parts.length < 3) {
        await reply(`📊 *Create a poll*\n\n\`${prefix}poll Question | Option A | Option B\`\n\nClose it later with \`${prefix}endpoll\`.`);
        break;
      }
      const [question, ...options] = parts;
      if (options.length < 2 || options.length > 12) { await reply('❌ A poll needs between 2 and 12 options.'); break; }
      try {
        const sentPoll = await sock.sendMessage(jid, { poll: { name: question, values: options, selectableCount: 1 } });
        setPoll(jid, { question, options, id: sentPoll?.key?.id || '', createdAt: Date.now(), votes: {} });
        await reply(`📊 *Poll started*\n\n❓ ${question}\n\n${options.map((o, i) => `${i + 1}. ${o}`).join('\n')}\n\nClose it with \`${prefix}endpoll\`.`);
      } catch (e) {
        await reply(`❌ Could not create the poll: ${e.message}`);
      }
      break;
    }

    case 'endpoll': {
      if (needGroup()) break;
      const current = getPoll(jid);
      if (!current) {
        await reply(`📊 No active poll in this group.\n\nStart one with \`${prefix}poll Question | Option A | Option B\`.`);
        break;
      }
      clearPoll(jid);
      const votes  = current.votes || {};
      const voters = Object.keys(votes);
      const tally  = current.options.map((o, i) => {
        const who = voters.filter(n => Number(votes[n]) === i);
        return `├◆ ${i + 1}. ${o} — *${who.length}* vote(s)` + (who.length ? `\n├◆    ${who.map(n => '@' + n).join(', ')}` : '');
      }).join('\n');
      await sock.sendMessage(jid, {
        text: `📊 *Poll closed*\n\n❓ ${current.question}\n\n${tally}\n\n🗳 Total votes: ${voters.length}`,
        mentions: voters.map(n => n + '@s.whatsapp.net'),
      }, { quoted: m });
      break;
    }

    // ── btntest – tiny interactive message to prove buttons render ──
    // The full .menu body is ~7,200 chars, which is far past what WhatsApp
    // accepts for an interactive message. This sends a deliberately short one
    // so you can tell "buttons don't render on my client" apart from
    // "the menu body was too long for the interactive message to go through".
    case 'btntest': {
      if (!_isOwner) { await reply('❌ Owner only.'); break; }
      const lib = bttns();
      if (!lib || typeof lib.sendButtons !== 'function') {
        await reply('❌ blacklord-bttns is not available on this install.');
        break;
      }
      const btn = lib && lib.btn
        ? lib.btn.url('🔗 Skylar Site', SKYLAR_SITE)
        : { name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: '🔗 Skylar Site', url: SKYLAR_SITE, merchant_url: SKYLAR_SITE }) };

      const results = [];

      // Shape A — viewOnceMessage wrapper (what the library documents as required)
      try {
        await sendInteractiveButtons(sock, jid, {
          title: 'A · wrapped',
          text: 'TEST A - viewOnceMessage wrapper.\n\nIf you can see a button under THIS message, the wrapper is the fix.',
          footer: 'SKYLAR X ULTRA',
          buttons: [btn],
          quoted: m,
        });
        results.push('A (wrapped) sent ✅');
      } catch (e) {
        results.push(`A (wrapped) FAILED ❌ ${e.message}`);
      }

      // Shape B — top-level interactiveMessage (what blacklord-bttns actually sends)
      if (lib && typeof lib.sendButtons === 'function') {
        try {
          await lib.sendButtons(sock, jid, {
            title: 'B · top-level',
            text: 'TEST B — top-level interactiveMessage (what blacklord-bttns sends).',
            footer: 'SKYLAR X ULTRA',
            buttons: [lib.btn.url('🔗 Skylar Site', SKYLAR_SITE)],
            contextInfo: NEWSLETTER_CONTEXT,
            quoted: m,
          });
          results.push('B (top-level) sent ✅');
        } catch (e) {
          results.push(`B (top-level) FAILED ❌ ${e.message}`);
        }
      }

      // Shape C -- quick_reply buttons (the type .play uses). The menu works
      // with cta_url on this account, so this isolates whether this WhatsApp
      // build renders quick_reply at all.
      try {
        await sendInteractiveButtons(sock, jid, {
          title: 'C · quick_reply',
          text : 'TEST C - quick_reply buttons (what .play sends).\n\nButtons here? Then .play buttons should appear too.',
          footer: 'SKYLAR X ULTRA',
          buttons: [{ name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: '🎵 Audio', id: 'PLAY_AUDIO|https://youtu.be/mock' }) }],
          quoted: m,
        });
        results.push('C (quick_reply) sent ✅');
      } catch (e) {
        results.push(`C (quick_reply) FAILED ❌ ${e.message}`);
      }

      await reply(`🔬 *Button diagnostics*\n\n${results.join('\n')}\n\nWhichever message shows a working button tells us which shape to use for .menu.`);
      break;
    }

    default: {
      // `isOwner` is a boolean (admin.js tests it directly) while dev-commands.js
      // invokes it as a function – supply both forms so neither module breaks.
      const h = {
        reply, replyImg, ft, cfg, dlMedia, reaction, react, normNum, getQuoted,
        isOwner: _isOwner,
        isOwnerFn: () => _isOwner,
      };

      // Each sub-handler is isolated, so one failing module can never stop the rest.
      const chain = [
        ['reactions', reactionHandler],
        ['scraps',    scrapsHandler],
        ['illusion',  illusionHandler],
        ['social',    socialHandler],
        ['ai',        aiHandler],
        ['economy',   economyHandler],
        ['tools',     toolsHandler],
        ['stickers',  stickerHandler],
        ['music',     musicHandler],
        ['games',     gamesHandler],
        ['admin',     adminHandler],
        ['arabic',    arabicHandler],
      ];

      let handled = false;
      for (const [name, fn] of chain) {
        try {
          if (await fn(sock, m, cmd, args, h)) { handled = true; break; }
        } catch (e) {
          logError('CMDHANDLER', `${name}:${cmd} -> ${e.message}`);
        }
      }

      if (!handled) {
        try { await devHandler(sock, m, cmd, args, h); }
        catch (e) { logError('CMDHANDLER', `dev:${cmd} -> ${e.message}`); }
      }
      break;
    }
  }
}

module.exports = { handleMessage, runAutoFollow, handlePollVotes, CMDS, KNOWN_COMMANDS };
