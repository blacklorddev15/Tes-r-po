// ============================================================
//   verify-antidelete.js  –  anti-delete delivery test
// ------------------------------------------------------------
//   Asserts that recovered (deleted) messages are delivered to the
//   PAIRED NUMBER'S OWN DM, with a fallback to the source chat, and
//   that the toggle / fromMe / unstored-message guards hold.
//
//   Usage:  node verify-antidelete.js
// ============================================================
const fs=require('fs'), path=require('path');
const DB=path.join(__dirname,'database');
fs.writeFileSync(path.join(DB,'settings.json'), JSON.stringify({ '254700000000': { antidelete: true, prefix: '.' } }, null, 2));

const { storeMessage } = require('./helper/function');
const { handleAntiDelete } = require('./helper/listeners');

const calls=[];
function mkSock(failOn){
  return {
    __waNum:'254700000000',
    user:{ id:'254700000000:1@s.whatsapp.net' },
    groupMetadata: async () => ({ subject:'Test Group' }),
    sendMessage: async (jid, payload) => {
      if (failOn && jid===failOn) throw new Error('simulated send failure');
      calls.push({ jid, text: payload.text || payload.caption || '(media)', mentions: payload.mentions });
      return { key:{ id:'X' } };
    },
  };
}

(async () => {
  let pass=0, fail=0;
  const check=(name,cond,extra='')=>{ if(cond){pass++;console.log('PASS  '+name);} else {fail++;console.log('FAIL  '+name+'  '+extra);} };

  // ── 1. group text deletion -> paired number DM
  calls.length=0;
  storeMessage({ key:{ remoteJid:'1111@g.us', id:'M1', participant:'254711111111@s.whatsapp.net', fromMe:false },
                 message:{ conversation:'the secret text' }, pushName:'Alice' });
  await handleAntiDelete(mkSock(), { keys:[{ remoteJid:'1111@g.us', id:'M1' }] });
  check('group text -> delivered to paired DM', calls.length>0 && calls[0].jid==='254700000000@s.whatsapp.net', JSON.stringify(calls));
  check('recovered body present', calls[0] && calls[0].text.includes('the secret text'), JSON.stringify(calls));
  check('source chat named in header', calls[0] && calls[0].text.includes('Test Group'), JSON.stringify(calls));
  check('no mentions in DM', calls[0] && calls[0].mentions===undefined, JSON.stringify(calls));

  // ── 2. group deletion with a failing DM send -> falls back to source group
  calls.length=0;
  storeMessage({ key:{ remoteJid:'2222@g.us', id:'M2', participant:'254711111111@s.whatsapp.net', fromMe:false },
                 message:{ conversation:'fallback text' }, pushName:'Bob' });
  await handleAntiDelete(mkSock('254700000000@s.whatsapp.net'), { keys:[{ remoteJid:'2222@g.us', id:'M2' }] });
  check('DM failure falls back to source chat', calls.length>0 && calls[0].jid==='2222@g.us', JSON.stringify(calls));
  check('fallback keeps the text', calls[0] && calls[0].text.includes('fallback text'), JSON.stringify(calls));
  check('fallback adds mentions', calls[0] && Array.isArray(calls[0].mentions), JSON.stringify(calls));

  // ── 3. private-chat deletion -> paired DM
  calls.length=0;
  storeMessage({ key:{ remoteJid:'254733333333@s.whatsapp.net', id:'M3', fromMe:false },
                 message:{ conversation:'dm secret' }, pushName:'Carol' });
  await handleAntiDelete(mkSock(), { keys:[{ remoteJid:'254733333333@s.whatsapp.net', id:'M3' }] });
  check('DM deletion -> paired DM', calls[0] && calls[0].jid==='254700000000@s.whatsapp.net', JSON.stringify(calls));
  check('DM source labelled', calls[0] && calls[0].text.includes('+254733333333'), JSON.stringify(calls));

  // ── 4. toggle off -> nothing sent
  fs.writeFileSync(path.join(DB,'settings.json'), JSON.stringify({ '254700000000': { antidelete: false, prefix: '.' } }, null, 2));
  calls.length=0;
  storeMessage({ key:{ remoteJid:'3333@g.us', id:'M4', participant:'254711111111@s.whatsapp.net', fromMe:false },
                 message:{ conversation:'should not appear' }, pushName:'Dave' });
  await handleAntiDelete(mkSock(), { keys:[{ remoteJid:'3333@g.us', id:'M4' }] });
  check('antidelete off -> silent', calls.length===0, JSON.stringify(calls));

  // ── 5. own deletion skipped
  fs.writeFileSync(path.join(DB,'settings.json'), JSON.stringify({ '254700000000': { antidelete: true, prefix: '.' } }, null, 2));
  calls.length=0;
  storeMessage({ key:{ remoteJid:'4444@g.us', id:'M5', fromMe:true }, message:{ conversation:'mine' }, pushName:'Me' });
  await handleAntiDelete(mkSock(), { keys:[{ remoteJid:'4444@g.us', id:'M5' }] });
  check('fromMe deletions skipped', calls.length===0, JSON.stringify(calls));

  // ── 6. unstored message ignored
  calls.length=0;
  await handleAntiDelete(mkSock(), { keys:[{ remoteJid:'5555@g.us', id:'NEVER_STORED' }] });
  check('unstored message ignored', calls.length===0, JSON.stringify(calls));


  // ── 7. media whose download fails still reports to the DM (not the group)
  calls.length=0;
  storeMessage({ key:{ remoteJid:'6666@g.us', id:'M6', participant:'254711111111@s.whatsapp.net', fromMe:false },
                 message:{ imageMessage:{ caption:'pic caption', mimetype:'image/jpeg' } }, pushName:'Eve' });
  await handleAntiDelete(mkSock(), { keys:[{ remoteJid:'6666@g.us', id:'M6' }] });
  check('undownloadable image -> DM notice', calls.length>0 && calls[0].jid==='254700000000@s.whatsapp.net' && calls[0].text.includes('Image'), JSON.stringify(calls));

  // ── 8. sticker deletion
  calls.length=0;
  storeMessage({ key:{ remoteJid:'7777@g.us', id:'M7', participant:'254711111111@s.whatsapp.net', fromMe:false },
                 message:{ stickerMessage:{ mimetype:'image/webp' } }, pushName:'Frank' });
  await handleAntiDelete(mkSock(), { keys:[{ remoteJid:'7777@g.us', id:'M7' }] });
  check('sticker deletion -> DM notice', calls.length>0 && calls[0].jid==='254700000000@s.whatsapp.net', JSON.stringify(calls));

  // ── 9. view-once deletion
  calls.length=0;
  storeMessage({ key:{ remoteJid:'8888@g.us', id:'M8', participant:'254711111111@s.whatsapp.net', fromMe:false },
                 message:{ viewOnceMessageV2:{ message:{ imageMessage:{ mimetype:'image/jpeg' } } } }, pushName:'Gina' });
  await handleAntiDelete(mkSock(), { keys:[{ remoteJid:'8888@g.us', id:'M8' }] });
  check('view-once deletion -> DM notice', calls.length>0 && calls[0].jid==='254700000000@s.whatsapp.net' && calls[0].text.includes('View Once'), JSON.stringify(calls));

  // ── 10. unknown/other type falls through to the generic notice
  calls.length=0;
  storeMessage({ key:{ remoteJid:'9999@g.us', id:'M9', participant:'254711111111@s.whatsapp.net', fromMe:false },
                 message:{ eventMessage:{ name:'party' } }, pushName:'Hank' });
  await handleAntiDelete(mkSock(), { keys:[{ remoteJid:'9999@g.us', id:'M9' }] });
  check('unknown type -> DM notice', calls.length>0 && calls[0].jid==='254700000000@s.whatsapp.net', JSON.stringify(calls));

  // ── 11. two deletions in one event both delivered
  calls.length=0;
  storeMessage({ key:{ remoteJid:'1010@g.us', id:'MA', participant:'254711111111@s.whatsapp.net', fromMe:false }, message:{ conversation:'first' }, pushName:'Ivy' });
  storeMessage({ key:{ remoteJid:'1010@g.us', id:'MB', participant:'254722222222@s.whatsapp.net', fromMe:false }, message:{ conversation:'second' }, pushName:'Joe' });
  await handleAntiDelete(mkSock(), { keys:[{ remoteJid:'1010@g.us', id:'MA' }, { remoteJid:'1010@g.us', id:'MB' }] });
  check('batch deletions both delivered to DM', calls.length===2 && calls.every(c=>c.jid==='254700000000@s.whatsapp.net'), JSON.stringify(calls));


  // ── 12. REAL-WORLD PATH: "delete for everyone" arrives as messages.update ──
  // with a REVOKE stub (WAMessageStubType.REVOKE = 1), NOT messages.delete.
  // This is the case that was silently broken.
  const { revokedKeysFromUpdates } = require('./helper/listeners');
  const revokeUpdate = (chatJid, originalId, sender) => ([{
    key: { remoteJid: chatJid, id: 'REVOKE_PROTOCOL_MSG', fromMe: false, participant: sender },
    update: {
      message: null,
      messageStubType: 1,                       // WAMessageStubType.REVOKE
      key: { remoteJid: chatJid, id: originalId, fromMe: false, participant: sender },
    },
  }]);

  calls.length = 0;
  storeMessage({ key:{ remoteJid:'1212@g.us', id:'RV1', participant:'254711111111@s.whatsapp.net', fromMe:false },
                 message:{ conversation:'deleted for everyone' }, pushName:'Alice' });
  await handleAntiDelete(mkSock(), { keys: revokedKeysFromUpdates(revokeUpdate('1212@g.us','RV1','254711111111@s.whatsapp.net')) });
  check('revoke via messages.update -> paired DM', calls.length>0 && calls[0].jid==='254700000000@s.whatsapp.net', JSON.stringify(calls));
  check('revoke recovers the original text', calls[0] && calls[0].text.includes('deleted for everyone'), JSON.stringify(calls));

  // the revoke key must resolve to the ORIGINAL message, not the revoke message
  const rk = revokedKeysFromUpdates(revokeUpdate('1212@g.us','RV1','254711111111@s.whatsapp.net'));
  check('revoke key uses original id, not protocol id', rk[0] && rk[0].id==='RV1', JSON.stringify(rk));

  // ── 13. ordinary message edits/updates are NOT treated as deletions
  calls.length = 0;
  const notRevoke = revokedKeysFromUpdates([{ key:{ remoteJid:'1313@g.us', id:'X' }, update:{ message:{ conversation:'edited' } } }]);
  check('non-revoke update ignored', notRevoke.length===0, JSON.stringify(notRevoke));

  // ── 14. revoke for an unstored message is ignored, not a crash
  calls.length = 0;
  await handleAntiDelete(mkSock(), { keys: revokedKeysFromUpdates(revokeUpdate('1414@g.us','NEVER_STORED','254711111111@s.whatsapp.net')) });
  check('revoke of unstored message ignored', calls.length===0, JSON.stringify(calls));


  // ── 15. disk capture (ELITE port) + note format ────────────
  const fsp  = require('fs');
  const pth  = require('path');
  const { captureForAntiDelete } = require('./helper/listeners');
  const antiDir = pth.join(__dirname, 'anti_delete');

  const incoming = {
    key: { remoteJid: '1515@g.us', id: 'DK1', participant: '254711111111@s.whatsapp.net', fromMe: false },
    message: { conversation: 'disk captured text' },
    pushName: 'Disk Alice',
  };
  captureForAntiDelete(incoming);
  const files = fsp.existsSync(antiDir) ? fsp.readdirSync(antiDir) : [];
  check('capture mirrors the message to disk', files.some(f => f.includes('DK1')), files.join(',') || 'dir missing');

  // nothing in the memory store -> only the disk copy can satisfy this
  calls.length = 0;
  await handleAntiDelete(mkSock(), {
    keys: [{ remoteJid: '1515@g.us', id: 'DK1', fromMe: false, participant: '254711111111@s.whatsapp.net' }],
  });
  check('recovers from disk when the memory store is empty',
    calls.length > 0 && calls[0].jid === '254700000000@s.whatsapp.net', JSON.stringify(calls).slice(0, 140));
  check('note uses the ELITE layout (Deleted / Sender / Chat)',
    /ANTI DELETE MESSAGES/.test(calls[0]?.text || '') && /Sender/.test(calls[0]?.text || '') && /Chat/.test(calls[0]?.text || ''),
    JSON.stringify((calls[0]?.text || '').slice(0, 90)));
  check('note is blockquoted', (calls[0]?.text || '').startsWith('> '),
    JSON.stringify((calls[0]?.text || '').slice(0, 40)));
  check('recovered message body is blockquoted', (calls[0]?.text || '').includes('> disk captured text'),
    JSON.stringify((calls[0]?.text || '').slice(-60)));
  check('disk copy deleted after recovery',
    !(fsp.existsSync(antiDir) && fsp.readdirSync(antiDir).some(f => f.includes('DK1'))));

  // ── 16. deletions made by the bot itself are not reported ──
  calls.length = 0;
  captureForAntiDelete({
    key: { remoteJid: '1616@g.us', id: 'DK2', participant: '254700000000@s.whatsapp.net', fromMe: false },
    message: { conversation: 'the bot wrote this' },
    pushName: 'Me',
  });
  await handleAntiDelete(mkSock(), {
    keys: [{ remoteJid: '1616@g.us', id: 'DK2', fromMe: false, participant: '254700000000@s.whatsapp.net' }],
  });
  check('bot-authored message not reported back to the bot', calls.length === 0, JSON.stringify(calls).slice(0, 120));

  // tidy up anything the sweep has not caught yet
  try {
    for (const f of fsp.readdirSync(antiDir)) if (/DK\d/.test(f)) fsp.unlinkSync(pth.join(antiDir, f));
  } catch {}

  console.log(`\n==== ${pass} passed, ${fail} failed ====`);
  process.exit(fail?1:0);
})();
