// admin.js – 30+ Extended Admin Commands
'use strict';
const path = require('path');
const { setWaSetting }         = require('./helper/function');
const { readJSON, writeJSON }  = require('./helper/utils');

const WARN_FILE = path.resolve(__dirname, 'database', 'warnings.json');

const ADMIN_CMDS = [
  'setrulesimg','clearrules','setrules','rules',
  'pinmsg','unpinmsg','allmsg','delmsg',
  'mutetime','unmuteall','banlist','unbanall',
  'setjoinmsg','setleavemsg','togglewelcome','togglegoodbye',
  'setnsfw','antinsfw','antiforward','antifake',
  'autopin','autoreact','autoreply','setautoreply',
  'kickinactive2','warnreset','warnlimit','setwarnlimit',
  'groupstat','reportadmin','requestrole','voteban',
  'addbot','removebot','listbots',
];

async function adminHandler(sock, m, cmd, args, helpers) {
  if (!ADMIN_CMDS.includes(cmd)) return false;
  const { reply, ft, cfg, reaction } = helpers;
  const jid    = m.key.remoteJid;
  const prefix = cfg(sock).prefix || '.';
  const text   = args.join(' ');
  const isGrp  = jid.endsWith('@g.us');

  if (!isGrp) { await reply(`❌ This command is for groups only.`); return true; }

  // ── shared helpers ───────────────────────────────────────────
  // Plain-digits WA number that owns this session (same key used by cfg()).
  const waNumOf = (s) => s.__waNum
    || (s.user?.id ? String(s.user.id).split('@')[0].split(':')[0].replace(/\D/g, '') : 'default');
  const senderId  = m.key.participant || m.key.remoteJid || '';
  const senderNum = helpers.normNum ? helpers.normNum(senderId) : String(senderId).replace(/\D/g, '');

  // Never let a network call hang the command forever.
  const withTimeout = (p, ms = 15000) => {
    let t;
    return Promise.race([
      p,
      new Promise((_, rej) => {
        t = setTimeout(() => rej(new Error('timed out waiting for WhatsApp')), ms);
        if (t && t.unref) t.unref();
      }),
    ]);
  };

  // Per-group persistence: same JSON store cfg() reads (settings.json).
  const gGet = (key) => cfg(sock)[key] || {};
  const gPut = (key, val) => { const o = { ...(cfg(sock)[key] || {}) }; o[jid] = val; setWaSetting(waNumOf(sock), key, o); return o; };
  const flagGet = (name) => !!(cfg(sock).groupFlags?.[jid]?.[name]);
  const flagSet = (name, val) => {
    const f = { ...(cfg(sock).groupFlags || {}) };
    f[jid] = { ...(f[jid] || {}), [name]: val };
    setWaSetting(waNumOf(sock), 'groupFlags', f);
    return val;
  };
  const onOff = (cur) => {
    const v = String(args[0] || '').toLowerCase();
    return v === 'on' ? true : v === 'off' ? false : !cur;
  };

  // Sender must be a group admin (or the bot owner).
  const requireAdmin = async () => {
    if (helpers.isOwner) return true;
    try {
      const metaA = await withTimeout(sock.groupMetadata(jid));
      if ((metaA?.participants || []).some(p => p.admin && helpers.normNum(p.id) === senderNum)) return true;
    } catch { /* fall through to denial */ }
    await reply(ft(`❌ This command is for group admins only.`, sock));
    return false;
  };

  switch (cmd) {
    case 'rules': {
      const rules = cfg(sock).groupRules?.[jid];
      if (!rules) { await reply(ft(`📋 No rules set.\nAdmin: *${prefix}setrules <rules>*`, sock)); break; }
      await reply(ft(`📋 *Group Rules*\n\n${rules}`, sock));
      break;
    }
    case 'setrules': {
      if (!(await requireAdmin())) break;
      if (!text) { await reply(`📋 *${prefix}setrules <your rules>*`); break; }
      gPut('groupRules', text);
      await reply(ft(`✅ Group rules set!`, sock));
      break;
    }
    
    case 'groupstat': {
      try {
        const meta  = await sock.groupMetadata(jid);
        const total = meta.participants?.length || 0;
        const admins2= meta.participants?.filter(p=>p.admin).length || 0;
        const bots2  = meta.participants?.filter(p=>p.id?.includes('bot')).length || 0;
        await reply(ft(
          `📊 *Group Stats*\n\n` +
          `👥 Members: ${total}\n` +
          `👑 Admins: ${admins2}\n` +
          `🤖 Bots: ${bots2}\n` +
          `📅 Created: ${meta.creation ? new Date(meta.creation * 1000).toLocaleDateString() : 'unknown'}`,
          sock
        ));
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'togglewelcome': {
      const config2 = cfg(sock);
      if (!config2.groupFlags) config2.groupFlags = {};
      if (!config2.groupFlags[jid]) config2.groupFlags[jid] = {};
      config2.groupFlags[jid].welcome = !config2.groupFlags[jid].welcome;
      const state2 = config2.groupFlags[jid].welcome;
      await reply(ft(`👋 Welcome messages: *${state2?'ON ✅':'OFF ❌'}*`, sock));
      break;
    }
    case 'togglegoodbye': {
      const config3 = cfg(sock);
      if (!config3.groupFlags) config3.groupFlags = {};
      if (!config3.groupFlags[jid]) config3.groupFlags[jid] = {};
      config3.groupFlags[jid].goodbye = !config3.groupFlags[jid].goodbye;
      const state3 = config3.groupFlags[jid].goodbye;
      await reply(ft(`👋 Goodbye messages: *${state3?'ON ✅':'OFF ❌'}*`, sock));
      break;
    }
    case 'antiforward': {
      const config4 = cfg(sock);
      if (!config4.groupFlags) config4.groupFlags = {};
      if (!config4.groupFlags[jid]) config4.groupFlags[jid] = {};
      config4.groupFlags[jid].antiforward = !config4.groupFlags[jid].antiforward;
      await reply(ft(`📤 Anti-Forward: *${config4.groupFlags[jid].antiforward?'ON ✅':'OFF ❌'}*`, sock));
      break;
    }
    case 'warnlimit':
    case 'setwarnlimit': {
      const limit = parseInt(args[0]);
      if (!limit||limit<1) { await reply(`⚠️ *${prefix}setwarnlimit <1-10>*`); break; }
      const wl = { ...(cfg(sock).warnLimits || {}) };
      wl[jid] = limit;
      setWaSetting(waNumOf(sock), 'warnLimits', wl);
      await reply(ft(`⚠️ Warn limit set to *${limit}* (auto-kick at ${limit} warnings)`, sock));
      break;
    }
    case 'mutetime': {
      const dur = parseInt(args[0]) || 60;
      const target = args[1]?.replace(/\D/g,'');
      if (!target) { await reply(`🔇 *${prefix}mutetime <minutes> @user*`); break; }
      try {
        await sock.groupParticipantsUpdate(jid, [target+'@s.whatsapp.net'], 'demote');
        await reply(ft(`🔇 Muted @${target} for ${dur} minutes`, sock));
        setTimeout(async ()=>{
          try { await sock.groupParticipantsUpdate(jid, [target+'@s.whatsapp.net'], 'promote'); } catch {}
        }, dur*60*1000);
      } catch(e) { await reply(`❌ ${e.message}`); }
      break;
    }
    // ── rules image / clear ──────────────────────────────────
    case 'setrulesimg': {
      if (!(await requireAdmin())) break;
      const qSRI = helpers.getQuoted(m) || {};
      let src = text.trim();
      if (!src && qSRI.qType === 'imageMessage') {
        try {
          const buf = await withTimeout(helpers.dlMedia(qSRI.qMsg, qSRI.qKey));
          const up  = sock.waUploadToServer ? await withTimeout(sock.waUploadToServer(buf, {})) : null;
          src = (up && up.url) || '';
        } catch { src = ''; }
        if (!src) { await reply(`❌ Could not upload the quoted image. Reply to an image again or pass a direct image URL.`); break; }
      }
      if (!src) { await reply(`🖼️ *${prefix}setrulesimg <image-url>* (or reply to an image)`); break; }
      gPut('groupRulesImg', src);
      await reply(ft(`✅ Group rules image saved.`, sock));
      break;
    }
    case 'clearrules': {
      if (!(await requireAdmin())) break;
      const rules0 = { ...(cfg(sock).groupRules || {}) };
      const hadR   = !!rules0[jid];
      if (hadR) { delete rules0[jid]; setWaSetting(waNumOf(sock), 'groupRules', rules0); }
      const imgs0  = { ...(cfg(sock).groupRulesImg || {}) };
      const hadI   = !!imgs0[jid];
      if (hadI) { delete imgs0[jid]; setWaSetting(waNumOf(sock), 'groupRulesImg', imgs0); }
      await reply(ft(hadR || hadI ? `🧹 Group rules cleared.` : `ℹ️ No rules or rules image were set for this group.`, sock));
      break;
    }

    // ── quoted-message actions ───────────────────────────────
    case 'pinmsg':
    case 'unpinmsg': {
      if (!(await requireAdmin())) break;
      const qP = helpers.getQuoted(m) || {};
      if (!qP.qKey) { await reply(`📌 Reply to the message you want to ${cmd === 'pinmsg' ? 'pin' : 'unpin'}.`); break; }
      // blacklord-baileys supports { pin, type, time } on sendMessage.
      // WAProto.PinInChat.Type: 1 = PIN_FOR_ALL, 2 = UNPIN_FOR_ALL.
      try {
        await withTimeout(sock.sendMessage(jid, { pin: qP.qKey, type: cmd === 'pinmsg' ? 1 : 2, time: 86400 }));
        await reply(ft(cmd === 'pinmsg' ? `📌 Message pinned in this chat.` : `📌 Message unpinned.`, sock));
      } catch (e) {
        await reply(`❌ Pin/unpin is not supported by the installed WhatsApp library build (${e.message}).`);
      }
      break;
    }
    case 'delmsg': {
      if (!(await requireAdmin())) break;
      const qD = helpers.getQuoted(m) || {};
      if (!qD.qKey) { await reply(`🗑️ Reply to the message the bot should delete.`); break; }
      try {
        await withTimeout(sock.sendMessage(jid, { delete: qD.qKey }));
        await reply(ft(`🗑️ Message deleted.`, sock));
      } catch (e) { await reply(`❌ Could not delete that message (${e.message}).`); }
      break;
    }
    case 'allmsg': {
      if (!(await requireAdmin())) break;
      try {
        const metaAll = await withTimeout(sock.groupMetadata(jid));
        const idsAll  = (metaAll?.participants || []).map(p => p.id).filter(Boolean);
        if (!idsAll.length) { await reply(`⚠️ No members found in this group.`); break; }
        const bodyAll = text.trim() || '📢 Attention everyone!';
        await withTimeout(sock.sendMessage(jid, {
          text: `${ft(bodyAll, sock)}\n\n${idsAll.map(i => '@' + helpers.normNum(i)).join(' ')}`,
          mentions: idsAll,
        }));
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }

    // ── group open / bans ────────────────────────────────────
    case 'unmuteall': {
      if (!(await requireAdmin())) break;
      try {
        await withTimeout(sock.groupSettingUpdate(jid, 'not_announcement'));
        await reply(ft(`🔓 Group opened — everyone can send messages again.`, sock));
      } catch (e) { await reply(`❌ Could not change the group setting (${e.message}).`); }
      break;
    }
    case 'banlist': {
      const bans0 = cfg(sock).groupBans?.[jid] || [];
      if (!bans0.length) { await reply(ft(`🚫 *Ban list* is empty for this group.`, sock)); break; }
      await reply(ft(`🚫 *Ban list* (${bans0.length})\n\n${bans0.map((n, i) => `${i + 1}. +${n}`).join('\n')}`, sock));
      break;
    }
    case 'unbanall': {
      if (!(await requireAdmin())) break;
      const bans1 = cfg(sock).groupBans?.[jid] || [];
      if (!bans1.length) { await reply(ft(`🚫 The ban list is already empty.`, sock)); break; }
      const allBans = { ...(cfg(sock).groupBans || {}) };
      delete allBans[jid];
      setWaSetting(waNumOf(sock), 'groupBans', allBans);
      await reply(ft(`✅ Cleared *${bans1.length}* banned user(s).`, sock));
      break;
    }

    // ── join / leave messages ────────────────────────────────
    case 'setjoinmsg':
    case 'setleavemsg': {
      if (!(await requireAdmin())) break;
      const isJoin = cmd === 'setjoinmsg';
      const keyM   = isJoin ? 'groupJoinMsg' : 'groupLeaveMsg';
      if (!text.trim()) {
        const curM = cfg(sock)[keyM]?.[jid];
        await reply(ft(curM
          ? `${isJoin ? '👋 *Join message*' : '👋 *Leave message*'}\n\n${curM}`
          : `👋 *${prefix}${cmd} <message>*\nPlaceholders: {name}, {group}, {count}`, sock));
        break;
      }
      gPut(keyM, text.trim());
      await reply(ft(`✅ ${isJoin ? 'Join' : 'Leave'} message saved.`, sock));
      break;
    }

    // ── per-group toggle flags ───────────────────────────────
    case 'setnsfw':
    case 'antinsfw':
    case 'antifake':
    case 'autopin':
    case 'autoreact':
    case 'autoreply': {
      if (!(await requireAdmin())) break;
      const LABELS = {
        setnsfw:   ['🔞 NSFW content',           'nsfw'],
        antinsfw:  ['🛡️ Anti-NSFW filter',       'antinsfw'],
        antifake:  ['🎭 Anti-fake accounts',     'antifake'],
        autopin:   ['📌 Auto-pin announcements', 'autopin'],
        autoreact: ['😀 Auto-react to messages', 'autoreact'],
        autoreply: ['💬 Auto-reply',             'autoreply'],
      };
      const [label, flagKey] = LABELS[cmd];
      const next = onOff(flagGet(flagKey));
      flagSet(flagKey, next);
      await reply(ft(`${label}: *${next ? 'ON ✅' : 'OFF ❌'}*`, sock));
      break;
    }
    case 'setautoreply': {
      if (!(await requireAdmin())) break;
      const mapA = cfg(sock).autoReplies || {};
      const curA = { ...(mapA[jid] || {}) };
      if (!text.trim()) {
        const keysA = Object.keys(curA);
        await reply(ft(keysA.length
          ? `💬 *Auto-replies*\n\n${keysA.map(k => `• ${k} → ${curA[k]}`).join('\n')}`
          : `💬 *${prefix}setautoreply <trigger> | <reply>*`, sock));
        break;
      }
      if (!text.includes('|')) { await reply(`💬 *${prefix}setautoreply <trigger> | <reply>*\nExample: *${prefix}setautoreply hi | Hello there!*`); break; }
      const segs = text.split('|');
      const trig = segs[0].trim();
      const resp = segs.slice(1).join('|').trim();
      if (!trig || !resp) { await reply(`❌ Both a trigger and a reply are required.`); break; }
      curA[trig] = resp;
      setWaSetting(waNumOf(sock), 'autoReplies', { ...mapA, [jid]: curA });
      await reply(ft(`✅ Auto-reply saved: *${trig}* → ${resp}`, sock));
      break;
    }
    case 'kickinactive2': {
      if (!(await requireAdmin())) break;
      const days = parseInt(args[0], 10) || 30;
      const act  = cfg(sock).groupActivity?.[jid];
      if (!act || !Object.keys(act).length) {
        await reply(ft(
          `ℹ️ *Inactive sweep unavailable*\n\n` +
          `No member activity has been recorded for this group yet, so the bot cannot tell who is inactive. ` +
          `Nothing was kicked.`,
          sock
        ));
        break;
      }
      try {
        const metaK  = await withTimeout(sock.groupMetadata(jid));
        const cutoff = Date.now() - days * 86400000;
        const idle   = (metaK?.participants || [])
          .filter(p => !p.admin)
          .map(p => ({ id: p.id, num: helpers.normNum(p.id) }))
          .filter(p => p.num !== waNumOf(sock) && (act[p.num] || 0) < cutoff)
          .map(p => p.id);
        if (!idle.length) { await reply(ft(`✅ No members inactive for ${days}+ days.`, sock)); break; }
        await withTimeout(sock.groupParticipantsUpdate(jid, idle, 'remove'));
        await reply(ft(`🧹 Removed *${idle.length}* member(s) inactive for ${days}+ days.`, sock));
      } catch (e) { await reply(`❌ Inactive sweep failed (${e.message}).`); }
      break;
    }
    case 'warnreset': {
      if (!(await requireAdmin())) break;
      const data = readJSON(WARN_FILE, {});
      const qW   = helpers.getQuoted(m) || {};
      const tgt  = String(args[0] || '').replace(/\D/g, '')
        || (qW.qKey?.participant ? helpers.normNum(qW.qKey.participant) : '');
      if (!tgt) {
        const pre  = jid + '|';
        let cleared = 0;
        for (const k of Object.keys(data)) { if (k.startsWith(pre)) { delete data[k]; cleared++; } }
        writeJSON(WARN_FILE, data);
        await reply(ft(cleared
          ? `♻️ Reset warnings for *${cleared}* member(s) in this group.`
          : `ℹ️ No warnings recorded in this group.`, sock));
        break;
      }
      delete data[`${jid}|${tgt}`];
      writeJSON(WARN_FILE, data);
      await reply(ft(`♻️ Warnings reset for @${tgt}.`, sock));
      break;
    }
    case 'reportadmin': {
      if (!text.trim()) { await reply(`📮 *${prefix}reportadmin <message>*`); break; }
      try {
        const metaR = await withTimeout(sock.groupMetadata(jid));
        const admR  = (metaR?.participants || []).filter(p => p.admin).map(p => p.id);
        const ownerR = String(cfg(sock).owner || '').replace(/\D/g, '');
        const targets = admR.length ? admR : (ownerR ? [ownerR + '@s.whatsapp.net'] : []);
        if (!targets.length) { await reply(`❌ No group admin or owner to report to.`); break; }
        gPut('groupReports', [
          ...(cfg(sock).groupReports?.[jid] || []),
          { from: senderNum, text: text.trim(), at: Date.now() },
        ].slice(-50));
        await withTimeout(sock.sendMessage(jid, {
          text: ft(`📮 *Member report*\nFrom: @${senderNum}\n\n${text.trim()}`, sock),
          mentions: targets,
        }));
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'requestrole': {
      const role    = text.trim() || 'member';
      const metaQ   = await withTimeout(sock.groupMetadata(jid)).catch(() => null);
      const admQ    = (metaQ?.participants || []).filter(p => p.admin).map(p => p.id);
      gPut('roleRequests', [
        ...(cfg(sock).roleRequests?.[jid] || []),
        { from: senderNum, role, at: Date.now() },
      ].slice(-50));
      if (!admQ.length) { await reply(ft(`📨 Your request for the role *${role}* was saved, but this group has no admin to notify.`, sock)); break; }
      try {
        await withTimeout(sock.sendMessage(jid, {
          text: ft(`📨 @${senderNum} requests the role *${role}*.`, sock),
          mentions: admQ,
        }));
      } catch (e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'voteban': {
      if (!(await requireAdmin())) break;
      const tgtNum = String(args[0] || '').replace(/\D/g, '');
      const votes  = { ...(cfg(sock).voteBans || {}) };
      const active = votes[jid];
      if (!tgtNum && !active) { await reply(`🗳️ *${prefix}voteban <number>* — start a vote to ban a member`); break; }
      if (active && (!tgtNum || active.target === tgtNum)) {
        if (active.votes.includes(senderNum)) {
          await reply(ft(`🗳️ You already voted. *${active.votes.length}/${active.threshold}*`, sock));
          break;
        }
        active.votes.push(senderNum);
        if (active.votes.length >= active.threshold) {
          try { await withTimeout(sock.groupParticipantsUpdate(jid, [active.target + '@s.whatsapp.net'], 'remove')); } catch { /* reported below */ }
          const allV = { ...(cfg(sock).voteBans || {}) };
          delete allV[jid];
          setWaSetting(waNumOf(sock), 'voteBans', allV);
          const bansV = { ...(cfg(sock).groupBans || {}) };
          bansV[jid] = [...new Set([...(bansV[jid] || []), active.target])];
          setWaSetting(waNumOf(sock), 'groupBans', bansV);
          await reply(ft(`✅ Vote passed (*${active.votes.length}/${active.threshold}*) — +${active.target} removed and added to the ban list.`, sock));
        } else {
          setWaSetting(waNumOf(sock), 'voteBans', { ...votes, [jid]: active });
          await reply(ft(`🗳️ Vote to ban +${active.target}: *${active.votes.length}/${active.threshold}*`, sock));
        }
        break;
      }
      const metaV = await withTimeout(sock.groupMetadata(jid)).catch(() => null);
      const totalV = (metaV?.participants || []).length || 3;
      const threshold = Math.max(2, Math.ceil(totalV / 2));
      setWaSetting(waNumOf(sock), 'voteBans', { ...votes, [jid]: { target: tgtNum, votes: [senderNum], threshold, startedBy: senderNum, startedAt: Date.now() } });
      await reply(ft(`🗳️ Vote started to ban +${tgtNum} (*1/${threshold}*)`, sock));
      break;
    }
    case 'addbot':
    case 'removebot': {
      if (!(await requireAdmin())) break;
      const numB = String(args[0] || '').replace(/\D/g, '');
      if (!numB) { await reply(`🤖 *${prefix}${cmd} <number>*`); break; }
      const listB = (cfg(sock).botList || []).map(String);
      if (cmd === 'addbot') {
        setWaSetting(waNumOf(sock), 'botList', [...new Set([...listB, numB])]);
        try {
          await withTimeout(sock.groupParticipantsUpdate(jid, [numB + '@s.whatsapp.net'], 'add'));
          await reply(ft(`🤖 +${numB} saved as a bot and added to this group.`, sock));
        } catch (e) { await reply(ft(`🤖 +${numB} saved as a bot (group add failed: ${e.message}).`, sock)); }
      } else {
        setWaSetting(waNumOf(sock), 'botList', listB.filter(n => n !== numB));
        try {
          await withTimeout(sock.groupParticipantsUpdate(jid, [numB + '@s.whatsapp.net'], 'remove'));
          await reply(ft(`🤖 +${numB} removed from the bot list and from this group.`, sock));
        } catch (e) { await reply(ft(`🤖 +${numB} removed from the bot list (group remove failed: ${e.message}).`, sock)); }
      }
      break;
    }
    case 'listbots': {
      const bots = cfg(sock).botList || [];
      await reply(ft(bots.length
        ? `🤖 *Bot list* (${bots.length})\n\n${bots.map((n, i) => `${i + 1}. +${n}`).join('\n')}`
        : `🤖 No bots registered yet. Use *${prefix}addbot <number>*.`, sock));
      break;
    }
    default:
      await reply(ft(`🔧 *${prefix}${cmd}* — Admin command. Coming soon!`, sock));
      return true;
  }
  return true;
}

module.exports = { adminHandler, ADMIN_CMDS };
