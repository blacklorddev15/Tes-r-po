// arabic.js – Arabic Language Commands
'use strict';
const axios = require('axios');

function escXml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&apos;');
}

// Commonly cited meanings for the most frequent Arabic given names.
const ARABIC_NAMES = {
  mohamed:   { ar: 'مُحَمَّد',   meaning: 'Praiseworthy — the most common given name in the Muslim world' },
  muhammad:  { ar: 'مُحَمَّد',   meaning: 'Praiseworthy' },
  mohammed:  { ar: 'مُحَمَّد',   meaning: 'Praiseworthy' },
  mohammad:  { ar: 'مُحَمَّد',   meaning: 'Praiseworthy' },
  ahmed:     { ar: 'أَحْمَد',    meaning: 'Most commendable, most praiseworthy' },
  ahmad:     { ar: 'أَحْمَد',    meaning: 'Most commendable, most praiseworthy' },
  ali:       { ar: 'عَلِيّ',      meaning: 'Exalted, high, noble' },
  omar:      { ar: 'عُمَر',      meaning: 'Flourishing, long-lived' },
  umar:      { ar: 'عُمَر',      meaning: 'Flourishing, long-lived' },
  abubakar:  { ar: 'أَبُو بَكْر', meaning: 'Father of Bakr (a young camel)' },
  hassan:    { ar: 'حَسَن',      meaning: 'Handsome, good, virtuous' },
  hussein:   { ar: 'حُسَيْن',    meaning: 'Diminutive of Hasan — good, handsome' },
  husain:    { ar: 'حُسَيْن',    meaning: 'Diminutive of Hasan — good, handsome' },
  khaled:    { ar: 'خَالِد',     meaning: 'Eternal, immortal' },
  khalid:    { ar: 'خَالِد',     meaning: 'Eternal, immortal' },
  yusuf:     { ar: 'يُوسُف',     meaning: 'Arabic form of Joseph — "God increases"' },
  youssef:   { ar: 'يُوسُف',     meaning: 'Arabic form of Joseph — "God increases"' },
  ibrahim:   { ar: 'إِبْرَاهِيم', meaning: 'Arabic form of Abraham — "father of many"' },
  ismail:    { ar: 'إِسْمَاعِيل', meaning: 'Arabic form of Ishmael — "God hears"' },
  musa:      { ar: 'مُوسَى',     meaning: 'Arabic form of Moses — "drawn out of the water"' },
  isa:       { ar: 'عِيسَى',     meaning: 'Arabic form of Jesus' },
  abdullah:  { ar: 'عَبْد الله',  meaning: 'Servant of God' },
  abdulrahman:{ ar: 'عَبْد الرَّحْمٰن', meaning: 'Servant of the Most Merciful' },
  karim:     { ar: 'كَرِيم',     meaning: 'Generous, noble, honourable' },
  kareem:    { ar: 'كَرِيم',     meaning: 'Generous, noble, honourable' },
  tariq:     { ar: 'طَارِق',     meaning: 'Knocker at the door; the morning star' },
  zaid:      { ar: 'زَيْد',      meaning: 'Increase, growth, abundance' },
  saeed:     { ar: 'سَعِيد',     meaning: 'Happy, fortunate' },
  amir:      { ar: 'أَمِير',     meaning: 'Prince, commander, leader' },
  hamza:     { ar: 'حَمْزَة',    meaning: 'Lion; steadfast' },
  bilal:     { ar: 'بِلَال',     meaning: 'Moisture, refreshment' },
  mustafa:   { ar: 'مُصْطَفَى',  meaning: 'The chosen one' },
  mahmoud:   { ar: 'مَحْمُود',   meaning: 'Praised, commendable' },
  rashid:    { ar: 'رَاشِد',     meaning: 'Rightly guided, sensible' },
  sami:      { ar: 'سَامِي',     meaning: 'Elevated, sublime' },
  fatima:    { ar: 'فَاطِمَة',   meaning: 'She who abstains (from wrongdoing)' },
  aisha:     { ar: 'عَائِشَة',   meaning: 'Living, alive, prosperous' },
  ayesha:    { ar: 'عَائِشَة',   meaning: 'Living, alive, prosperous' },
  maryam:    { ar: 'مَرْيَم',    meaning: 'Arabic form of Mary' },
  mariam:    { ar: 'مَرْيَم',    meaning: 'Arabic form of Mary' },
  zainab:    { ar: 'زَيْنَب',    meaning: 'Fragrant flower; adorned tree' },
  huda:      { ar: 'هُدَى',      meaning: 'Guidance' },
  amina:     { ar: 'آمِنَة',     meaning: 'Trustworthy, faithful, safe' },
  aminah:    { ar: 'آمِنَة',     meaning: 'Trustworthy, faithful, safe' },
  layla:     { ar: 'لَيْلَى',    meaning: 'Night' },
  laila:     { ar: 'لَيْلَى',    meaning: 'Night' },
  salma:     { ar: 'سَلْمَى',    meaning: 'Safe, peaceful' },
  noor:      { ar: 'نُور',      meaning: 'Light' },
  nur:       { ar: 'نُور',      meaning: 'Light' },
  sara:      { ar: 'سَارَة',     meaning: 'Princess' },
  yasmin:    { ar: 'يَاسْمِين',  meaning: 'Jasmine (flower)' },
  nadia:     { ar: 'نَادِيَة',   meaning: 'Caller; generous' },
  rania:     { ar: 'رَانِيَة',   meaning: 'Gazing, looking attentively' },
  halima:    { ar: 'حَلِيمَة',   meaning: 'Gentle, patient, forbearing' },
  jamila:    { ar: 'جَمِيلَة',   meaning: 'Beautiful, graceful' },
  lina:      { ar: 'لِينَا',     meaning: 'Tender, soft, delicate' },
  zahra:     { ar: 'زَهْرَة',    meaning: 'Flower, blossom' },
};
const ARABIC_CMDS = ['arabicquote','arabicname','tafsir','hadith','dua','quran','prayer','qibla','hijri','islamicfact','asmaullah','nasheeds','arabicpoem','arabicproverb','arabicsticker'];

async function arabicHandler(sock, m, cmd, args, helpers) {
  if (!ARABIC_CMDS.includes(cmd)) return false;
  const { reply, ft, cfg, reaction } = helpers;
  const jid    = m.key.remoteJid;
  const prefix = cfg(sock).prefix || '.';
  const text   = args.join(' ');

  switch (cmd) {
    case 'quran': {
      const ref = text || '1:1';
      const [surah, ayah] = ref.split(':').map(Number);
      if (!surah) { await reply(`📖 *${prefix}quran <surah>:<ayah>*\nExample: ${prefix}quran 1:1`); break; }
      await reaction('📖');
      try {
        const { data } = await axios.get(`https://api.alquran.cloud/v1/ayah/${surah}:${ayah||1}/ar.alafasy`, { timeout:10000 });
        const { data: eng } = await axios.get(`https://api.alquran.cloud/v1/ayah/${surah}:${ayah||1}/en.asad`, { timeout:10000 });
        await reply(ft(
          `📖 *Quran ${surah}:${ayah||1}*\n\n` +
          `${data.data?.text}\n\n` +
          `_"${eng.data?.text}"_\n\n` +
          `📚 Surah: ${data.data?.surah?.englishName}`,
          sock
        ));
      } catch(e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'hadith': {
      await reaction('📜');
      try {
        const { data } = await axios.get('https://random-hadith-generator.vercel.app/bukhari/', { timeout:10000 });
        const h = data?.data;
        await reply(ft(`📜 *Hadith*\n\n_"${h?.hadith_english||'N/A'}"_\n\n📚 ${h?.refno||''}`, sock));
      } catch { await reply(ft('📜 *Hadith*\n\n_"The best of people are those who are most beneficial to people."_\n\n📚 Bukhari', sock)); }
      break;
    }
    case 'prayer': {
      if (!text) { await reply(`🕌 *${prefix}prayer <city>*\nExample: ${prefix}prayer Nairobi`); break; }
      await reaction('🕌');
      try {
        const { data } = await axios.get(`https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(text)}&country=&method=2`, { timeout:10000 });
        const t = data?.data?.timings;
        await reply(ft(
          `🕌 *Prayer Times: ${text}*\n\n` +
          `🌅 Fajr: ${t?.Fajr}\n` +
          `☀️ Dhuhr: ${t?.Dhuhr}\n` +
          `🌤️ Asr: ${t?.Asr}\n` +
          `🌆 Maghrib: ${t?.Maghrib}\n` +
          `🌙 Isha: ${t?.Isha}`,
          sock
        ));
      } catch(e) { await reply(`❌ ${e.message}`); }
      break;
    }
    case 'dua': {
      await reaction('🤲');
      const duas = ['رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ\n\n_"Our Lord, give us good in this world and good in the Hereafter, and protect us from the punishment of the Fire"_','اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا\n\n_"O Allah, I ask You for beneficial knowledge"_','رَبِّ اشْرَحْ لِي صَدْرِي\n\n_"My Lord, expand for me my chest [with assurance]"_ (20:25)'];
      await reply(ft(`🤲 *Daily Dua*\n\n${duas[Math.floor(Math.random()*duas.length)]}`, sock));
      break;
    }
    case 'islamicfact': {
      const facts2 = ['Islam is the fastest growing religion in the world.','The Quran has 114 surahs (chapters).','Masjid al-Haram in Mecca is the largest mosque in the world.','Friday (Jumu\'ah) is considered the holiest day of the week in Islam.','The word "Islam" means peace and submission.','Zamzam water has been flowing for thousands of years.'];
      await reply(ft(`🌙 *Islamic Fact*\n\n${facts2[Math.floor(Math.random()*facts2.length)]}`, sock));
      break;
    }
    case 'hijri': {
      const today = new Date();
      try {
        const { data } = await axios.get(`https://api.aladhan.com/v1/gToH/${today.getDate()}-${today.getMonth()+1}-${today.getFullYear()}`, { timeout:8000 });
        const h2 = data?.data?.hijri;
        await reply(ft(`📅 *Hijri Date*\n\n${h2?.day} ${h2?.month?.en} ${h2?.year} AH\n\n_${h2?.day} ${h2?.month?.ar} ${h2?.year} هـ_`, sock));
      } catch { await reply(`❌ Failed to get Hijri date`); }
      break;
    }
    case 'arabicquote': {
      const quotes2 = ['الصبر مفتاح الفرج\n_Patience is the key to relief_','من جد وجد\n_Whoever works hard will find_','العلم نور\n_Knowledge is light_','لا يأس مع الحياة\n_There is no despair while there is life_'];
      await reply(ft(`💎 *Arabic Quote*\n\n${quotes2[Math.floor(Math.random()*quotes2.length)]}`, sock));
      break;
    }
    case 'arabicproverb': {
      const proverbs = ['"اضرب حديدا وهو ساخن" – Strike while the iron is hot','درهم وقاية خير من قنطار علاج – Prevention is better than cure','الجار قبل الدار – Choose your neighbor before your house','العين بصيرة والأيدي قصيرة – Eyes see far but hands reach little'];
      await reply(ft(`🌹 *Arabic Proverb*\n\n${proverbs[Math.floor(Math.random()*proverbs.length)]}`, sock));
      break;
    }
    case 'arabicname': {
      if (!text) { await reply(ft(`🔤 *${prefix}arabicname <name>*\nExample: ${prefix}arabicname mohamed`, sock)); break; }
      await reaction('🔤');
      const nameKey  = text.trim().toLowerCase().split(/\s+/)[0].replace(/[^a-z']/g, '');
      const nameHit  = ARABIC_NAMES[nameKey];
      if (nameHit) {
        await reply(ft(`🔤 *${text.trim()}*\n\n${nameHit.ar}\n\n📖 Meaning: ${nameHit.meaning}\n\n_Most commonly cited meaning._`, sock));
        break;
      }
      let nameInfo = null;
      try {
        const { data } = await axios.get(
          `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(text.trim())}`,
          { timeout: 10000 }
        );
        nameInfo = data?.extract || null;
      } catch { /* handled below */ }
      if (nameInfo) {
        await reply(ft(`🔤 *${text.trim()}*\n\nNo Arabic spelling is stored locally for this name, so here is what Wikipedia says:\n\n${String(nameInfo).slice(0, 700)}`, sock));
      } else {
        await reply(ft(`🔤 *${text.trim()}* is not in the built-in list of Arabic names, and en.wikipedia.org could not be reached right now. No free, no-key Arabic-name API is configured, so no spelling is guessed.`, sock));
      }
      break;
    }

    case 'tafsir': {
      const nums = (text.match(/\d+/g) || []).map(Number);
      const surah = nums[0];
      const ayah  = nums[1] || 1;
      if (!surah) { await reply(ft(`📚 *${prefix}tafsir <surah>:<ayah>*\nExample: ${prefix}tafsir 1:1`, sock)); break; }
      await reaction('📚');
      let tafsirText = null, tafsirSource = '';
      try {
        const { data } = await axios.get(`https://api.alquran.cloud/v1/ayah/${surah}:${ayah}/ar.muyassar`, { timeout: 10000 });
        tafsirText   = data?.data?.text || null;
        tafsirSource = data?.data?.edition?.englishName || data?.data?.edition?.identifier || 'ar.muyassar';
      } catch { /* translation fallback below */ }
      if (!tafsirText) {
        try {
          const { data } = await axios.get(`https://api.alquran.cloud/v1/ayah/${surah}:${ayah}/en.asad`, { timeout: 10000 });
          tafsirText   = data?.data?.text || null;
          tafsirSource = 'en.asad (translation — tafsir edition unavailable)';
        } catch { /* handled below */ }
      }
      if (tafsirText) await reply(ft(`📚 *Tafsir ${surah}:${ayah}*\n\n${tafsirText}\n\n📖 Source: ${tafsirSource}`, sock));
      else await reply(ft(`❌ Could not fetch tafsir for ${surah}:${ayah} from api.alquran.cloud right now. Please try again or pick another ayah.`, sock));
      break;
    }

    case 'qibla': {
      if (!text) {
        await reply(ft(`🧭 *${prefix}qibla <city>* or *${prefix}qibla <lat> <lng>*\nExample: ${prefix}qibla Nairobi — or — ${prefix}qibla -1.29 36.82`, sock));
        break;
      }
      await reaction('🧭');
      const numsQ = (text.match(/-?\d+(\.\d+)?/g) || []).map(Number);
      let lat = null, lng = null, where = '';
      if (numsQ.length >= 2) {
        lat = numsQ[0]; lng = numsQ[1];
        where = `${lat}, ${lng}`;
      } else {
        try {
          const { data } = await axios.get(
            `https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(text)}&country=&method=2`,
            { timeout: 10000 }
          );
          const meta = data?.data?.meta;
          if (meta && typeof meta.latitude === 'number' && typeof meta.longitude === 'number') {
            lat = meta.latitude; lng = meta.longitude;
            where = `${text} (${lat}, ${lng})`;
          }
        } catch { /* handled below */ }
      }
      if (lat === null || lng === null) {
        await reply(ft(`🧭 The free aladhan.com geocoder did not return coordinates for *${text}*, so the Qibla direction could not be computed. Try *${prefix}qibla <lat> <lng>* with explicit coordinates.`, sock));
        break;
      }
      try {
        const { data: q } = await axios.get(`https://api.aladhan.com/v1/qibla/${lat}/${lng}`, { timeout: 10000 });
        const dir = q?.data?.direction;
        if (typeof dir !== 'number') throw new Error('no direction in the API response');
        await reply(ft(`🧭 *Qibla direction*\n\n📍 Location: ${where}\n🕋 Bearing: ${dir.toFixed(2)}° from true north\n\n_Facing this bearing points towards the Kaaba in Makkah._`, sock));
      } catch (e) { await reply(`❌ Qibla lookup failed: ${e.message}`); }
      break;
    }

    case 'asmaullah': {
      await reaction('☪️');
      let husna = null;
      try {
        const { data } = await axios.get('https://api.aladhan.com/v1/asmaAlHusna', { timeout: 10000 });
        const list = Array.isArray(data?.data) ? data.data : (Array.isArray(data) ? data : null);
        if (list && list.length) husna = list;
      } catch { /* handled below */ }
      if (!husna) {
        await reply(ft(`❌ Could not load the 99 Names of Allah from *api.aladhan.com/v1/asmaAlHusna* right now. No other free, no-key source is configured — nothing is shown rather than guessed.`, sock));
        break;
      }
      const pick = husna[Math.floor(Math.random() * husna.length)] || {};
      const nm   = pick.name || pick.arabic || '';
      const tr   = pick.transliteration || pick.latin || '';
      const mn   = pick.en?.meaning || pick.meaning || '';
      await reply(ft(`☪️ *Asma ul Husna* (${husna.length} names)\n\n${nm}\n_${tr}_\n\n${mn}`, sock));
      break;
    }

    case 'nasheeds': {
      await reaction('🎧');
      await reply(ft(`🎧 *Nasheeds*\n\nAudio playback is unavailable: there is no free, no-key nasheed streaming endpoint configured on this bot, and licensed audio APIs need paid keys. Nothing is downloaded rather than sending a broken link.\n\n_Widely known nasheed titles you can search elsewhere:_\n• طلع البدر علينا\n• يا رب صلِّ على محمد\n• أشرقت الشمس`, sock));
      break;
    }

    case 'arabicpoem': {
      await reaction('📜');
      const poets = [
        { title: 'المتنبي',        desc: 'Al-Mutanabbi — classical Abbasid poet' },
        { title: 'نزار قباني',      desc: 'Nizar Qabbani — modern Arabic poet' },
        { title: 'أحمد شوقي',       desc: 'Ahmed Shawqi — "Prince of Poets"' },
        { title: 'محمود درويش',     desc: 'Mahmoud Darwish — Palestinian poet' },
        { title: 'أبو نواس',        desc: 'Abu Nuwas — Abbasid poet' },
        { title: 'امرؤ القيس',      desc: "Imru' al-Qays — pre-Islamic poet" },
      ];
      const poet = poets[Math.floor(Math.random() * poets.length)];
      let poemInfo = null;
      try {
        const { data } = await axios.get(
          `https://ar.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(poet.title)}`,
          { timeout: 10000 }
        );
        poemInfo = data?.extract || null;
      } catch { /* handled below */ }
      if (poemInfo) await reply(ft(`📜 *${poet.desc}*\n\n${String(poemInfo).slice(0, 900)}`, sock));
      else await reply(ft(`📜 *${poet.desc}*\n\nArabic Wikipedia could not be reached right now and no free, no-key Arabic poetry API is configured — no verses are shown rather than invented.`, sock));
      break;
    }

    case 'arabicsticker': {
      const arabicText = text.trim();
      if (!arabicText) { await reply(ft(`🩹 *${prefix}arabicsticker <نص عربي>*\nExample: ${prefix}arabicsticker السلام عليكم`, sock)); break; }
      await reaction('🩹');
      try {
        let sent = false;
        try {
          const { data } = await axios.get(
            `https://api.siputzx.my.id/api/sticker/attp?text=${encodeURIComponent(arabicText.slice(0, 60))}`,
            { responseType: 'arraybuffer', timeout: 20000 }
          );
          const bufA = Buffer.from(data || []);
          if (bufA.length) { await sock.sendMessage(jid, { sticker: bufA }, { quoted: m }); sent = true; }
        } catch { /* local rendering below */ }
        if (!sent) {
          const sharp = require('sharp');
          const svg = Buffer.from(
            `<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512">` +
            `<rect width="512" height="512" fill="#0b1020"/>` +
            `<text x="256" y="300" font-size="60" font-family="DejaVu Sans, Noto Naskh Arabic, sans-serif" fill="#ffffff" text-anchor="middle">${escXml(arabicText.slice(0, 40))}</text>` +
            `</svg>`
          );
          const sticker = await sharp(svg)
            .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
            .webp({ quality: 90 })
            .toBuffer();
          await sock.sendMessage(jid, { sticker }, { quoted: m });
        }
      } catch (e) { await reply(`❌ arabicsticker failed: ${e.message}`); }
      break;
    }

    default: await reply(ft(`🌙 *${prefix}${cmd}* — Coming soon!`, sock)); return true;
  }
  return true;
}

module.exports = { arabicHandler, ARABIC_CMDS };
