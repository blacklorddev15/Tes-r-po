// ============================================================
//   economy.js  –  Economy/Game Commands (30+)
// ============================================================
'use strict';
const fs   = require('fs');
const path = require('path');
const axios = require('axios');

const DB_FILE = path.resolve(__dirname, 'database/economy.json');
function loadEcon() { try { return JSON.parse(fs.readFileSync(DB_FILE,'utf8')); } catch { return {}; } }
function saveEcon(d) { fs.writeFileSync(DB_FILE, JSON.stringify(d,null,2)); }
function getUser(data, id) {
  if (!data[id]) data[id] = { wallet:0, bank:0, lastDaily:0, lastWork:0, lastRob:0, inventory:[], level:1, xp:0 };
  return data[id];
}

// Shop catalogue, crops and crafting recipes used by buy/plant/harvest/craft.
const SHOP_ITEMS = [
  { id:'pickaxe', name:'⛏️ Pickaxe',     price:500,  desc:'Boosts mining luck' },
  { id:'rod',     name:'🎣 Fishing Rod', price:400,  desc:'Better catches when fishing' },
  { id:'bow',     name:'🏹 Hunting Bow', price:600,  desc:'Better hunts' },
  { id:'shield',  name:'🛡️ Shield',      price:1200, desc:'Protects your wallet from robbers' },
  { id:'lucky',   name:'🍀 Lucky Charm', price:2000, desc:'Better luck everywhere' },
  { id:'vip',     name:'💎 VIP Badge',   price:5000, desc:'Pure status symbol' },
];
const CROPS = {
  wheat:   { emoji:'🌾', cost:50,   value:120,  mins:3  },
  carrot:  { emoji:'🥕', cost:100,  value:260,  mins:6  },
  tomato:  { emoji:'🍅', cost:200,  value:550,  mins:12 },
  corn:    { emoji:'🌽', cost:400,  value:1100, mins:20 },
  pumpkin: { emoji:'🎃', cost:800,  value:2400, mins:35 },
};
const CRAFT_RECIPES = [
  { key:'blade', out:'🗡️ Iron Blade',    need:['⛏️ Iron','⛏️ Iron','🪨 Stone'],           reward:600  },
  { key:'ring',  out:'💍 Diamond Ring',  need:['💎 Diamond','⛏️ Iron'],                  reward:2500 },
  { key:'sushi', out:'🍣 Sushi Platter', need:['🐟 Small Fish','🐠 Tropical Fish'],      reward:400  },
];

const ECON_CMDS = [
  'balance','bal','daily','work','deposit','withdraw','transfer','rob',
  'shop','buy','inventory','sell','slots','flip','blackjack',
  'leaderboard','richlist','give','beg','crime','lottery',
  'mine','fish','hunt','plant','harvest','craft','levelup','profile',
  'bankrob','heist',
];
async function economyHandler(sock, m, cmd, args, helpers) {
  if (!ECON_CMDS.includes(cmd)) return false;
  const { reply, ft, cfg } = helpers;
  const jid    = m.key.remoteJid;
  const prefix = cfg(sock).prefix || '.';
  const sender = m.key.fromMe
    ? (sock.__waNum || '')
    : (m.key.participant || m.key.remoteJid).split('@')[0];
  const text   = args.join(' ');
  const data   = loadEcon();
  const user   = getUser(data, sender);

  const CURRENCY = '💰';
  const fmt = n => n.toLocaleString();

  switch(cmd) {
    case 'balance':
    case 'bal': {
      await reply(ft(
        `${CURRENCY} *Balance*\n\n` +
        `👛 Wallet: ${fmt(user.wallet)} coins\n` +
        `🏦 Bank: ${fmt(user.bank)} coins\n` +
        `📊 Total: ${fmt(user.wallet+user.bank)} coins\n` +
        `⭐ Level: ${user.level} (${user.xp} XP)`,
        sock
      ));
      break;
    }

    case 'daily': {
      const now     = Date.now();
      const cd      = 24*60*60*1000;
      const elapsed = now - (user.lastDaily||0);
      if (elapsed < cd) {
        const left = new Date(cd-elapsed).toISOString().slice(11,19);
        await reply(ft(`⏰ Daily cooldown: *${left}* remaining`, sock)); break;
      }
      const streak = Math.min((user.streak||0)+1, 30);
      const amount = 200 + (streak-1)*50;
      user.wallet    += amount;
      user.lastDaily  = now;
      user.streak     = streak;
      saveEcon(data);
      await reply(ft(`✅ *Daily Reward!*\n\n+${fmt(amount)} coins ${streak>1?`(🔥 ${streak} day streak!)`:''}`, sock));
      break;
    }

    case 'work': {
      const cd2 = 30*60*1000;
      if (Date.now()-(user.lastWork||0) < cd2) {
        const left2 = Math.ceil((cd2-(Date.now()-user.lastWork))/60000);
        await reply(ft(`⏰ Work cooldown: *${left2} min* remaining`, sock)); break;
      }
      const jobs    = [['Programmer','wrote code',300,600],['Driver','delivered packages',150,350],['Chef','cooked meals',200,500],['Streamer','streamed games',100,800],['Miner','mined crypto',250,450]];
      const job     = jobs[Math.floor(Math.random()*jobs.length)];
      const earned  = Math.floor(Math.random()*(job[3]-job[2]))+job[2];
      user.wallet    += earned;
      user.lastWork   = Date.now();
      user.xp        += 10;
      if (user.xp >= user.level*100) { user.level++; user.xp=0; }
      saveEcon(data);
      await reply(ft(`💼 *Work Done!*\nYou ${job[1]} as a ${job[0]}.\n+${fmt(earned)} coins earned!`, sock));
      break;
    }

    case 'deposit': {
      const amt = parseInt(args[0]);
      if (!amt || amt<=0) { await reply(`${CURRENCY} *${prefix}deposit <amount>*`); break; }
      if (amt>user.wallet) { await reply(`❌ Not enough in wallet (${fmt(user.wallet)} coins)`); break; }
      user.wallet -= amt; user.bank += amt; saveEcon(data);
      await reply(ft(`🏦 Deposited ${fmt(amt)} coins → Bank`, sock));
      break;
    }

    case 'withdraw': {
      const amt2 = parseInt(args[0]);
      if (!amt2||amt2<=0) { await reply(`${CURRENCY} *${prefix}withdraw <amount>*`); break; }
      if (amt2>user.bank) { await reply(`❌ Not enough in bank (${fmt(user.bank)} coins)`); break; }
      user.bank -= amt2; user.wallet += amt2; saveEcon(data);
      await reply(ft(`👛 Withdrew ${fmt(amt2)} coins → Wallet`, sock));
      break;
    }

    case 'rob': {
      const target = args[0]?.replace(/\D/g,'');
      if (!target) { await reply(`${CURRENCY} *${prefix}rob <number>*`); break; }
      const cd3 = 60*60*1000;
      if (Date.now()-(user.lastRob||0) < cd3) {
        const left3 = Math.ceil((cd3-(Date.now()-user.lastRob))/60000);
        await reply(ft(`⏰ Rob cooldown: *${left3} min*`, sock)); break;
      }
      const victim = getUser(data, target);
      if (victim.wallet < 100) { await reply('❌ Target is too broke to rob!'); break; }
      const success = Math.random() > 0.4;
      if (success) {
        const stolen = Math.floor(victim.wallet * (Math.random()*0.3+0.1));
        victim.wallet -= stolen; user.wallet += stolen;
      } else {
        const fine = Math.min(user.wallet, Math.floor(Math.random()*200+100));
        user.wallet -= fine; victim.wallet += fine;
      }
      user.lastRob = Date.now(); saveEcon(data);
      await reply(ft(success ? `🦹 Rob successful! You stole coins from ${target}!` : `👮 Rob failed! You paid a fine!`, sock));
      break;
    }

    case 'slots': {
      const bet = parseInt(args[0])||50;
      if (bet > user.wallet) { await reply(`❌ Not enough coins (wallet: ${fmt(user.wallet)})`); break; }
      const emojis = ['🍒','🍋','🍇','💎','7️⃣','⭐','🎰'];
      const reels  = [0,1,2].map(()=>emojis[Math.floor(Math.random()*emojis.length)]);
      let mult = 0;
      if (reels[0]===reels[1]&&reels[1]===reels[2]) {
        mult = reels[0]==='7️⃣' ? 10 : reels[0]==='💎' ? 7 : 4;
      } else if (reels[0]===reels[1]||reels[1]===reels[2]||reels[0]===reels[2]) {
        mult = 1.5;
      }
      user.wallet -= bet;
      const win = Math.floor(bet*mult);
      if (win) user.wallet += win;
      saveEcon(data);
      await reply(ft(
        `🎰 *SLOTS*\n\n[ ${reels.join(' | ')} ]\n\n` +
        (mult>0 ? `🎉 WIN! +${fmt(win)} coins (${mult}x)` : `❌ Lost ${fmt(bet)} coins`),
        sock
      ));
      break;
    }

    case 'flip': {
      const bet2 = parseInt(args[0])||50;
      const side = (args[1]||'heads').toLowerCase();
      if (!['heads','tails'].includes(side)) { await reply(`${CURRENCY} *${prefix}flip <amount> heads/tails*`); break; }
      if (bet2>user.wallet) { await reply(`❌ Not enough coins`); break; }
      const result2 = Math.random()>0.5?'heads':'tails';
      user.wallet -= bet2;
      if (result2===side) user.wallet += bet2*2;
      saveEcon(data);
      await reply(ft(`🪙 Coin: *${result2}*\n\n${result2===side?`✅ +${fmt(bet2)} coins!`:`❌ -${fmt(bet2)} coins!`}`, sock));
      break;
    }

    case 'leaderboard':
    case 'richlist': {
      const sorted = Object.entries(data)
        .map(([id,u])=>({id,total:(u.wallet||0)+(u.bank||0)}))
        .sort((a,b)=>b.total-a.total).slice(0,10);
      const list   = sorted.map((u,i)=>`${i+1}. +${u.id}: ${fmt(u.total)} coins`).join('\n');
      await reply(ft(`🏆 *Richlist*\n\n${list||'No data yet'}`, sock));
      break;
    }

    case 'give': {
      const target2 = args[0]?.replace(/\D/g,'');
      const amt3    = parseInt(args[1]);
      if (!target2||!amt3) { await reply(`${CURRENCY} *${prefix}give <number> <amount>*`); break; }
      if (amt3>user.wallet) { await reply(`❌ Not enough coins`); break; }
      const recv = getUser(data, target2);
      user.wallet -= amt3; recv.wallet += amt3; saveEcon(data);
      await reply(ft(`💸 Sent ${fmt(amt3)} coins to +${target2}!`, sock));
      break;
    }

    case 'beg': {
      const amounts = [0,0,0,10,25,50,100,200,500];
      const got     = amounts[Math.floor(Math.random()*amounts.length)];
      user.wallet  += got; saveEcon(data);
      const msgs    = ['Nobody gave you anything 😔','A stranger threw you some coins 🪙','Someone felt sorry for you 😅','Lucky day! You found coins on the ground 💰'];
      await reply(ft(`🙏 ${msgs[Math.floor(Math.random()*msgs.length)]}${got>0?`\n+${got} coins`:''}`, sock));
      break;
    }

    case 'crime': {
      const cd4  = 45*60*1000;
      if (Date.now()-(user.lastCrime||0) < cd4) {
        const left4 = Math.ceil((cd4-(Date.now()-user.lastCrime||0))/60000);
        await reply(ft(`⏰ Crime cooldown: *${left4} min*`, sock)); break;
      }
      const crimes2 = ['robbed a store','pickpocketed a tourist','hacked an ATM','sold counterfeit goods','ran a scam'];
      const success2 = Math.random() > 0.35;
      if (success2) {
        const earn = Math.floor(Math.random()*600+200);
        user.wallet += earn;
      } else {
        const fine2 = Math.floor(Math.random()*300+100);
        user.wallet = Math.max(0, user.wallet-fine2);
      }
      user.lastCrime = Date.now(); saveEcon(data);
      await reply(ft(success2?`🦹 Crime success! You ${crimes2[Math.floor(Math.random()*crimes2.length)]}!`:`👮 Caught! You paid a fine!`, sock));
      break;
    }

    case 'profile': {
      await reply(ft(
        `👤 *Profile: +${sender}*\n\n` +
        `💰 Wallet: ${fmt(user.wallet)}\n` +
        `🏦 Bank: ${fmt(user.bank)}\n` +
        `⭐ Level: ${user.level}\n` +
        `📊 XP: ${user.xp}/${user.level*100}\n` +
        `🔥 Streak: ${user.streak||0} days\n` +
        `🎒 Items: ${(user.inventory||[]).length}`,
        sock
      ));
      break;
    }

    case 'mine':
    case 'fish':
    case 'hunt': {
      const cd5 = 20*60*1000;
      const key  = `last${cmd.charAt(0).toUpperCase()+cmd.slice(1)}`;
      if (Date.now()-(user[key]||0) < cd5) {
        const left5 = Math.ceil((cd5-(Date.now()-user[key]||0))/60000);
        await reply(ft(`⏰ ${cmd} cooldown: *${left5} min*`, sock)); break;
      }
      const loot = { mine:['🪨 Stone','⛏️ Iron','💎 Diamond'], fish:['🐟 Small Fish','🐠 Tropical Fish','🐡 Pufferfish'], hunt:['🐰 Rabbit','🦌 Deer','🐗 Boar'] };
      const item = loot[cmd][Math.floor(Math.random()*3)];
      const val  = { '🪨 Stone':10,'⛏️ Iron':50,'💎 Diamond':500,'🐟 Small Fish':30,'🐠 Tropical Fish':80,'🐡 Pufferfish':200,'🐰 Rabbit':40,'🦌 Deer':150,'🐗 Boar':300 };
      user[key] = Date.now();
      if (!user.inventory) user.inventory = [];
      user.inventory.push(item); saveEcon(data);
      await reply(ft(`${cmd==='mine'?'⛏️':cmd==='fish'?'🎣':'🏹'} You got: *${item}* (worth ~${val[item]||50} coins)\nSell with *${prefix}sell ${item}*`, sock));
      break;
    }

    case 'inventory': {
      if (!user.inventory?.length) { await reply(`🎒 Inventory empty. Try *${prefix}mine*, *${prefix}fish*, or *${prefix}hunt*`); break; }
      const counts = {};
      user.inventory.forEach(i => { counts[i] = (counts[i]||0)+1; });
      await reply(ft(`🎒 *Inventory*\n\n${Object.entries(counts).map(([k,v])=>`${k} x${v}`).join('\n')}`, sock));
      break;
    }

    case 'sell': {
      const item2 = args.join(' ');
      if (!item2) { await reply(`💰 *${prefix}sell <item name>*\nSell items from your inventory.`); break; }
      const idx2 = user.inventory?.findIndex(i => i.toLowerCase().includes(item2.toLowerCase()));
      if (idx2 === -1 || idx2 === undefined) { await reply(`❌ Item not found in inventory.`); break; }
      const prices = { Stone:10,Iron:50,Diamond:500,'Small Fish':30,'Tropical Fish':80,'Pufferfish':200,Rabbit:40,Deer:150,Boar:300 };
      const name3  = user.inventory[idx2];
      const price  = Object.entries(prices).find(([k])=>name3.includes(k))?.[1] || 20;
      user.inventory.splice(idx2,1);
      user.wallet += price; saveEcon(data);
      await reply(ft(`💰 Sold *${name3}* for ${fmt(price)} coins!`, sock));
      break;
    }

    case 'lottery': {
      const ticket = 100;
      if (user.wallet < ticket) { await reply(`❌ Need ${ticket} coins for a lottery ticket.`); break; }
      user.wallet -= ticket;
      const win2 = Math.random() < 0.05;
      if (win2) { const prize = 5000+Math.floor(Math.random()*10000); user.wallet += prize; await reply(ft(`🎊 *LOTTERY JACKPOT!* You won ${fmt(prize)} coins! 🎉`, sock)); }
      else { await reply(ft(`🎟️ No luck this time. Better luck next draw!`, sock)); }
      saveEcon(data);
      break;
    }

    case 'transfer': {
      const tTarget = (args[0]||'').replace(/\D/g,'');
      const tAmt    = parseInt(args[1]);
      if (!tTarget || !tAmt) { await reply(`${CURRENCY} *${prefix}transfer <number> <amount>*\nMoves coins from your wallet to another player.`); break; }
      if (tAmt <= 0) { await reply('❌ Amount must be a positive number.'); break; }
      if (tTarget === sender) { await reply('❌ You cannot transfer coins to yourself.'); break; }
      if (tAmt > user.wallet) { await reply(`❌ Not enough in wallet (${fmt(user.wallet)} coins).`); break; }
      const tRecv = getUser(data, tTarget);
      user.wallet -= tAmt; tRecv.wallet += tAmt;
      saveEcon(data);
      await reply(ft(`💸 *Transfer complete!*\n\nSent ${fmt(tAmt)} coins to +${tTarget}\n👛 Wallet left: ${fmt(user.wallet)} coins`, sock));
      break;
    }

    case 'shop': {
      const shopList = SHOP_ITEMS.map((it,i)=>`${i+1}. ${it.name} — ${fmt(it.price)} coins\n   _${it.desc}_`).join('\n');
      await reply(ft(`🛒 *Shop*\n\n${shopList}\n\nBuy with *${prefix}buy <item>*`, sock));
      break;
    }

    case 'buy': {
      const want = text.trim().toLowerCase();
      if (!want) { await reply(`${CURRENCY} *${prefix}buy <item>*\nSee *${prefix}shop* for the catalogue.`); break; }
      const item3 = SHOP_ITEMS.find(it => it.id === want || want.includes(it.id) || it.name.toLowerCase().includes(want));
      if (!item3) { await reply(`❌ Unknown shop item: *${text.trim()}*.\nUse *${prefix}shop* to see what is available.`); break; }
      if (user.wallet < item3.price) { await reply(`❌ Not enough coins for ${item3.name} (need ${fmt(item3.price)}, you have ${fmt(user.wallet)}).`); break; }
      user.wallet -= item3.price;
      if (!user.inventory) user.inventory = [];
      user.inventory.push(item3.name);
      saveEcon(data);
      await reply(ft(`🛒 Bought *${item3.name}* for ${fmt(item3.price)} coins!\n👛 Wallet: ${fmt(user.wallet)} coins\n🎒 Check it with *${prefix}inventory*`, sock));
      break;
    }

    case 'blackjack': {
      const sub = (args[0]||'').toLowerCase();
      const BJ  = [2,3,4,5,6,7,8,9,10,10,10,10,11];
      const pick = () => BJ[Math.floor(Math.random()*BJ.length)];
      const total = h => h.reduce((a,b)=>a+b,0);
      if (sub === 'hit' || sub === 'stand') {
        const g2 = user.bj;
        if (!g2) { await reply(`🃏 No active game. Start one with *${prefix}blackjack <bet>*`); break; }
        if (sub === 'hit') {
          g2.player.push(pick());
          const pt = total(g2.player);
          if (pt > 21) {
            const lostBet = g2.bet;
            const hand = g2.player.join(' + ');
            delete user.bj; saveEcon(data);
            await reply(ft(`🃏 *Blackjack*\n\nYou: ${hand} = *${pt}* 💥 BUST\n\n❌ Lost ${fmt(lostBet)} coins`, sock));
            break;
          }
          saveEcon(data);
          await reply(ft(`🃏 *Blackjack*\n\nYou: ${g2.player.join(' + ')} = *${pt}*\nDealer shows: ${g2.dealer[0]}\n\n*${prefix}blackjack hit* or *${prefix}blackjack stand*`, sock));
          break;
        }
        while (total(g2.dealer) < 17) g2.dealer.push(pick());
        const pt2 = total(g2.player), dt = total(g2.dealer), bet3 = g2.bet;
        const pHand = g2.player.join(' + '), dHand = g2.dealer.join(' + ');
        delete user.bj;
        let out;
        if (dt > 21 || pt2 > dt) { user.wallet += bet3*2; out = `🎉 You win! +${fmt(bet3)} coins`; }
        else if (pt2 === dt)     { user.wallet += bet3;   out = `🤝 Push — bet returned (${fmt(bet3)} coins)`; }
        else                     {                        out = `❌ Dealer wins. -${fmt(bet3)} coins`; }
        saveEcon(data);
        await reply(ft(`🃏 *Blackjack*\n\nYou: ${pHand} = *${pt2}*\nDealer: ${dHand} = *${dt}*\n\n${out}`, sock));
        break;
      }
      const bet = parseInt(args[0]);
      if (!bet || bet <= 0) { await reply(`🃏 *${prefix}blackjack <bet>*\nThen use *${prefix}blackjack hit* or *${prefix}blackjack stand*`); break; }
      if (bet > user.wallet) { await reply(`❌ Not enough coins (wallet: ${fmt(user.wallet)}).`); break; }
      user.wallet -= bet;
      const pHand0 = [pick(), pick()];
      const dHand0 = [pick(), pick()];
      user.bj = { bet, player: pHand0, dealer: dHand0 };
      saveEcon(data);
      await reply(ft(`🃏 *Blackjack* (bet ${fmt(bet)})\n\nYou: ${pHand0.join(' + ')} = *${total(pHand0)}*\nDealer shows: ${dHand0[0]}\n\n*${prefix}blackjack hit* or *${prefix}blackjack stand*`, sock));
      break;
    }

    case 'plant': {
      const cropKey = text.trim().toLowerCase();
      if (!cropKey) {
        const cropList = Object.entries(CROPS).map(([k,v])=>`${v.emoji} ${k} — seed ${fmt(v.cost)}, sells ${fmt(v.value)}, grows in ${v.mins} min`).join('\n');
        await reply(ft(`🌱 *${prefix}plant <crop>*\n\n${cropList}`, sock));
        break;
      }
      const crop = CROPS[cropKey];
      if (!crop) { await reply(`❌ Unknown crop: *${text.trim()}*.\nUse *${prefix}plant* to see the crop list.`); break; }
      if (user.wallet < crop.cost) { await reply(`❌ Seeds cost ${fmt(crop.cost)} coins — you have ${fmt(user.wallet)}.`); break; }
      if (!user.farm) user.farm = [];
      const nowP = Date.now();
      user.wallet -= crop.cost;
      user.farm.push({ crop: cropKey, at: nowP, ready: nowP + crop.mins*60*1000 });
      saveEcon(data);
      await reply(ft(`🌱 Planted *${crop.emoji} ${cropKey}* for ${fmt(crop.cost)} coins!\n⏳ Ready in ${crop.mins} min\n🌾 Harvest with *${prefix}harvest*`, sock));
      break;
    }

    case 'harvest': {
      if (!user.farm?.length) { await reply(`🌾 Nothing planted. Use *${prefix}plant <crop>* first.`); break; }
      const nowH  = Date.now();
      const ready = user.farm.filter(p => nowH >= (p.ready||0));
      const growing = user.farm.length - ready.length;
      if (!ready.length) {
        const soonest  = Math.min(...user.farm.map(p => p.ready||nowH));
        const minsLeft = Math.max(1, Math.ceil((soonest-nowH)/60000));
        await reply(ft(`🌾 Nothing is ready yet.\n⏳ Next crop in ~${minsLeft} min (${growing} growing)`, sock));
        break;
      }
      let earned = 0;
      const names = [];
      for (const p of ready) {
        const c2 = CROPS[p.crop] || { emoji:'🌱', value:0 };
        earned += c2.value;
        names.push(`${c2.emoji} ${p.crop}`);
      }
      user.farm = user.farm.filter(p => nowH < (p.ready||0));
      user.wallet += earned;
      user.xp += ready.length*5;
      if (user.xp >= user.level*100) { user.level++; user.xp = 0; }
      saveEcon(data);
      await reply(ft(`🌾 *Harvested!*\n\n${names.join('\n')}\n\n+${fmt(earned)} coins\n👛 Wallet: ${fmt(user.wallet)}${growing?`\n⏳ ${growing} still growing`:''}`, sock));
      break;
    }

    case 'craft': {
      const cw = text.trim().toLowerCase();
      if (!cw) {
        const recipeList = CRAFT_RECIPES.map(r=>`${r.out} = ${r.need.join(' + ')} → pays ${fmt(r.reward)} coins`).join('\n');
        await reply(ft(`🔨 *${prefix}craft <item>*\n\n${recipeList}`, sock));
        break;
      }
      const recipe = CRAFT_RECIPES.find(r => r.out.toLowerCase().includes(cw) || cw.includes(r.key));
      if (!recipe) { await reply(`❌ Unknown recipe: *${text.trim()}*.\nUse *${prefix}craft* to see the recipe list.`); break; }
      const inv  = user.inventory || [];
      const need = {};
      recipe.need.forEach(n => { need[n] = (need[n]||0)+1; });
      const missing = Object.entries(need).filter(([n,c]) => inv.filter(i=>i===n).length < c).map(([n])=>n);
      if (missing.length) {
        await reply(`❌ Missing materials: ${missing.join(', ')}\n\nYou have: ${inv.length ? inv.join(', ') : 'nothing'}\nGather materials with *${prefix}mine*, *${prefix}fish* and *${prefix}hunt*`);
        break;
      }
      for (const [n,c] of Object.entries(need)) {
        for (let i=0;i<c;i++) { const k = user.inventory.indexOf(n); if (k > -1) user.inventory.splice(k,1); }
      }
      user.wallet += recipe.reward;
      saveEcon(data);
      await reply(ft(`🔨 Crafted *${recipe.out}* and sold it for ${fmt(recipe.reward)} coins!\n👛 Wallet: ${fmt(user.wallet)}`, sock));
      break;
    }

    case 'levelup': {
      const needXp = user.level*100;
      if (user.xp < needXp) {
        await reply(ft(`⭐ Not enough XP to level up.\n\n📊 ${user.xp}/${needXp} XP\nNeed ${needXp-user.xp} more XP.\n\nEarn XP with *${prefix}work*, *${prefix}crime* or *${prefix}mine*`, sock));
        break;
      }
      const fee = user.level*500;
      if (user.wallet + user.bank < fee) {
        await reply(ft(`⭐ You have the XP, but the level-up ceremony costs ${fmt(fee)} coins (you have ${fmt(user.wallet+user.bank)}).`, sock));
        break;
      }
      if (user.wallet >= fee) user.wallet -= fee;
      else { const rest = fee - user.wallet; user.wallet = 0; user.bank -= rest; }
      user.level++; user.xp = 0;
      saveEcon(data);
      await reply(ft(`🎉 *Level Up!*\n\n⭐ Level: ${user.level}\n💰 Paid ${fmt(fee)} coins\n📊 XP reset to 0/${user.level*100}`, sock));
      break;
    }

    case 'bankrob': {
      if (!user.inventory) user.inventory = [];
      const cdBR = 90*60*1000;
      const sinceBR = Date.now()-(user.lastBankrob||0);
      if (sinceBR < cdBR) {
        const leftBR = Math.ceil((cdBR-sinceBR)/60000);
        await reply(ft(`⏰ Bank robbery cooldown: *${leftBR} min*`, sock));
        break;
      }
      if (user.wallet < 500) { await reply(`❌ You need at least 500 coins in your wallet to plan a bank robbery (you have ${fmt(user.wallet)}).`); break; }
      const hasTool = user.inventory.some(i => i.includes('Iron') || i.includes('Diamond'));
      const success3 = Math.random() < (hasTool ? 0.55 : 0.35);
      user.lastBankrob = Date.now();
      if (success3) {
        const lootGain = Math.floor(Math.random()*4000)+1000;
        user.wallet += lootGain;
        saveEcon(data);
        await reply(ft(`🏦 *Bank Robbery Successful!*\n\nYou cracked the vault and escaped.\n+${fmt(lootGain)} coins 🤑${hasTool?'\n_(your tools helped)_':''}`, sock));
      } else {
        const fine3 = Math.min(user.wallet, Math.floor(Math.random()*1500)+500);
        user.wallet -= fine3;
        saveEcon(data);
        await reply(ft(`🚨 *Busted!*\n\nThe guards caught you.\n-${fmt(fine3)} coins fine\n👛 Wallet: ${fmt(user.wallet)}`, sock));
      }
      break;
    }

    case 'heist': {
      const entry = 1000;
      const cdH   = 2*60*60*1000;
      const sinceH = Date.now()-(user.lastHeist||0);
      if (sinceH < cdH) {
        const leftH = Math.ceil((cdH-sinceH)/60000);
        await reply(ft(`⏰ Heist cooldown: *${leftH} min*`, sock));
        break;
      }
      if (user.wallet < entry) { await reply(`❌ The crew entry fee is ${fmt(entry)} coins (you have ${fmt(user.wallet)}).\nTry a heist once you can afford it.`); break; }
      user.wallet -= entry;
      user.lastHeist = Date.now();
      const roll = Math.random();
      if (roll < 0.08) {
        const jackpot = Math.floor(Math.random()*50000)+20000;
        user.wallet += jackpot;
        saveEcon(data);
        await reply(ft(`💎 *HEIST JACKPOT!*\n\nThe vault was loaded. Your cut: +${fmt(jackpot)} coins! 🎉`, sock));
      } else if (roll < 0.45) {
        const take = Math.floor(Math.random()*(entry*4)) + entry;
        user.wallet += take;
        saveEcon(data);
        await reply(ft(`🏦 *Heist Successful!*\n\nYou slipped out with +${fmt(take)} coins.`, sock));
      } else {
        const bail = Math.min(user.wallet, Math.floor(Math.random()*entry));
        user.wallet -= bail;
        saveEcon(data);
        await reply(ft(`🚨 *Heist Failed!*\n\nThe crew got caught. You lost the ${fmt(entry)} entry fee${bail>0?` and paid ${fmt(bail)} coins bail`:''}.\n👛 Wallet: ${fmt(user.wallet)}`, sock));
      }
      break;
    }

    default: return false;
  }
  return true;
}

module.exports = { economyHandler, ECON_CMDS };
