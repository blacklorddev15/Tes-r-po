// ============================================================
//   verify-play.js  --  .play format picker
// ------------------------------------------------------------
// Covers: the interactive card (3 quick-reply buttons + header image),
// the tap handlers for Audio / Video / Document, blockquoted captions,
// and the failure path.
//
//   node verify-play.js
// ============================================================
'use strict';

const fs   = require('fs');
const os   = require('os');
const path = require('path');
const zlib = require('zlib');

const BOT_NUM   = '254700000000';
const BOT_JID   = `${BOT_NUM}@s.whatsapp.net`;
const USER_JID  = '254711111111@s.whatsapp.net';
const VIDEO_URL = 'https://youtu.be/mock';

// ── 1. Stub yt-search (it does its own HTTP, so axios stubbing is not enough) ──
const ytPath = require.resolve('yt-search');
require.cache[ytPath] = {
  id: ytPath, filename: ytPath, loaded: true, exports: async () => ({
    videos: [{
      title: 'Mock Song', url: VIDEO_URL, timestamp: '3:21',
      views: 1234567, ago: '2 years ago', type: 'video',
      thumbnail: 'https://example.com/thumb.jpg',
    }],
    all: [],
  }),
};

// ── 2. Test image (must exceed the 200-byte header guard) ─────
function makePng(w = 160, h = 160) {
  const raw = Buffer.alloc((w * 3 + 1) * h);
  let seed = 987654;
  for (let y = 0; y < h; y++) {
    raw[y * (w * 3 + 1)] = 0;
    for (let x = 0; x < w; x++) {
      seed = (seed * 1103515245 + 12345) & 0x7fffffff;
      const o = y * (w * 3 + 1) + 1 + x * 3;
      raw[o] = seed & 0xff; raw[o + 1] = (seed >> 8) & 0xff; raw[o + 2] = (seed >> 16) & 0xff;
    }
  }
  const crc = (b) => { let c = ~0; for (const x of b) { c ^= x; for (let k = 0; k < 8; k++) c = (c >>> 1) ^ (0xEDB88320 & -(c & 1)); } return ~c >>> 0; };
  const chunk = (t, d) => {
    const len = Buffer.alloc(4); len.writeUInt32BE(d.length);
    const td = Buffer.concat([Buffer.from(t), d]);
    const c = Buffer.alloc(4); c.writeUInt32BE(crc(td));
    return Buffer.concat([len, td, c]);
  };
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}
const IMG = makePng();

// ── 3. Stub the network ──────────────────────────────────────
let ytmp3Mode = 'ok';
let videoMode = 'ok';
const apiHits = [];

const axios = require('axios');
axios.get = async (url, opts = {}) => {
  apiHits.push(url);
  const buf = (o) => ({ data: IMG, status: 200, statusText: 'OK', headers: {}, config: {} });

  if (opts.responseType === 'arraybuffer') return buf();
  if (url.includes('eliteprotech-apis.zone.id/ytmp3')) {
    if (ytmp3Mode === 'fail') return { data: { status: false }, status: 200 };
    return { data: { status: true, download: { title: 'Mock Song', thumbnail: 'https://example.com/thumb.jpg', duration: '3.55 min', downloadUrl: 'https://example.com/audio.mp3', format: 'mp3' } }, status: 200 };
  }
  if (url.includes('neosoft')) {
    if (videoMode === 'fail') return { data: { status: false }, status: 200 };
    return { data: { status: true, title: 'Mock Song', type: 'mp4', duration: 213, download: 'https://example.com/video.mp4' }, status: 200 };
  }
  return { data: {}, status: 200 };
};
axios.post = async () => ({ data: {}, status: 200 });
axios.request = async () => ({ data: {}, status: 200 });
axios.create = () => axios;
global.fetch = async () => ({ ok: true, status: 200, json: async () => ({}), text: async () => '', arrayBuffer: async () => new ArrayBuffer(8) });

// ── 4. Stub socket ───────────────────────────────────────────
let out = [];
const baseSock = {
  user: { id: `${BOT_NUM}:1@s.whatsapp.net` },
  __waNum: BOT_NUM,
  __sessionId: `wa_playtest_${BOT_NUM}`,
  waUploadToServer: async () => ({ mediaUrl: 'https://mmg.whatsapp.net/v/mock.enc', directPath: '/v/mock.enc' }),
  sendMessage: async (jid, content, opts) => { out.push({ jid, content, opts }); return { key: { id: 'M' + out.length, remoteJid: jid } }; },
  relayMessage: async (jid, message, opts) => { out.push({ jid, content: message, opts, relayed: true }); return { key: { id: 'R' } }; },
  sendPresenceUpdate: async () => {},
  readMessages: async () => {},
};
const sock = new Proxy(baseSock, {
  get(t, p) {
    if (p in t) return t[p];
    if (typeof p === 'symbol') return undefined;
    return async () => ({ key: { id: 'MOCK' }, status: 200 });
  },
});

const react = () => out.filter(m => m.content?.react);
const msgs  = () => out.filter(m => !m.content?.react);

// ── 5. Settings isolation ────────────────────────────────────
const DB_DIR = path.join(__dirname, 'database');
const SNAP = fs.mkdtempSync(path.join(os.tmpdir(), 'play-db-'));
if (fs.existsSync(DB_DIR)) fs.cpSync(DB_DIR, SNAP, { recursive: true });
const restore = () => {
  try {
    fs.rmSync(DB_DIR, { recursive: true, force: true });
    fs.cpSync(SNAP, DB_DIR, { recursive: true });
    fs.rmSync(SNAP, { recursive: true, force: true });
  } catch { /* best effort */ }
};
process.on('exit', restore);
fs.writeFileSync(path.join(DB_DIR, 'settings.json'), JSON.stringify({
  [BOT_NUM]: { prefix: '.', mode: 'public', font: 0, botName: 'ULTRATEST', menuImg: '', iphoneMode: false },
}, null, 2));

// ── 6. Assertions ────────────────────────────────────────────
const { handleMessage } = require('./case.js');
const results = [];
const check = (name, ok, detail = '') => results.push({ name, ok: !!ok, detail });
const reset = () => { out = []; apiHits.length = 0; };

const textMsg = (body) => ({
  key: { remoteJid: USER_JID, fromMe: false, id: 'T' + Math.random().toString(36).slice(2, 8) },
  mtype: 'conversation', message: { conversation: body }, pushName: 'Tester',
});
const tapMsg = (id) => ({
  key: { remoteJid: USER_JID, fromMe: false, id: 'B' + Math.random().toString(36).slice(2, 8) },
  mtype: 'buttonsResponseMessage', message: { buttonsResponseMessage: { selectedButtonId: id } }, pushName: 'Tester',
});

(async () => {
  // ── the picker ────────────────────────────────────────────
  reset();
  await handleMessage(sock, textMsg('.play mock song'), {});
  const relayed = out.find(m => m.relayed);
  const inter = relayed?.content?.viewOnceMessage?.message?.interactiveMessage
    || relayed?.content?.interactiveMessage;

  check('play sends ONE interactive card', !!relayed && msgs().length === 1, `msgs=${msgs().length}`);
  check('card carries the song title', /Mock Song/.test(inter?.body?.text || ''), JSON.stringify((inter?.body?.text || '').slice(0, 60)));
  check('card body is blockquoted', (inter?.body?.text || '').trimStart().startsWith('> '),
    JSON.stringify((inter?.body?.text || '').slice(0, 30)));
  check('card has the thumbnail as header image',
    inter?.header?.hasMediaAttachment === true && !!inter?.header?.imageMessage,
    `hasMedia=${inter?.header?.hasMediaAttachment}`);

  const btns = inter?.nativeFlowMessage?.buttons || [];
  const ids  = btns.map(b => { try { return JSON.parse(b.buttonParamsJson); } catch { return {}; } });
  check('three buttons offered', btns.length === 3, `got ${btns.length}`);
  check('buttons are quick_reply Audio / Video / Document',
    ids.every(b => b.name === undefined || btns.some(() => true)) && ids.filter(b => /^PLAY_(AUDIO|VIDEO|DOC)\|/.test(b.id || '')).length === 3,
    JSON.stringify(ids.map(b => b.id)));
  check('button ids carry the video url',
    ids.every(b => String(b.id || '').endsWith(VIDEO_URL)), JSON.stringify(ids.map(b => b.id)));

  // ── tapping Audio ─────────────────────────────────────────
  reset();
  await handleMessage(sock, tapMsg(`PLAY_AUDIO|${VIDEO_URL}`), {});
  const audio = msgs().find(m => m.content?.audio);
  check('Audio tap -> audio message sent', !!audio, `msgs=${msgs().length}`);
  check('Audio tap -> uses the ELITE ytmp3 endpoint',
    apiHits.some(u => u.includes('eliteprotech-apis.zone.id/ytmp3')), apiHits.join(' | ').slice(0, 120));
  check('Audio tap -> success reaction ✅', react().some(r => r.content.react.text === '✅'),
    react().map(r => r.content.react.text).join(','));
  check('Audio tap -> no stray text reply', msgs().filter(m => m.content?.text).length === 0);

  // ── tapping Video ─────────────────────────────────────────
  reset();
  await handleMessage(sock, tapMsg(`PLAY_VIDEO|${VIDEO_URL}`), {});
  const video = msgs().find(m => m.content?.video);
  check('Video tap -> video message sent', !!video, `msgs=${msgs().length}`);
  check('Video tap -> uses the mp4 provider',
    apiHits.some(u => u.includes('type=mp4')), apiHits.join(' | ').slice(0, 120));
  check('Video tap -> caption blockquoted', (video?.content?.caption || '').startsWith('> '),
    JSON.stringify((video?.content?.caption || '').slice(0, 40)));
  check('Video tap -> .mp4 file name', /\.mp4$/.test(video?.content?.fileName || ''), video?.content?.fileName);

  // ── tapping Document ──────────────────────────────────────
  reset();
  await handleMessage(sock, tapMsg(`PLAY_DOC|${VIDEO_URL}`), {});
  const doc = msgs().find(m => m.content?.document);
  check('Document tap -> document message sent', !!doc, `msgs=${msgs().length}`);
  check('Document tap -> .mp3 attachment named after the song',
    /Mock Song.*\.mp3$/.test(doc?.content?.fileName || ''), doc?.content?.fileName);
  check('Document tap -> caption blockquoted', (doc?.content?.caption || '').startsWith('> '),
    JSON.stringify((doc?.content?.caption || '').slice(0, 40)));

  // ── failure paths ─────────────────────────────────────────
  reset();
  ytmp3Mode = 'fail';
  await handleMessage(sock, tapMsg(`PLAY_AUDIO|${VIDEO_URL}`), {});
  ytmp3Mode = 'ok';
  const errText = msgs().find(m => m.content?.text);
  check('audio failure -> error reaction ❌', react().some(r => r.content.react.text === '❌'),
    react().map(r => r.content.react.text).join(','));
  check('audio failure -> blockquoted error text',
    (errText?.content?.text || '').startsWith('> ') && /Download failed/i.test(errText?.content?.text || ''),
    JSON.stringify((errText?.content?.text || '').slice(0, 70)));
  check('audio failure -> no media sent', !msgs().some(m => m.content?.audio || m.content?.video || m.content?.document));

  reset();
  videoMode = 'fail';
  await handleMessage(sock, tapMsg(`PLAY_VIDEO|${VIDEO_URL}`), {});
  videoMode = 'ok';
  check('video failure -> no video, error reported',
    !msgs().some(m => m.content?.video) && msgs().some(m => /Download failed/i.test(m.content?.text || '')),
    `msgs=${msgs().length}`);

  // ── usage ─────────────────────────────────────────────────
  reset();
  await handleMessage(sock, textMsg('.play'), {});
  check('play with no arguments -> usage hint, no download',
    msgs().length >= 1 && !apiHits.some(u => u.includes('ytmp3')), `msgs=${msgs().length}`);


  // ── numbered fallback (clients with no quick_reply buttons) ──
  reset(); await handleMessage(sock, textMsg('.play mock song'), {});
  reset();
  await handleMessage(sock, textMsg('1'), {});
  check('DM reply "1" -> audio download', !!msgs().find(m => m.content?.audio), `msgs=${msgs().length}`);

  reset(); await handleMessage(sock, textMsg('.play mock song'), {});
  reset();
  await handleMessage(sock, textMsg('2'), {});
  check('DM reply "2" -> video download', !!msgs().find(m => m.content?.video), `msgs=${msgs().length}`);

  reset(); await handleMessage(sock, textMsg('.play mock song'), {});
  reset();
  await handleMessage(sock, textMsg('document'), {});
  check('DM reply "document" -> document download', !!msgs().find(m => m.content?.document), `msgs=${msgs().length}`);

  reset();
  await handleMessage(sock, textMsg('1'), {});
  check('bare "1" with no pending card -> nothing happens',
    msgs().length === 0 || !msgs().some(m => m.content?.audio || m.content?.video || m.content?.document),
    `msgs=${msgs().length}`);

  // in a group a bare number must NOT trigger (the card has to be quoted)
  const groupText = (body) => ({
    key: { remoteJid: '120363999999999999@g.us', fromMe: false, id: 'G' + Math.random().toString(36).slice(2, 8), participant: USER_JID },
    mtype: 'conversation', message: { conversation: body }, pushName: 'Tester',
  });
  reset(); await handleMessage(sock, groupText('.play mock song'), {});
  reset();
  await handleMessage(sock, groupText('1'), {});
  check('group bare "1" does not trigger a download',
    !msgs().some(m => m.content?.audio || m.content?.video || m.content?.document), `msgs=${msgs().length}`);

  // card body advertises the fallback
  reset(); await handleMessage(sock, textMsg('.play mock song'), {});
  const inter2 = (out.find(m => m.relayed)?.content?.viewOnceMessage?.message?.interactiveMessage) || {};
  check('card body tells the user about 1/2/3',
    /1 = Audio/.test(inter2?.body?.text || ''), JSON.stringify((inter2?.body?.text || '').slice(-60)));


  // ── report ────────────────────────────────────────────────
  const failed = results.filter(r => !r.ok);
  console.log('\n=================== PLAY VERIFICATION ===================');
  for (const r of results) console.log(`${r.ok ? 'PASS' : 'FAIL'}  ${r.name}${r.detail ? `\n        ${r.detail}` : ''}`);
  console.log('---------------------------------------------------------');
  console.log(`checks: ${results.length}   passed: ${results.length - failed.length}   failed: ${failed.length}`);
  console.log('=========================================================\n');
  process.exit(failed.length ? 1 : 0);
})().catch(e => { console.error('harness error:', e); process.exit(2); });
