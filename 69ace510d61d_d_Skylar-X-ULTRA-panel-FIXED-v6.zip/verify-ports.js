// ============================================================
//   verify-ports.js  --  checkban, screenshot, approve + console style
// ------------------------------------------------------------
//   node verify-ports.js
// ============================================================
'use strict';

const fs   = require('fs');
const os   = require('os');
const path = require('path');
const zlib = require('zlib');

const BOT_NUM   = '254700000000';
const ADMIN_JID = '254711111111@s.whatsapp.net';
const GROUP_JID = '120363111111111111@g.us';

// lolcatjs prints via its own writer, so stub it through console.log for the
// run; a separate check confirms the real package is installed (production
// therefore keeps the rainbow output).
const lolcatPath = require.resolve('lolcatjs');
require.cache[lolcatPath] = {
  id: lolcatPath, filename: lolcatPath, loaded: true,
  exports: { fromString: (str) => console.log(str) },
};

// settings.js reads this at require time, so set it before anything loads.
process.env.BANCHECK_API_KEY = 'test-ban-key';

// ── 1. Capture console output ────────────────────────────────
const printed = [];
const realLog    = console.log;
const realError  = console.error;
const realStdout = process.stdout.write.bind(process.stdout);
console.log   = (...a) => { printed.push(a.join(' ')); };
console.error = (...a) => { printed.push(a.join(' ')); };
// lolcatjs writes straight to stdout, so it has to be captured as well.
process.stdout.write = (chunk, ...rest) => { printed.push(String(chunk)); return true; };
const strip = (s) => String(s).replace(/\x1b\[[0-9;]*m/g, '');
const output = () => strip(printed.join('\n'));

// ── 2. Test image ────────────────────────────────────────────
function makePng(w = 80, h = 80) {
  const raw = Buffer.alloc((w * 3 + 1) * h);
  let seed = 4242;
  for (let y = 0; y < h; y++) {
    raw[y * (w * 3 + 1)] = 0;
    for (let x = 0; x < w; x++) {
      seed = (seed * 1103515245 + 12345) & 0x7fffffff;
      const o = y * (w * 3 + 1) + 1 + x * 3;
      raw[o] = seed & 0xff; raw[o + 1] = (seed >> 8) & 0xff; raw[o + 2] = (seed >> 16) & 0xff;
    }
  }
  const crc = (b) => { let c = ~0; for (const x of b) { c ^= x; for (let k = 0; k < 8; k++) c = (c >>> 1) ^ (0xEDB88320 & -(c & 1)); } return ~c >>> 0; };
  const chunk = (t, d) => {
    const len = Buffer.alloc(4); len.writeUInt32BE(d.length);
    const td = Buffer.concat([Buffer.from(t), d]);
    const c = Buffer.alloc(4); c.writeUInt32BE(crc(td));
    return Buffer.concat([len, td, c]);
  };
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}
const IMG = makePng();

// ── 3. Stub the network ──────────────────────────────────────
let banMode = 'clean';
let ssMode  = 'ok';
const hits  = [];
const axios = require('axios');
axios.get = async (url, opts = {}) => {
  hits.push(url);
  if (url.includes('/ssweb')) {
    if (ssMode === 'fail') throw new Error('simulated screenshot failure');
    return { data: IMG, status: 200, statusText: 'OK', headers: {}, config: {} };
  }
  return { data: {}, status: 200 };
};
axios.post = async (url) => {
  hits.push(url);
  if (banMode === 'banned') return { data: { banned: true, reason: 'Spam', ban_type: 'Permanent', violation_category: 'SPAM', in_app_ban_appeal: true, is_eu: false }, status: 200 };
  return { data: { banned: false }, status: 200 };
};
axios.request = async () => ({ data: {}, status: 200 });
axios.create = () => axios;
global.fetch = async () => ({ ok: true, status: 200, json: async () => ({}), text: async () => '', arrayBuffer: async () => new ArrayBuffer(8) });

// ── 4. Stub socket ───────────────────────────────────────────
let out = [];
const approveCalls = [];
const baseSock = {
  user: { id: `${BOT_NUM}:1@s.whatsapp.net` },
  __waNum: BOT_NUM,
  __sessionId: `wa_portstest_${BOT_NUM}`,
  groupMetadata: async () => ({
    subject: 'Mock Group',
    participants: [
      { id: `${BOT_NUM}@s.whatsapp.net`, admin: 'superadmin' },
      { id: ADMIN_JID, admin: 'admin' },
    ],
  }),
  groupRequestParticipantsList: async () => [{ jid: '254733333333@s.whatsapp.net' }],
  groupRequestParticipantsUpdate: async (jid, users, action) => { approveCalls.push({ jid, users, action }); return []; },
  sendMessage: async (jid, content, opts) => { out.push({ jid, content, opts }); return { key: { id: 'M' + out.length, remoteJid: jid } }; },
  relayMessage: async () => ({ key: { id: 'R' } }),
  sendPresenceUpdate: async () => {},
  readMessages: async () => {},
};
const sock = new Proxy(baseSock, {
  get(t, p) {
    if (p in t) return t[p];
    if (typeof p === 'symbol') return undefined;
    return async () => ({ key: { id: 'MOCK' }, status: 200 });
  },
});

const msgs   = () => out.filter(m => !m.content?.react);
const reacts = () => out.filter(m => m.content?.react);
const texts  = () => msgs().map(m => m.content?.text || '').filter(Boolean);

// ── 5. Settings isolation ────────────────────────────────────
const DB_DIR = path.join(__dirname, 'database');
const SNAP = fs.mkdtempSync(path.join(os.tmpdir(), 'ports-db-'));
if (fs.existsSync(DB_DIR)) fs.cpSync(DB_DIR, SNAP, { recursive: true });
const restore = () => {
  try {
    fs.rmSync(DB_DIR, { recursive: true, force: true });
    fs.cpSync(SNAP, DB_DIR, { recursive: true });
    fs.rmSync(SNAP, { recursive: true, force: true });
  } catch { /* best effort */ }
};
process.on('exit', restore);
fs.writeFileSync(path.join(DB_DIR, 'settings.json'), JSON.stringify({
  [BOT_NUM]: { prefix: '.', mode: 'public', font: 0, botName: 'ULTRATEST', menuImg: '', iphoneMode: false },
}, null, 2));

// ── 6. Messages ──────────────────────────────────────────────
const buildMsg = (body, { group = false, mentioned = [] } = {}) => ({
  key: { remoteJid: group ? GROUP_JID : ADMIN_JID, fromMe: false, id: 'P' + Math.random().toString(36).slice(2, 8), participant: group ? ADMIN_JID : undefined },
  mtype: 'extendedTextMessage',
  message: { extendedTextMessage: { text: body, contextInfo: mentioned.length ? { mentionedJid: mentioned } : {} } },
  pushName: 'Tester',
});

// ── 7. Assertions ────────────────────────────────────────────
const results = [];
const check = (name, ok, detail = '') => results.push({ name, ok: !!ok, detail });
const reset = () => { out = []; approveCalls.length = 0; hits.length = 0; };

(async () => {
  // ══════════ console style ══════════
  const logger = require('./helper/logger');
  printed.length = 0;
  logger.skylarLog('hello world', 'green');
  check('logger tags every line with the brand', output().includes('[ SKYLAR ULTRA ]'), JSON.stringify(output()));
  check('global.log is wired', typeof global.log === 'function');
  check('lolcatjs is installed (rainbow banner)',
    !!require.resolve('lolcatjs') && fs.existsSync(path.join(__dirname, 'node_modules', 'lolcatjs')),
    'lolcatjs missing from node_modules');

  printed.length = 0;
  logger.logMessage({
    key: { remoteJid: GROUP_JID, participant: ADMIN_JID, id: 'L1' },
    message: { conversation: 'console style check' },
    pushName: 'Alice', messageTimestamp: Math.floor(Date.now() / 1000),
  }, { groupName: 'Mock Group' });
  const boxed = output();
  check('message banner uses the June field set',
    boxed.includes('Sent Time') && boxed.includes('Message Type') && boxed.includes('Chat ID') && boxed.includes('Group JID'),
    JSON.stringify(boxed.slice(0, 160)));
  check('message banner is branded', boxed.includes('SKYLAR ULTRA'), JSON.stringify(boxed.slice(0, 80)));
  check('message banner draws the box', boxed.includes('┏') && boxed.includes('┗'), 'box art missing');

  printed.length = 0;
  logger.logError('Boom', 'it failed');
  check('errors are logged through the tagged logger', output().includes('[ ERR ]') || output().includes('[ERR]'), JSON.stringify(output()));
  check('logInfo/logError still exported', typeof logger.logInfo === 'function' && typeof logger.logError === 'function');

  // ══════════ checkban ══════════
  const { handleMessage } = require('./case.js');

  reset();
  await handleMessage(sock, buildMsg('.checkban 254712345678'), {});
  check('checkban clean -> NOT BANNED', texts().some(t => /NOT BANNED/.test(t)), JSON.stringify(texts()));
  check('checkban posts to the baron0 provider', hits.some(h => h.includes('baron0.com')), hits.join(' | '));
  check('checkban body is blockquoted', texts().some(t => t.trimStart().startsWith('> ')), JSON.stringify((texts()[0] || '').slice(0, 40)));

  reset();
  banMode = 'banned';
  await handleMessage(sock, buildMsg('.checkban +254712345678'), {});
  banMode = 'clean';
  const bannedText = texts().join('\n');
  check('checkban banned -> full report',
    /BANNED/.test(bannedText) && /Reason/.test(bannedText) && /Ban Type/.test(bannedText) && /Engine/.test(bannedText),
    JSON.stringify(bannedText.slice(0, 140)));
  check('checkban reports the engine name', /Baron0 v2/.test(bannedText), JSON.stringify(bannedText.slice(-60)));

  reset();
  await handleMessage(sock, buildMsg('.checkban 12345678901234567'), {});
  check('checkban rejects an out-of-range number', /Invalid number/.test(texts().join('\n')), JSON.stringify(texts()));

  reset();
  await handleMessage(sock, buildMsg('.checkban 123'), {});
  check('checkban with a too-short input -> usage (reference behaviour)',
    /checkban <number>/.test(texts().join('\n')), JSON.stringify(texts()));

  reset();
  await handleMessage(sock, buildMsg('.checkban'), {});
  check('checkban with no target -> usage', /checkban <number>/.test(texts().join('\n')), JSON.stringify(texts()));

  // ══════════ screenshot ══════════
  reset();
  await handleMessage(sock, buildMsg('.screenshot example.com'), {});
  const shot = msgs().find(m => m.content?.image);
  check('screenshot sends an image', !!shot, `msgs=${msgs().length}`);
  check('screenshot uses the ELITE /ssweb provider', hits.some(h => h.includes('/ssweb?url=')), hits.join(' | '));
  check('screenshot caption mentions success', /Screenshot captured/.test(shot?.content?.caption || ''), JSON.stringify((shot?.content?.caption || '').slice(0, 60)));
  check('screenshot reacts 🖼️ then ✅',
    reacts().some(r => r.content.react.text === '🖼️') && reacts().some(r => r.content.react.text === '✅'),
    reacts().map(r => r.content.react.text).join(','));

  reset();
  ssMode = 'fail';
  await handleMessage(sock, buildMsg('.screenshot example.com'), {});
  ssMode = 'ok';
  check('screenshot failure -> ❌ reaction + error text',
    reacts().some(r => r.content.react.text === '❌') && /Failed to capture/.test(texts().join('\n')),
    JSON.stringify(texts()));

  reset();
  await handleMessage(sock, buildMsg('.screenshot'), {});
  check('screenshot with no url -> usage', /screenshot <URL>/.test(texts().join('\n')), JSON.stringify(texts()));

  // ══════════ approve ══════════
  reset();
  await handleMessage(sock, buildMsg('.approve', { group: true }), { groupName: 'Mock Group' });
  check('approve with no target approves pending requests',
    approveCalls.length === 1 && approveCalls[0].action === 'approve' && approveCalls[0].users.length === 1,
    JSON.stringify(approveCalls));
  check('approve announces who was approved',
    /Approved Member/.test(texts().join('\n')) && /254733333333/.test(msgs().map(m => m.content?.text || '').join('\n') + JSON.stringify(msgs().map(m => m.content?.mentions || []))),
    JSON.stringify(msgs().map(m => m.content?.text || '').slice(0, 2)));

  reset();
  await handleMessage(sock, buildMsg('.approve', { group: true, mentioned: ['254744444444@s.whatsapp.net'] }), { groupName: 'Mock Group' });
  check('approve with a tag approves that member',
    approveCalls.length === 1 && approveCalls[0].users[0] === '254744444444@s.whatsapp.net',
    JSON.stringify(approveCalls));

  reset();
  await handleMessage(sock, buildMsg('.approve'), {});
  check('approve outside a group -> refused', approveCalls.length === 0 && /group only/i.test(texts().join('\n')), JSON.stringify(texts()));

  // ── report ─────────────────────────────────────────────────
  console.log = realLog;
  console.error = realError;
  process.stdout.write = realStdout;
  const failed = results.filter(r => !r.ok);
  realLog('\n=================== PORTS VERIFICATION ===================');
  for (const r of results) realLog(`${r.ok ? 'PASS' : 'FAIL'}  ${r.name}${r.detail ? `\n        ${r.detail}` : ''}`);
  realLog('---------------------------------------------------------');
  realLog(`checks: ${results.length}   passed: ${results.length - failed.length}   failed: ${failed.length}`);
  realLog('=========================================================\n');
  process.exit(failed.length ? 1 : 0);
})().catch(e => { console.error = realError; console.error('harness error:', e); process.exit(2); });
