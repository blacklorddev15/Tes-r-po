// ============================================================
//   verify-commands.js  –  offline command dispatch checker
// ------------------------------------------------------------
//   Drives handleMessage() for EVERY advertised command with a
//   mocked socket + mocked network, then reports:
//     • commands that throw  (ReferenceError / TypeError / etc.)
//     • commands that are advertised but reach no handler
//     • commands whose reply came back malformed ("[object Object]")
//
//   Usage:  node verify-commands.js
// ============================================================
'use strict';

process.env.TELEGRAM_TOKEN = process.env.TELEGRAM_TOKEN || 'test-token';

// ── 1. Stub child_process BEFORE anything destructures it ────
const cp = require('child_process');
const shellStub = (cmd, opts, cb) => {
  const done = typeof opts === 'function' ? opts : cb;
  if (typeof done === 'function') setImmediate(() => done(null, JSON.stringify({ ok: true, mock: true }), ''));
  return { on() {}, stdout: { on() {} }, stderr: { on() {} }, kill() {} };
};
cp.exec = shellStub;
cp.execSync = () => JSON.stringify({ ok: true, mock: true });

// ── 2. Stub the network layer ────────────────────────────────
const fakePayload = (url) => {
  const u = String(url);

  // Plain-text endpoints (the handler interpolates the whole body)
  if (u.includes('wttr.in'))                 return 'Mock weather: +25°C, clear sky';
  if (u.includes('tinyurl.com/api-create'))  return 'https://tinyurl.com/mock';
  if (u.includes('pastebin.com/api'))        return 'https://pastebin.com/mock123';
  if (u.includes('loremipsum'))              return 'lorem ipsum dolor sit amet';

  // Structured endpoints – shaped exactly like the real API responses
  if (u.includes('animechan'))               return { data: { content: 'Mock anime quote', character: { name: 'Mock Char' }, anime: { name: 'Mock Anime' } } };
  if (u.includes('boredapi'))                return { activity: 'Mock activity', type: 'recreational', participants: 2, price: 0.1 };
  if (u.includes('thecolorapi'))             return { hex: { value: '#FF5733' }, rgb: { value: 'rgb(255,87,51)' }, hsl: { value: 'hsl(9,100%,60%)' }, name: { value: 'Mock Orange' } };
  if (u.includes('uselessfacts'))            return { text: 'Mock fact about the universe.', id: '1', source: 'mock', language: 'en' };
  if (u.includes('official-joke-api'))       return { setup: 'Mock setup?', punchline: 'Mock punchline!' };
  if (u.includes('api.aladhan.com/v1/gToH')) return { data: { hijri: { day: '12', month: { en: 'Ramadan', ar: 'رمضان' }, year: '1447' } } };
  if (u.includes('api.aladhan.com'))         return { data: { timings: { Fajr: '05:00', Sunrise: '06:20', Dhuhr: '12:15', Asr: '15:30', Maghrib: '18:40', Isha: '20:00' }, date: { readable: '01 Jan 2026', hijri: { day: '1', month: { en: 'Rajab', ar: 'رجب' }, year: '1447' } }, meta: { timezone: 'UTC' } } };
  if (u.includes('ipwho.is'))                return { city: 'Mock City', region: 'Mock Region', country: 'Mockland', connection: { isp: 'Mock ISP' }, timezone: { id: 'UTC' }, type: 'IPv4', success: true };
  if (u.includes('some-random-api.com/lyrics')) return { lyrics: 'Mock lyric line 1\nMock lyric line 2', title: 'Mock Song', author: 'Mock Artist' };
  if (u.includes('lyrics.ovh'))              return { lyrics: 'Mock lyric line 1\nMock lyric line 2' };
  if (u.includes('registry.npmjs.org'))      return { name: 'mock-pkg', version: '1.2.3', description: 'Mock package', author: { name: 'Mock Dev' }, license: 'MIT' };
  if (u.includes('meme-api'))                return { url: 'https://example.com/m.jpg', title: 'Mock meme', ups: 12345, subreddit: 'memes', postLink: 'https://example.com/p' };
  if (u.includes('en.wikipedia.org'))        return { title: 'Mock Topic', extract: 'Mock extract about the topic that is long enough to render.', content_urls: { desktop: { page: 'https://en.wikipedia.org/wiki/Mock' } }, thumbnail: { source: 'https://example.com/t.jpg' } };
  if (u.includes('wikipedia'))               return { query: { pages: { 1: { title: 'Mock', extract: 'Mock extract' } } }, extract: 'Mock extract' };
  if (u.includes('thecatapi') || u.includes('thedogapi')) return [{ url: 'https://example.com/cat.jpg' }];
  if (u.includes('dog.ceo'))                 return { message: 'https://example.com/dog.jpg', status: 'success' };
  if (u.includes('waifu.pics') || u.includes('waifu.im')) return { url: 'https://example.com/waifu.jpg' };
  if (u.includes('jikan'))                   return { data: { title: 'Mock Anime', episodes: 12, score: 8.1, synopsis: 'Mock synopsis', images: { jpg: { image_url: 'https://example.com/a.jpg' } }, aired: { string: '2020' }, status: 'Finished' } };
  if (u.includes('tenor'))                   return { results: [{ media_formats: { gif: { url: 'https://example.com/g.gif' }, mediumgif: { url: 'https://example.com/g.gif' }, tinygif: { url: 'https://example.com/g.gif' }, nanogif: { url: 'https://example.com/g.gif' } } }] };
  if (u.includes('giphy'))                   return { data: [{ images: { original: { url: 'https://example.com/g.gif' }, fixed_height: { url: 'https://example.com/g.gif' } }, url: 'https://example.com/g' }] };
  if (u.includes('zenquotes') || u.includes('quotes')) return [{ q: 'Mock quote text', a: 'Mock Author', h: '<blockquote>Mock</blockquote>' }];
  if (u.includes('adviceslip'))              return { slip: { advice: 'Mock advice for you.', id: 1 } };
  if (u.includes('alquran'))                 return { data: { text: 'Mock ayah text', numberInSurah: 1, surah: { number: 1, englishName: 'Mock', name: 'Mock' }, edition: { identifier: 'mock' } } };
  if (u.includes('ipify'))                   return { ip: '127.0.0.1' };
  if (u.includes('is.gd'))                    return 'https://is.gd/mock';
  if (u.includes('worldtimeapi.org'))        return { datetime: '2026-01-01T12:00:00.000000+03:00', utc_offset: '+03:00', timezone: 'Africa/Nairobi', day_of_week: 4, abbreviation: 'EAT' };
  if (u.includes('api.github.com'))          return { full_name: 'mock/repo', description: 'Mock repository', stargazers_count: 1234, forks_count: 56, watchers_count: 1234, language: 'JavaScript', open_issues_count: 7, updated_at: '2026-01-01T00:00:00Z', owner: { login: 'mock' }, html_url: 'https://github.com/mock/repo', license: { spdx_id: 'MIT' } };
  if (u.includes('aztro'))                   return { description: 'Mock horoscope for today.', lucky_number: '7', mood: 'curious', color: 'blue', compatibility: 'leo' };
  if (u.includes('ip-api') || u.includes('ipinfo')) return { ip: '127.0.0.1', query: '127.0.0.1', country: 'Mockland', city: 'Mock City', regionName: 'Mock Region', isp: 'Mock ISP', org: 'Mock Org', timezone: 'Africa/Nairobi', lat: -1.29, lon: 36.82, status: 'success', message: '' };
  if (u.includes('open.er-api') || u.includes('exchangerate') || u.includes('crypto')) return { rates: { USD: 1, KES: 130, EUR: 0.9 }, data: { rates: { USD: 1, KES: 130 } }, result: 'success' };
  if (u.includes('open-meteo'))              return { current_weather: { temperature: 25, windspeed: 5 }, current: { temperature_2m: 25 } };
  if (u.includes('weather'))                 return { main: { temp: 25, humidity: 60 }, weather: [{ description: 'clear sky', main: 'Clear' }], name: 'Mock City', wind: { speed: 3 } };

  // Generic but field-rich fallback
  return {
    result: 'Mock result', reply: 'Mock reply', status: 'success', ok: true, success: true,
    answer: 'Mock answer', text: 'Mock text', message: 'Mock message', items: [], results: [],
    data: { result: 'Mock result', text: 'Mock text', answer: 'Mock answer', url: 'https://example.com/x', title: 'Mock title', author: 'Mock author', name: 'Mock name', value: 'Mock value' },
  };
};

const axios = require('axios');
const netCalls = { get: 0, post: 0, failed: 0 };
const makeRes = (url, opts = {}) => {
  netCalls.get++;
  const isBuf = opts.responseType === 'arraybuffer';
  const body = isBuf ? Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]) : fakePayload(url);
  return { data: body, status: 200, statusText: 'OK', headers: {}, config: {} };
};
axios.get = async (url, opts) => makeRes(url, opts);
axios.post = async (url, body, opts) => { netCalls.post++; return makeRes(url, opts); };
axios.request = async (opts = {}) => makeRes(opts.url, opts);
axios.head = async (url, opts) => makeRes(url, opts);
axios.create = () => axios;

// global fetch (ai.js uses it)
global.fetch = async () => ({
  ok: true,
  status: 200,
  json: async () => ({ content: [{ text: 'Mock AI reply' }], choices: [{ message: { content: 'Mock AI reply' } }] }),
  text: async () => 'Mock AI reply',
  arrayBuffer: async () => new ArrayBuffer(8),
});

// ── 3. Mock WhatsApp socket ──────────────────────────────────
const BOT_NUM = '254700000000';
const sent = [];

const baseSock = {
  user: { id: `${BOT_NUM}:1@s.whatsapp.net` },
  __waNum: BOT_NUM,
  __sessionId: `wa_test_${BOT_NUM}`,
  waUploadToServer: async () => ({ url: 'https://example.com/up' }),
  sendMessage: async (jid, content) => {
    sent.push({ jid, content });
    return { key: { id: 'MOCK_' + sent.length, remoteJid: jid }, message: content };
  },
  sendPresenceUpdate: async () => {},
  readMessages: async () => {},
  groupMetadata: async () => ({
    subject: 'Mock Group',
    participants: [
      { id: `${BOT_NUM}@s.whatsapp.net`, admin: 'superadmin' },
      { id: '254711111111@s.whatsapp.net', admin: 'admin' },
    ],
  }),
  groupInviteCode: async () => 'MOCKINVITECODE',
  groupRevokeInvite: async () => 'MOCKINVITECODE',
  groupFetchAllParticipating: async () => ({
    '123456789-987654@g.us': { subject: 'Mock Group One', participants: [{ id: `${BOT_NUM}@s.whatsapp.net` }] },
  }),
  profilePictureUrl: async () => 'https://example.com/pp.jpg',
  fetchStatus: async () => ({ status: 'Mock status' }),
  // Interactive buttons (blacklord-bttns) are delivered via relayMessage, so
  // treat a relay as a reply too — otherwise .menu would look "silent".
  relayMessage: async (jid, message, opts) => {
    sent.push({ jid, content: message, relayed: true, opts });
    return { key: { id: 'MOCK_RELAY_' + sent.length } };
  },
  logout: async () => {},
};
const sock = new Proxy(baseSock, {
  get(target, prop) {
    if (prop in target) return target[prop];
    if (typeof prop === 'symbol') return undefined;
    return async () => ({ key: { id: 'MOCK' }, status: 200 });
  },
});

// ── 4. Mock inbound messages ─────────────────────────────────
const buildMsg = (body, { group = false, fromMe = true } = {}) => ({
  key: {
    remoteJid: group ? '123456789-987654@g.us' : `${BOT_NUM}@s.whatsapp.net`,
    fromMe,
    id: 'MSGID' + Math.random().toString(36).slice(2, 8),
    participant: group ? `${BOT_NUM}@s.whatsapp.net` : undefined,
  },
  mtype: 'conversation',
  message: { conversation: body },
  pushName: 'Verifier',
});

// ── 5. Isolate on-disk state ─────────────────────────────────
// Commands such as .setprefix / .self mutate database/*.json, which would
// change the prefix mid-run and make every later command look "silent".
// Snapshot the database, reset the test bot's settings before each command,
// and restore the original files when the run finishes.
const fs = require('fs');
const os = require('os');
const path = require('path');

const DB_DIR = path.join(__dirname, 'database');
const DB_SNAPSHOT = fs.mkdtempSync(path.join(os.tmpdir(), 'panel-db-'));

function snapshotDb() {
  if (fs.existsSync(DB_DIR)) fs.cpSync(DB_DIR, DB_SNAPSHOT, { recursive: true });
}
function restoreDb() {
  try {
    fs.rmSync(DB_DIR, { recursive: true, force: true });
    fs.cpSync(DB_SNAPSHOT, DB_DIR, { recursive: true });
    fs.rmSync(DB_SNAPSHOT, { recursive: true, force: true });
  } catch { /* best effort */ }
}
function resetBotSettings() {
  fs.writeFileSync(path.join(DB_DIR, 'settings.json'), JSON.stringify({
    [BOT_NUM]: {
      prefix: '.', mode: 'public', font: 0, owner: '', botName: ' 𝐔𝐋𝐓𝐑𝐀 𝐗𝐌𝐃 ', menuImg: '',
      antidelete: true, iphoneMode: false, autoViewStatus: false, autoLikeStatus: false,
    },
  }, null, 2));
}

snapshotDb();
process.on('exit', restoreDb);
process.on('SIGINT', () => { restoreDb(); process.exit(130); });

// ── 6. Collect the command inventory ─────────────────────────
const { handleMessage, CMDS, KNOWN_COMMANDS } = require('./case.js');

const advertised = new Map(); // cmd -> group
for (const [group, list] of Object.entries(CMDS)) {
  if (!Array.isArray(list)) continue;
  for (const c of list) if (!advertised.has(c)) advertised.set(c, group);
}

// switch cases implemented directly in case.js
const caseSrc = fs.readFileSync(path.join(__dirname, 'case.js'), 'utf8');
const directCases = new Set();
// Prefer the runtime registry; the source scan is only a fallback. Anchored at
// line start so the helper inside case.js that mentions the same text is ignored.
const switchHits = [...caseSrc.matchAll(/^ {2}switch \(cmd\) \{/gm)];
const switchBody = switchHits.length ? caseSrc.slice(switchHits[switchHits.length - 1].index) : '';
for (const m of switchBody.matchAll(/case\s+'([^']+)'\s*:/g)) directCases.add(m[1]);
// strip block comments so commented-out cases (e.g. credits) are excluded
for (const m of switchBody.matchAll(/\/\*([\s\S]*?)\*\//g)) {
  for (const c of m[1].matchAll(/case\s+'([^']+)'\s*:/g)) directCases.delete(c[1]);
}

// Registry from the running module when available (authoritative), else parsed.
if (KNOWN_COMMANDS && typeof KNOWN_COMMANDS[Symbol.iterator] === 'function' && KNOWN_COMMANDS.size) {
  for (const c of KNOWN_COMMANDS) directCases.add(c);
}
const allCmds = new Set([...advertised.keys(), ...directCases]);

// ── 7. Run every command ─────────────────────────────────────
// Some commands need a well-typed argument; "test" is a fine default for the
// rest but would produce a misleading "invalid input" reply for these.
const TEST_ARGS = {
  calculator: '2+2*5', math: '2+2', calc: '2+2',
  bmi: '70 1.75', age: '2000-01-01', tempconvert: '100 c f', unitconvert: '10 km mi',
  timezone: 'Africa/Nairobi', worldtime: 'Africa/Nairobi',
  tr: 'hello sw', translate: 'hello sw', translate2: 'hello sw',
  qr: 'https://example.com', qrgenerator: 'https://example.com',
  '8ball': 'will it work', ship: 'alice bob', ship2: 'alice bob', ratemyname: 'alice',
  wordcount: 'hello world', charcount: 'hello world', diff: 'a|b',
  base64: 'hello', unbase64: 'aGVsbG8=', b64enc: 'hello', b64dec: 'aGVsbG8=',
  hexenc: 'hello', hexdec: '68656c6c6f',
  md5: 'hello', sha256: 'hello', sha512: 'hello',
  regex: '/a/g hello', slug: 'Hello World!', timestamp: '1700000000',
  dice: '6', mine: '', play: 'mock song', playdoc: 'mock song', ytmp3: 'https://youtu.be/mock', ytmp4: 'https://youtu.be/mock',
  lyrics: 'mock song', lyrics2: 'mock song', lyrics3: 'mock song', spotify: 'mock song',
  ig: 'https://instagram.com/p/mock', instagram: 'https://instagram.com/p/mock',
  tt: 'https://tiktok.com/@mock', tiktok: 'https://tiktok.com/@mock',
  fb: 'https://facebook.com/mock', facebook: 'https://facebook.com/mock',
  twitter: 'https://twitter.com/mock', x: 'https://twitter.com/mock',
  pinterest: 'https://pinterest.com/pin/mock',
  stickerinfo: '', warn: '@254711111111 spam', promote: '@254711111111', demote: '@254711111111',
  kick: '@254711111111', mute: '@254711111111', unmute: '@254711111111',
  anticall: 'on', antidelete: 'on', antilink: 'on', antimedia: 'on', antimention: 'on',
  antispam: 'on', antibot: 'on', welcome: 'on', goodbye: 'on', iphonemode: 'on',
  autoviewstatus: 'on', autolikestatus: 'on', disap: 'on', slowmode: 'on',
  setprefix: '!', setbotname: 'MockBot', setowner: '254711111111',
  addprem: '12345', delprem: '12345', addowner: '12345', block: '254711111111',
  unblock: '254711111111', crypto: 'bitcoin', currency: '100 USD KES',
  weather: 'Nairobi', weather2: 'Nairobi', wikipedia: 'WhatsApp', news: 'tech',
  animeinfo: 'naruto', mangainfo: 'naruto', movieinfo: 'inception', gameinfo: 'minecraft',
  anisearch: 'naruto', charsearch: 'naruto', dictionary: 'hello', thesaurus: 'happy',
  football: 'arsenal', motivate: 'keep going', fakeid: 'John Doe',
  screenshot: 'https://example.com', reverseimage: 'https://example.com/x.jpg',
  shorten: 'https://example.com/very/long/url', shorturl2: 'https://example.com/very/long/url',
  tourl: 'https://example.com/x.jpg', ocr: 'https://example.com/x.jpg',
  tts: 'hello world', tr2: 'hello', quote: '', joke: '', fact: '', dare: '', truth: '',
  riddle: '', roast: 'alice', horoscope: 'aries', trivia: '', compliment: 'alice',
  bored: '', rps: 'rock', neverhaveiever: '', wouldyourather: '',
  emojimix: '😀 😎', attp: 'hello', whois: 'example.com', reversegif: '',
  poll: 'Best fruit? | Apple | Banana | Cherry', endpoll: '',
  delpair: '254704955033',
  carbon: 'const a = 1;', imagine: 'a cat wearing a hat',
  setgname: 'New Name', setgdesc: 'New description', warnlimit: '3',
  addprem2: '', ip2: '8.8.8.8', myip: '', dns: 'example.com', portscan: 'example.com',
  checkurl: 'https://example.com', ipinfo: '8.8.8.8', eval: '1+1',
  npm: 'axios', github: 'axios/axios', ghrepo: 'axios/axios', color: '#ff5733',
  color2: '#ff5733', hexcolor: '#ff5733', password: '16', lorem: '20', randstr: '16',
  uuid: '', jwt: 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxIn0.abc',
  vcard: 'John Doe|+254700000000', emoji: 'smile', emojisearch: 'smile',
  prompt: 'a cat', imagine: 'a cat', carbon: 'const a = 1;',
  jsonformat: '{"a":1}', jsoncheck: '{"a":1}', formatjson: '{"a":1}', tableify: 'a,b\n1,2',
  minify: 'const a = 1;', beautify: 'const a=1;', ts: '1700000000', randomstring: '16',
  quran: '1 1', hadith: '', dua: '', prayer: 'Nairobi', tafsir: '1 1',
  arabicname: 'mohamed', asmaullah: '', nasheeds: '', arabicpoem: '', arabicsticker: '',
  hijri: '', qibla: '', islamicfact: '', arabicquote: '',
};

const argsFor = (cmd) => (Object.prototype.hasOwnProperty.call(TEST_ARGS, cmd) ? TEST_ARGS[cmd] : 'test');

const results = [];
const isBadText = (t) => typeof t === 'string' && (t.includes('[object Object]') || t.includes('undefined'));

(async () => {
  for (const cmd of [...allCmds].sort()) {
    resetBotSettings();               // keep every command independent
    const before = sent.length;
    const argStr = argsFor(cmd);
    const body   = argStr ? `.${cmd} ${argStr}` : `.${cmd}`;
    let error = null;
    try {
      await handleMessage(sock, buildMsg(body), { groupName: '' });
      resetBotSettings();
      await handleMessage(sock, buildMsg(body, { group: true }), { groupName: 'Mock Group' });
    } catch (e) {
      error = `${e.name}: ${e.message}`;
    }
    const produced = sent.slice(before);
    const texts = produced.map(p =>
      p.content?.text ||
      p.content?.caption ||
      p.content?.interactiveMessage?.body?.text ||
      p.content?.viewOnceMessage?.message?.interactiveMessage?.body?.text ||
      p.content?.viewOnceMessageV2?.message?.interactiveMessage?.body?.text ||
      ''
    ).filter(Boolean);
    const bad = texts.find(isBadText);
    results.push({ cmd, group: advertised.get(cmd) || '(case.js)', error, replies: produced.length, badText: bad || null });
  }

  const broken = results.filter(r => r.error);
  const malformed = results.filter(r => !r.error && r.badText);
  const silent = results.filter(r => !r.error && r.replies === 0);

  console.log('\n================ COMMAND VERIFICATION ================');
  console.log(`commands tested        : ${results.length}`);
  console.log(`network calls stubbed  : ${netCalls.get} GET / ${netCalls.post} POST`);
  console.log(`OK (replied, no error) : ${results.length - broken.length - malformed.length - silent.length}`);
  console.log(`THREW                  : ${broken.length}`);
  console.log(`MALFORMED reply        : ${malformed.length}`);
  console.log(`SILENT (no reply)      : ${silent.length}`);

  if (broken.length) {
    console.log('\n---- THREW ----');
    for (const r of broken) console.log(`  ${r.cmd.padEnd(20)} [${r.group}] ${r.error}`);
  }
  if (malformed.length) {
    console.log('\n---- MALFORMED ----');
    for (const r of malformed) console.log(`  ${r.cmd.padEnd(20)} [${r.group}] ${JSON.stringify(r.badText).slice(0, 120)}`);
  }
  if (silent.length) {
    console.log('\n---- SILENT (no reply) ----');
    for (const r of silent) console.log(`  ${r.cmd.padEnd(20)} [${r.group}]`);
  }
  console.log('=====================================================\n');

  fs.writeFileSync(
    path.join(__dirname, 'command-verification-report.json'),
    JSON.stringify({ total: results.length, broken, malformed, silent, results }, null, 2)
  );
  process.exit(broken.length ? 1 : 0);
})();
