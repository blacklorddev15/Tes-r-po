# SKYLAR X ULTRA panel — command repair report

Source: `https://github.com/blacklorddev15/Back` (`d_Skylar-X-ULTRA-panel.zip`)

Result: **565 / 565 commands now dispatch and reply** — 0 throwing, 0 silent, 0 malformed.
(Verified with `panel/verify-commands.js`; machine-readable output in `panel/command-verification-report.json`.)

---

## 1. Why "some commands were not working"

Five independent defects, three of which were fatal to whole groups of commands.

### 1.1 Every command-list array was commented out (fatal)

All 13 command modules declared their command registry inside a block comment, while still
referencing it at runtime:

```js
/*const SCRAPS_CMDS = [ 'ytmp3', 'ytmp4', ... ];*/   // ← declared but commented out

async function scrapsHandler(sock, m, cmd, args, helpers) {
  if (!SCRAPS_CMDS.includes(cmd)) return false;     // ← ReferenceError
```

`ReferenceError: SCRAPS_CMDS is not defined` was thrown by the **first** sub-handler in the
dispatch chain, so the chain aborted before any handler ran and the incoming message was
dropped in silence. `case.js` also destructured these names, so `CMDS` was populated with
`undefined` for 13 of its 17 groups.

Affected: `helper/reactions.js`, `scraps.js`, `illusion.js`, `social.js`, `ai.js`, `economy.js`,
`tools.js`, `stickers.js`, `music.js`, `games.js`, `admin.js`, `arabic.js`, `dev-commands.js`.

**Fix:** uncommented each array and added it to that module's `module.exports`.

### 1.2 `replyImg` was never defined (fatal)

`case.js` built its helper bundle with a shorthand property for an identifier that did not exist:

```js
const h = { reply, replyImg, ft, cfg, dlMedia, reaction, ... };  // ReferenceError
```

Any command not handled by `case.js`'s own switch died there. Separately, ~17 `case` blocks
inside `case.js` called `replyImg(...)` directly.

**Fix:** implemented `replyImg` (buffer or URL → image, text fallback on failure).

### 1.3 `prefix` was referenced ~70 times but never declared

`case.js` defined `storedPrefix` and then used a bare `prefix` in usage hints, copy-code
buttons and menu text. 35 commands — including `sticker`, `welcome`, `antilink`, `pair`,
`instagram`, `tiktok`, `setowner` — died with `ReferenceError: prefix is not defined`.

**Fix:** declared `const prefix = storedPrefix;` once, in `handleMessage` scope.

### 1.4 Helper signature mismatches

| Helper | Supplied as | Expected as | Effect |
|---|---|---|---|
| `react` | `reaction` only | `react(...)` — dev-commands | `TypeError: react is not a function` |
| `isOwner` | boolean | `helpers.isOwner(m, sock)` — dev-commands | `TypeError`, so `.eval` / `.exec` never replied |
| `reply` | `reply(txt)` | `reply(sock, m, txt)` — dev-commands | would have sent `[object Object]` |

**Fix:** `reply` and `replyImg` now accept both call styles; `react` is aliased to `reaction`
and both accept both arg styles; `isOwnerFn` was added alongside the boolean `isOwner`.

### 1.5 `require('@whiskeysockets/baileys')` was not a dependency

`package.json` declares `blacklord-baileys`, but **16 call sites** across `case.js`,
`stickers.js`, `illusion.js`, `helper/listeners.js` and `dev-commands.js` hard-required
`@whiskeysockets/baileys`. Every media download (`.sticker`, `.toimg`, `.vv`, view-once
forwarding, all `enc*/dec*` dev commands, every illusion filter) threw `MODULE_NOT_FOUND`.

**Fix:** added `helper/baileys.js`, a resolver that loads whichever Baileys build is actually
installed (`blacklord-baileys` → `@whiskeysockets/baileys` → `baileys` → old fork) and exposes
`downloadMediaMessage` with a `downloadContentFromMessage` fallback. All 16 sites now require
the resolver. Resolved library on this install: **blacklord-baileys**.

---

## 2. Advertised but never implemented

Beyond the crashes, **120 commands were listed in the menus but had no implementation** — they
either fell through to `default: return false` (no reply at all) or hit a module placeholder
such as `⚠️ *${cmd}* — Reply to an image/video to use this command` / `— Coming soon!`.

All 120 now have real implementations:

| File | Implemented | Notable approach |
|---|---|---|
| `stickers.js` | 18 | sharp pipelines, hand-written RIFF/WebP EXIF writer (no `node-webpmux` needed), gstatic emoji-kitchen |
| `illusion.js` | 1 | sharp composite glow/sheen for `shine` |
| `arabic.js` | 7 | alquran.cloud (`ar.muyassar` tafsir), aladhan.com (`/v1/qibla`, `/v1/asmaAlHusna`) |
| `music.js` | 24 | Deezer public API, iTunes Search API, MusicBrainz, lyrics.ovh, Genius search |
| `admin.js` | 26 | native group metadata / `groupParticipantsUpdate` / `groupSettingUpdate` + per-group JSON stores |
| `games.js` | 15 | real playable state (tictactoe board, wordle scoring, memory, akinator tree) in `database/games.json` |
| `economy.js` | 10 | real balance mutations with validation, blackjack hand state, farming, heists |
| `social.js` | 10 | deterministic hashing for stable per-subject results + persisted rant/confession walls |
| `ai.js` | 4 | existing `askClaude` path; explicit "AI key not configured" instead of fake output |
| `case.js` | 6 | `carbon`, `imagine` (keyless text-to-image), `typeracer`, `delpair`, and a new `poll` / `endpoll` pair |

### Honest gaps (not fabricated)

These reply with an explicit statement of what is missing rather than inventing data:

- **MP4 → sticker** (`sticker2`, `tomp4sticker`, `gifsticker`, `videosticker`): needs `ffmpeg`, absent on the host. GIF/image paths work.
- **`nasheeds`**: no free, keyless nasheed audio API.
- **Audio fingerprinting** (`shazam2`, `identify`, `fingerprint`, `beatmatch`, `remix`): needs ACRCloud / AcoustID / aubio.
- **`suno`, `udiogen`**: generative-audio services require a paid key.
- **`musixmatch`, `soundcloud` (search)**: require an API key / client id. `soundcloud` still works for track URLs via keyless oEmbed.
- **`key`, `bpm`**: no keyless API publishes musical key; these report only provider-published values.

---

## 3. Other fixes

- **Resilient dispatch.** Each sub-handler in `case.js`'s `default:` branch is now isolated in
  try/catch, so one failing module can never take down the rest of the chain again; failures are
  logged as `[CMDHANDLER] <module>:<cmd> -> <error>`.
- **`.delpair <number>` added.** The WhatsApp `.pair` command advertised "*Use .delpair <number> to
  disconnect*", but `delpair` only existed as a Telegram panel command, so that hint pointed at
  nothing. It is now implemented on the WhatsApp side too (owner-only logout + session delete)
  and registered in the Owner command list.
- **`poll` added** to the Group command list so `endpoll` has something to close. Votes are
  recorded from Baileys `messages.update` / `pollUpdates` (wired in `index.js`) and tallied from
  `database/polls.json`. One active poll per chat.
- **`.eval` returned `undefined` for every expression.** The sandbox wrapped input as
  `(async()=>{1+1})()` — an arrow *block*, not a return. It now tries `return (...)` first and
  falls back to statement mode for multi-statement input.
- **Raw-body replies hardened.** `weather`, `shorten`, `pastebin`, `shorturl2` interpolated the
  HTTP body directly, producing `[object Object]` whenever an upstream answered with JSON.
  They now coerce via a shared `asPlainText` / `asText` helper.
- **Dependencies.** Added to `package.json`: `canvas ^3.2.3`, `js-confuser ^2.1.3`,
  `prettier ^3.9.6`, `terser ^5.51.2`. All four were required by `welcomeImg.js` /
  `dev-commands.js` but undeclared.
- **`.gitignore`-worthy state.** The verifier snapshots and restores `database/`, so running it
  no longer mutates the bot's saved settings.

---

## 4. How to re-verify

```bash
cd panel
npm install
node verify-commands.js          # exit 0 = all commands OK
```

The script stubs the socket and the network, drives `handleMessage()` for every advertised
command in both a DM and a group, and reports commands that throw, reply with malformed text
(`[object Object]` / `undefined`), or stay silent. Latest run:

```
commands tested        : 565
OK (replied, no error) : 565
THREW                  : 0
MALFORMED reply        : 0
SILENT (no reply)      : 0
```

Per-module `CMDS` ↔ `case` parity is now 1:1 everywhere (`reactions.js` is dictionary-driven
rather than switch-driven, and `dev-commands.js` additionally exposes 22 alias names).

---

## 5. Security note (pre-existing, unchanged)

`case.js` and `settings.js` contain hard-coded credentials: a GitHub personal access token
(`GITHUB_TOKEN`), a Neon Postgres connection string, a Telegram bot token and Telegram owner
IDs. These are in the public zip. They are outside the scope of this repair, but they should be
moved to `.env` and the exposed tokens rotated.

---

## 6. Anti-delete now reports to the paired number's DM

**Before:** `handleAntiDelete` re-posted the recovered message back into
`key.remoteJid` — the very chat the message was deleted from. So a deletion in a group was
re-published to the whole group (announcing the recovery to everyone, and often to the person
who deleted it).

**After:** the recovered message is delivered to the **paired number's own DM**
(`"Message yourself"`), with the source chat named in the header so the owner knows where it
came from:

```
🚫 AntiDelete
👤 From: Alice (+254711111111)
💬 Chat: Test Group

📝 the deleted message
```

- Destination is `sock.__waNum@s.whatsapp.net`, falling back to `sock.user.id` when `__waNum`
  is not yet set.
- If the DM send fails, it falls back to the source chat so nothing is lost.
- `mentions` are only attached when delivering into a group (the fallback path) — in a DM they
  are meaningless.
- The header now includes the sender number and the originating chat.

Two bugs found and fixed while testing:

1. **`fromMe` guard was incomplete.** It read `key.fromMe` from the event only; it now also
   checks the stored key, so the account's own deletions stay skipped even when the update
   omits the flag.
2. **The view-once branch was dead code.** `storeMessage()` unwraps `viewOnceMessage*` before
   storing, so `handleAntiDelete` could never see the wrapper and a deleted view-once was
   mislabelled as a plain image. `storeMessage()` now records a `viewOnce` flag and the handler
   uses it, restoring the `👁 Deleted View Once` label.

Verified by `panel/verify-antidelete.js` — 17 assertions, all passing:
group text → paired DM · source chat named · no mentions in DM · DM failure → source-chat
fallback · private-chat deletion → paired DM · toggle off → silent · `fromMe` skipped ·
unstored message ignored · undownloadable image · sticker · view-once · unknown type ·
batch deletions.

```bash
cd panel
node verify-antidelete.js     # 17 passed, 0 failed
node verify-commands.js       # 565/565, exit 0
```

---

## 7. Reply frame re-styled + newsletter forwarding

`reply()` in `case.js` was rebuilt to the requested SKYLAR X ULTRA look.

**Frame** — `top` and `footer` are now exactly the supplied templates (two
`ꪶ ཻུ۪۪ꦽꦼ̷⸙` flourishes on each line):

```
╭━━•›ꪶ ཻུ۪۪ꦽꦼ̷⸙〘  🌸 PING 🌸 〙 ꪶ ཻུ۪۪ꦽꦼ̷⸙‹━•⩵꙰ཱི࿐
├◆ 🏓 Pong! 1ms
╰━━•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙‹•━•⩵꙰ཱི࿐
```

**One message only.** The separate banner (`✿ 🌹𝐒𝐊𝐘𝐋Λ𝐑 𝐗𝐌𝐃🌹 ✿`) is gone; a reply is now a
single send. The blockquote wrapper was dropped too, otherwise every `>` prefix would break the
ornate frame — the `blockquote` helper is left defined in `case.js` if you want it back.

**Forwarded from the channel.** Every reply now carries the WhatsApp "Forwarded" tag via
`addNewsletterContext()`, pointing at the SKYLAR X ULTRA newsletter:

```js
const NEWSLETTER_JID  = '120363407629340544@newsletter';
const NEWSLETTER_NAME = 'SKYLAR X ULTRA';
// contextInfo: { forwardingScore: 999, isForwarded: true,
//                forwardedNewsletterMessageInfo: { newsletterJid, newsletterName, serverMessageId: -1 } }
```

Confirmed with `generateWAMessageFromContent` that the forwarding info survives the
`{ quoted: m }` merge — the final message keeps `isForwarded: true`, `forwardingScore: 999` and
the newsletter info, while also quoting the triggering message.

Verified: `node verify-commands.js` → 565/565, exit 0; `node verify-antidelete.js` → 17/17.

---

## 8. Menu now ships with a Skylar-site button

`blacklord-bttns` had been declared in `package.json` but was never actually used anywhere.
It is now wired in as the button engine, per its docs at
<https://github.com/blacklorddev15/blacklord-btns>.

**Menu output is now a single interactive message** (`case 'menu'`), sent through
`sendButtons()` with one URL button:

| Field | Value |
|---|---|
| header title | `🌹𝐒𝐊𝐘𝐋Λ𝐑 𝐗 𝐔𝐋𝐓𝐑𝐀🌹` |
| body | the full command list (same text as before) |
| footer | `〖𝐒𝐊𝐘𝐋Λ𝐑 𝐗 𝐔𝐋𝐓𝐑𝐀〗 • https://skylar-pairing.vercel.app` |
| button | `cta_url` — `🔗 𝑺𝑲𝒀𝑳Λ𝑹 𝑷𝑨𝑰𝑹𝑰𝑵𝑮 𝑺𝑰𝑻𝑬` → **https://skylar-pairing.vercel.app** |
| forwarding | SKYLAR X ULTRA newsletter tag, same as every other reply |

`blacklord-socket` resolves to `blacklord-baileys` through the existing `overrides` entry, which
is what `blacklord-bttns` imports `generateWAMessageFromContent` from — so no extra dependency
was needed. `blacklord-bttns` is ESM and is `require()`d directly (Node ≥22); the loader is
wrapped in try/catch so an older Node or a missing package degrades instead of crashing.

**Fallback preserved:** if the buttons send throws, the menu falls back to the previous
image-caption menu, then to plain text — so the menu can never go silent.

Verified with a capture harness: `relayMessage` is called once with the `biz / interactive /
native_flow` stanza, the `cta_url` button payload, and `isForwarded: true`. The harness
(`verify-commands.js`) was updated to count a `relayMessage` as a reply, otherwise `.menu` would
have been misreported as silent.

```
commands tested        : 565
OK (replied, no error) : 565
THREW / MALFORMED / SILENT : 0 / 0 / 0
```

> **Known limit:** the command list body is ~7,200 characters. WhatsApp caps interactive-message
> bodies far below that, so on a live account the tail of the list is likely to be truncated —
> the same applied to the old image-caption menu (captions cap at 1,024 characters). If you hit
> that, the fix is paging the menu by category (e.g. `.menu 2`) or switching the button to a
> `btn.list()` with one row per category. Say the word and I'll page it.

---

## 9. `.btntest` — button rendering diagnostic

Added an owner-only `case 'btntest'` to `case.js`. The full `.menu` body is **~7,200 characters**,
far past what WhatsApp accepts for an interactive message, so if the menu's interactive message is
rejected or truncated the button silently never arrives. `.btntest` sends a deliberately short
interactive message (one URL button, ~180-char body) through the same
`sendButtons()` → `blacklord-bttns` path, so you can tell these two failures apart:

| Symptom on `.btntest` | Meaning |
|---|---|
| button renders and taps open the site | native-flow buttons work on that client — the menu problem is body length |
| text arrives, no button | your WhatsApp build is not rendering native-flow buttons |
| `❌ Button send failed: …` | the send itself threw — the message never left the bot |

```bash
# in WhatsApp, from the owner account
.btntest
```

Verified: `node verify-commands.js` → **566/566**, exit 0.

---

## 10. Button fix, baileys check, and the chatbot

### 10.1 Why the button wasn't coming

The bot-side code was already correct — but the interactive message body was **7,203 characters**.
WhatsApp caps interactive-message bodies far below that, so the client drops the interactive
content and the button never arrives. Critically, this failure is *silent*: the send succeeds, so
there is no error to catch.

`.menu` now sends **two** messages:

1. an **interactive message with a 612-character body** — system info + category list + the
   `🔗 𝑺𝑲𝒀𝑳Λ𝑹 𝑷𝑨𝑰𝑹𝑰𝑵𝑮 𝑺𝑰𝑻𝑬` → `https://skylar-pairing.vercel.app` button (well inside the limit)
2. the **full command list** (7,195 chars) as a normal text message

Also fixed: the menu's uptime read `NaNd NaNh NaNm NaNs` when `global.botStartTime` was unset.

### 10.2 Baileys

`blacklord-baileys@1.0.1` is already the latest published version — `npm view blacklord-baileys
version` returns `1.0.1`, matching what is installed, and `package.json` already pins `"latest"`.
There is nothing to upgrade. `blacklord-socket` is not published separately; your `overrides`
entry maps it to `blacklord-baileys`, which is how `blacklord-bttns` resolves its
`generateWAMessageFromContent` import, and `helper/baileys.js` resolves to `blacklord-baileys`.

### 10.3 Chatbot was dead — all four AI endpoints are offline

Verified live:

| Endpoint | Result |
|---|---|
| `zellapi.autos` | connection failure (HTTP 000) |
| `hercai.onrender.com` | 503 |
| `discardapi.dpdns.org/api/chat/spark` | 503 |
| `discardapi.dpdns.org/api/bot/llama` | 503 |

Every chatbot message therefore ended in *"Hmm, I'm having trouble replying right now."*

Replaced with a raced provider chain:

- **Keyed (recommended, tried first)** — `GROQ_API_KEY`, `OPENAI_API_KEY`, `OPENROUTER_API_KEY`,
  read from `.env` or `settings.js`
- **Keyless best-effort** — Pollinations `POST /openai`, then the text endpoint
- Providers now run **in parallel** and the first usable answer wins (reply latency 17s → ~5s)

Two further bugs found while testing:

1. **Upstream error text was being sent to users as a reply.** Pollinations answered with the
   literal string *"The API key used for this request has reached its budget…"* inside
   `choices[0].message.content`, and the filter only covered plain-text providers. The usability
   filter now applies to **every** provider.
2. **The chatbot went silent when no provider worked.** Added a small local fallback responder
   (greetings, thanks, bye, time/date, help) so the chatbot always answers something sensible.
   It is deliberately transparent — it never pretends to be the AI.

Honest limitation: **keyless AI endpoints are not dependable** (exhausted keys, 429 queue limits,
403s). For a chatbot that replies reliably, set `GROQ_API_KEY` in `.env` — Groq's free tier is
enough. The three key names are now documented in `.env.example`.

Verified: chatbot end-to-end over the real network returns `"Hey! 👋 How can I help you today?"`
in 5.3s; `node verify-commands.js` → **566/566**; `node verify-antidelete.js` → **17/17**.

---

## 11. Real cause of the missing button: the library omits a required wrapper

Splitting the menu body (section 10) was necessary but **not sufficient** — the button still did
not render. The actual cause is in `blacklord-bttns` itself.

Its README documents the option and says it is mandatory:

```
viewOnce?: boolean      // default true -- required by current WhatsApp
                        // clients to render native-flow buttons correctly
```

Its implementation does the opposite — `index.js` line 136:

```js
// No viewOnceMessage wrapper -- interactiveMessage goes at the top level.
```

Current WhatsApp clients accept that send, then **silently discard the buttons**: no error, no
log, no button. That is why the failure looked invisible from the bot side.

This project's own working interactive blocks use the wrapper — e.g. `case1.js.bak` line 6499 and
`case.js` line 2836 — which is the pattern that actually renders:

```js
generateWAMessageFromContent(jid, {
  viewOnceMessage: { message: {
    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
    interactiveMessage: proto.Message.InteractiveMessage.fromObject({ ... }),
  }},
}, { quoted, userJid: sock.user?.id })
→ sock.relayMessage(jid, msg.message, { messageId: msg.key.id, additionalNodes: [biz/interactive/native_flow] })
```

**Fix:** added `sendInteractiveButtons()` to `case.js`, which builds and relays the message with
the `viewOnceMessage` wrapper + `messageContextInfo` + the `biz → interactive → native_flow`
stanza. `blacklord-bttns` is still used for its `btn` builders, and its `sendButtons()` is kept as
a secondary attempt. Verified payload for `.menu`:

```
shape             : viewOnceMessage > message > interactiveMessage  ✅
messageContextInfo: present ✅
body length       : 612
buttons           : [{"display_text":"🔗 𝑺𝑲𝒀𝑳Λ𝑹 𝑷𝑨𝑰𝑹𝑰𝑵𝑮 𝑺𝑰𝑻𝑬",
                     "url":"https://skylar-pairing.vercel.app","merchant_url":"..."}]
additionalNodes   : biz/interactive/native_flow
```

### `.btntest` now compares both shapes

It sends two labelled messages so you can see which one renders on your client:

| Message | Shape | Expected |
|---|---|---|
| **A — wrapped** | `viewOnceMessage` wrapper (the fix) | button renders |
| **B — top-level** | bare `interactiveMessage` (what the library sends) | no button |

Whichever shows a working button tells us the correct shape for `.menu`. The verifier harness was
also updated to read interactive bodies from inside the `viewOnceMessage` wrapper — otherwise
`.menu` would have been misreported as silent.

Verified: `node verify-commands.js` → **566/566**, exit 0 · `node verify-antidelete.js` → 17/17.

---

## 12. Anti-delete never fired — wrong event was being listened to

Section 6 changed *where* the recovery is delivered. It did not fix *whether* it fires at all.

**Root cause:** the bot only listened on `messages.delete`. In
`blacklord-baileys@1.0.1` that event is emitted **only for "delete for me"** —
`Utils/chat-utils.js`:

```js
else if (action?.deleteMessageForMeAction || type === 'deleteMessageForMe') {
    ev.emit('messages.delete', { keys: [ { remoteJid: id, id: msgId, fromMe: fromMe === '1' } ] })
```

**"Delete for everyone"** — the case that actually matters — is emitted elsewhere, in
`Utils/process-message.js`:

```js
case proto.Message.ProtocolMessage.Type.REVOKE:
    ev.emit('messages.update', [{
        key: { ...message.key, id: protocolMsg.key.id },
        update: { message: null, messageStubType: WAMessageStubType.REVOKE, key: message.key }
    }]);
```

So a revoke arrives as a **`messages.update` carrying a `REVOKE` stub (`WAMessageStubType.REVOKE = 1`)**,
and nothing was listening for it. Anti-delete was dead for every group message someone else deleted.

**Fix:**

- `helper/listeners.js` — added `revokedKeysFromUpdates(updates)`, which pulls the **original
  message key** out of a revoke update (`update.key`, not the outer key, which belongs to the revoke
  protocol message itself).
- `index.js` — the existing `messages.update` handler now routes revokes into `handleAntiDelete`
  alongside the poll-vote handling. The `messages.delete` listener is kept, so "delete for me" still works.

**Verified** by `panel/verify-antidelete.js` — now **22 assertions**, including:

| Assertion | Result |
|---|---|
| revoke via `messages.update` → paired number DM | PASS |
| revoke recovers the original text | PASS |
| revoke key resolves to the original id, not the protocol id | PASS |
| non-revoke updates (edits) ignored | PASS |
| revoke of an unstored message ignored, no crash | PASS |

```
node verify-antidelete.js   →  22 passed, 0 failed
node verify-commands.js     →  566/566, exit 0
```

---

## 13. Menu is one message again: header image + full list + button

Section 10 split `.menu` into **two** sends (a short interactive card + the full list as a text
message) because the button would not render. Section 11 then found the real cause of the missing
button — the library omits the `viewOnceMessage` wrapper — so the split was never actually
required. `.menu` now ships as **a single message** again.

### What `.menu` sends now

| Part of the one message | Content |
|---|---|
| header media | the menu image (`c.menuImg` or `settings.DEFAULT_MENU_IMG`), uploaded once and cached for 30 min |
| header title | `🌹𝐒𝐊𝐘𝐋Λ𝐑 𝐗 𝐔𝐋𝐓𝐑𝐀🌹` |
| body | the **full command list** — 7,195 chars, 17 categories, 537 commands |
| footer | `〖𝐒𝐊𝐘𝐋Λ𝐑 𝐗 𝐔𝐋𝐓𝐑𝐀〗` |
| button | `cta_url` — `🔗 𝑺𝑲𝒀𝑳Λ𝑹 𝑷𝑨𝑰𝑹𝑰𝑵𝑮 𝑺𝑰𝑻𝑬` → `https://skylar-pairing.vercel.app` |

### Changes

- `sendInteractiveButtons()` now accepts an `imageMessage` and puts it on the interactive
  **header** (`hasMediaAttachment: true` + `header.imageMessage`), which is what allows image +
  body + button to travel as one message. Existing callers (`.btntest`) are unaffected — without
  the argument the header stays text-only.
- New `menuHeaderImage()` + `loadImageBuffer()`: fetches the menu image (data-URL, http, or local
  path), uploads it via `prepareWAMessageMedia` / `sock.waUploadToServer`, and caches the
  resulting `imageMessage` for 30 minutes. Without the cache every `.menu` would pay a media
  upload round trip. Images under 200 bytes are rejected — a truncated fetch must not become a
  broken header.
- `case 'menu'` rewritten: **one** send. Removed the second full-list text message, the short
  `menuCard` body, and the image-caption / plain-text fallback chain. The only remaining fallback
  fires if the interactive send *throws*, and it is still a single message.
- **No forwarded channel tag.** The menu no longer attaches `NEWSLETTER_CONTEXT` (`isForwarded`,
  `forwardingScore`, `forwardedNewsletterMessageInfo`) and no longer quotes the channel
  (`qchanel`). It quotes the user's own command instead.
- **No printed link.** The raw pairing URL was removed from the body and the footer; it now exists
  only inside the button payload.

### Verified

`node verify-menu.js` — 22 assertions, all passing:

```
exactly ONE message delivered ...................... PASS (1 relay, 0 extra sends)
shape viewOnceMessage > interactiveMessage ......... PASS
header.hasMediaAttachment = true ................... PASS
header.imageMessage with url + directPath .......... PASS
body = FULL command list ........................... PASS (7195 chars, 537 commands, 0 missing)
exactly ONE button, cta_url -> pairing site ........ PASS
no forwarded / newsletter fields ................... PASS
no raw pairing URL in body or footer ............... PASS
repeat .menu re-uses the uploaded image ............ PASS (0 extra fetches)
iphoneMode: one message, no image, button kept ..... PASS
relay failure: single text fallback ................ PASS
```

`node verify-commands.js` → **566/566**, exit 0 (no regression).

Independently re-checked by a separate verifier pass: `node --check case.js` clean, the same 22/22
and 566/566 results reproduced, and the exact relayed payload round-tripped through
`proto.Message.encode` → `decode` (7,462 bytes) with `hasMediaAttachment: true`, the `imageMessage`
(url / directPath / mediaKey / mimetype) intact, the 7,195-char body intact, and the `cta_url`
params intact. Not verifiable in this environment: how a real client renders a 7,195-character
interactive body alongside header media and a button — that needs a live account.

> **Remaining limit — body length.** WhatsApp caps interactive-message bodies (and image captions)
> around **1,024 characters**; the full list is **7,195** (6,806 before font conversion). The body is
> sent complete, so if the client truncates it the tail of the list is what suffers — the image and
> the button are unaffected. Options if that happens: page the list (`.menu 2`, `.menu 3`, …), send
> a compact body (all 537 names, no decoration: 5,460 chars, or 4,268 with a flat name list — both
> still over the cap), or move categories into a `btn.list()` dropdown. Ask and it is a small change.
>
> Note the fallback cannot cover this case: an over-length body is dropped **silently by the client**
> — `relayMessage` still resolves, so `menuSent` stays true and no fallback fires. A live-account
> test on `.menu` is the only way to confirm how your client handles 7,195 characters.

---

## 14. autoviewstatus / autolikestatus — audited against a working reference

Compared against `handleStatusWatcher` in ELITE-PRO-V1 (same Baileys family) and fixed three
defects in the status branch of `case.js`:

1. **Status likes were accepted and silently dropped.** The reaction was sent with the incoming
   key and no options. A status reaction is only delivered when the target is listed in
   `statusJidList`, so the like never reached anyone:
   ```js
   await sock.sendMessage('status@broadcast',
     { react: { text: emoji, key: statusKey } },
     { statusJidList: [target] });          // ← this was missing
   ```
2. **LID participants were used as the status target.** Modern statuses can arrive with a
   `@lid` participant, which is not a valid target. `resolveStatusTarget()` now prefers a real
   `@s.whatsapp.net` address (`participantAlt` / `participantPn` first).
3. **No dedupe, no error visibility.** The same status could be viewed/liked repeatedly as updates
   arrived, and failures were swallowed by empty `catch {}`. Now: a 5-minute processed-id set, and
   `logInfo` / `logError` lines (`[Status] viewed …`, `[Status] like failed …`).

Also added `autoLikeStatusEmoji` (default `❤️`) to the settings defaults, matching the reference,
and reaction/protocol traffic on the status feed is ignored rather than treated as a status.

## 15. Chatbot replaced with the ELITE-PRO-V1 function

Ported `handleChatbot` from ELITE-PRO-V1 `index.js` into `case.js`, per request:

| Ported | Detail |
|---|---|
| endpoint | `GET https://eliteprotech-apis.zone.id/deepai?prompt=…` (verified live: HTTP 200, 2.7s) |
| response handling | reads `data.success` / `data.response` |
| dedupe | one reply per message id, 60 s window |
| memory | rolling per-sender transcript, 15 turns, dropped after 30 min idle (sweeper interval) |
| presence | `composing` before the call, `paused` after |
| reply | quoted to the triggering message, sent **in the chat the bot was addressed in** |
| skips | `fromMe`, status broadcasts, empty bodies, command-prefixed text |

**ELITE-only**, as requested: this path tries no other provider. If the call throws or returns an
unusable payload, exactly one short line goes out:
`❌ The assistant is unavailable right now — please try again.`

Note on parity: the reference builds a `basePrompt` containing the transcript but sends only the
raw text (its endpoint keeps the session server-side), so this port sends the text alone. The
transcript is still maintained, trimmed and TTL'd — ready if you want it included in the prompt.

The earlier provider chain (`aiProviders` / `getAIResponse` / `localChatbotReply` / `usableAiText`)
and the panel's own `chatMemory` / `extractUserInfo` are **no longer called by anything**. They are
left in place behind an explanatory comment and can be deleted on request.

## 16. Chatbot now answers only when tagged or replied to

The gate applies in **groups and DMs** (as chosen). A message wakes the chatbot only when:

- the bot is **tagged** — `contextInfo.mentionedJid` contains one of the bot's JIDs, or the text
  contains `@<bot number>` typed by hand; or
- the message is a **reply to one of the bot's own messages** — `contextInfo.participant` resolves
  to the bot, including the device-suffixed `2547…:12@s.whatsapp.net` form.

Anything else is ignored silently. When a tag triggered the reply, the `@number` is stripped from
the prompt before it is sent. Commands (`.menu`) never reach the chatbot.

```
node verify-chatbot.js   →  32 passed, 0 failed
```

Covers: chatbot off · group plain (silent) · group tagged (replies **in the group**) · group reply
to bot · group reply to a device-suffixed bot JID · group reply to another member (silent) · DM
plain (silent) · DM reply to bot · DM reply to another person (silent) · command ignored ·
duplicate id deduped · ELITE failure → one error line and no fallback provider · ELITE success →
verbatim reply, quoted · and the seven status cases (off, view only, like only, both, LID
resolution, dedupe, reaction feed ignored).

Regression on the rest of the panel: `verify-commands.js` **566/566**, `verify-menu.js` **22/22**,
`verify-antidelete.js` **22/22**.

---

## 17. Post-verification hardening (independent verifier findings)

An independent adversarial pass reproduced all four harnesses and the port parity, then found
four genuine defects. All are fixed and covered by new assertions:

1. **Over-trigger: a bare bot number counted as a tag.** `chatbotTrigger` built
   ``new RegExp(`@?${digits}(?!\\d)`)`` — the `@` was optional, so the ordinary sentence
   `"ping 254700000000 at noon"` triggered a reply. The `@` is now required. A hand-typed
   `@2547…` still triggers, and the number is still stripped from the prompt.
2. **`.chatbot` help text contradicted the new gate.** The DM branch promised *"I'll reply to every
   DM message"* / *"I'll now reply to your DM messages"*. Both now say the bot answers when you
   reply to one of its messages.
3. **The chatbot was unreachable in prefix-free chats.** With `prefixfree` on, the first word of
   any message was treated as a command and the handler returned before the chatbot ran. An
   unrecognised first word now falls through to the chatbot (a real command still dispatches as a
   command).
4. **Document captions never reached the chatbot.** The body extraction covered conversation /
   image / video / extended-text but not `documentMessage`, so a captioned document was invisible.
   Added to the chain.

Also fixed in this pass:

- **The command registry is now a single source of truth.** `case.js` derives `DIRECT_CMDS` by
  reading the real dispatch switch out of its own source (anchored at line start so the helper
  cannot match its own text) and exports `KNOWN_COMMANDS` (566 names). The first version of that
  helper matched the wrong `switch (cmd) {` occurrence — its own string literal — which silently
  cut the registry to 32 names and made `verify-commands.js` report 533 instead of 566. The
  harness now consumes the exported registry and keeps the source scan only as a fallback, so the
  two can no longer drift apart.

Already correct in the earlier passes, confirmed by the verifier: ELITE-only single-message failure
path, port parity on endpoint / query / success flag / dedupe / presence / quoted reply / sweeper,
no missing-gate bypass in groups or DMs, status branch (view, like, `statusJidList`, LID→PN
resolution, dedupe), and antidelete revoke + `messages.delete` delivery to the paired number DM.

```
node verify-chatbot.js   →  37 passed, 0 failed   (was 32; +5 regression assertions)
node verify-menu.js      →  22 passed, 0 failed
node verify-antidelete.js→  22 passed, 0 failed
node verify-commands.js  →  566/566, exit 0
```

**Not verifiable in this environment** (stated plainly rather than assumed): real WhatsApp delivery
effects — sending, read receipts, status reactions, LID→PN resolution in the wild — and whether
`eliteprotech-apis.zone.id/deepai` stays up or keeps returning `{success, response}`. All network
work in the harnesses is stubbed.

---

## 18. Anti-delete ported from ELITE, play format buttons, blockquoted replies

### 18.1 Anti-delete — disk-backed capture (ELITE-PRO-V1)

Ported the capture half of `handleAntiDeleteCapture` / `saveMessage` from ELITE-PRO-V1. The panel
previously kept recovered messages in an **in-memory** map, so anything that arrived before a
restart was unrecoverable. Now:

- every incoming message is mirrored to `anti_delete/<jid>_<id>.json` (`captureForAntiDelete()`,
  called from `handleMessage` right after `storeMessage`),
- `loadStoredMessage()` reads **disk first**, in-memory second, so a deletion is still recoverable
  after a restart,
- files expire after **10 minutes** and a 60-second sweeper prunes them (same TTL as the reference),
- the stored copy is deleted once the recovery has been delivered.

Note layout is now the reference's:

```
> ╭━━[ *× ANTI DELETE MESSAGES ×* ]━┉
> ┣━ *Deleted:* @254711111111
> ┣━
> ┣━ *Sender:* *Alice*
> ┣━
> ┣━ *Chat:* Mock Group
> ╰━━━━━━━━━━━━━━━━━━━━┉
```

plus `♻️ *Message:*` followed by the blockquoted original text.

Two deliberate deviations from the reference, both from your earlier instructions:

1. **Delivery stays in the paired number's own DM**, not the chat where the deletion happened
   (`ownerNumber` in the reference is also the bot's own JID, so this matches — but the panel
   additionally falls back to the source chat if the DM send fails).
2. Additions kept from the previous round: view-once labelling, contact / location / poll /
   interactive-button recovery, and the `messages.delete` path alongside the revoke path.

New: a deletion is also skipped when the *deleter* is this account (reference behaviour), not just
when the message was authored by it.

### 18.2 `.play` now ships a format picker

`case 'play'` no longer downloads immediately. It sends **one interactive message** — song
thumbnail as the header image, blockquoted details, and three quick-reply buttons:

| Button | id | Result |
|---|---|---|
| 🎵 Audio | `PLAY_AUDIO\|<url>` | audio message (`eliteprotech /ytmp3`) |
| 🎬 Video | `PLAY_VIDEO\|<url>` | video message (`neosoft /downloader/youtube?type=mp4`) |
| 📄 Document | `PLAY_DOC\|<url>` | `.mp3` sent as a document |

A tap arrives with the button id as the message body; the handler routes anything matching
`PLAY_(AUDIO|VIDEO|DOC)|…` to `handlePlayChoice()` before command or chatbot handling. Captions and
failures are blockquoted, failures additionally react with ❌.

Both endpoints were verified live before wiring: `eliteprotech /ytmp3` → 200 with
`{status, download:{title, downloadUrl}}`, `neosoft …type=mp4` → 200 with `{status, download}`.
The previous `play` provider (`api.drexapp.space`) is gone.

### 18.3 Replies are blockquoted again

`reply()` wraps its framed body in the blockquote helper again, so ordinary command replies render
as quote blocks. The menu is untouched — it uses the interactive path, not `reply()`.

```
node verify-play.js      →  23 passed, 0 failed
node verify-antidelete.js→  29 passed, 0 failed   (was 22; +7 for disk capture and the note)
node verify-chatbot.js   →  37 passed, 0 failed
node verify-menu.js      →  22 passed, 0 failed
node verify-commands.js  →  566/566, exit 0
```

---

## 19. checkban (VARNOX), console style (June Ultra), screenshot + approve (ELITE)

Four items from `github.com/blacklorddev15/Tes-r-po` (the folder holds two zips: the VARNOX
checkban bot and June-Ultra) plus ELITE-PRO-V1.

### 19.1 `.checkban` — ported from VARNOX X ULTRA

`case 'checkban'` in `case.js`, provider `POST https://baron0.com/api/v2/check` with
`Authorization: Bearer <key>` and body `{ number }`, engine label `Baron0 v2`. Target resolution
follows the reference exactly: a typed number, a replied-to contact, a tagged member — including
the **LID → phone-number** lookup through `groupMetadata.participants`, which is what makes tagging
work in modern groups.

The API is read from settings, as requested:

```js
// settings.js  —  .env wins, then settings.js
BANCHECK_API_KEY: process.env.BANCHECK_API_KEY || '',
BANCHECK_API_URL: process.env.BANCHECK_API_URL || 'https://baron0.com/api/v2/check',
BANCHECK_ENGINE:  'Baron0 v2',
```

`BANCHECK_API_KEY` is documented in `.env.example`. With no key the command answers with an
explicit "not configured" message instead of failing obscurely. Output covers banned / not-banned
/ provider-error, wrapped in the standard blockquoted frame.

### 19.2 Console output restyled from June-Ultra

`helper/logger.js` rewritten in June's style, branded for this bot:

- every line carries `chalk.blue.bold('[ SKYLAR ULTRA ]')` — June's `[ JUNEX ULTRA ]` tag, renamed as you asked
- `global.log` is wired the same way June wires it (`log(msg, color, isErr)`), so existing calls to `global.log` work
- the per-message banner is drawn with **lolcatjs** (rainbow) and uses June's field set:
  `Sent Time · Date · Message Type · Sender Name · Chat ID · Group · Group JID · Message`, inside
  the `┏━━━『 SKYLAR ULTRA 』━━━─ … ┗━━━⳹` box
- `logInfo / logSuccess / logWarn / logError` route through the tagged logger in cyan / green / yellow / red
- `lolcatjs@^2.4.3` added to `package.json`; if it is ever missing the banner prints uncoloured instead of throwing

```
┏━━━━━━━━━━━━━『  SKYLAR ULTRA  』━━━━━━━━━━━━━─
»  Sent Time: Wednesday, 00:28:21
»  Date: 16/09/2026
»  Message Type: 💬 text
»  Sender Name: Alice
»  Chat ID: 120363111111111111
»  Group: Mock Group
»  Group JID: 120363111111111111
»  Message: hello
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━─ ⳹
```

### 19.3 `.screenshot` — repaired with ELITE's provider

The command existed but **both** of its providers were dead: `api.screenshotone.com/take` answers
`400 access_key_required` (it needs a paid key that was never configured) and the thum.io fallback
answers `400`. It now uses ELITE's `/ssweb` endpoint, verified live before wiring
(HTTP 200, image/png, 1216×900):

```
https://eliteprotech-apis.zone.id/ssweb?url=…
```

with `SCREENSHOT_API` overridable in `settings.js`, plus the reference's 🖼️ → ✅ / ❌ reactions and
the "Screenshot captured successfully" caption.

### 19.4 `.approve` — ported from ELITE-PRO-V1

New group command (the panel only had `approveall`). Approves tagged members, a replied-to
contact, a number argument, or — when no target is given — every pending join request via
`groupRequestParticipantsList` / `groupRequestParticipantsUpdate(..., 'approve')`, then announces
the approved members with real `mentions`. Registered in the Group command list; `checkban` and
`screenshot` are registered in Utility.

```
node verify-ports.js       →  26 passed, 0 failed   (new harness)
node verify-play.js        →  23 passed, 0 failed
node verify-chatbot.js     →  37 passed, 0 failed
node verify-menu.js        →  22 passed, 0 failed
node verify-antidelete.js  →  29 passed, 0 failed
node verify-commands.js    →  568/568, exit 0      (was 566; +checkban +approve)
```

**Not verifiable here:** the baron0 ban API needs a real key (the harness stubs it), and the
screenshot endpoint's behaviour on JS-heavy or login-walled sites is untested — it is a plain
server-side capture.

---

## 20. .play buttons: diagnosis and a fallback that always works

**Report:** `.menu` buttons render, `.play` buttons do not.

The menu and the play card go through the *same* sender (`sendInteractiveButtons` →
`viewOnceMessage` + `native_flow` + `biz/interactive` nodes) and the harness proves the play card is
built correctly — one interactive message, header image, three `quick_reply` buttons with
`PLAY_AUDIO|…` ids. The only substantive difference is the button **type**: the menu uses
`cta_url`, play uses `quick_reply`, which renders as an action button rather than a link.

**Conclusion:** this WhatsApp build renders `cta_url` but not `quick_reply` buttons. No payload
change can fix that — it is a client-side rendering difference.

### What was added

1. **A numbered fallback, so the feature works regardless.** The card body now also says
   `Or reply 1 = Audio · 2 = Video · 3 = Document`, and the reply is routed like a tap:
   - DM: a bare `1` / `2` / `3` (or `audio` / `video` / `document`) works — one pending card per chat
   - Group: the reply **must quote the card** (`contextInfo.stanzaId` must match the sent card), so
     an unrelated "1" in a busy group can never trigger a download
   - the pending card expires after 10 minutes; a numeric reply with no pending card does nothing
2. **`.btntest` now sends a third labelled message — Shape C — built from a `quick_reply` button.**
   Run `.btntest` and tell me which of the three shows a working button:

   | Message | Shape | Meaning if it has no button |
   |---|---|---|
   | A · wrapped | `cta_url` in a `viewOnceMessage` | wrapper unsupported |
   | B · top-level | `cta_url`, bare `interactiveMessage` | wrapper required (expected) |
   | **C · quick_reply** | what `.play` sends | **your build does not render quick_reply buttons** |

```
node verify-play.js  →  29 passed, 0 failed   (was 23; +6 for the numbered fallback)
```
