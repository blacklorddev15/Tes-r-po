// ============================================================
//   verify-menu.js  --  payload check for the single-message .menu
// ------------------------------------------------------------
// Asserts that `.menu` produces ONE outbound message carrying
//   header image  +  full command list (body)  +  URL button
// with no newsletter/forwarded context and no printed pairing URL.
//
//   node verify-menu.js
// ============================================================
'use strict';

const fs   = require('fs');
const os   = require('os');
const path = require('path');
const zlib = require('zlib');

// ── 1. Synthesise a realistic test image (>200 bytes) ────────
function makePng(w = 160, h = 160) {
  const raw = Buffer.alloc((w * 3 + 1) * h);
  let seed = 12345;
  for (let y = 0; y < h; y++) {
    raw[y * (w * 3 + 1)] = 0;                       // filter byte
    for (let x = 0; x < w; x++) {
      seed = (seed * 1103515245 + 12345) & 0x7fffffff;
      const o = y * (w * 3 + 1) + 1 + x * 3;
      raw[o] = seed & 0xff; raw[o + 1] = (seed >> 8) & 0xff; raw[o + 2] = (seed >> 16) & 0xff;
    }
  }
  const crc = (b) => { let c = ~0; for (const x of b) { c ^= x; for (let k = 0; k < 8; k++) c = (c >>> 1) ^ (0xEDB88320 & -(c & 1)); } return ~c >>> 0; };
  const chunk = (t, d) => {
    const len = Buffer.alloc(4); len.writeUInt32BE(d.length);
    const td = Buffer.concat([Buffer.from(t), d]);
    const c = Buffer.alloc(4); c.writeUInt32BE(crc(td));
    return Buffer.concat([len, td, c]);
  };
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  return Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0)),
  ]);
}
const TEST_IMG = makePng();
if (TEST_IMG.length < 200) { console.error('harness: test image too small'); process.exit(2); }

// ── 2. Stub the network ──────────────────────────────────────
const netCalls = { get: 0 };
const axios = require('axios');
const resp = () => ({ data: TEST_IMG, status: 200, statusText: 'OK', headers: {}, config: {} });
axios.get = async () => { netCalls.get++; return resp(); };
axios.post = async () => resp();
axios.request = async () => resp();
axios.head = async () => resp();
axios.create = () => axios;
global.fetch = async () => ({ ok: true, status: 200, json: async () => ({}), text: async () => '', arrayBuffer: async () => new ArrayBuffer(8) });

// ── 3. Stub socket ───────────────────────────────────────────
const BOT_NUM = '254700000000';
let outbound = [];

const baseSock = {
  user: { id: `${BOT_NUM}:1@s.whatsapp.net` },
  __waNum: BOT_NUM,
  __sessionId: `wa_menutest_${BOT_NUM}`,
  // Mirrors the real uploader's return shape (messages-media.js:
  // { mediaUrl: result.url, directPath: result.direct_path }).
  waUploadToServer: async () => ({ mediaUrl: 'https://mmg.whatsapp.net/v/t62/mock.enc', directPath: '/v/t62/mock.enc' }),
  sendMessage: async (jid, content, opts) => {
    outbound.push({ kind: 'sendMessage', jid, content, opts });
    return { key: { id: 'MOCK_' + outbound.length, remoteJid: jid }, message: content };
  },
  relayMessage: async (jid, message, opts) => {
    outbound.push({ kind: 'relayMessage', jid, content: message, opts });
    return { key: { id: 'MOCK_RELAY_' + outbound.length } };
  },
  sendPresenceUpdate: async () => {},
  readMessages: async () => {},
};
const sock = new Proxy(baseSock, {
  get(t, p) {
    if (p in t) return t[p];
    if (typeof p === 'symbol') return undefined;
    return async () => ({ key: { id: 'MOCK' }, status: 200 });
  },
});

// A 🌹 reaction is not a message -- exclude it from delivery counts.
const deliveries = () => outbound.filter(m => !(m.content && m.content.react));

// ── 4. Isolate on-disk settings ──────────────────────────────
const DB_DIR = path.join(__dirname, 'database');
const DB_SNAPSHOT = fs.mkdtempSync(path.join(os.tmpdir(), 'menu-db-'));
if (fs.existsSync(DB_DIR)) fs.cpSync(DB_DIR, DB_SNAPSHOT, { recursive: true });
const restore = () => {
  try {
    fs.rmSync(DB_DIR, { recursive: true, force: true });
    fs.cpSync(DB_SNAPSHOT, DB_DIR, { recursive: true });
    fs.rmSync(DB_SNAPSHOT, { recursive: true, force: true });
  } catch { /* best effort */ }
};
process.on('exit', restore);

function setBotConfig(extra = {}) {
  fs.writeFileSync(path.join(DB_DIR, 'settings.json'), JSON.stringify({
    [BOT_NUM]: {
      prefix: '.', mode: 'public', font: 0, owner: '', botName: ' 𝐔𝐋𝐓𝐑𝐀 𝐗𝐌𝐃 ',
      menuImg: '', antidelete: true, iphoneMode: false, ...extra,
    },
  }, null, 2));
}

const buildMsg = (body) => ({
  key: { remoteJid: `${BOT_NUM}@s.whatsapp.net`, fromMe: true, id: 'MSG' + Math.random().toString(36).slice(2, 8) },
  mtype: 'conversation',
  message: { conversation: body },
  pushName: 'Verifier',
});

// ── 5. Assertions ────────────────────────────────────────────
const { handleMessage, CMDS } = require('./case.js');
const SKYLAR_SITE = 'https://skylar-pairing.vercel.app';

const expectedCommands = Object.values(CMDS).filter(Array.isArray).flat();
const results = [];
const check = (name, ok, detail = '') => results.push({ name, ok: !!ok, detail });

const unwrap = (content) => {
  const inner = content?.viewOnceMessage?.message || content?.viewOnceMessageV2?.message || content;
  return inner?.interactiveMessage || null;
};

// Only forwarding / newsletter plumbing counts as a "forwarded channel" tag;
// a quoted reply legitimately carries its own contextInfo.
function forwardingFields(obj) {
  const hits = [];
  const seen = new Set();
  const walk = (o, keyPath) => {
    if (!o || typeof o !== 'object' || seen.has(o)) return;
    seen.add(o);
    for (const [k, v] of Object.entries(o)) {
      const p = keyPath ? `${keyPath}.${k}` : k;
      if (/^(isForwarded|forwardingScore|forwardedNewsletterMessageInfo|newsletterJid|newsletterName)$/.test(k)) hits.push(p);
      if (v && typeof v === 'object') walk(v, p);
    }
  };
  walk(obj, '');
  return hits;
}

(async () => {
  // ── case A: default config -> image header + full list + button ─
  setBotConfig();
  outbound = [];
  await handleMessage(sock, buildMsg('.menu'), { groupName: '' });
  const msgs = deliveries().slice();
  const relay = msgs.find(m => m.kind === 'relayMessage');

  check('exactly ONE message delivered', msgs.length === 1, `got ${msgs.length}: ${msgs.map(m => m.kind).join(', ')}`);
  check('delivered through the interactive (relay) path', !!relay);

  const interactive = relay ? unwrap(relay.content) : null;
  check('shape = viewOnceMessage > message > interactiveMessage',
    !!(relay?.content?.viewOnceMessage?.message?.interactiveMessage));
  check('messageContextInfo present', !!relay?.content?.viewOnceMessage?.message?.messageContextInfo);

  const header = interactive?.header;
  check('header.hasMediaAttachment = true', header?.hasMediaAttachment === true);
  check('header carries imageMessage', !!header?.imageMessage,
    header?.imageMessage ? `mimetype=${header.imageMessage.mimetype} fileLength=${header.imageMessage.fileLength}` : 'MISSING');
  check('imageMessage has url + directPath',
    !!header?.imageMessage?.url && !!header?.imageMessage?.directPath,
    `url=${String(header?.imageMessage?.url || '').slice(0, 48)} directPath=${String(header?.imageMessage?.directPath || '').slice(0, 24)}`);

  const body = interactive?.body?.text || '';
  const missing = expectedCommands.filter(c => !body.includes(c));
  check('body = FULL command list (every advertised command)',
    body.includes('𝐒𝐊𝐘𝐋Λ𝐑 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒') && missing.length === 0,
    `bodyLen=${body.length} commands=${expectedCommands.length} missing=${missing.length}${missing.length ? ' first=' + missing.slice(0, 5).join(',') : ''}`);

  const btns = interactive?.nativeFlowMessage?.buttons || [];
  const parsed = btns.map(b => { try { return JSON.parse(b.buttonParamsJson); } catch { return {}; } });
  check('exactly ONE button', btns.length === 1, `got ${btns.length}`);
  check('button is cta_url -> pairing site', btns[0]?.name === 'cta_url' && parsed[0]?.url === SKYLAR_SITE,
    `${btns[0]?.name} url=${parsed[0]?.url}`);
  check('no copy_code / list-style second button', parsed.every(p => !p.copy_code));

  const fwd = forwardingFields(interactive || {});
  check('no forwarded / newsletter fields on the menu message', fwd.length === 0, fwd.join(', ') || 'none');
  check('no raw pairing URL anywhere in body', !body.includes('skylar-pairing'));
  const footer = interactive?.footer?.text || '';
  check('no raw pairing URL in footer', !footer.includes('skylar-pairing'), `footer="${footer}"`);

  // ── case B: second call reuses the uploaded header image ───────
  const fetchesBefore = netCalls.get;
  outbound = [];
  await handleMessage(sock, buildMsg('.menu'), { groupName: '' });
  check('repeat .menu: still exactly ONE message', deliveries().length === 1, `got ${deliveries().length}`);
  check('repeat .menu: header image re-used (no re-upload)',
    (netCalls.get - fetchesBefore) === 0, `extra image fetches=${netCalls.get - fetchesBefore}`);

  // ── case C: iphoneMode -> still one message, no image ─────────
  setBotConfig({ iphoneMode: true });
  outbound = [];
  await handleMessage(sock, buildMsg('.menu'), { groupName: '' });
  const relayC = deliveries().find(m => m.kind === 'relayMessage');
  const interC = relayC ? unwrap(relayC.content) : null;
  check('iphoneMode: still exactly ONE message', deliveries().length === 1, `got ${deliveries().length}`);
  check('iphoneMode: image header omitted', interC?.header?.hasMediaAttachment === false && !interC?.header?.imageMessage);
  check('iphoneMode: button still present', (interC?.nativeFlowMessage?.buttons || []).length === 1);

  // ── case D: interactive send throws -> single text fallback ───
  setBotConfig();
  outbound = [];
  const realRelay = baseSock.relayMessage;
  baseSock.relayMessage = async () => { throw new Error('simulated relay failure'); };
  await handleMessage(sock, buildMsg('.menu'), { groupName: '' });
  baseSock.relayMessage = realRelay;
  const fb = deliveries().slice();
  check('relay failure: exactly ONE fallback message', fb.length === 1 && fb[0].kind === 'sendMessage',
    `got ${fb.length}: ${fb.map(m => m.kind).join(', ')}`);
  check('relay failure: fallback body is the full list',
    (fb[0]?.content?.text || '').length > 1000, `len=${(fb[0]?.content?.text || '').length}`);
  check('relay failure: fallback has no forwarded / newsletter fields',
    forwardingFields(fb[0]?.content || {}).length === 0);

  // ── report ───────────────────────────────────────────────────
  const failed = results.filter(r => !r.ok);
  console.log('\n============== SINGLE-MESSAGE MENU VERIFICATION ==============');
  for (const r of results) console.log(`${r.ok ? 'PASS' : 'FAIL'}  ${r.name}${r.detail ? `\n        ${r.detail}` : ''}`);
  console.log('-------------------------------------------------------------');
  console.log(`checks: ${results.length}   passed: ${results.length - failed.length}   failed: ${failed.length}`);
  console.log(`image fetches over the wire: ${netCalls.get}`);
  console.log('=============================================================\n');
  process.exit(failed.length ? 1 : 0);
})().catch(e => { console.error('harness error:', e); process.exit(2); });
