const OU_r$VJaYD = hgGrfwAK_KMjYF;
(function (TGpB_rMUW, shFm_KnkOQGAJ) {
  const fr_fsuElhICQitJWBUJ$paav = hgGrfwAK_KMjYF,
    dTBoxb_ty$sYmM = TGpB_rMUW();
  while (!![]) {
    try {
      const TYAs$PKyGAzoolDTIoDQLE_MLg = Math['floor'](-parseFloat(fr_fsuElhICQitJWBUJ$paav(0x1cd)) / (Number(0x2c9) * 0x7 + 0xce0 + -0xaca * parseInt(0x3))) * (-parseFloat(fr_fsuElhICQitJWBUJ$paav(0x1c3)) / (Number(parseInt(0x2625)) + -parseInt(0x1) * 0xa13 + 0x10 * Math.floor(-parseInt(0x1c1)))) + parseFloat(fr_fsuElhICQitJWBUJ$paav(0x1e7)) / (-parseInt(0x22d8) + 0xfd + 0x21de) * Math['floor'](parseFloat(fr_fsuElhICQitJWBUJ$paav(0x1a3)) / (Math.ceil(-parseInt(0xb)) * Math.floor(parseInt(0x95)) + -parseInt(0x16f5) * Math.ceil(0x1) + parseInt(-parseInt(0x1)) * -parseInt(0x1d60))) + Math['max'](parseFloat(fr_fsuElhICQitJWBUJ$paav(0x1b5)) / (parseFloat(parseInt(0xd6)) * parseInt(0x9) + -0x236d + -parseInt(0x6fb) * Math.floor(-parseInt(0x4))), parseFloat(fr_fsuElhICQitJWBUJ$paav(0x1ff)) / (0xa6f * parseInt(0x1) + -parseInt(0xf) * Math.ceil(parseInt(0xe5)) + Math.floor(parseInt(0x302)))) + -parseFloat(fr_fsuElhICQitJWBUJ$paav(0x196)) / (Number(parseInt(0xbea)) + parseFloat(-parseInt(0x1129)) + -0xa * -parseInt(0x87)) + parseInt(parseFloat(fr_fsuElhICQitJWBUJ$paav(0x1cc)) / (parseFloat(-parseInt(0x362)) + 0x787 + -parseInt(0x9) * Math.max(parseInt(0x75), parseInt(0x75)))) + Math['ceil'](parseFloat(fr_fsuElhICQitJWBUJ$paav(0x1d3)) / (-0x16e4 + Math.ceil(-0x740) + 0x67 * parseInt(0x4b))) + -parseFloat(fr_fsuElhICQitJWBUJ$paav(0x1ba)) / (-parseInt(0xe52) + Math.trunc(-parseInt(0xc78)) + Math.ceil(0x6b5) * parseInt(0x4)) * (parseFloat(fr_fsuElhICQitJWBUJ$paav(0x173)) / (-0x1cc5 + Number(0x220c) + 0x14 * -parseInt(0x43)));
      if (TYAs$PKyGAzoolDTIoDQLE_MLg === shFm_KnkOQGAJ) break;else dTBoxb_ty$sYmM['push'](dTBoxb_ty$sYmM['shift']());
    } catch (jIns_nr_LzKfY) {
      dTBoxb_ty$sYmM['push'](dTBoxb_ty$sYmM['shift']());
    }
  }
})(xa$Lwdz$kMdbQHReCnCTj, Math.trunc(-parseInt(0x673ca)) + 0xba31d * -parseInt(0x1) + parseInt(0x19dfe5));
const axios = require(OU_r$VJaYD(0x16f)),
  database = require(require(OU_r$VJaYD(0x202))[OU_r$VJaYD(0x20a)](global[OU_r$VJaYD(0x1bb)], OU_r$VJaYD(0x214))),
  config = require(require(OU_r$VJaYD(0x202))[OU_r$VJaYD(0x20a)](global[OU_r$VJaYD(0x1f1)], OU_r$VJaYD(0x1ef))),
  JUNE_API_URL = config[OU_r$VJaYD(0x1c1)] || process[OU_r$VJaYD(0x18e)][OU_r$VJaYD(0x1c1)],
  JUNE_BOT_ID = config[OU_r$VJaYD(0x203)] || process[OU_r$VJaYD(0x18e)][OU_r$VJaYD(0x203)],
  JUNE_API_KEY = config[OU_r$VJaYD(0x1fc)] || process[OU_r$VJaYD(0x18e)][OU_r$VJaYD(0x1fc)] || OU_r$VJaYD(0x1ac),
  lastRequest = new Map(),
  RATE_MS = parseInt(-parseInt(0x22b)) * -0xd + parseInt(0x717) * Number(-parseInt(0x4)) + parseInt(0xfcd),
  RETRY_DELAY = Number(parseInt(0x39c)) + Math.ceil(parseInt(0xfb2)) + Number(parseInt(0x2)) * -parseInt(0x4c5);
let CHATBOT_VERSION = OU_r$VJaYD(0x20e);
async function fetchVersion() {
  const vBRsQVzbxhAxuqbLq$NUIkpLP = OU_r$VJaYD;
  try {
    const {
      data: AsadoPbS$BRMbH_V
    } = await axios[vBRsQVzbxhAxuqbLq$NUIkpLP(0x1ed)](JUNE_API_URL + vBRsQVzbxhAxuqbLq$NUIkpLP(0x1d9), {
      'timeout': 0x1f40,
      'headers': {
        'Authorization': vBRsQVzbxhAxuqbLq$NUIkpLP(0x1be) + JUNE_API_KEY,
        'X-Bot-Id': JUNE_BOT_ID
      }
    });
    AsadoPbS$BRMbH_V?.[vBRsQVzbxhAxuqbLq$NUIkpLP(0x1aa)] && (CHATBOT_VERSION = AsadoPbS$BRMbH_V[vBRsQVzbxhAxuqbLq$NUIkpLP(0x1aa)], global[vBRsQVzbxhAxuqbLq$NUIkpLP(0x20d)](vBRsQVzbxhAxuqbLq$NUIkpLP(0x1d8) + CHATBOT_VERSION, vBRsQVzbxhAxuqbLq$NUIkpLP(0x1bc)));
  } catch (MsjWyRg_EwIqfqHKbYK$ai) {
    global[vBRsQVzbxhAxuqbLq$NUIkpLP(0x20d)](vBRsQVzbxhAxuqbLq$NUIkpLP(0x197) + CHATBOT_VERSION, vBRsQVzbxhAxuqbLq$NUIkpLP(0x1bc));
  }
}
function hgGrfwAK_KMjYF(QiwMrLQzibtqIiTDLrKOd, eRgQV$VbRDbrpIXoeK) {
  const STTK_KE$sptj = xa$Lwdz$kMdbQHReCnCTj();
  return hgGrfwAK_KMjYF = function (PeRYJGtq, EIoHo) {
    PeRYJGtq = PeRYJGtq - (parseFloat(-0x1) * Math.max(-0x11ae, -0x11ae) + -parseInt(0x248a) + Math.trunc(-0x1) * -0x1445);
    let GgXukxG$AnAwD = STTK_KE$sptj[PeRYJGtq];
    if (hgGrfwAK_KMjYF['NgFUgq'] === undefined) {
      const tNczvcssJeskaplkPnF$FBVEl = function (oVYuXO$szVDs) {
        let q$juBjwvjQzWXzsHLnnFfFx$Asa = -0x80d * -0x3 + -0x1 * parseInt(-0xb99) + parseInt(0x6c5) * Math.trunc(-0x5) & parseInt(0x37) * Number(-parseInt(0x8e)) + Number(0x5) * Math.ceil(-0x10f) + parseInt(0x24cc),
          oP$bSBR = new Uint8Array(oVYuXO$szVDs['match'](/.{1,2}/g)['map'](dXdkgAi => parseInt(dXdkgAi, parseFloat(-parseInt(0x764)) + -parseInt(0xbb9) * -0x2 + Number(-parseInt(0x7ff)) * 0x2))),
          bHVMMsjWyR_gEwIqfqHKb = oP$bSBR['map'](zIIsjPnLWqod_kO => zIIsjPnLWqod_kO ^ q$juBjwvjQzWXzsHLnnFfFx$Asa),
          KaiOMY$$boyLNSDobbYvLCsGhZG = new TextDecoder(),
          rZUixvSlQzvK = KaiOMY$$boyLNSDobbYvLCsGhZG['decode'](bHVMMsjWyR_gEwIqfqHKb);
        return rZUixvSlQzvK;
      };
      hgGrfwAK_KMjYF['TxpZCl'] = tNczvcssJeskaplkPnF$FBVEl, QiwMrLQzibtqIiTDLrKOd = arguments, hgGrfwAK_KMjYF['NgFUgq'] = !![];
    }
    const EIQ$sddkQgybX = STTK_KE$sptj[parseInt(parseInt(0x1)) * parseInt(0xccd) + -parseInt(0x24) * -parseInt(0x1f) + Math.trunc(-parseInt(0x1129))],
      ynbFAYMwI$PPlJ$O = PeRYJGtq + EIQ$sddkQgybX,
      AniHL = QiwMrLQzibtqIiTDLrKOd[ynbFAYMwI$PPlJ$O];
    return !AniHL ? (hgGrfwAK_KMjYF['kfeVVb'] === undefined && (hgGrfwAK_KMjYF['kfeVVb'] = !![]), GgXukxG$AnAwD = hgGrfwAK_KMjYF['TxpZCl'](GgXukxG$AnAwD), QiwMrLQzibtqIiTDLrKOd[ynbFAYMwI$PPlJ$O] = GgXukxG$AnAwD) : GgXukxG$AnAwD = AniHL, GgXukxG$AnAwD;
  }, hgGrfwAK_KMjYF(QiwMrLQzibtqIiTDLrKOd, eRgQV$VbRDbrpIXoeK);
}
fetchVersion();
function getPrivate() {
  const MuGpLzwVEVUxaVxb = OU_r$VJaYD;
  return database[MuGpLzwVEVUxaVxb(0x181)](MuGpLzwVEVUxaVxb(0x21b)) ?? ![];
}
function setPrivate(MYboyLNSDobbYvLCsGhZG) {
  const gGbQCbjePvuFWdExQOdNk = OU_r$VJaYD;
  database[gGbQCbjePvuFWdExQOdNk(0x1dc)](gGbQCbjePvuFWdExQOdNk(0x21b), MYboyLNSDobbYvLCsGhZG);
}
function getGroupChatbot(rZUixvSlQz_vK) {
  const LEL$DynXZGUPSyF_xVCOV = OU_r$VJaYD;
  return database[LEL$DynXZGUPSyF_xVCOV(0x181)](LEL$DynXZGUPSyF_xVCOV(0x212) + rZUixvSlQz_vK) ?? ![];
}
function setGroupChatbot(dXd_kgA$i, zIIsjPnLWqodkO) {
  const u$bpZxmpKymm = OU_r$VJaYD;
  database[u$bpZxmpKymm(0x1dc)](u$bpZxmpKymm(0x212) + dXd_kgA$i, zIIsjPnLWqodkO);
}
function getGroupMention(dhbFhjyIDekS$UgvDmSdUm) {
  const qxJRa$$gwDx = OU_r$VJaYD;
  return database[qxJRa$$gwDx(0x181)](qxJRa$$gwDx(0x17b) + dhbFhjyIDekS$UgvDmSdUm) ?? ![];
}
function xa$Lwdz$kMdbQHReCnCTj() {
  const WloXvU_sba$oXB = ['9792948f', 'bb94cd', 'bca4afa6b3a5a8b3bac7a692938fc795828d8284938283c7056773c7848f82848cc7adb2a9a2b8a6b7aeb8aca2bec7c8c7adb2a9a2b8a5a8b3b8aea3c9', '869f8e8894', 'c7c7c9848f8693858893c78084c78889c7c7056773c7828986858b82c786929388ca9582978b9ec78e89c7938f8e94c78095889297ed', '8697978b8e8486938e8889c88884938293ca94939582868a', 'cda4929595828993c7a48f8693c7cfb7958e91869382cecd', 'd3d6df84838fa68290', '8f8694', 'bca4afa6b3a5a8b3bac7a1868e8b8283c79388c794828983c7', '056745c7aa8289938e8889c7aa888382c7ddc7cd', '056745c7a095889297c7a48f8693c7c7c7ddc7cd', '056745c7a68b8bc78095889297c7848889818e80929586938e888994c7848b8286958283ed', '8e8a868082aa829494868082', '91868b928294', '8095889297aa8289938e8889a8898b9edd', '86838a8e89', '8b8e83', 'a1928b8bc7a6929388cab582978b9e', '848697938e8889', '8e8a868082', '808293a58893b48293938e8980', '918e838288c88a97d3', '85869482d1d3', 'bca4afa6b3a5a8b3bac78692838e88ddc78988c7859281818295c892958b', '9582949788899482', '8488899182959486938e8889', '84888993829f93ae898188', 'c7c7c9848f8693858893c7978ac7888181c7056773c7838e9486858b82c78e89c797958e91869382c7848f869394', '888181', '818e8b8289868a82', 'a58893c7908e8b8bc788898b9ec79582978b9ec7908f8289c7a78a8289938e88898283c78895c7969288938283c9c7a095889297c7a48f8693c7aa888382c78f8694c785828289c7838e9486858b8283c9', '056745c7b7958e91869382c7848f8693c7838e9486858b8283ed', '8a8e8a82b39e9782', '828991', '17787642c7cda095889297c7a48f8693c7', '8195888aaa82', '057b62c7a8a9', '948293', 'cecbc7958293959e8e8980c78e89c7', 'c7c7c9848f8693858893c78a8289938e8889c7888181c7056773c7838e9486858b82c78a8289938e8889ca88898b9ec78a888382', '94938e848c8295', 'd4d6dfd1d5d6dfa080b0838bb5', 'bcc7a4afa6b3a5a8b3c7bac781868e8b8283c79388c7818293848fc7918295948e8889cbc792948e8980c781868b8b8586848cddc791', '818e8b82a9868a82', '9582978b9e', '97889493', '056745c7aa8289938e8889c78a88838294c7848b8286958283ed', '85929393888994b582949788899482aa829494868082', '84888a9788948e8980', '9582978b868482', '848f8693', 'cda684938e9182c7aa888382cd', '17787076085f68c7cda488899182959486938e8889c78f8e949388959ec7848b8286958283c9cdedb38f82c7858893c7908e8b8bc79493869593c7819582948fc78e89c7938f8e94c7848f8693c9', '83828b829382', 'd6d0ded6dfd0d1a2b2a29196ac', '848f8693858893', 'a9888982', '8697978b8e8486938e8889c88d948889', 'cbc781868b8b8e8980c78586848cc79388c793829f93dd', '858893', '9582948293', '918295948e8889', '1778754bc7cdb7958e91869382c7a48f8693c7', '8d9fb88b8e9182b889b6b884b5d0d6a2948adea195a08e9f89d6deaedea682d7bedf84b183a5a28dafaa9db2d6cab8b7a2b0a2', '9388ab88908295a4869482', '056745c7c9848f8693858893c7848b828695c7c7c7c7c7c7c7c7c7c7c7056773c7848b828695c7a6aec78488899182959486938e8889c78f8e949388959ec7818895c7938f8e94c7848f8693ed', '818e8983', 'bca4afa6b3a5a8b3bac7a1868e8b8283c79388c7848b828695c795828a889382c78f8e949388959edd', 'a8a1a1c7057a6b', '057d47085f68c7cda186849388959ec7b582948293c7a4888a978b829382cded', 'bca4afa6b3a5a8b3bac7b5829692829493c781868e8b8283c7cf', '8195888a', 'd3ded0d6d5d79385b392aab3', 'c891d6c8848f8693', '056745c7a6aec78488899182959486938e8889c78f8e949388959ec7848b8286958283', 'bca4afa6b3a5a8b3bac7838884928a828993ddc78988c7859281818295c892958b', 'ae8991868b8e83c7a6aec79582949788899482', 'd2d4d5d6d3d78b82b7a6bea4', 'b8b8a4a8b5a2b8b8', '8095828289', '056745c7c9848f8693858893c78a8289938e8889c78889c8888181c7c7056773c79582978b9ec788898b9ec7908f8289c7a78a8289938e88898283c8969288938283c7cf938f8e94c78095889297ceed', 'a58286958295c7', 'aa8289938e8889c78a888382c7838e9486858b8283c9c7b29482c7cdc9848f8693858893c78084c78889cdc79388c79582ca828986858b82c781928b8bc786929388ca9582978b8e8294c9', '8186849388959e9582948293', 'adb2a9a2b8a6b7aeb8b2b5ab', 'cdededb39e9782c7cdc9848f8693858893c78f828b97cdc79388c7948282c78691868e8b86858b82c784888a8a86898394c9', 'd5d2d7a9a4ae869391', '94978b8e93', '898890', '057a6bc7b38f8e94c784888a8a868983c788898b9ec79088958c94c78e89948e8382c786c78095889297c9', '057366057366057366057366057366057366057366057366057366057366057366057366057366057366057366057366057366057366ed', 'aa8289938e8889c7a8898b9e', '82978f828a8295868baa829494868082', '93829f93', '83869386', 'd0d7d6d3ded0d192afaaa5ad8e', 'd3d2d3d08bb483a0a8b6', 'bca4afa6b3a5a8b3bac78e8a868082ddc78988c7859281818295c892958b', '818e8b82', '8c829e', 'a68b8bc7848f8693858893c7948293938e898094c78f869182c785828289c79582949388958283c79388c7938f828e95c783828186928b9394c9ed', '057a74c7b2898c89889089c78897938e8889ddc7cd', 'dfded2d4dfd3dfabb09eb483a1', 'cda4929595828993c7a48f8693c7cfa095889297cecd', '056745c7c9848f8693858893c78186849388959e9582948293c7c7c7c7056773c7057d47085f68c79582948293c7a6ababc7948293938e898094c79388c783828186928b93c7cf8e959582918295948e858b82ce', '057a6bc7aa8289938e8889c78a888382c788898b9ec78697978b8e8294c78e89948e8382c786c78095889297c9', 'a6aec7848f8693858893c7918e86c7adb2a9a2b8b2abb3b5a6b8a6aec78586848c828983c7056773c786929388ca9582978b8e8294c78e89c7809588929794c7868983c7a3aa94', 'bcc7a4afa6b3a5a8b3c7bac7b18295948e8889c7949e89848283c78195888ac7948295918295ddc791', 'c886978ec89493869394', '17786850085f68c7cdaa8289938e8889c7aa888382c7', 'cdeded', '948293a58893b48293938e8980', '8a829494868082', 'cdc7cf938f8e94c78095889297ceed', '969288938283aa829494868082', '838884928a828993', 'c7c7c9848f8693858893c78a8289938e8889c78889c7c7056773c79582978b9ec788898b9ec7908f8289c7a7938680808283c78895c7969288938283ed', 'b7958e91869382c7a48f8693', 'bca4afa6b3a5a8b3bac794938e848c8295ddc78988c7859281818295c892958b', '978695938e848e97868993', '829f9788959394', '8295958895', 'd48bae9681bfad', '90869589', 'a8a9c7057b62', '17784371c7cda48f8693858893c7a4888a8a86898394cdc791', '8a8289938e8889', 'c7c7c9848f8693858893c7978ac78889c7c7056773c7828986858b82c78e89c797958e91869382c7848f869394ed', '808293', 'bca4afa6b3a5a8b3bac78f8689838b82a6929388b582978b9ec78295958895dd', '848889818e80', '829f938289838283b3829f93aa829494868082', 'b8b8b5a8a8b3b8b8', '95828a889382ad8e83', '056745c7c9848f8693858893c7978ac78889c8888181c7c7c7c7c7c7c7056773c7828986858b82c8838e9486858b82c797958e91869382c7848f8693c79582978b8e8294ed', 'c7c7c9848f8693858893c78084c7888181c7056773c7838e9486858b82c786929388ca9582978b9ec78e89c7938f8e94c78095889297', '94828983b795829482898482b29783869382', '94888a82', '17784371c7cda4afa6b3a5a8b3c7b4b3a6b3b2b4cdc791', 'bca4afa6b3a5a8b3bac7b5869382c78b8e8a8e938283dd', '838884928a828993aa829494868082', '918e838288', '949386939294', 'adb2a9a2b8a6b7aeb8aca2be', 'bca4afa6b3a5a8b3bac7a6aec7a295958895c7cf80869182c79297cedd', '8a8289938e88898283ad8e83', 'd2ded1d2d3d3a5b6b488ad9f', 'cda691868e8b86858b82c7a4888a8a86898394cded', '94828983aa829494868082', '9786938f', 'adb2a9a2b8a5a8b3b8aea3', '83828b829382a58893b48293938e898094a59eb79582818e9f', '056745c7c9848f8693858893c78084c78889c8888181c7c7c7c7c7c7c7056773c786929388ca9582978b9ec78e89c7938f8e94c78095889297c788898b9eed', '92958b', '056745c7b7958e91869382c7a48f8693c7ddc7cd', '057a6bc7a8a1a1', '8692838e88', '8d888e89', '056745c7c9848f8693858893c7949386939294c7c7c7c7c7c7c7c7c7c7056773c7918e8290c784929595828993c7948293938e898094ed', 'cdc7cf938f8e94c78095889297ceeded', '8b8880', 'd6c9d7c9d7', '94828b8284938283a38e94978b869eb3829f93', '8f828b97', '057a6bc7a8898b9ec7938f82c7858893c78890898295c7848689c7848f86898082c7848f8693858893c7948293938e898094c9', '8095889297a48f8693858893dd', 'c9848f8693858893c78f828b97c79bc7949386939294c79bc78084c78889c8888181c79bc7978ac78889c8888181c79bc78a8289938e8889c78889c8888181c79bc7848b828695c79bc78186849388959e9582948293', '8386938685869482', '81928984938e8889', '94928484829494', '057366057366057366057366057366057366057366057366057366057366057366057366057366057366057366057366057366057366eded', '17787076085f68', '859281818295', '8e89848b92838294', '97958e91869382a48f8693858893', 'ad928982bfb28b939586c8d5c9d7', '057a74c7cdb294868082ddcded', '92948295', '918e8290a8898482aa829494868082b1d5', '8a94056741', '93958e8a', 'bca4afa6b3a5a8b3bac7918e838288ddc78988c7859281818295c892958b', '848b828695a68b8ba58893b48293938e898094', '8692838e88c88a978280', '918e838288aa829494868082', '848b828695'];
  xa$Lwdz$kMdbQHReCnCTj = function () {
    return WloXvU_sba$oXB;
  };
  return xa$Lwdz$kMdbQHReCnCTj();
}
function setGroupMention(h$nzua$ehWRfs, IKMWR) {
  const aWdZugzOyvTgckT$YR = OU_r$VJaYD;
  database[aWdZugzOyvTgckT$YR(0x1dc)](aWdZugzOyvTgckT$YR(0x17b) + h$nzua$ehWRfs, IKMWR);
}
function icon(BrfCFcIWmtFHcJAp$ZjP_EsWQR) {
  const ZUI_ikWQ$Si = OU_r$VJaYD;
  return BrfCFcIWmtFHcJAp$ZjP_EsWQR ? ZUI_ikWQ$Si(0x191) : ZUI_ikWQ$Si(0x208);
}
function sleep(HDxkUqRtBrU) {
  return new Promise(XjOA$FIwurK => setTimeout(XjOA$FIwurK, HDxkUqRtBrU));
}
async function callAI(TpyeczyHpiEfLk$XuoGXijwtP, s_hTsq, GIZHxbgNTlA$xntzteS, GpRnMZbrRJriPnX$Sdrgnm = 0x1839 + Number(-0x3d) * parseInt(0x6d) + 0x20 * Math.floor(0xe)) {
  const XG$hMuJPkpuLpCD = OU_r$VJaYD;
  try {
    const {
      data: NTigOsmpGrjyHfR$qKDSW
    } = await axios[XG$hMuJPkpuLpCD(0x19a)](JUNE_API_URL + XG$hMuJPkpuLpCD(0x1b6), {
      'prompt': TpyeczyHpiEfLk$XuoGXijwtP,
      'userId': s_hTsq,
      'groupId': GIZHxbgNTlA$xntzteS
    }, {
      'timeout': 0x61a8,
      'headers': {
        'Authorization': XG$hMuJPkpuLpCD(0x1be) + JUNE_API_KEY,
        'X-Bot-Id': JUNE_BOT_ID,
        'X-Client-Ver': CHATBOT_VERSION,
        'Content-Type': XG$hMuJPkpuLpCD(0x1a6),
        'User-Agent': XG$hMuJPkpuLpCD(0x21c)
      }
    });
    if (NTigOsmpGrjyHfR$qKDSW?.[XG$hMuJPkpuLpCD(0x216)] && NTigOsmpGrjyHfR$qKDSW?.[XG$hMuJPkpuLpCD(0x199)]) return NTigOsmpGrjyHfR$qKDSW;
    throw new Error(NTigOsmpGrjyHfR$qKDSW?.[XG$hMuJPkpuLpCD(0x1e6)] || XG$hMuJPkpuLpCD(0x1b9));
  } catch (VGlJazxiOalJLr$QG_bAD) {
    const OeiMQX$DVv$ZiN = VGlJazxiOalJLr$QG_bAD[XG$hMuJPkpuLpCD(0x185)]?.[XG$hMuJPkpuLpCD(0x1fb)],
      WeiPQ_RpcBaj_NToZaTk = VGlJazxiOalJLr$QG_bAD[XG$hMuJPkpuLpCD(0x185)]?.[XG$hMuJPkpuLpCD(0x1cb)]?.[XG$hMuJPkpuLpCD(0x1e6)];
    if (OeiMQX$DVv$ZiN === 0x3 * parseInt(0x408) + Math.floor(-0xb) * parseInt(0x266) + Math.max(0x63, parseInt(0x63)) * parseInt(0x29)) {
      console[XG$hMuJPkpuLpCD(0x1e6)](XG$hMuJPkpuLpCD(0x16e));
      throw VGlJazxiOalJLr$QG_bAD;
    }
    if (OeiMQX$DVv$ZiN === 0x1 * parseInt(0x202e) + -parseInt(0x24af) + 0x62e) {
      console[XG$hMuJPkpuLpCD(0x1e6)](XG$hMuJPkpuLpCD(0x1f8), WeiPQ_RpcBaj_NToZaTk);
      throw VGlJazxiOalJLr$QG_bAD;
    }
    if (GpRnMZbrRJriPnX$Sdrgnm === -parseInt(0x1ff0) + parseInt(0x196) * 0xa + 0x2a * Number(0x62)) return console[XG$hMuJPkpuLpCD(0x1e8)](XG$hMuJPkpuLpCD(0x1b3) + VGlJazxiOalJLr$QG_bAD[XG$hMuJPkpuLpCD(0x1dd)] + XG$hMuJPkpuLpCD(0x193) + RETRY_DELAY + XG$hMuJPkpuLpCD(0x220)), await sleep(RETRY_DELAY), callAI(TpyeczyHpiEfLk$XuoGXijwtP, s_hTsq, GIZHxbgNTlA$xntzteS, -0x862 * 0x3 + parseFloat(0x1aa6) * -parseInt(0x1) + parseInt(0x59) * Number(0x95));
    console[XG$hMuJPkpuLpCD(0x1e6)](XG$hMuJPkpuLpCD(0x1fd), WeiPQ_RpcBaj_NToZaTk || VGlJazxiOalJLr$QG_bAD[XG$hMuJPkpuLpCD(0x1dd)]);
    throw VGlJazxiOalJLr$QG_bAD;
  }
}
async function clearRemoteHistory(TeizYJPxxQjxHP, vOy_q$qlYAahTgSujPCbP) {
  const Nkpnk_DY_rhWF = OU_r$VJaYD;
  try {
    await axios[Nkpnk_DY_rhWF(0x1a2)](JUNE_API_URL + Nkpnk_DY_rhWF(0x1b6), {
      'data': {
        'userId': TeizYJPxxQjxHP,
        'groupId': vOy_q$qlYAahTgSujPCbP
      },
      'timeout': 0x3a98,
      'headers': {
        'Authorization': Nkpnk_DY_rhWF(0x1be) + JUNE_API_KEY,
        'X-Bot-Id': JUNE_BOT_ID,
        'Content-Type': Nkpnk_DY_rhWF(0x1a6)
      }
    });
  } catch (nLSaAMkoIsDuYUzzHPa_E) {
    console[Nkpnk_DY_rhWF(0x1e6)](Nkpnk_DY_rhWF(0x1b0), nLSaAMkoIsDuYUzzHPa_E[Nkpnk_DY_rhWF(0x185)]?.[Nkpnk_DY_rhWF(0x1cb)]?.[Nkpnk_DY_rhWF(0x1e6)] || nLSaAMkoIsDuYUzzHPa_E[Nkpnk_DY_rhWF(0x1dd)]);
  }
}
async function factoryReset() {
  const J_S$Hjjju = OU_r$VJaYD;
  database[J_S$Hjjju(0x1dc)](J_S$Hjjju(0x21b), ![]);
  try {
    if (typeof database[J_S$Hjjju(0x204)] === J_S$Hjjju(0x215)) database[J_S$Hjjju(0x204)](J_S$Hjjju(0x212)), database[J_S$Hjjju(0x204)](J_S$Hjjju(0x17b));else typeof database[J_S$Hjjju(0x223)] === J_S$Hjjju(0x215) && (database[J_S$Hjjju(0x223)](), database[J_S$Hjjju(0x1dc)](J_S$Hjjju(0x21b), ![]));
  } catch (t$oOfd) {}
  await clearRemoteHistory(null, null);
}
async function handleAIResponse(a$ygkhgi, WqPvoBxBOHaZ_RK_yoljaIIP, e_HstB, dgPEPxvmpUPLRvqv$$WwmRARW) {
  const XtRrjSA$HJs_mvQO = OU_r$VJaYD,
    {
      type = XtRrjSA$HJs_mvQO(0x1ca),
      reply: ouHbG,
      data = {}
    } = dgPEPxvmpUPLRvqv$$WwmRARW,
    ZadKy = {
      'quoted': e_HstB
    };
  function PniLGIYQVeEpoDDci$PGF_d() {
    const HBeB_$EicHkyKjzOX = XtRrjSA$HJs_mvQO;
    if (data[HBeB_$EicHkyKjzOX(0x219)]) return Buffer[HBeB_$EicHkyKjzOX(0x1b4)](String(data[HBeB_$EicHkyKjzOX(0x219)]), HBeB_$EicHkyKjzOX(0x183));
    if (data[HBeB_$EicHkyKjzOX(0x206)]) return {
      'url': String(data[HBeB_$EicHkyKjzOX(0x206)])
    };
    return null;
  }
  async function Obtfn$oOGvGniK() {
    const LII$xBEITwaXdzhsVtQjcwV = XtRrjSA$HJs_mvQO;
    await a$ygkhgi[LII$xBEITwaXdzhsVtQjcwV(0x201)](WqPvoBxBOHaZ_RK_yoljaIIP, {
      'text': ouHbG
    }, ZadKy);
  }
  async function YZcFARhONMULUxggNI(zdghsZgLeTO) {
    const xrXYdlPjv = XtRrjSA$HJs_mvQO;
    try {
      await a$ygkhgi[xrXYdlPjv(0x201)](WqPvoBxBOHaZ_RK_yoljaIIP, zdghsZgLeTO, ZadKy);
    } catch (tymzIYmcwdQpvIZ_HxYZUwr) {
      console[xrXYdlPjv(0x1e6)](xrXYdlPjv(0x175) + type + xrXYdlPjv(0x1a7), tymzIYmcwdQpvIZ_HxYZUwr[xrXYdlPjv(0x1dd)]), await Obtfn$oOGvGniK();
    }
  }
  if (type === XtRrjSA$HJs_mvQO(0x180)) {
    const qGqli_EEbW_MOwnrYRtxUz = PniLGIYQVeEpoDDci$PGF_d();
    if (!qGqli_EEbW_MOwnrYRtxUz) return console[XtRrjSA$HJs_mvQO(0x1e8)](XtRrjSA$HJs_mvQO(0x1ce)), Obtfn$oOGvGniK();
    return YZcFARhONMULUxggNI({
      'image': qGqli_EEbW_MOwnrYRtxUz,
      'caption': ouHbG
    });
  }
  if (type === XtRrjSA$HJs_mvQO(0x1e0)) {
    const t_jLaoi = PniLGIYQVeEpoDDci$PGF_d();
    if (!t_jLaoi) return console[XtRrjSA$HJs_mvQO(0x1e8)](XtRrjSA$HJs_mvQO(0x1b8)), Obtfn$oOGvGniK();
    return YZcFARhONMULUxggNI({
      'document': t_jLaoi,
      'mimetype': String(data[XtRrjSA$HJs_mvQO(0x18d)] || XtRrjSA$HJs_mvQO(0x171)),
      'fileName': String(data[XtRrjSA$HJs_mvQO(0x18a)] || data[XtRrjSA$HJs_mvQO(0x198)] || XtRrjSA$HJs_mvQO(0x1cf)),
      'caption': ouHbG
    });
  }
  if (type === XtRrjSA$HJs_mvQO(0x209)) {
    const WuhFDaz = PniLGIYQVeEpoDDci$PGF_d();
    if (!WuhFDaz) return console[XtRrjSA$HJs_mvQO(0x1e8)](XtRrjSA$HJs_mvQO(0x184)), Obtfn$oOGvGniK();
    return YZcFARhONMULUxggNI({
      'audio': WuhFDaz,
      'mimetype': String(data[XtRrjSA$HJs_mvQO(0x18d)] || XtRrjSA$HJs_mvQO(0x169)),
      'ptt': ![]
    });
  }
  if (type === XtRrjSA$HJs_mvQO(0x1fa)) {
    const fcxKoKmNLMW_bHOuwh_h = PniLGIYQVeEpoDDci$PGF_d();
    if (!fcxKoKmNLMW_bHOuwh_h) return console[XtRrjSA$HJs_mvQO(0x1e8)](XtRrjSA$HJs_mvQO(0x222)), Obtfn$oOGvGniK();
    return YZcFARhONMULUxggNI({
      'video': fcxKoKmNLMW_bHOuwh_h,
      'mimetype': String(data[XtRrjSA$HJs_mvQO(0x18d)] || XtRrjSA$HJs_mvQO(0x182)),
      'caption': ouHbG
    });
  }
  if (type === XtRrjSA$HJs_mvQO(0x195)) {
    const rBbAStVGz_sFIFb_CoBGklhhVmq = PniLGIYQVeEpoDDci$PGF_d();
    if (!rBbAStVGz_sFIFb_CoBGklhhVmq) return console[XtRrjSA$HJs_mvQO(0x1e8)](XtRrjSA$HJs_mvQO(0x1e3)), Obtfn$oOGvGniK();
    return YZcFARhONMULUxggNI({
      'sticker': rBbAStVGz_sFIFb_CoBGklhhVmq
    });
  }
  await Obtfn$oOGvGniK();
}
function extractText(PxDiZReyC$pMT) {
  const QmykaIgMJAadOH = OU_r$VJaYD,
    xIaYw = PxDiZReyC$pMT?.[QmykaIgMJAadOH(0x1dd)];
  if (!xIaYw) return '';
  const DWzY_qMtgOsyzkS_iY = xIaYw[QmykaIgMJAadOH(0x1c9)]?.[QmykaIgMJAadOH(0x1dd)] || xIaYw[QmykaIgMJAadOH(0x21f)]?.[QmykaIgMJAadOH(0x1dd)] || xIaYw;
  let wfDUVTWwtYjiF = (DWzY_qMtgOsyzkS_iY[QmykaIgMJAadOH(0x186)] || DWzY_qMtgOsyzkS_iY[QmykaIgMJAadOH(0x1f0)]?.[QmykaIgMJAadOH(0x1ca)] || DWzY_qMtgOsyzkS_iY[QmykaIgMJAadOH(0x179)]?.[QmykaIgMJAadOH(0x17f)] || DWzY_qMtgOsyzkS_iY[QmykaIgMJAadOH(0x16a)]?.[QmykaIgMJAadOH(0x17f)] || DWzY_qMtgOsyzkS_iY[QmykaIgMJAadOH(0x1f9)]?.[QmykaIgMJAadOH(0x17f)] || DWzY_qMtgOsyzkS_iY[QmykaIgMJAadOH(0x19c)]?.[QmykaIgMJAadOH(0x20f)] || '')[QmykaIgMJAadOH(0x221)]();
  const zJB_rq$D = Object[QmykaIgMJAadOH(0x17a)](DWzY_qMtgOsyzkS_iY || {})[QmykaIgMJAadOH(0x1af)](UgUaUMrAzTUUJzPluzwfHoC$B => UgUaUMrAzTUUJzPluzwfHoC$B?.[QmykaIgMJAadOH(0x187)])?.[QmykaIgMJAadOH(0x187)];
  if (zJB_rq$D?.[QmykaIgMJAadOH(0x1df)]) {
    const HExWlLNoGaKHZePCMDXBN = zJB_rq$D[QmykaIgMJAadOH(0x1df)],
      VNo_VpJtQqRzBBySmk = (HExWlLNoGaKHZePCMDXBN[QmykaIgMJAadOH(0x186)] || HExWlLNoGaKHZePCMDXBN[QmykaIgMJAadOH(0x1f0)]?.[QmykaIgMJAadOH(0x1ca)] || HExWlLNoGaKHZePCMDXBN[QmykaIgMJAadOH(0x179)]?.[QmykaIgMJAadOH(0x17f)] || HExWlLNoGaKHZePCMDXBN[QmykaIgMJAadOH(0x16a)]?.[QmykaIgMJAadOH(0x17f)] || HExWlLNoGaKHZePCMDXBN[QmykaIgMJAadOH(0x1f9)]?.[QmykaIgMJAadOH(0x17f)] || '')[QmykaIgMJAadOH(0x221)]();
    if (VNo_VpJtQqRzBBySmk) wfDUVTWwtYjiF = wfDUVTWwtYjiF ? wfDUVTWwtYjiF + '\x20' + VNo_VpJtQqRzBBySmk : VNo_VpJtQqRzBBySmk;
  }
  return wfDUVTWwtYjiF;
}
function mentionsBot(cSCDXaLlPQqqNVCEXeVk$Nt, KKjqA_KG$hh) {
  const bqaNrJ_HscJzUJMpjRhF$N = OU_r$VJaYD,
    fTbhsiDKxI = (KKjqA_KG$hh?.[bqaNrJ_HscJzUJMpjRhF$N(0x21e)]?.['id'] || '')[bqaNrJ_HscJzUJMpjRhF$N(0x1c4)](':')[0xae8 + -0x39a * parseFloat(parseInt(0x5)) + Math.trunc(-parseInt(0x3)) * parseFloat(-0x25e)][bqaNrJ_HscJzUJMpjRhF$N(0x1c4)]('@')[-0x2 * -0x2c + 0x7 * Number(-parseInt(0xc1)) + Math.ceil(-0x3) * parseInt(-0x1a5)],
    vXYp_QNE = (KKjqA_KG$hh?.[bqaNrJ_HscJzUJMpjRhF$N(0x21e)]?.[bqaNrJ_HscJzUJMpjRhF$N(0x17d)] || '')[bqaNrJ_HscJzUJMpjRhF$N(0x1c4)](':')[Number(-0x2483) + parseInt(0x233d) + Math.floor(parseInt(0x146))][bqaNrJ_HscJzUJMpjRhF$N(0x1c4)]('@')[parseInt(0x2468) + Math.floor(parseInt(0xbf)) * parseFloat(0x1a) + -parseInt(0x94d) * 0x6];
  if (!fTbhsiDKxI && !vXYp_QNE) return ![];
  const ahsUtLGK$TSCUH_jTc = cSCDXaLlPQqqNVCEXeVk$Nt?.[bqaNrJ_HscJzUJMpjRhF$N(0x1dd)]?.[bqaNrJ_HscJzUJMpjRhF$N(0x1c9)]?.[bqaNrJ_HscJzUJMpjRhF$N(0x1dd)] || cSCDXaLlPQqqNVCEXeVk$Nt?.[bqaNrJ_HscJzUJMpjRhF$N(0x1dd)]?.[bqaNrJ_HscJzUJMpjRhF$N(0x21f)]?.[bqaNrJ_HscJzUJMpjRhF$N(0x1dd)] || cSCDXaLlPQqqNVCEXeVk$Nt?.[bqaNrJ_HscJzUJMpjRhF$N(0x1dd)],
    cKpGYrhTlUMJhZA_UXgaNHZQoD = Object[bqaNrJ_HscJzUJMpjRhF$N(0x17a)](ahsUtLGK$TSCUH_jTc || {})[bqaNrJ_HscJzUJMpjRhF$N(0x1af)](tnjJG => tnjJG?.[bqaNrJ_HscJzUJMpjRhF$N(0x187)])?.[bqaNrJ_HscJzUJMpjRhF$N(0x187)];
  if (cKpGYrhTlUMJhZA_UXgaNHZQoD?.[bqaNrJ_HscJzUJMpjRhF$N(0x1fe)]?.[bqaNrJ_HscJzUJMpjRhF$N(0x1f6)](q_PwMSpRz_N => fTbhsiDKxI && q_PwMSpRz_N[bqaNrJ_HscJzUJMpjRhF$N(0x21a)](fTbhsiDKxI) || vXYp_QNE && q_PwMSpRz_N[bqaNrJ_HscJzUJMpjRhF$N(0x21a)](vXYp_QNE))) return !![];
  const eXONCAnCM$EGRV_fpe = cKpGYrhTlUMJhZA_UXgaNHZQoD?.[bqaNrJ_HscJzUJMpjRhF$N(0x1e4)] || '';
  if (eXONCAnCM$EGRV_fpe && (fTbhsiDKxI && eXONCAnCM$EGRV_fpe[bqaNrJ_HscJzUJMpjRhF$N(0x21a)](fTbhsiDKxI) || vXYp_QNE && eXONCAnCM$EGRV_fpe[bqaNrJ_HscJzUJMpjRhF$N(0x21a)](vXYp_QNE))) return !![];
  const chFRTnyln = (ahsUtLGK$TSCUH_jTc?.[bqaNrJ_HscJzUJMpjRhF$N(0x186)] || ahsUtLGK$TSCUH_jTc?.[bqaNrJ_HscJzUJMpjRhF$N(0x1f0)]?.[bqaNrJ_HscJzUJMpjRhF$N(0x1ca)] || ahsUtLGK$TSCUH_jTc?.[bqaNrJ_HscJzUJMpjRhF$N(0x179)]?.[bqaNrJ_HscJzUJMpjRhF$N(0x17f)] || ahsUtLGK$TSCUH_jTc?.[bqaNrJ_HscJzUJMpjRhF$N(0x16a)]?.[bqaNrJ_HscJzUJMpjRhF$N(0x17f)] || ahsUtLGK$TSCUH_jTc?.[bqaNrJ_HscJzUJMpjRhF$N(0x1f9)]?.[bqaNrJ_HscJzUJMpjRhF$N(0x17f)] || ahsUtLGK$TSCUH_jTc?.[bqaNrJ_HscJzUJMpjRhF$N(0x19c)]?.[bqaNrJ_HscJzUJMpjRhF$N(0x20f)] || '')[bqaNrJ_HscJzUJMpjRhF$N(0x221)]();
  return fTbhsiDKxI && chFRTnyln[bqaNrJ_HscJzUJMpjRhF$N(0x21a)]('@' + fTbhsiDKxI) || vXYp_QNE && chFRTnyln[bqaNrJ_HscJzUJMpjRhF$N(0x21a)]('@' + vXYp_QNE);
}
async function handleAutoReply(dXzybJQAsrcQUWLos, A$XIpw$OubKvqdMwMMcOe, XNtVX$u_FH) {
  const FjByXlML$BIODKZ = OU_r$VJaYD;
  try {
    const {
      from: B_$cRnFWEGV,
      isGroup: ryszZSPzO$AGGtJfN
    } = XNtVX$u_FH;
    if (A$XIpw$OubKvqdMwMMcOe[FjByXlML$BIODKZ(0x1d0)][FjByXlML$BIODKZ(0x190)]) return;
    const Qhk_uxVEvLIcS_ajeuqOyxBF = A$XIpw$OubKvqdMwMMcOe[FjByXlML$BIODKZ(0x1d0)][FjByXlML$BIODKZ(0x1e4)] || A$XIpw$OubKvqdMwMMcOe[FjByXlML$BIODKZ(0x1d0)][FjByXlML$BIODKZ(0x1f2)] || B_$cRnFWEGV,
      y$ZHEurZlNISZThCXLWRJcoyf = Date[FjByXlML$BIODKZ(0x1c5)]();
    if (lastRequest[FjByXlML$BIODKZ(0x174)](Qhk_uxVEvLIcS_ajeuqOyxBF) && y$ZHEurZlNISZThCXLWRJcoyf - lastRequest[FjByXlML$BIODKZ(0x1ed)](Qhk_uxVEvLIcS_ajeuqOyxBF) < RATE_MS) return;
    if (ryszZSPzO$AGGtJfN) {
      if (getGroupMention(B_$cRnFWEGV)) {
        if (!mentionsBot(A$XIpw$OubKvqdMwMMcOe, dXzybJQAsrcQUWLos)) return;
      } else {
        if (getGroupChatbot(B_$cRnFWEGV)) {} else return;
      }
    } else {
      if (!getPrivate()) return;
    }
    let jQPT$BMryklsQf = extractText(A$XIpw$OubKvqdMwMMcOe);
    if (!jQPT$BMryklsQf) return;
    const ZqwM_vdi = (dXzybJQAsrcQUWLos?.[FjByXlML$BIODKZ(0x21e)]?.['id'] || '')[FjByXlML$BIODKZ(0x1c4)](':')[Math.ceil(0x670) * -0x4 + 0xb7f + -0xe41 * -0x1][FjByXlML$BIODKZ(0x1c4)]('@')[0xec7 + Number(-0x20b0) + 0x11e9],
      v_fPYZjTJKkw = (dXzybJQAsrcQUWLos?.[FjByXlML$BIODKZ(0x21e)]?.[FjByXlML$BIODKZ(0x17d)] || '')[FjByXlML$BIODKZ(0x1c4)](':')[0x1 * Number(0x1727) + parseFloat(parseInt(0x1c0)) * Number(-parseInt(0xb)) + -0x25 * parseInt(0x1b)][FjByXlML$BIODKZ(0x1c4)]('@')[Number(parseInt(0x1615)) + Math.floor(0x5) * -0x237 + parseFloat(-0xb02)];
    if (ZqwM_vdi) jQPT$BMryklsQf = jQPT$BMryklsQf[FjByXlML$BIODKZ(0x19e)](new RegExp('@' + ZqwM_vdi + FjByXlML$BIODKZ(0x16d), 'g'), '')[FjByXlML$BIODKZ(0x221)]();
    if (v_fPYZjTJKkw) jQPT$BMryklsQf = jQPT$BMryklsQf[FjByXlML$BIODKZ(0x19e)](new RegExp('@' + v_fPYZjTJKkw + FjByXlML$BIODKZ(0x16d), 'g'), '')[FjByXlML$BIODKZ(0x221)]();
    if (!jQPT$BMryklsQf) return;
    lastRequest[FjByXlML$BIODKZ(0x192)](Qhk_uxVEvLIcS_ajeuqOyxBF, y$ZHEurZlNISZThCXLWRJcoyf);
    try {
      await dXzybJQAsrcQUWLos[FjByXlML$BIODKZ(0x1f5)](FjByXlML$BIODKZ(0x19d), B_$cRnFWEGV);
    } catch (JEDbPUYQcATUXrh) {}
    const a$_TAfg = await callAI(jQPT$BMryklsQf, Qhk_uxVEvLIcS_ajeuqOyxBF, ryszZSPzO$AGGtJfN ? B_$cRnFWEGV : undefined);
    await handleAIResponse(dXzybJQAsrcQUWLos, B_$cRnFWEGV, A$XIpw$OubKvqdMwMMcOe, a$_TAfg);
  } catch (WpsrrLEt$RY) {
    console[FjByXlML$BIODKZ(0x1e6)](FjByXlML$BIODKZ(0x1ee), WpsrrLEt$RY[FjByXlML$BIODKZ(0x1dd)]);
  }
}
function buildStatus(kbQ_VFLSUDkX, ILjUdPI$vQcrdkUjcnjPruoqAD) {
  const npRxkvgpGLwYJhI_jgZvqyR = OU_r$VJaYD,
    NIJmJi = getPrivate(),
    k$Y$qFNPB = ILjUdPI$vQcrdkUjcnjPruoqAD ? getGroupChatbot(kbQ_VFLSUDkX) : ![],
    iN_xLaHIAq_KbmEtvpOjs = ILjUdPI$vQcrdkUjcnjPruoqAD ? getGroupMention(kbQ_VFLSUDkX) : ![];
  let CzyOFvIGsByZXFke;
  if (ILjUdPI$vQcrdkUjcnjPruoqAD) {
    if (iN_xLaHIAq_KbmEtvpOjs) CzyOFvIGsByZXFke = npRxkvgpGLwYJhI_jgZvqyR(0x1c8);else {
      if (k$Y$qFNPB) CzyOFvIGsByZXFke = npRxkvgpGLwYJhI_jgZvqyR(0x17e);else CzyOFvIGsByZXFke = npRxkvgpGLwYJhI_jgZvqyR(0x1a5);
    }
  } else CzyOFvIGsByZXFke = NIJmJi ? npRxkvgpGLwYJhI_jgZvqyR(0x1e2) : npRxkvgpGLwYJhI_jgZvqyR(0x1a5);
  const OaihU$vWSG$rgM = [npRxkvgpGLwYJhI_jgZvqyR(0x1f7) + CHATBOT_VERSION, npRxkvgpGLwYJhI_jgZvqyR(0x1c7)];
  return ILjUdPI$vQcrdkUjcnjPruoqAD ? OaihU$vWSG$rgM[npRxkvgpGLwYJhI_jgZvqyR(0x16c)](npRxkvgpGLwYJhI_jgZvqyR(0x1d4), npRxkvgpGLwYJhI_jgZvqyR(0x177) + icon(k$Y$qFNPB) + '*', npRxkvgpGLwYJhI_jgZvqyR(0x176) + icon(iN_xLaHIAq_KbmEtvpOjs) + '*\x0a') : OaihU$vWSG$rgM[npRxkvgpGLwYJhI_jgZvqyR(0x16c)](npRxkvgpGLwYJhI_jgZvqyR(0x172), npRxkvgpGLwYJhI_jgZvqyR(0x207) + icon(NIJmJi) + '*\x0a'), OaihU$vWSG$rgM[npRxkvgpGLwYJhI_jgZvqyR(0x16c)](npRxkvgpGLwYJhI_jgZvqyR(0x1a0), '•\x20' + CzyOFvIGsByZXFke), OaihU$vWSG$rgM[npRxkvgpGLwYJhI_jgZvqyR(0x20a)]('\x0a');
}
function buildHelp() {
  const ZHWE_snjEjthNejKRdAnZrH_WBF = OU_r$VJaYD;
  return ZHWE_snjEjthNejKRdAnZrH_WBF(0x1ea) + CHATBOT_VERSION + '\x0a' + ZHWE_snjEjthNejKRdAnZrH_WBF(0x217) + ZHWE_snjEjthNejKRdAnZrH_WBF(0x200) + ZHWE_snjEjthNejKRdAnZrH_WBF(0x205) + ZHWE_snjEjthNejKRdAnZrH_WBF(0x1f3) + ZHWE_snjEjthNejKRdAnZrH_WBF(0x1bd) + ZHWE_snjEjthNejKRdAnZrH_WBF(0x1ae) + ZHWE_snjEjthNejKRdAnZrH_WBF(0x20b) + ZHWE_snjEjthNejKRdAnZrH_WBF(0x1d5);
}
module[OU_r$VJaYD(0x1e5)] = {
  'name': OU_r$VJaYD(0x1a4),
  'aliases': ['cb', OU_r$VJaYD(0x1a8)],
  'category': OU_r$VJaYD(0x17c),
  'description': OU_r$VJaYD(0x1d7),
  'usage': OU_r$VJaYD(0x213),
  async 'execute'(OYNk$gHH, lZvZjRlTLpZPLwhaiso, yKLFvQW$tsFbuTkU$xNWoinW, GELYwX$OxGWGixdwjAAOgSb) {
    const lwtK__bDtmi = OU_r$VJaYD,
      {
        from: ytgTjQTvIy$hxu$iBn,
        isGroup: y_mPCbrZrxC_begbbZPJfvRi,
        isOwner: ItbWJasMmTmR_VLJUSf,
        reply: VnurvH$aF$stygeJdViVdsxUgjY,
        react: QZWQ$jzIaNDM$u
      } = GELYwX$OxGWGixdwjAAOgSb,
      qhNCLvaRtQ$VombL$Imcats = (yKLFvQW$tsFbuTkU$xNWoinW[Number(parseInt(0x1a6)) + -0x1944 + parseInt(0x179e)] || '')[lwtK__bDtmi(0x1ad)](),
      PZczKXh$NZmGhPdI = (yKLFvQW$tsFbuTkU$xNWoinW[0x2307 + Number(parseInt(0x7)) * Number(-0x1f) + -parseInt(0x222d)] || '')[lwtK__bDtmi(0x1ad)]();
    if (!qhNCLvaRtQ$VombL$Imcats || qhNCLvaRtQ$VombL$Imcats === lwtK__bDtmi(0x210)) return VnurvH$aF$stygeJdViVdsxUgjY(buildHelp());
    if (qhNCLvaRtQ$VombL$Imcats === lwtK__bDtmi(0x1fb)) return VnurvH$aF$stygeJdViVdsxUgjY(buildStatus(ytgTjQTvIy$hxu$iBn, y_mPCbrZrxC_begbbZPJfvRi));
    if (qhNCLvaRtQ$VombL$Imcats === lwtK__bDtmi(0x16b) || qhNCLvaRtQ$VombL$Imcats === lwtK__bDtmi(0x1a9)) {
      const BWzwB_RgBwmiKkHMFRyYV = lZvZjRlTLpZPLwhaiso[lwtK__bDtmi(0x1d0)][lwtK__bDtmi(0x1e4)] || lZvZjRlTLpZPLwhaiso[lwtK__bDtmi(0x1d0)][lwtK__bDtmi(0x1f2)] || ytgTjQTvIy$hxu$iBn,
        SC$hvyCj = y_mPCbrZrxC_begbbZPJfvRi ? ytgTjQTvIy$hxu$iBn : undefined;
      return await clearRemoteHistory(BWzwB_RgBwmiKkHMFRyYV, SC$hvyCj), await QZWQ$jzIaNDM$u(lwtK__bDtmi(0x218)), VnurvH$aF$stygeJdViVdsxUgjY(lwtK__bDtmi(0x1a1));
    }
    if (!ItbWJasMmTmR_VLJUSf) return VnurvH$aF$stygeJdViVdsxUgjY(lwtK__bDtmi(0x211));
    if (qhNCLvaRtQ$VombL$Imcats === 'gc') {
      if (!y_mPCbrZrxC_begbbZPJfvRi) return VnurvH$aF$stygeJdViVdsxUgjY(lwtK__bDtmi(0x1c6));
      if (PZczKXh$NZmGhPdI !== 'on' && PZczKXh$NZmGhPdI !== lwtK__bDtmi(0x189)) return VnurvH$aF$stygeJdViVdsxUgjY(lwtK__bDtmi(0x21d) + lwtK__bDtmi(0x170) + lwtK__bDtmi(0x1f4));
      const sFlPZCryHtBejKmpCEDDP$r = PZczKXh$NZmGhPdI === 'on';
      setGroupChatbot(ytgTjQTvIy$hxu$iBn, sFlPZCryHtBejKmpCEDDP$r);
      if (sFlPZCryHtBejKmpCEDDP$r) setGroupMention(ytgTjQTvIy$hxu$iBn, ![]);
      return await QZWQ$jzIaNDM$u(sFlPZCryHtBejKmpCEDDP$r ? '✅' : '❌'), VnurvH$aF$stygeJdViVdsxUgjY(lwtK__bDtmi(0x18f) + (sFlPZCryHtBejKmpCEDDP$r ? lwtK__bDtmi(0x1e9) : lwtK__bDtmi(0x1b1)) + lwtK__bDtmi(0x20c) + buildStatus(ytgTjQTvIy$hxu$iBn, y_mPCbrZrxC_begbbZPJfvRi));
    }
    if (qhNCLvaRtQ$VombL$Imcats === 'pm' || qhNCLvaRtQ$VombL$Imcats === lwtK__bDtmi(0x19f) || qhNCLvaRtQ$VombL$Imcats === 'dm') {
      if (PZczKXh$NZmGhPdI !== 'on' && PZczKXh$NZmGhPdI !== lwtK__bDtmi(0x189)) return VnurvH$aF$stygeJdViVdsxUgjY(lwtK__bDtmi(0x21d) + lwtK__bDtmi(0x1ec) + lwtK__bDtmi(0x188));
      const CpQTTaKcA = PZczKXh$NZmGhPdI === 'on';
      return setPrivate(CpQTTaKcA), await QZWQ$jzIaNDM$u(CpQTTaKcA ? '✅' : '❌'), VnurvH$aF$stygeJdViVdsxUgjY(lwtK__bDtmi(0x1ab) + (CpQTTaKcA ? lwtK__bDtmi(0x1e9) : lwtK__bDtmi(0x1b1)) + lwtK__bDtmi(0x1db) + buildStatus(ytgTjQTvIy$hxu$iBn, y_mPCbrZrxC_begbbZPJfvRi));
    }
    if (qhNCLvaRtQ$VombL$Imcats === lwtK__bDtmi(0x1eb)) {
      if (!y_mPCbrZrxC_begbbZPJfvRi) return VnurvH$aF$stygeJdViVdsxUgjY(lwtK__bDtmi(0x1d6));
      if (PZczKXh$NZmGhPdI !== 'on' && PZczKXh$NZmGhPdI !== lwtK__bDtmi(0x189)) return VnurvH$aF$stygeJdViVdsxUgjY(lwtK__bDtmi(0x21d) + lwtK__bDtmi(0x1e1) + lwtK__bDtmi(0x194));
      const RLoPrlalOqeVdv = PZczKXh$NZmGhPdI === 'on';
      setGroupMention(ytgTjQTvIy$hxu$iBn, RLoPrlalOqeVdv);
      if (RLoPrlalOqeVdv) setGroupChatbot(ytgTjQTvIy$hxu$iBn, ![]);
      return await QZWQ$jzIaNDM$u(RLoPrlalOqeVdv ? '✅' : '❌'), VnurvH$aF$stygeJdViVdsxUgjY(lwtK__bDtmi(0x1da) + (RLoPrlalOqeVdv ? lwtK__bDtmi(0x1e9) : lwtK__bDtmi(0x1b1)) + lwtK__bDtmi(0x1de) + (RLoPrlalOqeVdv ? lwtK__bDtmi(0x18b) : lwtK__bDtmi(0x1bf)) + ('\x0a\x0a' + buildStatus(ytgTjQTvIy$hxu$iBn, y_mPCbrZrxC_begbbZPJfvRi)));
    }
    if (qhNCLvaRtQ$VombL$Imcats === lwtK__bDtmi(0x1c0)) return await factoryReset(), await QZWQ$jzIaNDM$u('⚠️'), VnurvH$aF$stygeJdViVdsxUgjY(lwtK__bDtmi(0x1b2) + lwtK__bDtmi(0x1c7) + lwtK__bDtmi(0x1d1) + lwtK__bDtmi(0x178) + lwtK__bDtmi(0x18c) + lwtK__bDtmi(0x19b) + lwtK__bDtmi(0x1b7));
    return VnurvH$aF$stygeJdViVdsxUgjY(lwtK__bDtmi(0x1d2) + qhNCLvaRtQ$VombL$Imcats + lwtK__bDtmi(0x1c2));
  },
  'handleAutoReply': handleAutoReply
};