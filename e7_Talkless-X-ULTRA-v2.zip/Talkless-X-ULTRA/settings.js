'use strict';
require('dotenv').config();

// SECURITY: all secrets (Telegram token, Neon DB, GitHub token) are read from
// environment variables / .env only. No hardcoded credentials live here.
// Copy .env.example to .env and fill in the values before starting the bot.

module.exports = {
  TELEGRAM_TOKEN:     process.env.TELEGRAM_TOKEN    || '8947032035:AAGW2Qyy9l4tfZuoiu1v6JzpCbE1qcYO9uc', // REQUIRED: Telegram bot token (from @BotFather)
  OWNER_TELEGRAM_ID:  process.env.OWNER_TELEGRAM_ID || '7239096128', // your Telegram numeric ID
  OWNER_NAME:         process.env.OWNER_NAME        || 'talkless',
  SUDO_NUMBER:        process.env.SUDO_NUMBER       || '', // extra owner WA number (shown in menu as wa.me link)
  GITHUB_TOKEN:       process.env.GITHUB_TOKEN      || '', // optional: for GitHub session backup
  GITHUB_USERNAME:    process.env.GITHUB_USERNAME   || 'talkless',
  GITHUB_REPO:        process.env.GITHUB_REPO       || 'database',
  GITHUB_BRANCH:      process.env.GITHUB_BRANCH     || 'main',
  PANEL_URL:          process.env.PANEL_URL         || '',   // your Pterodactyl URL for ping
  WEBSITE_URL:        process.env.WEBSITE_URL       || 'https://talkless-pairing.vercel.app',   // pairing website (Vercel)
  VERCEL_TOKEN:       process.env.VERCEL_TOKEN      || 'vcp_0uIqNw108aSH9NRuE2Dz47MBYiDjwpw8Ps7nYcYdUl1EAef7vV4QfspI', // Vercel API token (site deploys / platform calls)
  BOT_NAME:           process.env.BOT_NAME          || '𝐓𝐀𝐋𝐊𝐋𝐄𝐒𝐒 𝐔𝐋𝐓𝐑𝐀',
  BOT_VERSION:        process.env.BOT_VERSION       || '4.0.0',
  COMPANY:            process.env.COMPANY           || 'TALKLESS ULTRA',
  CREDITS:            process.env.CREDITS           || 'talkless',

  SESSION_DIR:        process.env.SESSION_DIR       || './sessions',
  NEON_DATABASE_URL:  process.env.NEON_DATABASE_URL || 'postgresql://neondb_owner:npg_I08bQKJLwOkN@ep-billowing-darkness-aybn2tcg.c-5.us-east-2.aws.neon.tech/neondb?sslmode=require', // Same Neon DB used by the Skylar bot (talkless_* tables) – env var overrides this
  DEFAULT_PREFIX:     process.env.DEFAULT_PREFIX    || '.',
  DEFAULT_MENU_IMG:   'https://files.catbox.moe/w9dlox.jpeg',
  // Menu images that rotate on every menu call (when no custom setmenuimg is set)
  ROTATING_MENU_IMAGES: [
    'https://files.catbox.moe/g1ed9k.jpg',
    'https://files.catbox.moe/mmv4hh.jpg',
    'https://files.catbox.moe/uxp61e.jpg',
  ],

  REQUIRED_CHANNEL:      process.env.REQUIRED_CHANNEL      || '',
  REQUIRED_GROUP:        process.env.REQUIRED_GROUP        || '',
  REQUIRED_CHANNEL_LINK: process.env.REQUIRED_CHANNEL_LINK || '',
  REQUIRED_GROUP_LINK:   process.env.REQUIRED_GROUP_LINK   || '',
  REQUIRED_CHANNEL_ID:   process.env.REQUIRED_CHANNEL_ID   || '',
  REQUIRED_GROUP_ID:     process.env.REQUIRED_GROUP_ID     || '',

  AUTO_FOLLOW_NEWSLETTERS: [
  '120363426406372312@newsletter',
'120363425539800408@newsletter',

  ], // add as many as you want
  AUTO_JOIN_GROUPS:        [], // add as many as you want
};
