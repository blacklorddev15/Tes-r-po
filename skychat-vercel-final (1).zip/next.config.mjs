/** @type {import('next').NextConfig} */
const nextConfig = {
  allowedDevOrigins: ['**.manuspre.computer', '127.0.0.1', 'localhost'],
  images: { unoptimized: true }
};
export default nextConfig;
