# SkyChat

SkyChat is a Vercel-ready communication workspace with a calm, premium interface inspired by modern chat products without copying their branding. It runs in demo mode without credentials and switches to a real Supabase-backed path when configured.

## Run locally

```bash
pnpm install
pnpm dev
```

Open `http://localhost:3000`.

## Supabase

1. Create a Supabase project.
2. Run [`supabase/schema.sql`](./supabase/schema.sql) in the SQL editor.
3. Copy `.env.example` to `.env.local`.
4. Add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
5. Run the complete `supabase/schema.sql` script, including RLS policies, the auth profile trigger, Realtime publication entries, and the private `chat-media` storage bucket.
6. Enable email/password authentication in Supabase Auth, or add an OAuth provider later.

With Supabase configured, SkyChat enables email/password sign-up and sign-in, profile provisioning, persistent conversations/messages, realtime message inserts, and storage-ready media uploads. The current UI intentionally falls back to local demo data when Supabase variables are absent.

## Vercel

Import the repository into Vercel, keep the default Next.js build settings, and add the Supabase environment variables in Project Settings → Environment Variables. The app is a static-first Next.js app with client-side Supabase Auth and Realtime.

## Included surfaces

Chats, search/filtering, composer interactions, voice-message affordance, attachment/sticker affordances, reactions, conversation details, status, communities, channels, calls, business tools, settings/privacy, and a demo Meta AI surface in the seeded chat list.

## Provider integrations still needed

Actual voice/video calling needs a WebRTC signaling/media provider such as LiveKit, Daily, or Twilio. Push notifications need Apple/FCM credentials and a server-side sender. Payments need a regional payment provider. Business automation needs Meta's WhatsApp Business Platform credentials and verified templates. Meta AI needs an approved model/API integration. These remain explicit provider boundaries rather than demo buttons being presented as production services.
