'use client';

import { FormEvent, useState } from 'react';
import { ArrowRight, LockKeyhole, Mail, X } from 'lucide-react';
import { supabase } from '../lib/supabase';

export function AuthModal({ onClose, onSuccess }: { onClose?: () => void; onSuccess: () => void }) {
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!supabase) return;
    setBusy(true); setError('');
    const result = mode === 'signin'
      ? await supabase.auth.signInWithPassword({ email, password })
      : await supabase.auth.signUp({ email, password, options: { data: { display_name: name || email.split('@')[0] } } });
    setBusy(false);
    if (result.error) { setError(result.error.message); return; }
    onSuccess();
  }

  return <div className="modal-backdrop" onClick={onClose}><div className="auth-modal" onClick={(event) => event.stopPropagation()}><button className="icon-button auth-close" onClick={onClose}><X size={18} /></button><div className="auth-logo"><LockKeyhole size={22} /></div><p className="eyebrow">{mode === 'signin' ? 'Welcome back' : 'Create your space'}</p><h2>{mode === 'signin' ? 'Sign in to SkyChat' : 'Join SkyChat'}</h2><p className="auth-subtitle">Use your Supabase account to sync conversations across devices.</p><form onSubmit={submit}>{mode === 'signup' && <label>Name<input value={name} onChange={(event) => setName(event.target.value)} placeholder="Alex Rivera" required /></label>}<label>Email<input type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@example.com" required /></label><label>Password<input type="password" minLength={6} value={password} onChange={(event) => setPassword(event.target.value)} placeholder="At least 6 characters" required /></label>{error && <p className="auth-error">{error}</p>}<button className="primary-button auth-submit" disabled={busy}>{busy ? 'Connecting…' : mode === 'signin' ? 'Sign in' : 'Create account'}<ArrowRight size={16} /></button></form><button className="auth-switch" onClick={() => { setMode(mode === 'signin' ? 'signup' : 'signin'); setError(''); }}>{mode === 'signin' ? 'Need an account? Sign up' : 'Already have an account? Sign in'}</button></div></div>;
}
