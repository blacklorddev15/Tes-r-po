'use client';

import { useEffect, useMemo, useState } from 'react';
import { AuthModal } from './auth-modal';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { createConversation, getMessages, sendMessage as sendCloudMessage, subscribeToMessages, upsertMyProfile, type Message } from '../lib/skychat-data';
import type { Session } from '@supabase/supabase-js';

import {
  Archive, Bell, Bot, BriefcaseBusiness, CalendarDays, Check, ChevronDown, CircleHelp, Clock3,
  Cloud, Compass, Copy, FileText, Hash, Image as ImageIcon, Inbox, Layers3, Link2, LockKeyhole,
  Menu, MessageCircle, Mic, MoreHorizontal, Paperclip, Phone, Pin, Play, Plus, Search, Send,
  Settings, ShieldCheck, Smile, Star, Store, Users, Video, Volume2, X, Zap
} from 'lucide-react';

type Section = 'chats' | 'status' | 'communities' | 'channels' | 'calls' | 'business' | 'settings';

type Chat = {
  id: string; name: string; initials: string; color: string; preview: string; time: string; unread?: number;
  online?: boolean; pinned?: boolean; kind?: string;
};

const chats: Chat[] = [
  { id: 'mira', name: 'Mira Chen', initials: 'MC', color: '#f7b3a6', preview: 'That launch note is such a good direction.', time: '10:42', unread: 3, online: true, pinned: true },
  { id: 'orbit', name: 'Orbit Design Club', initials: 'OD', color: '#c9b9ff', preview: 'Sam: Dropped the moodboard in Files', time: '09:18', unread: 8, kind: 'Group', pinned: true },
  { id: 'noah', name: 'Noah Williams', initials: 'NW', color: '#93d9d3', preview: 'Voice message · 0:32', time: 'Yesterday', online: true },
  { id: 'studio', name: 'Skyline Studio', initials: 'SS', color: '#e8d7a4', preview: 'Your catalog has been updated', time: 'Mon', kind: 'Business' },
  { id: 'lena', name: 'Lena Ortiz', initials: 'LO', color: '#a7c7f2', preview: 'See you at the Sunday market?', time: 'Sun' },
  { id: 'ai', name: 'Meta AI', initials: '✦', color: '#d9cbff', preview: 'Ask me anything...', time: 'Sun', kind: 'Assistant' }
];

const messages = [
  { id: 1, from: 'them', text: 'Hey — I pulled together the latest launch notes. Want the short version?', time: '10:38' },
  { id: 2, from: 'me', text: 'Yes please. And tell me if anything feels off before I share it with the team.', time: '10:39', read: true },
  { id: 3, from: 'them', text: 'The story is clear. I would make the “private by default” line the headline and let the rest breathe.', time: '10:41' },
  { id: 4, from: 'me', text: 'That launch note is such a good direction. I’ll shape the page around it today.', time: '10:42', read: true, reaction: '✦' }
];

const navItems: { id: Section; label: string; icon: typeof MessageCircle }[] = [
  { id: 'chats', label: 'Chats', icon: MessageCircle },
  { id: 'status', label: 'Status', icon: Compass },
  { id: 'communities', label: 'Communities', icon: Users },
  { id: 'channels', label: 'Channels', icon: Hash },
  { id: 'calls', label: 'Calls', icon: Phone },
  { id: 'business', label: 'Business', icon: Store },
];

export default function SkyChat() {
  const [section, setSection] = useState<Section>('chats');
  const [activeChat, setActiveChat] = useState('mira');
  const [query, setQuery] = useState('');
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState<{ text: string; time: string }[]>([]);
  const [toast, setToast] = useState('');
  const [showDetails, setShowDetails] = useState(false);
  const [showComposer, setShowComposer] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [privacy, setPrivacy] = useState(true);
  const [session, setSession] = useState<Session | null>(null);
  const [authOpen, setAuthOpen] = useState(false);
  const [cloudConversationId, setCloudConversationId] = useState<string | null>(null);
  const [cloudMessages, setCloudMessages] = useState<Message[]>([]);

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => setSession(nextSession));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session) return;
    upsertMyProfile(session.user.id, session.user.user_metadata?.display_name || session.user.email?.split('@')[0] || 'SkyChat user').catch(() => undefined);
  }, [session]);

  useEffect(() => {
    if (!cloudConversationId) return;
    getMessages(cloudConversationId).then(setCloudMessages).catch(() => undefined);
    const channel = subscribeToMessages(cloudConversationId, (incoming) => setCloudMessages((current) => current.some((message) => message.id === incoming.id) ? current : [...current, incoming]));
    return () => { if (channel) supabase?.removeChannel(channel); };
  }, [cloudConversationId]);

  const filteredChats = useMemo(() => chats.filter((chat) => `${chat.name} ${chat.preview}`.toLowerCase().includes(query.toLowerCase())), [query]);
  const selected = chats.find((chat) => chat.id === activeChat) ?? chats[0];

  function notify(text: string) {
    setToast(text);
    window.setTimeout(() => setToast(''), 2400);
  }

  async function sendMessage() {
    const clean = message.trim();
    if (!clean) return;
    setSent((current) => [...current, { text: clean, time: 'now' }]);
    setMessage('');
    if (session && isSupabaseConfigured) {
      try {
        let conversationId = cloudConversationId;
        if (!conversationId) {
          const created = await createConversation(session.user.id, selected.name, selected.kind === 'Group' ? 'group' : 'direct');
          conversationId = created?.id ?? null;
          setCloudConversationId(conversationId);
        }
        if (conversationId) await sendCloudMessage(conversationId, session.user.id, clean);
        notify('Message synced to Supabase');
      } catch { notify('Message saved locally; check your Supabase policies'); }
    } else {
      notify(isSupabaseConfigured ? 'Sign in to sync messages' : 'Message sent in demo mode');
    }
  }

  return (
    <main className="app-shell">
      <aside className="nav-rail">
        <div className="brand-mark" aria-label="SkyChat"><span className="brand-orbit" /><span className="brand-bubble" /></div>
        <div className="rail-items">
          {navItems.map((item) => {
            const Icon = item.icon;
            return <button key={item.id} className={`rail-button ${section === item.id ? 'active' : ''}`} onClick={() => setSection(item.id)} title={item.label}><Icon size={19} strokeWidth={section === item.id ? 2.4 : 1.8} /><span>{item.label}</span>{item.id === 'chats' && <b>12</b>}</button>;
          })}
        </div>
        <div className="rail-bottom">
          <button className={`rail-button ${section === 'settings' ? 'active' : ''}`} onClick={() => setSection('settings')} title="Settings"><Settings size={19} /><span>Settings</span></button>
          <button className="avatar self" onClick={() => notify('Your profile is ready to customize')}><span>AR</span><i /></button>
        </div>
      </aside>

      <section className="inbox-panel">
        <header className="inbox-header">
          <div><p className="eyebrow">Private by default</p><h1>Good morning, Alex</h1></div>
          <button className="icon-button mobile-menu" onClick={() => notify('Navigation is always one tap away')}><Menu size={19} /></button>
          <div className="header-actions"><button className="new-chat" onClick={() => { setShowComposer(true); notify('Start a new conversation'); }}><Plus size={16} /> <span>New chat</span></button>{isSupabaseConfigured && <button className="cloud-status" onClick={() => session ? supabase?.auth.signOut() : setAuthOpen(true)}>{session ? 'Sign out' : 'Sign in'}</button>}</div>
        </header>
        <div className="search-box"><Search size={17} /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search conversations" /><span className="shortcut">⌘ K</span></div>

        {section === 'chats' && <>
          <div className="segmented"><button className="selected">All <span>12</span></button><button>Unread <span>8</span></button><button>Groups</button></div>
          <div className="inbox-list">
            {filteredChats.map((chat) => <button key={chat.id} className={`chat-row ${activeChat === chat.id ? 'selected-row' : ''}`} onClick={() => setActiveChat(chat.id)}>
              <div className="avatar" style={{ background: chat.color }}>{chat.initials}<i className={chat.online ? 'online' : ''} /></div>
              <div className="chat-meta"><div className="row-top"><strong>{chat.name}</strong><time>{chat.time}</time></div><div className="row-bottom"><span>{chat.preview}</span>{chat.unread && <b>{chat.unread}</b>}</div></div>
            </button>)}
          </div>
          <div className="inbox-footer"><ShieldCheck size={14} /> Your personal messages are end-to-end encrypted</div>
        </>}
        {section === 'status' && <StatusPanel notify={notify} />}
        {section === 'communities' && <CommunitiesPanel notify={notify} />}
        {section === 'channels' && <ChannelsPanel notify={notify} />}
        {section === 'calls' && <CallsPanel notify={notify} />}
        {section === 'business' && <BusinessPanel notify={notify} />}
        {section === 'settings' && <SettingsPanel privacy={privacy} setPrivacy={setPrivacy} notify={notify} />}
      </section>

      <section className="conversation-panel">
        {section === 'chats' ? <>
          <header className="conversation-header">
            <button className="avatar large" style={{ background: selected.color }} onClick={() => setShowDetails(true)}>{selected.initials}<i className={selected.online ? 'online' : ''} /></button>
            <button className="conversation-title" onClick={() => setShowDetails(true)}><strong>{selected.name}</strong><span>{selected.online ? 'Online now' : selected.kind ?? 'Last seen recently'}</span></button>
            <div className="header-actions"><button className="icon-button" onClick={() => notify('Starting a secure voice call')}><Phone size={18} /></button><button className="icon-button" onClick={() => notify('Starting a private video call')}><Video size={18} /></button><button className="icon-button" onClick={() => setShowDetails(true)}><MoreHorizontal size={18} /></button></div>
          </header>
          <div className="encryption-banner"><LockKeyhole size={14} /><span>Messages are end-to-end encrypted. No one outside of this chat can read them.</span><button onClick={() => notify('Security code verified')}>Learn more</button></div>
          <div className="message-canvas">
            <div className="date-chip">Today</div>
            {messages.map((item) => <MessageBubble key={item.id} item={item} notify={notify} />)}
            {cloudMessages.map((item) => <div className={`message-row ${item.sender_id === session?.user.id ? 'mine' : ''}`} key={`cloud-${item.id}`}><div className="bubble"><p>{item.body}</p><span>{new Date(item.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span></div></div>)}{sent.map((item, index) => <div className="message-row mine" key={`sent-${index}`}><div className="bubble"><p>{item.text}</p><span>{item.time} <Check size={13} /></span></div></div>)}
            <div className="typing"><span className="typing-dots"><i /><i /><i /></span> Mira is typing</div>
          </div>
          <div className="composer-wrap">
            <div className="quick-actions"><button onClick={() => notify('Attachment picker opened')}><Paperclip size={18} /></button><button onClick={() => notify('Sticker and GIF picker opened')}><Smile size={18} /></button></div>
            <div className="composer"><input value={message} onChange={(e) => setMessage(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && sendMessage()} placeholder="Write a message..." /><button className="mic-button" onClick={() => message ? sendMessage() : notify('Recording voice message…')} >{message ? <Send size={18} /> : <Mic size={19} />}</button></div>
            <button className="composer-more" onClick={() => notify('More message options')}><MoreHorizontal size={19} /></button>
          </div>
        </> : <EmptyState section={section} notify={notify} />}
      </section>

      {showDetails && <aside className="details-panel"><div className="details-head"><h3>Conversation details</h3><button className="icon-button" onClick={() => setShowDetails(false)}><X size={18} /></button></div><div className="profile-card"><div className="avatar huge" style={{ background: selected.color }}>{selected.initials}<i className={selected.online ? 'online' : ''} /></div><h2>{selected.name}</h2><p>{selected.online ? 'Online now' : 'Available on SkyChat'}</p><div className="profile-actions"><button onClick={() => notify('Voice call started')}><Phone size={16} />Call</button><button onClick={() => notify('Video call started')}><Video size={16} />Video</button><button onClick={() => notify('Search opened')}><Search size={16} />Search</button></div></div><DetailItem icon={<ImageIcon size={16} />} label="Media, links and docs" value="24 items" /><DetailItem icon={<Star size={16} />} label="Starred messages" value="3 saved" /><DetailItem icon={<Bell size={16} />} label="Notifications" value="On" toggle /><DetailItem icon={<Clock3 size={16} />} label="Disappearing messages" value="Off" toggle /><DetailItem icon={<LockKeyhole size={16} />} label="Chat lock" value="Protected" toggle /></aside>}
      {showComposer && <div className="modal-backdrop" onClick={() => setShowComposer(false)}><div className="new-chat-modal" onClick={(e) => e.stopPropagation()}><div className="details-head"><div><p className="eyebrow">New conversation</p><h3>Who would you like to message?</h3></div><button className="icon-button" onClick={() => setShowComposer(false)}><X size={18} /></button></div><div className="search-box"><Search size={17} /><input autoFocus placeholder="Search people or groups" /></div><div className="contact-option"><div className="avatar" style={{ background: '#f7b3a6' }}>MC</div><div><strong>Mira Chen</strong><span>Available now</span></div><button onClick={() => { setActiveChat('mira'); setShowComposer(false); }}>Open</button></div><div className="contact-option"><div className="avatar" style={{ background: '#c9b9ff' }}>OD</div><div><strong>Orbit Design Club</strong><span>8 active members</span></div><button onClick={() => { setActiveChat('orbit'); setShowComposer(false); }}>Open</button></div></div></div>}
      {toast && <div className="toast"><Check size={15} />{toast}</div>}
      {authOpen && <AuthModal onClose={() => setAuthOpen(false)} onSuccess={() => { setAuthOpen(false); notify('Signed in — cloud sync is active'); }} />}
    </main>
  );
}

function MessageBubble({ item, notify }: { item: typeof messages[number]; notify: (s: string) => void }) {
  return <div className={`message-row ${item.from === 'me' ? 'mine' : ''}`}><div className="bubble"><p>{item.text}</p><span>{item.time}{item.from === 'me' && <Check size={13} />}</span>{item.reaction && <button className="reaction" onClick={() => notify('Reaction added')}>{item.reaction}</button>}</div></div>;
}

function DetailItem({ icon, label, value, toggle }: { icon: React.ReactNode; label: string; value: string; toggle?: boolean }) { return <div className="detail-item"><span className="detail-icon">{icon}</span><div><strong>{label}</strong><small>{value}</small></div>{toggle ? <button className="toggle on"><i /></button> : <ChevronDown size={16} />}</div>; }

function StatusPanel({ notify }: { notify: (s: string) => void }) { return <div className="feature-panel"><div className="feature-title"><div><p className="eyebrow">Updates</p><h2>Status</h2></div><button className="outline-button" onClick={() => notify('Status composer opened')}><Plus size={15} /> Add update</button></div><div className="my-status-card"><div className="status-ring"><div className="avatar" style={{ background: '#b6e8df' }}>AR</div><span>+</span></div><div><strong>My status</strong><p>Share a photo, thought or voice note</p></div><button className="icon-button" onClick={() => notify('Status privacy opened')}><MoreHorizontal size={18} /></button></div><div className="section-label">Recent updates <span>Muted by default</span></div><StatusRow initials="MC" color="#f7b3a6" name="Mira Chen" time="18 minutes ago" text="A little quiet time before the big week ✦" notify={notify} /><StatusRow initials="NW" color="#93d9d3" name="Noah Williams" time="2 hours ago" text="Sunday market finds" notify={notify} /></div> }
function StatusRow({ initials, color, name, time, text, notify }: { initials: string; color: string; name: string; time: string; text: string; notify: (s: string) => void }) { return <button className="status-row" onClick={() => notify(`Opening ${name}'s status`)}><div className="status-ring"><div className="avatar" style={{ background: color }}>{initials}</div></div><div><strong>{name}</strong><p>{text}</p><small>{time}</small></div><Play size={15} fill="currentColor" /></button>; }
function CommunitiesPanel({ notify }: { notify: (s: string) => void }) { return <div className="feature-panel"><div className="feature-title"><div><p className="eyebrow">Organize together</p><h2>Communities</h2></div><button className="outline-button" onClick={() => notify('Community creator opened')}><Plus size={15} /> New</button></div><div className="community-hero"><div className="community-symbol"><Users size={24} /></div><div><h3>Bring people together</h3><p>Organize related groups in one calm place.</p></div></div><div className="community-card"><div className="avatar square" style={{ background: '#c9b9ff' }}>OD</div><div><strong>Orbit Design Club</strong><p>3 groups · 128 members</p><small>Announcement: Moodboard review Friday</small></div><ChevronDown size={17} /></div><div className="community-card"><div className="avatar square" style={{ background: '#e8d7a4' }}>NW</div><div><strong>Northside Neighbors</strong><p>5 groups · 64 members</p><small>1 new announcement</small></div><ChevronDown size={17} /></div></div> }
function ChannelsPanel({ notify }: { notify: (s: string) => void }) { return <div className="feature-panel"><div className="feature-title"><div><p className="eyebrow">Broadcasts</p><h2>Channels</h2></div><button className="outline-button" onClick={() => notify('Channel directory opened')}><Compass size={15} /> Explore</button></div><div className="channel-intro"><Hash size={22} /><div><h3>Stay in the loop</h3><p>Follow the people and ideas you care about.</p></div></div><ChannelRow icon="✦" color="#d9cbff" name="Meta AI" text="New ways to make your chats work harder" followers="2.4M followers" notify={notify} /><ChannelRow icon="S" color="#49d7d0" name="Skyline Studio" text="The latest from our creative desk" followers="18.2K followers" notify={notify} /><ChannelRow icon="◒" color="#f7b3a6" name="Sunday Market" text="Fresh finds, local makers, good coffee" followers="8.9K followers" notify={notify} /></div> }
function ChannelRow({ icon, color, name, text, followers, notify }: { icon: string; color: string; name: string; text: string; followers: string; notify: (s: string) => void }) { return <div className="channel-row"><div className="channel-avatar" style={{ background: color }}>{icon}</div><div><strong>{name}<span className="verified">✓</span></strong><p>{text}</p><small>{followers}</small></div><button onClick={() => notify(`Following ${name}`)}>Follow</button></div>; }
function CallsPanel({ notify }: { notify: (s: string) => void }) { return <div className="feature-panel"><div className="feature-title"><div><p className="eyebrow">Private and clear</p><h2>Calls</h2></div><button className="outline-button" onClick={() => notify('Call link copied')}><Link2 size={15} /> Create link</button></div><div className="call-card"><div className="call-card-icon"><Video size={21} /></div><div><h3>Call together</h3><p>Bring your people in with a secure call link. No time limits.</p></div><button onClick={() => notify('Starting a group call')}>Start call</button></div><div className="section-label">Recent</div><CallRow initials="MC" color="#f7b3a6" name="Mira Chen" time="Today, 09:12" kind="Outgoing video" notify={notify} /><CallRow initials="NW" color="#93d9d3" name="Noah Williams" time="Yesterday, 18:42" kind="Incoming voice" notify={notify} /></div> }
function CallRow({ initials, color, name, time, kind, notify }: { initials: string; color: string; name: string; time: string; kind: string; notify: (s: string) => void }) { return <button className="call-row" onClick={() => notify(`Calling ${name}`)}><div className="avatar" style={{ background: color }}>{initials}</div><div><strong>{name}</strong><p>{kind} · {time}</p></div><Phone size={17} /></button>; }
function BusinessPanel({ notify }: { notify: (s: string) => void }) { return <div className="feature-panel"><div className="feature-title"><div><p className="eyebrow">For teams</p><h2>Business</h2></div><button className="outline-button" onClick={() => notify('Business profile opened')}><BriefcaseBusiness size={15} /> Manage</button></div><div className="business-profile"><div className="store-mark"><Store size={23} /></div><div><h3>Skyline Studio <span className="verified">✓</span></h3><p>Creative studio · Open until 18:00</p></div><button className="icon-button" onClick={() => notify('Business options opened')}><MoreHorizontal size={18} /></button></div><div className="business-grid"><BusinessTile icon={<Store size={18} />} title="Catalog" value="24 products" onClick={() => notify('Catalog opened')} /><BusinessTile icon={<Zap size={18} />} title="Quick replies" value="12 shortcuts" onClick={() => notify('Quick replies opened')} /><BusinessTile icon={<Layers3 size={18} />} title="Labels" value="6 active" onClick={() => notify('Labels opened')} /><BusinessTile icon={<CalendarDays size={18} />} title="Orders" value="3 open" onClick={() => notify('Orders opened')} /></div><div className="business-note"><Bot size={18} /><div><strong>Automate the quiet parts</strong><p>Greeting, away messages, and customer support tools are ready to connect.</p></div><ChevronDown size={16} /></div></div> }
function BusinessTile({ icon, title, value, onClick }: { icon: React.ReactNode; title: string; value: string; onClick: () => void }) { return <button className="business-tile" onClick={onClick}><span>{icon}</span><strong>{title}</strong><small>{value}</small></button>; }
function SettingsPanel({ privacy, setPrivacy, notify }: { privacy: boolean; setPrivacy: (v: boolean) => void; notify: (s: string) => void }) { return <div className="feature-panel settings-view"><div className="feature-title"><div><p className="eyebrow">Your space</p><h2>Settings</h2></div><button className="icon-button" onClick={() => notify('Help center opened')}><CircleHelp size={18} /></button></div><div className="settings-profile"><div className="avatar huge" style={{ background: '#b6e8df' }}>AR</div><div><h3>Alex Rivera</h3><p>+1 415 555 0189</p></div><ChevronDown size={17} /></div><div className="settings-group"><div className="section-label">Privacy & security</div><SettingRow icon={<ShieldCheck size={17} />} title="End-to-end encryption" subtitle="Your personal messages and calls stay private" control={<span className="status-pill"><Check size={12} /> On</span>} /><SettingRow icon={<LockKeyhole size={17} />} title="App lock" subtitle="Require device authentication to open SkyChat" control={<button className={`toggle ${privacy ? 'on' : ''}`} onClick={() => { setPrivacy(!privacy); notify(privacy ? 'App lock disabled' : 'App lock enabled'); }}><i /></button>} /><SettingRow icon={<Cloud size={17} />} title="Encrypted backups" subtitle="Last backup today at 08:30" control={<ChevronDown size={16} />} /></div><div className="settings-group"><div className="section-label">Workspace</div><SettingRow icon={<Bell size={17} />} title="Notifications" subtitle="Messages, calls, and status updates" control={<ChevronDown size={16} />} /><SettingRow icon={<Archive size={17} />} title="Storage and data" subtitle="Used 1.8 GB · Manage files" control={<ChevronDown size={16} />} /><SettingRow icon={<Copy size={17} />} title="Linked devices" subtitle="2 devices connected" control={<ChevronDown size={16} />} /></div></div> }
function SettingRow({ icon, title, subtitle, control }: { icon: React.ReactNode; title: string; subtitle: string; control: React.ReactNode }) { return <div className="setting-row"><span className="setting-icon">{icon}</span><div><strong>{title}</strong><p>{subtitle}</p></div>{control}</div>; }
function EmptyState({ section, notify }: { section: Section; notify: (s: string) => void }) { const labels: Record<Section, [string, string, typeof MessageCircle]> = { chats: ['Your messages, in focus', 'Select a conversation to start chatting.', MessageCircle], status: ['Your updates, your rhythm', 'Status previews will appear here.', Compass], communities: ['A calmer way to gather', 'Select a Community to see its groups.', Users], channels: ['Ideas worth following', 'Select a Channel to read the latest update.', Hash], calls: ['Your calls, together', 'Select a call to view details.', Phone], business: ['A clearer way to connect', 'Select a workspace to manage your business.', Store], settings: ['Your space, your rules', 'Select a setting to make it yours.', Settings] }; const [title, subtitle, Icon] = labels[section]; return <div className="empty-state"><div className="empty-icon"><Icon size={25} /></div><h2>{title}</h2><p>{subtitle}</p><button className="primary-button" onClick={() => notify('This surface is ready to connect')}><Plus size={16} /> Explore</button></div>; }
