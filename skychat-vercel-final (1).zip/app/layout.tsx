import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'SkyChat — Private by default',
  description: 'A calm, expressive communication workspace for your conversations.',
  icons: { icon: '/skychat-icon.png' }
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
