import type { RealtimeChannel } from '@supabase/supabase-js';
import { supabase } from './supabase';

export type Profile = { id: string; display_name: string; handle: string | null; avatar_url: string | null; about: string | null };
export type Conversation = { id: string; kind: string; title: string | null; created_at: string; conversation_members?: { user_id: string }[] };
export type Message = { id: string; conversation_id: string; sender_id: string; body: string | null; media_url: string | null; media_type: string | null; reply_to: string | null; created_at: string; edited_at: string | null };

export async function getMyProfile(userId: string) {
  if (!supabase) return null;
  const { data, error } = await supabase.from('profiles').select('*').eq('id', userId).maybeSingle();
  if (error) throw error;
  return data as Profile | null;
}

export async function upsertMyProfile(userId: string, displayName: string) {
  if (!supabase) return null;
  const { data, error } = await supabase.from('profiles').upsert({ id: userId, display_name: displayName }, { onConflict: 'id' }).select().single();
  if (error) throw error;
  return data as Profile;
}

export async function getConversations() {
  if (!supabase) return [] as Conversation[];
  const { data, error } = await supabase.from('conversations').select('id,kind,title,created_at,conversation_members!inner(user_id)').order('created_at', { ascending: false });
  if (error) throw error;
  return (data ?? []) as Conversation[];
}

export async function getMessages(conversationId: string) {
  if (!supabase) return [] as Message[];
  const { data, error } = await supabase.from('messages').select('*').eq('conversation_id', conversationId).order('created_at', { ascending: true }).limit(100);
  if (error) throw error;
  return (data ?? []) as Message[];
}

export async function sendMessage(conversationId: string, senderId: string, body: string) {
  if (!supabase) return null;
  const { data, error } = await supabase.from('messages').insert({ conversation_id: conversationId, sender_id: senderId, body }).select().single();
  if (error) throw error;
  return data as Message;
}

export async function createConversation(userId: string, title: string, kind: 'direct' | 'group' = 'direct') {
  if (!supabase) return null;
  const { data, error } = await supabase.from('conversations').insert({ title, kind, created_by: userId }).select().single();
  if (error) throw error;
  const { error: memberError } = await supabase.from('conversation_members').insert({ conversation_id: data.id, user_id: userId, role: 'owner' });
  if (memberError) throw memberError;
  return data as Conversation;
}

export function subscribeToMessages(conversationId: string, onInsert: (message: Message) => void): RealtimeChannel | null {
  if (!supabase) return null;
  return supabase.channel(`messages:${conversationId}`).on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${conversationId}` }, (payload) => onInsert(payload.new as Message)).subscribe();
}

export async function uploadChatMedia(userId: string, file: File) {
  if (!supabase) return null;
  const safeName = file.name.replace(/[^a-z0-9._-]/gi, '-');
  const path = `${userId}/${crypto.randomUUID()}-${safeName}`;
  const { error } = await supabase.storage.from('chat-media').upload(path, file, { upsert: false, contentType: file.type });
  if (error) throw error;
  const { data } = supabase.storage.from('chat-media').getPublicUrl(path);
  return { path, url: data.publicUrl };
}
