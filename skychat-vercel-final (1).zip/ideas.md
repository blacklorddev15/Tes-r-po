# SkyChat design brief

## Theme Name
Signal Garden

## Introduction
A calm, premium communication workspace that feels like a private constellation of conversations rather than a generic messenger clone.

## Design movement
Editorial utility: generous whitespace, precise information hierarchy, soft surfaces, and a few expressive neon accents.

## Core principles
- Make the current conversation feel focused and alive.
- Keep high-density communication legible at a glance.
- Use color as a navigation signal, not decoration.
- Every interaction should have a quiet, immediate response.

## Color philosophy
Deep ink (#10131A) anchors navigation and text. Warm off-white (#F7F5F0) keeps the canvas human. Electric cyan (#49D7D0) signals presence and action. Soft lilac (#C9B9FF) marks discovery and AI. Coral (#FF8E7A) is reserved for attention.

## Layout paradigm
Three-column desktop workspace: navigation rail, conversation index, and active thread. On smaller screens the rail collapses into a bottom bar and the conversation index becomes a drawer.

## Signature elements
A rounded-square chat mark with a cyan orbit cut through the center, thin lilac status rings, pill-shaped presence indicators, and timestamp micro-labels.

## Interaction philosophy
Optimistic, reversible, and tactile. Buttons use short transitions, active states are obvious, and demo actions surface a toast rather than silently failing.

## Animation
Subtle 150–220ms transitions, a gentle message-in reveal, and pulsing presence dots only where they convey live state.

## Typography system
Use Inter / system sans for interface text, with compact semibold labels and comfortable 15–16px body copy.

## Brand essence
Private by default, expressive by choice.

## Brand voice
Warm, direct, quietly confident.

## Wordmark / logo
SkyChat wordmark paired with a two-shape orbit-chat glyph.

## Signature brand color
Electric cyan (#49D7D0).

## Implementation notes
- Demo data is local-first and should remain useful without credentials.
- Supabase is an integration boundary, not a hard runtime dependency for the demo.
- The first version intentionally surfaces the breadth of the product while keeping the core chat journey polished.
