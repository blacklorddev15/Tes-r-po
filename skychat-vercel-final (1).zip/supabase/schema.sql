-- SkyChat production Supabase starter schema
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  handle text unique,
  avatar_url text,
  about text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(), kind text not null default 'direct' check (kind in ('direct','group','community','channel','business')),
  title text, created_by uuid references auth.users(id) on delete set null, created_at timestamptz not null default now()
);
create table if not exists public.conversation_members (
  conversation_id uuid references public.conversations(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  role text not null default 'member', joined_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(), conversation_id uuid references public.conversations(id) on delete cascade not null,
  sender_id uuid references auth.users(id) on delete cascade not null, body text, media_url text, media_type text,
  reply_to uuid references public.messages(id) on delete set null, created_at timestamptz not null default now(), edited_at timestamptz
);
create table if not exists public.message_reactions (
  message_id uuid references public.messages(id) on delete cascade, user_id uuid references auth.users(id) on delete cascade,
  reaction text not null, created_at timestamptz not null default now(), primary key (message_id, user_id, reaction)
);
create table if not exists public.status_updates (
  id uuid primary key default gen_random_uuid(), user_id uuid references auth.users(id) on delete cascade not null,
  body text, media_url text, expires_at timestamptz not null default now() + interval '24 hours', created_at timestamptz not null default now()
);
create table if not exists public.channels (
  id uuid primary key default gen_random_uuid(), owner_id uuid references auth.users(id) on delete cascade not null,
  name text not null, description text, avatar_url text, created_at timestamptz not null default now()
);
create table if not exists public.channel_followers (
  channel_id uuid references public.channels(id) on delete cascade, user_id uuid references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(), primary key (channel_id, user_id)
);

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin insert into public.profiles (id, display_name) values (new.id, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1))) on conflict (id) do nothing; return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;
alter table public.message_reactions enable row level security;
alter table public.status_updates enable row level security;
alter table public.channels enable row level security;
alter table public.channel_followers enable row level security;

drop policy if exists "profiles are visible to signed in users" on public.profiles;
create policy "profiles are visible to signed in users" on public.profiles for select to authenticated using (true);
drop policy if exists "users update their own profile" on public.profiles;
create policy "users update their own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "members see conversations" on public.conversations;
create policy "members see conversations" on public.conversations for select to authenticated using (exists (select 1 from public.conversation_members m where m.conversation_id = id and m.user_id = auth.uid()));
drop policy if exists "signed in users create conversations" on public.conversations;
create policy "signed in users create conversations" on public.conversations for insert to authenticated with check (created_by = auth.uid());

drop policy if exists "members see membership" on public.conversation_members;
create policy "members see membership" on public.conversation_members for select to authenticated using (user_id = auth.uid() or exists (select 1 from public.conversation_members m where m.conversation_id = conversation_id and m.user_id = auth.uid()));
drop policy if exists "users add themselves" on public.conversation_members;
create policy "users add themselves" on public.conversation_members for insert to authenticated with check (user_id = auth.uid());

drop policy if exists "members read messages" on public.messages;
create policy "members read messages" on public.messages for select to authenticated using (exists (select 1 from public.conversation_members m where m.conversation_id = conversation_id and m.user_id = auth.uid()));
drop policy if exists "members send messages" on public.messages;
create policy "members send messages" on public.messages for insert to authenticated with check (sender_id = auth.uid() and exists (select 1 from public.conversation_members m where m.conversation_id = conversation_id and m.user_id = auth.uid()));
drop policy if exists "senders edit messages" on public.messages;
create policy "senders edit messages" on public.messages for update to authenticated using (sender_id = auth.uid()) with check (sender_id = auth.uid());
drop policy if exists "senders delete messages" on public.messages;
create policy "senders delete messages" on public.messages for delete to authenticated using (sender_id = auth.uid());

create policy "users manage their reactions" on public.message_reactions for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "users read active status" on public.status_updates for select to authenticated using (expires_at > now());
create policy "users create status" on public.status_updates for insert to authenticated with check (user_id = auth.uid());
create policy "users manage own status" on public.status_updates for delete to authenticated using (user_id = auth.uid());
create policy "channels are discoverable" on public.channels for select to authenticated using (true);
create policy "users create own channels" on public.channels for insert to authenticated with check (owner_id = auth.uid());
create policy "users manage follows" on public.channel_followers for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Realtime events for live chat and presence.
alter table public.messages replica identity full;
alter publication supabase_realtime add table public.messages;
alter publication supabase_realtime add table public.conversation_members;

-- Run once if the bucket does not exist yet.
insert into storage.buckets (id, name, public) values ('chat-media', 'chat-media', false) on conflict (id) do nothing;
create policy "authenticated users upload chat media" on storage.objects for insert to authenticated with check (bucket_id = 'chat-media' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "authenticated users read chat media" on storage.objects for select to authenticated using (bucket_id = 'chat-media' and (storage.foldername(name))[1] = auth.uid()::text);
