# Implementation references

- Neon serverless driver: https://neon.com/docs/serverless/serverless-driver — `@neondatabase/serverless` supports HTTP queries via `neon()` and WebSocket `Pool`/`Client`; HTTP is suitable for single statements and non-interactive transactions, while database functions can keep checkout and queue transitions atomic.
- Neon Node.js connection guide: https://neon.com/docs/guides/node — configure a private `DATABASE_URL`; never expose Neon credentials in browser code.
- Neon from Vercel: https://neon.com/docs/guides/vercel-connection-methods — connection choice depends on Vercel compute; the serverless HTTP driver is supported for request-scoped queries, while Fluid compute can use pooled TCP connections.
- Supabase Auth overview: https://supabase.com/docs/guides/auth — Supabase Auth issues access tokens; the application retains Supabase as the identity provider only.
- Supabase email/password authentication: https://supabase.com/docs/guides/auth/passwords — use Supabase Auth open sign-up and user sessions; the Vercel API verifies tokens with Supabase Auth.
- Paystack transaction API: https://paystack.com/docs/api/transaction/ — initialize transactions from the backend with the secret key; verify transactions by unique reference; amount uses the currency's subunit.
- Paystack payment flow: https://paystack.com/docs/payments/accept-payments/ — return the hosted authorization URL, verify status and amount before delivering value, and never expose the secret key in frontend code.
- Paystack webhooks: https://paystack.com/docs/payments/webhooks/ — validate `x-paystack-signature` as an HMAC-SHA512 over the raw payload; callbacks alone are not proof of payment.
- Vercel Node.js Functions: https://vercel.com/docs/functions/runtimes/node-js — Vercel explicitly supports `export default { fetch(request) { ... } }` for a shared Node.js Function; the current API's `export default { fetch: handle }` matches that documented shape, and `Request.arrayBuffer()` keeps the raw Paystack webhook payload available for signature validation.
