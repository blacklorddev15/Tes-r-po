import crypto from 'node:crypto';
import { createClient } from '@supabase/supabase-js';
import { neon } from '@neondatabase/serverless';

const COOKIE_NAME = 'botdeck_admin';
const ADMIN_SESSION_SECONDS = 8 * 60 * 60;
const MAX_BODY_BYTES = 32 * 1024;

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'private, no-store', 'x-content-type-options': 'nosniff', ...headers },
  });
}

function authConfig() {
  const url = process.env.SUPABASE_URL || '';
  const key = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_ANON_KEY || '';
  if (!url || !key) throw new HttpError(503, 'Supabase Auth configuration is incomplete. Set SUPABASE_URL and SUPABASE_PUBLISHABLE_KEY (or SUPABASE_ANON_KEY).');
  return { url, key };
}
function database() {
  const connectionString = process.env.DATABASE_URL || '';
  if (!connectionString) throw new HttpError(503, 'Neon database configuration is incomplete. Set DATABASE_URL.');
  return neon(connectionString);
}

function parseCookies(header = '') {
  const result = {};
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    const key = part.slice(0, i).trim();
    try { result[key] = decodeURIComponent(part.slice(i + 1).trim()); } catch { result[key] = ''; }
  }
  return result;
}
function timingSafeEqualText(left, right) {
  const a = Buffer.from(String(left));
  const b = Buffer.from(String(right));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function originAllowlist() {
  const values = [process.env.APP_ORIGIN, process.env.VERCEL_URL, process.env.VERCEL_BRANCH_URL];
  const origins = new Set();
  for (const value of values) {
    if (!value) continue;
    try {
      const url = new URL(String(value).includes('://') ? String(value) : `https://${value}`);
      if (url.protocol === 'https:' || ['localhost', '127.0.0.1'].includes(url.hostname)) origins.add(url.origin);
    } catch {}
  }
  if (process.env.NODE_ENV !== 'production') {
    for (const value of ['http://localhost:3000', 'http://127.0.0.1:3000', 'http://localhost:5173', 'http://127.0.0.1:5173']) origins.add(value);
  }
  return origins;
}
function assertAllowedOrigin(request) {
  const origin = request.headers.get('origin');
  try {
    if (!origin || !originAllowlist().has(new URL(origin).origin)) throw new Error();
  } catch { throw new HttpError(403, 'Request origin is not allowed.'); }
}
async function readJson(request) {
  const declared = Number(request.headers.get('content-length') || 0);
  if (declared > MAX_BODY_BYTES) throw new HttpError(413, 'Request body is too large.');
  const text = await request.text();
  if (Buffer.byteLength(text) > MAX_BODY_BYTES) throw new HttpError(413, 'Request body is too large.');
  try {
    const value = JSON.parse(text || '{}');
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error();
    return value;
  } catch { throw new HttpError(400, 'Request body must be a JSON object.'); }
}
function bearerToken(request) {
  const header = request.headers.get('authorization') || '';
  const match = header.match(/^Bearer\s+(.+)$/i);
  return match?.[1]?.trim() || '';
}
async function requireUser(request) {
  const token = bearerToken(request);
  if (!token) throw new HttpError(401, 'Sign in to continue.');
  const { url, key } = authConfig();
  const auth = createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { headers: { Authorization: `Bearer ${token}` } },
  });
  const { data, error } = await auth.auth.getUser(token);
  const user = data?.user;
  if (error || !user?.id || !uuid(user.id)) throw new HttpError(401, 'Your session has expired. Sign in again.');
  const sql = database();
  try {
    await sql`insert into public.profiles (id, email) values (${user.id}::uuid, ${user.email || null}) on conflict (id) do update set email = excluded.email, updated_at = pg_catalog.now()`;
  } catch {
    throw new HttpError(503, 'Could not synchronize your profile with the Neon database. Check DATABASE_URL and apply the Neon migration.');
  }
  return { user, token, sql };
}

function adminSecret() {
  const value = process.env.ADMIN_SESSION_SECRET || '';
  if (Buffer.byteLength(value) < 32) throw new HttpError(503, 'Admin session signing is not configured.');
  return value;
}
function signAdmin(payload) { return crypto.createHmac('sha256', adminSecret()).update(payload).digest('base64url'); }
function issueAdminCookie(userId) {
  const payload = Buffer.from(JSON.stringify({ sub: userId, exp: Math.floor(Date.now() / 1000) + ADMIN_SESSION_SECONDS })).toString('base64url');
  const value = `${payload}.${signAdmin(payload)}`;
  return `${COOKIE_NAME}=${encodeURIComponent(value)}; Path=/; Max-Age=${ADMIN_SESSION_SECONDS}; HttpOnly; Secure; SameSite=None`;
}
function clearAdminCookie() { return `${COOKIE_NAME}=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=None`; }
function adminCookieUser(request) {
  try {
    const value = parseCookies(request.headers.get('cookie') || '')[COOKIE_NAME];
    const [payload, signature, extra] = String(value || '').split('.');
    if (!payload || !signature || extra || !timingSafeEqualText(signature, signAdmin(payload))) return null;
    const parsed = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    if (typeof parsed.sub !== 'string' || !Number.isInteger(parsed.exp) || parsed.exp <= Date.now() / 1000) return null;
    return parsed.sub;
  } catch { return null; }
}
function verifyAdminPassword(value) {
  const encoded = process.env.ADMIN_PASSWORD_HASH || '';
  const parts = encoded.split('$');
  if (parts.length !== 3 || parts[0] !== 'scrypt' || !/^[a-f0-9]{32,128}$/i.test(parts[1]) || !/^[a-f0-9]{64}$/i.test(parts[2])) return false;
  const salt = Buffer.from(parts[1], 'hex');
  const expected = Buffer.from(parts[2], 'hex');
  const actual = crypto.scryptSync(String(value), salt, expected.length);
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}
function publicError(error) {
  const message = String(error?.message || '').toLowerCase();
  if (message.includes('subscription_required') || message.includes('active plan') || message.includes('active subscription')) return 'An active plan is required for this action.';
  if (message.includes('repository_limit') || message.includes('repository limit')) return 'Your plan repository limit has been reached.';
  if (message.includes('voucher') && message.includes('current plan')) return 'This free-days voucher is limited to a different subscription plan.';
  if (message.includes('repo_url') || message.includes('github') || message.includes('repository url')) return 'Use a public GitHub URL like https://github.com/owner/repository.';
  if (message.includes('voucher') && (message.includes('expired') || message.includes('limit') || message.includes('invalid') || message.includes('redemption'))) return 'That voucher is invalid, expired, or has reached its redemption limit.';
  if (message.includes('already queued') || message.includes('in progress') || message.includes('already has an operation')) return 'That repository already has an operation in progress.';
  return 'The request could not be completed. Please try again or contact the site administrator.';
}
function normalizeGithubUrl(value) {
  if (typeof value !== 'string' || value.length > 300) throw new HttpError(400, 'Enter a public GitHub repository URL.');
  let url;
  try { url = new URL(value.trim()); } catch { throw new HttpError(400, 'Enter a valid public GitHub repository URL.'); }
  if (url.protocol !== 'https:' || url.hostname.toLowerCase() !== 'github.com' || url.port || url.username || url.password || url.search || url.hash) throw new HttpError(400, 'Only public https://github.com/owner/repository links are accepted.');
  const parts = url.pathname.replace(/^\/+|\/+$/g, '').split('/');
  if (parts.length !== 2) throw new HttpError(400, 'Use a public GitHub URL like https://github.com/owner/repository.');
  const owner = parts[0];
  const repo = parts[1].replace(/\.git$/i, '');
  if (!/^[A-Za-z0-9][A-Za-z0-9-]{0,38}$/.test(owner) || !/^[A-Za-z0-9_.-]{1,100}$/.test(repo) || repo === '.' || repo === '..') throw new HttpError(400, 'Use a public GitHub URL like https://github.com/owner/repository.');
  return `https://github.com/${owner}/${repo}`;
}
function uuid(value) { return typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value); }
function first(rows) { return Array.isArray(rows) ? rows[0] : undefined; }

async function repositories(request, user, method, body, repoMatch) {
  const sql = user.sql;
  if (method === 'GET' && !repoMatch) {
    const rows = await sql`select id, repo_name, repo_url, status, last_error, created_at from public.repositories where owner_id = ${user.user.id}::uuid order by created_at desc limit 250`;
    return json({ repositories: rows.map(row => ({ id: row.id, name: row.repo_name, url: row.repo_url, status: row.status, last_error: row.last_error, created_at: row.created_at })) });
  }
  if (method === 'POST' && !repoMatch) {
    assertAllowedOrigin(request);
    const repoUrl = normalizeGithubUrl(body?.repoUrl);
    let rows;
    try { rows = await sql`select public.queue_repository_import(${user.user.id}::uuid, ${repoUrl}) as repository_id`; }
    catch (error) { throw new HttpError(400, publicError(error)); }
    const repositoryId = first(rows)?.repository_id || null;
    const jobs = repositoryId ? await sql`select id from public.hosting_jobs where repository_id = ${repositoryId}::uuid and owner_id = ${user.user.id}::uuid and action = 'import' order by created_at desc limit 1` : [];
    return json({ repository: { id: repositoryId, name: repoUrl.split('/').pop(), url: repoUrl, status: 'queued' }, jobId: first(jobs)?.id || null }, 202);
  }
  if (!repoMatch || !uuid(repoMatch[1])) throw new HttpError(404, 'Not found.');
  assertAllowedOrigin(request);
  const action = method === 'DELETE' ? 'delete' : (method === 'POST' ? repoMatch[2] : '');
  if (!['start', 'stop', 'delete'].includes(action)) throw new HttpError(404, 'Not found.');
  let rows;
  try { rows = await sql`select public.queue_repository_action(${user.user.id}::uuid, ${repoMatch[1]}::uuid, ${action}) as job_id`; }
  catch (error) { throw new HttpError(400, publicError(error)); }
  return json({ jobId: first(rows)?.job_id || null, repositoryId: repoMatch[1], status: { start: 'starting', stop: 'stopping', delete: 'deleting' }[action] }, 202);
}

async function subscriptionFor(sql, userId) {
  const subscriptions = await sql`select user_id, plan_id, expires_at, updated_at from public.subscriptions where user_id = ${userId}::uuid limit 1`;
  const subscription = first(subscriptions);
  if (!subscription) return { subscription: null, plan: null };
  const plans = await sql`select id, name, description, amount_minor, currency, duration_days, max_repositories, is_active from public.plans where id = ${subscription.plan_id}::uuid limit 1`;
  const plan = first(plans) || null;
  const active = Date.parse(subscription.expires_at) > Date.now() && plan?.is_active !== false;
  return {
    subscription: { ...subscription, status: active ? 'active' : 'expired' },
    plan: plan ? { ...plan, amount: plan.amount_minor, repository_limit: plan.max_repositories, active: plan.is_active } : null,
  };
}
function paystackSecret() {
  const value = process.env.PAYSTACK_SECRET_KEY || '';
  if (!value) throw new HttpError(503, 'Paystack is not configured on this deployment.');
  return value;
}
function siteOrigin() {
  const value = process.env.APP_ORIGIN || process.env.VERCEL_URL || '';
  if (!value) throw new HttpError(503, 'APP_ORIGIN is not configured for this deployment.');
  try {
    const url = new URL(String(value).includes('://') ? String(value) : `https://${value}`);
    if (url.protocol !== 'https:' && !['localhost', '127.0.0.1'].includes(url.hostname)) throw new Error();
    return url.origin;
  } catch { throw new HttpError(503, 'APP_ORIGIN must be a valid HTTPS origin.'); }
}
async function paystackRequest(path, init = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15_000);
  try {
    const response = await fetch(`https://api.paystack.co${path}`, {
      ...init,
      headers: { authorization: `Bearer ${paystackSecret()}`, 'content-type': 'application/json', ...(init.headers || {}) },
      redirect: 'error', signal: controller.signal,
    });
    const payload = await response.json().catch(() => null);
    if (!response.ok || !payload?.status) throw new HttpError(502, 'Paystack could not process the request. Check the configured keys and try again.');
    return payload.data;
  } catch (error) {
    if (error instanceof HttpError) throw error;
    throw new HttpError(502, error?.name === 'AbortError' ? 'Paystack did not respond in time.' : 'Could not connect to Paystack.');
  } finally { clearTimeout(timer); }
}
async function verifyAndFulfill(reference, sql, expectedUserId = null) {
  if (typeof reference !== 'string' || !/^[A-Za-z0-9.=-]{8,100}$/.test(reference)) throw new HttpError(400, 'Invalid payment reference.');
  const payments = expectedUserId
    ? await sql`select reference, user_id, plan_id, status, amount_minor, currency from public.payments where reference = ${reference} and user_id = ${expectedUserId}::uuid limit 1`
    : await sql`select reference, user_id, plan_id, status, amount_minor, currency from public.payments where reference = ${reference} limit 1`;
  const payment = first(payments);
  if (!payment) throw new HttpError(404, 'Payment record not found.');
  if (payment.status === 'reconciliation_required') return { paid: false, reconciliationRequired: true, reference };
  if (payment.status === 'paid') return { paid: true, alreadyFulfilled: true };
  const transaction = await paystackRequest(`/transaction/verify/${encodeURIComponent(reference)}`, { method: 'GET' });
  if (transaction.reference !== reference || transaction.status !== 'success') return { paid: false };
  if (Number(transaction.amount) !== Number(payment.amount_minor) || String(transaction.currency).toUpperCase() !== String(payment.currency).toUpperCase()) throw new HttpError(409, 'The verified payment amount or currency did not match the order. No access was granted.');
  let rows;
  try {
    rows = await sql`select public.fulfill_checkout(${reference}, ${Number(transaction.amount)}::bigint, ${String(transaction.currency).toUpperCase()}, ${reference}) as fulfillment`;
  } catch {
    throw new HttpError(503, 'Payment was verified, but account activation is pending. Contact the administrator with your payment reference.');
  }
  let fulfillment = first(rows)?.fulfillment;
  if (typeof fulfillment === 'string') { try { fulfillment = JSON.parse(fulfillment); } catch {} }
  if (fulfillment?.reconciliation_required) return { paid: false, reconciliationRequired: true, reference };
  return { paid: true, subscription: fulfillment };
}

function validatePlan(body) {
  const name = String(body?.name || '').trim();
  const amount = Number(body?.amount_minor ?? body?.amount);
  const duration = Number(body?.duration_days);
  const maxRepos = Number(body?.max_repositories ?? body?.repository_limit);
  const currency = String(body?.currency || '').trim().toUpperCase();
  if (!name || name.length > 80) throw new HttpError(400, 'Plan name must be 1–80 characters.');
  if (!Number.isSafeInteger(amount) || amount < 1 || amount > 2_000_000_000) throw new HttpError(400, 'Plan amount must be a positive amount in minor currency units.');
  if (!/^[A-Z]{3}$/.test(currency)) throw new HttpError(400, 'Currency must be a three-letter ISO code supported by your Paystack account.');
  if (!Number.isInteger(duration) || duration < 1 || duration > 3650) throw new HttpError(400, 'Access duration must be 1–3650 days.');
  if (!Number.isInteger(maxRepos) || maxRepos < 1 || maxRepos > 1000) throw new HttpError(400, 'Repository allowance must be 1–1000.');
  return { ...(uuid(body.id) ? { id: body.id } : {}), name, description: String(body.description || '').trim().slice(0, 500) || null, amount_minor: amount, currency, duration_days: duration, max_repositories: maxRepos, is_active: body.is_active !== false && body.active !== false };
}

async function adminRoute(request, route, method, user) {
  if (route === '/admin/login' && method === 'POST') {
    assertAllowedOrigin(request);
    const body = await readJson(request);
    if (typeof body.password !== 'string' || body.password.length > 1024 || !verifyAdminPassword(body.password)) throw new HttpError(401, 'Admin password is incorrect or has not been configured.');
    return json({ authenticated: true }, 200, { 'set-cookie': issueAdminCookie(user.user.id) });
  }
  if (route === '/admin/logout' && method === 'POST') {
    assertAllowedOrigin(request);
    return json({ loggedOut: true }, 200, { 'set-cookie': clearAdminCookie() });
  }
  if (adminCookieUser(request) !== user.user.id) throw new HttpError(401, 'Enter the admin password to continue.');
  const sql = user.sql;
  if (route === '/admin/overview' && method === 'GET') {
    const [plans, vouchers, payments, redemptions] = await Promise.all([
      sql`select id, name, description, amount_minor, currency, duration_days, max_repositories, is_active, created_at from public.plans order by created_at desc limit 100`,
      sql`select id, code, kind, value, currency, plan_id, max_redemptions, per_user_limit, expires_at, is_active, created_at from public.vouchers order by created_at desc limit 200`,
      sql`select reference, user_id, plan_id, status, amount_minor, currency, discount_minor, created_at, paid_at from public.payments order by created_at desc limit 100`,
      sql`select id, voucher_id, user_id, payment_reference, discount_minor, redeemed_at from public.voucher_redemptions order by redeemed_at desc limit 100`,
    ]);
    const voucherById = new Map(vouchers.map(voucher => [voucher.id, voucher]));
    return json({
      plans: plans.map(plan => ({ ...plan, amount: plan.amount_minor, repository_limit: plan.max_repositories, active: plan.is_active })),
      vouchers: vouchers.map(voucher => ({ ...voucher, enabled: voucher.is_active, per_user_cap: voucher.per_user_limit })),
      payments: payments.map(payment => ({ ...payment, amount: payment.amount_minor })),
      redemptions: redemptions.map(redemption => {
        const voucher = voucherById.get(redemption.voucher_id);
        return { ...redemption, code: voucher?.code || redemption.voucher_id, voucher_code: voucher?.code, kind: voucher?.kind, value: voucher?.value };
      }),
    });
  }
  if (route === '/admin/plans' && method === 'POST') {
    assertAllowedOrigin(request);
    const values = validatePlan(await readJson(request));
    let rows;
    try {
      rows = values.id
        ? await sql`insert into public.plans (id, name, description, amount_minor, currency, duration_days, max_repositories, is_active) values (${values.id}::uuid, ${values.name}, ${values.description}, ${values.amount_minor}, ${values.currency}, ${values.duration_days}, ${values.max_repositories}, ${values.is_active}) on conflict (id) do update set name = excluded.name, description = excluded.description, amount_minor = excluded.amount_minor, currency = excluded.currency, duration_days = excluded.duration_days, max_repositories = excluded.max_repositories, is_active = excluded.is_active returning *`
        : await sql`insert into public.plans (name, description, amount_minor, currency, duration_days, max_repositories, is_active) values (${values.name}, ${values.description}, ${values.amount_minor}, ${values.currency}, ${values.duration_days}, ${values.max_repositories}, ${values.is_active}) returning *`;
    } catch (error) { throw new HttpError(400, publicError(error)); }
    return json({ plan: first(rows) });
  }
  if (route === '/admin/vouchers' && method === 'POST') {
    assertAllowedOrigin(request);
    const body = await readJson(request);
    const code = String(body.code || '').trim().toUpperCase();
    const kind = String(body.kind || '');
    const value = Number(body.value);
    const currency = String(body.currency || '').trim().toUpperCase();
    const planId = uuid(body.plan_id) ? body.plan_id : null;
    const maxRedemptions = body.max_redemptions === '' || body.max_redemptions == null ? null : Number(body.max_redemptions);
    const perUserInput = body.per_user_limit ?? body.per_user_cap;
    const perUserLimit = perUserInput == null || perUserInput === '' ? 1 : Number(perUserInput);
    const expiryMillis = body.expires_at ? Date.parse(body.expires_at) : null;
    if (!/^[A-Z0-9_-]{4,64}$/.test(code)) throw new HttpError(400, 'Voucher code must contain 4–64 letters, numbers, hyphens, or underscores.');
    if (!['percent', 'fixed', 'free_days'].includes(kind)) throw new HttpError(400, 'Choose percent, fixed, or free-days voucher type.');
    if (!Number.isInteger(value) || value < 1 || (kind === 'percent' && value > 99) || (kind === 'free_days' && value > 3650)) throw new HttpError(400, 'Voucher value is invalid. Percentage discounts must be 1–99; free days must be 1–3650.');
    if (kind === 'fixed' && !/^[A-Z]{3}$/.test(currency)) throw new HttpError(400, 'Fixed discount vouchers require a three-letter currency code.');
    if (kind === 'free_days' && !planId) throw new HttpError(400, 'Free-day vouchers must select a plan.');
    if (maxRedemptions !== null && (!Number.isInteger(maxRedemptions) || maxRedemptions < 1 || maxRedemptions > 1_000_000)) throw new HttpError(400, 'Maximum redemptions must be a positive whole number.');
    if (!Number.isInteger(perUserLimit) || perUserLimit < 1 || perUserLimit > 100) throw new HttpError(400, 'Per-user redemption limit must be 1–100.');
    if (body.expires_at && !Number.isFinite(expiryMillis)) throw new HttpError(400, 'Voucher expiry date is invalid.');
    const expiresAt = expiryMillis === null ? null : new Date(expiryMillis).toISOString();
    let rows;
    try { rows = await sql`insert into public.vouchers (code, kind, value, currency, plan_id, max_redemptions, per_user_limit, expires_at, is_active) values (${code}, ${kind}, ${value}, ${kind === 'fixed' ? currency : null}, ${planId}::uuid, ${maxRedemptions}, ${perUserLimit}, ${expiresAt}::timestamptz, true) returning *`; }
    catch (error) { throw new HttpError(400, publicError(error)); }
    return json({ voucher: first(rows) }, 201);
  }
  const toggle = route.match(/^\/admin\/vouchers\/([0-9a-f-]{36})\/toggle$/i);
  if (toggle && method === 'POST') {
    assertAllowedOrigin(request);
    const rows = await sql`update public.vouchers set is_active = not is_active where id = ${toggle[1]}::uuid returning *`;
    const data = first(rows);
    if (!data) throw new HttpError(404, 'Voucher not found.');
    return json({ voucher: { ...data, enabled: data.is_active, per_user_cap: data.per_user_limit } });
  }
  throw new HttpError(404, 'Not found.');
}

async function handle(request) {
  const url = new URL(request.url);
  const route = `/${(url.searchParams.get('route') || '').replace(/^\/+|\/+$/g, '')}`;
  const method = request.method.toUpperCase();
  if (route === '/health' && method === 'GET') return json({ ok: true, service: 'botdeck-vercel-api' });

  if (route === '/paystack/webhook' && method === 'POST') {
    const secret = process.env.PAYSTACK_SECRET_KEY || '';
    if (!secret) return json({ error: 'Webhook is not configured.' }, 503);
    const declaredLength = Number(request.headers.get('content-length') || 0);
    if (declaredLength > 256 * 1024) return json({ error: 'Payload too large.' }, 413);
    const raw = Buffer.from(await request.arrayBuffer());
    if (raw.length > 256 * 1024) return json({ error: 'Payload too large.' }, 413);
    const supplied = request.headers.get('x-paystack-signature') || '';
    const expected = crypto.createHmac('sha512', secret).update(raw).digest('hex');
    if (!timingSafeEqualText(supplied, expected)) return json({ error: 'Invalid webhook signature.' }, 401);
    let event;
    try { event = JSON.parse(raw.toString('utf8')); } catch { return json({ error: 'Invalid JSON payload.' }, 400); }
    if (event?.event !== 'charge.success') return json({ received: true });
    const reference = event?.data?.reference;
    if (typeof reference !== 'string') return json({ received: true });
    try {
      const sql = database();
      const payments = await sql`select reference from public.payments where reference = ${reference} limit 1`;
      if (!first(payments)) return json({ received: true });
      await verifyAndFulfill(reference, sql);
      return json({ received: true });
    } catch (error) {
      if (error instanceof HttpError && (error.status === 409 || error.status === 404)) return json({ received: true });
      if (error instanceof HttpError && error.status === 503) return json({ error: error.message }, 503);
      console.error('BotDeck webhook processing failed:', error?.message || 'Unknown error');
      return json({ error: 'Payment verification is temporarily unavailable.' }, 503);
    }
  }

  try {
    if (route === '/admin/login' && method === 'POST') {
      const user = await requireUser(request);
      return await adminRoute(request, route, method, user);
    }
    if (route === '/admin/logout' && method === 'POST') {
      const user = await requireUser(request);
      return await adminRoute(request, route, method, user);
    }
    const user = await requireUser(request);

    if (route === '/repositories' || route === '/repositories/import' || /^\/repositories\/[0-9a-f-]{36}(?:\/(?:start|stop))?$/i.test(route)) {
      if (route === '/repositories/import' && method !== 'POST') throw new HttpError(404, 'Not found.');
      const match = route.match(/^\/repositories\/([0-9a-f-]{36})(?:\/(start|stop))?$/i);
      let body = {};
      if (method === 'POST' && (route === '/repositories/import' || match)) body = await readJson(request);
      return await repositories(request, user, method, body, match);
    }
    if (route === '/worker/status' && method === 'GET') {
      const rows = await user.sql`select worker_id, last_seen_at, execution_enabled from public.worker_heartbeats order by last_seen_at desc limit 1`;
      const heartbeat = first(rows) || null;
      const lastSeen = heartbeat?.last_seen_at ? Date.parse(heartbeat.last_seen_at) : NaN;
      return json({ connected: Number.isFinite(lastSeen) && Date.now() - lastSeen < 90_000, lastSeenAt: Number.isFinite(lastSeen) ? heartbeat.last_seen_at : null, executionEnabled: Boolean(heartbeat?.execution_enabled) });
    }
    if (route === '/plans' && method === 'GET') {
      const rows = await user.sql`select id, name, description, amount_minor, currency, duration_days, max_repositories, is_active from public.plans where is_active = true order by amount_minor asc`;
      return json({ plans: rows.map(plan => ({ ...plan, amount: plan.amount_minor, repository_limit: plan.max_repositories, active: plan.is_active })) });
    }
    if (route === '/subscription' && method === 'GET') return json(await subscriptionFor(user.sql, user.user.id));

    if (route === '/paystack/initialize' && method === 'POST') {
      assertAllowedOrigin(request);
      if (!user.user.email || !user.user.email_confirmed_at) throw new HttpError(400, 'Confirm your email address in Supabase before starting checkout.');
      const body = await readJson(request);
      if (!uuid(body.planId)) throw new HttpError(400, 'Choose a valid plan.');
      const reference = `bd-${crypto.randomUUID().replaceAll('-', '')}`;
      let orderRows;
      try { orderRows = await user.sql`select * from public.prepare_checkout(${user.user.id}::uuid, ${body.planId}::uuid, ${String(body.voucherCode || '').trim().toUpperCase() || null}, ${reference})`; }
      catch (error) { throw new HttpError(400, publicError(error)); }
      const order = first(orderRows);
      if (!order || !Number.isSafeInteger(Number(order.amount_minor)) || !/^[A-Z]{3}$/.test(String(order.currency || '').toUpperCase())) throw new HttpError(503, 'The checkout order could not be prepared.');
      try {
        const result = await paystackRequest('/transaction/initialize', {
          method: 'POST',
          body: JSON.stringify({ email: user.user.email, amount: String(order.amount_minor), currency: String(order.currency).toUpperCase(), reference, callback_url: `${siteOrigin()}/?payment=return`, metadata: { user_id: user.user.id, plan_id: body.planId, reference } }),
        });
        const authorizationUrl = new URL(result.authorization_url);
        if (authorizationUrl.protocol !== 'https:' || authorizationUrl.hostname !== 'checkout.paystack.com') throw new Error('Unexpected Paystack checkout URL.');
        return json({ authorizationUrl: authorizationUrl.toString(), reference });
      } catch (error) {
        await user.sql`update public.payments set status = 'failed' where reference = ${reference} and user_id = ${user.user.id}::uuid and status = 'pending'`;
        throw error;
      }
    }
    if (route === '/paystack/verify' && method === 'GET') {
      const result = await verifyAndFulfill(url.searchParams.get('reference') || '', user.sql, user.user.id);
      const subscriptionRows = await user.sql`select user_id, plan_id, expires_at, updated_at from public.subscriptions where user_id = ${user.user.id}::uuid limit 1`;
      return json({ ...result, subscription: first(subscriptionRows) || null });
    }
    if (route === '/vouchers/redeem' && method === 'POST') {
      assertAllowedOrigin(request);
      const body = await readJson(request);
      const code = String(body.code || '').trim().toUpperCase();
      if (!/^[A-Z0-9_-]{4,64}$/.test(code)) throw new HttpError(400, 'Enter a valid voucher code.');
      let rows;
      try { rows = await user.sql`select public.redeem_free_voucher(${user.user.id}::uuid, ${code}) as redemption`; }
      catch (error) { throw new HttpError(400, publicError(error)); }
      return json({ subscription: first(rows)?.redemption ?? null });
    }
    if (route.startsWith('/admin/')) return await adminRoute(request, route, method, user);
    throw new HttpError(404, 'Not found.');
  } catch (error) {
    if (error instanceof HttpError) return json({ error: error.message }, error.status);
    console.error('BotDeck API request failed:', error?.message || 'Unknown error');
    return json({ error: 'The request could not be completed. Check the server configuration and try again.' }, 500);
  }
}

export default { fetch: handle };
