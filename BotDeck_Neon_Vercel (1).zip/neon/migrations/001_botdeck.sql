-- BotDeck application schema for a private Neon Postgres database.
-- Supabase Auth remains external. Trusted API code must derive user UUIDs only from
-- verified Supabase Auth sessions and must never accept an identity from request bodies.
-- Connect with the Neon connection string only from trusted Vercel/worker processes.
-- No RLS is used: this database is private, and application access is through trusted code.

BEGIN;

CREATE TABLE public.profiles (
  id uuid PRIMARY KEY,
  email text,
  created_at timestamptz NOT NULL DEFAULT pg_catalog.now(),
  updated_at timestamptz NOT NULL DEFAULT pg_catalog.now()
);

CREATE TABLE public.plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  amount_minor bigint NOT NULL CHECK (amount_minor >= 0),
  currency text NOT NULL CHECK (currency ~ '^[A-Z]{3}$'),
  duration_days integer NOT NULL CHECK (duration_days > 0),
  max_repositories integer NOT NULL CHECK (max_repositories > 0),
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT pg_catalog.now()
);

CREATE TABLE public.subscriptions (
  user_id uuid PRIMARY KEY,
  plan_id uuid NOT NULL REFERENCES public.plans (id) ON DELETE RESTRICT,
  expires_at timestamptz NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT pg_catalog.now()
);

CREATE TABLE public.repositories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL,
  repo_name text NOT NULL,
  repo_url text NOT NULL,
  status text NOT NULL DEFAULT 'queued',
  last_error text,
  worker_id text,
  created_at timestamptz NOT NULL DEFAULT pg_catalog.now(),
  updated_at timestamptz NOT NULL DEFAULT pg_catalog.now(),
  CONSTRAINT repositories_public_github_url CHECK (
    repo_url ~ '^https://github\.com/[A-Za-z0-9][A-Za-z0-9-]{0,38}/[A-Za-z0-9_.-]+$'
  ),
  CONSTRAINT repositories_owner_repo_url_unique UNIQUE (owner_id, repo_url)
);

CREATE TABLE public.hosting_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL,
  repository_id uuid REFERENCES public.repositories (id) ON DELETE SET NULL,
  action text NOT NULL CHECK (action IN ('import', 'start', 'stop', 'delete')),
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  status text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued', 'running', 'succeeded', 'failed')),
  attempt integer NOT NULL DEFAULT 0 CHECK (attempt >= 0),
  worker_id text,
  lease_until timestamptz,
  result jsonb,
  error text,
  created_at timestamptz NOT NULL DEFAULT pg_catalog.now(),
  updated_at timestamptz NOT NULL DEFAULT pg_catalog.now()
);

CREATE TABLE public.worker_heartbeats (
  worker_id text PRIMARY KEY,
  host_name text NOT NULL,
  execution_enabled boolean NOT NULL DEFAULT false,
  last_seen_at timestamptz NOT NULL DEFAULT pg_catalog.now(),
  CONSTRAINT worker_heartbeats_worker_id_nonempty CHECK (length(btrim(worker_id)) > 0)
);

CREATE TABLE public.vouchers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE CHECK (code = upper(btrim(code)) AND length(code) > 0),
  kind text NOT NULL CHECK (kind IN ('percent', 'fixed', 'free_days')),
  value bigint NOT NULL CHECK (value > 0),
  currency text CHECK (currency IS NULL OR currency ~ '^[A-Z]{3}$'),
  plan_id uuid REFERENCES public.plans (id) ON DELETE RESTRICT,
  max_redemptions integer CHECK (max_redemptions IS NULL OR max_redemptions > 0),
  per_user_limit integer NOT NULL DEFAULT 1 CHECK (per_user_limit > 0),
  expires_at timestamptz,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT pg_catalog.now(),
  CONSTRAINT vouchers_value_kind_check CHECK (
    (kind = 'percent' AND value <= 100)
    OR (kind = 'fixed' AND currency IS NOT NULL)
    OR (kind = 'free_days' AND plan_id IS NOT NULL AND value <= 2147483647)
  )
);

CREATE TABLE public.payments (
  reference text PRIMARY KEY,
  user_id uuid NOT NULL,
  plan_id uuid NOT NULL REFERENCES public.plans (id) ON DELETE RESTRICT,
  voucher_id uuid REFERENCES public.vouchers (id) ON DELETE RESTRICT,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'failed', 'expired', 'reconciliation_required')),
  amount_minor bigint NOT NULL CHECK (amount_minor >= 0),
  currency text NOT NULL CHECK (currency ~ '^[A-Z]{3}$'),
  discount_minor bigint NOT NULL DEFAULT 0 CHECK (discount_minor >= 0),
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT pg_catalog.now(),
  paid_at timestamptz,
  gateway_reference text UNIQUE,
  CONSTRAINT payments_reference_nonempty CHECK (length(btrim(reference)) > 0)
);

CREATE TABLE public.voucher_redemptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  voucher_id uuid NOT NULL REFERENCES public.vouchers (id) ON DELETE RESTRICT,
  user_id uuid NOT NULL,
  payment_reference text UNIQUE REFERENCES public.payments (reference) ON DELETE SET NULL,
  discount_minor bigint NOT NULL DEFAULT 0 CHECK (discount_minor >= 0),
  redeemed_at timestamptz NOT NULL DEFAULT pg_catalog.now()
);

-- One current log tail per repository; the stored UTF-8 text is capped at 64 KiB.
CREATE TABLE public.repository_logs (
  repository_id uuid PRIMARY KEY REFERENCES public.repositories (id) ON DELETE CASCADE,
  log_tail text NOT NULL DEFAULT '',
  updated_at timestamptz NOT NULL DEFAULT pg_catalog.now(),
  CONSTRAINT repository_logs_tail_max_64k CHECK (pg_catalog.octet_length(log_tail) <= 65536)
);

CREATE INDEX subscriptions_plan_id_idx ON public.subscriptions (plan_id);
CREATE INDEX repositories_owner_created_idx ON public.repositories (owner_id, created_at DESC);
CREATE INDEX hosting_jobs_queue_idx ON public.hosting_jobs (status, lease_until, created_at)
  WHERE status IN ('queued', 'running');
CREATE INDEX hosting_jobs_owner_created_idx ON public.hosting_jobs (owner_id, created_at DESC);
CREATE INDEX hosting_jobs_repository_status_idx ON public.hosting_jobs (repository_id, status)
  WHERE repository_id IS NOT NULL;
CREATE INDEX payments_user_created_idx ON public.payments (user_id, created_at DESC);
CREATE INDEX payments_voucher_reservations_idx ON public.payments (voucher_id, user_id, expires_at)
  WHERE status = 'pending' AND voucher_id IS NOT NULL;
CREATE INDEX voucher_redemptions_voucher_user_idx ON public.voucher_redemptions (voucher_id, user_id);

-- API callers supply p_user_id only after verifying the Supabase Auth session; never
-- derive or trust an account UUID from an unverified request body.
CREATE OR REPLACE FUNCTION public.queue_repository_import(p_user_id uuid, p_repo_url text)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $function$
DECLARE
  v_url text;
  v_repo_name text;
  v_max_repositories integer;
  v_repository_id uuid;
BEGIN
  IF p_user_id IS NULL THEN
    RAISE EXCEPTION 'verified user id is required' USING ERRCODE = '42501';
  END IF;
  IF p_repo_url IS NULL THEN
    RAISE EXCEPTION 'repository URL is required' USING ERRCODE = '22023';
  END IF;
  v_url := pg_catalog.regexp_replace(pg_catalog.btrim(p_repo_url), '/+$', '');
  IF v_url !~ '^https://github\.com/[A-Za-z0-9][A-Za-z0-9-]{0,38}/[A-Za-z0-9_.-]+(\.git)?$' THEN
    RAISE EXCEPTION 'only a public GitHub HTTPS repository URL is accepted' USING ERRCODE = '22023';
  END IF;
  v_url := pg_catalog.regexp_replace(v_url, '\.git$', '');
  v_repo_name := pg_catalog.regexp_replace(v_url, '^https://github\.com/', '');

  -- Serialize imports for one account so concurrent requests cannot exceed its plan limit.
  SELECT p.max_repositories
    INTO v_max_repositories
    FROM public.subscriptions AS s
    JOIN public.plans AS p ON p.id = s.plan_id AND p.is_active
   WHERE s.user_id = p_user_id
     AND s.expires_at > pg_catalog.now()
   FOR UPDATE OF s;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'an active subscription is required' USING ERRCODE = '42501';
  END IF;

  IF (SELECT pg_catalog.count(*) FROM public.repositories AS r WHERE r.owner_id = p_user_id) >= v_max_repositories THEN
    RAISE EXCEPTION 'repository limit reached' USING ERRCODE = '22023';
  END IF;

  INSERT INTO public.repositories (owner_id, repo_name, repo_url, status)
  VALUES (p_user_id, v_repo_name, v_url, 'queued')
  RETURNING id INTO v_repository_id;

  INSERT INTO public.hosting_jobs (owner_id, repository_id, action, payload)
  VALUES (
    p_user_id,
    v_repository_id,
    'import',
    pg_catalog.jsonb_build_object('repo_url', v_url, 'repo_name', v_repo_name)
  );
  RETURN v_repository_id;
EXCEPTION
  WHEN unique_violation THEN
    RAISE EXCEPTION 'this GitHub repository is already registered for this account' USING ERRCODE = '23505';
END;
$function$;

-- User-facing control function also receives the verified Auth UUID explicitly and
-- checks repository ownership before queuing any action.
CREATE OR REPLACE FUNCTION public.queue_repository_action(p_user_id uuid, p_repo_id uuid, p_action text)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $function$
DECLARE
  v_repository public.repositories%ROWTYPE;
  v_job_id uuid;
BEGIN
  IF p_user_id IS NULL THEN
    RAISE EXCEPTION 'verified user id is required' USING ERRCODE = '42501';
  END IF;
  IF p_action IS NULL OR p_action NOT IN ('start', 'stop', 'delete') THEN
    RAISE EXCEPTION 'action must be start, stop, or delete' USING ERRCODE = '22023';
  END IF;

  SELECT r.* INTO v_repository
    FROM public.repositories AS r
   WHERE r.id = p_repo_id AND r.owner_id = p_user_id
   FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'repository not found' USING ERRCODE = 'P0002';
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.hosting_jobs AS j
     WHERE j.repository_id = p_repo_id AND j.status IN ('queued', 'running')
  ) THEN
    RAISE EXCEPTION 'a job is already in flight for this repository' USING ERRCODE = '55000';
  END IF;

  IF p_action = 'start' AND NOT EXISTS (
    SELECT 1 FROM public.subscriptions AS s
    JOIN public.plans AS p ON p.id = s.plan_id AND p.is_active
     WHERE s.user_id = p_user_id AND s.expires_at > pg_catalog.now()
  ) THEN
    RAISE EXCEPTION 'an active subscription is required to start a repository' USING ERRCODE = '42501';
  END IF;

  INSERT INTO public.hosting_jobs (owner_id, repository_id, action, payload)
  VALUES (p_user_id, p_repo_id, p_action,
          pg_catalog.jsonb_build_object('repo_url', v_repository.repo_url, 'repo_name', v_repository.repo_name))
  RETURNING id INTO v_job_id;
  UPDATE public.repositories AS r
     SET status = CASE p_action WHEN 'start' THEN 'starting' WHEN 'stop' THEN 'stopping' ELSE 'deleting' END,
         updated_at = pg_catalog.now()
   WHERE r.id = p_repo_id;
  RETURN v_job_id;
END;
$function$;

-- Worker claim lease is five minutes. Expired running jobs are reclaimable and attempts increment.
CREATE OR REPLACE FUNCTION public.claim_hosting_job(p_worker_id text)
RETURNS TABLE (
  id uuid,
  owner_id uuid,
  repository_id uuid,
  action text,
  payload jsonb,
  status text,
  attempt integer,
  worker_id text,
  lease_until timestamptz,
  result jsonb,
  error text,
  created_at timestamptz,
  updated_at timestamptz,
  repo_url text,
  repo_name text
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $function$
BEGIN
  IF p_worker_id IS NULL OR length(btrim(p_worker_id)) = 0 THEN
    RAISE EXCEPTION 'worker id is required' USING ERRCODE = '22023';
  END IF;

  RETURN QUERY
  WITH candidate AS (
    SELECT j.id
      FROM public.hosting_jobs AS j
     WHERE (j.status = 'queued' OR (j.status = 'running' AND j.lease_until <= pg_catalog.now()))
       AND j.repository_id IS NOT NULL
     ORDER BY j.created_at, j.id
     LIMIT 1
     FOR UPDATE SKIP LOCKED
  ), claimed AS (
    UPDATE public.hosting_jobs AS j
       SET status = 'running',
           attempt = j.attempt + 1,
           worker_id = p_worker_id,
           lease_until = pg_catalog.now() + interval '5 minutes',
           error = NULL,
           updated_at = pg_catalog.now()
      FROM candidate AS c
     WHERE j.id = c.id
     RETURNING j.*
  )
  SELECT c.id, c.owner_id, c.repository_id, c.action, c.payload, c.status,
         c.attempt, c.worker_id, c.lease_until, c.result, c.error,
         c.created_at, c.updated_at, r.repo_url, r.repo_name
    FROM claimed AS c
    JOIN public.repositories AS r ON r.id = c.repository_id;
END;
$function$;

CREATE OR REPLACE FUNCTION public.heartbeat_worker(p_worker_id text, p_host_name text, p_execution_enabled boolean)
RETURNS timestamptz
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $function$
DECLARE
  v_seen timestamptz;
BEGIN
  IF p_worker_id IS NULL OR length(btrim(p_worker_id)) = 0 OR p_host_name IS NULL OR length(btrim(p_host_name)) = 0 THEN
    RAISE EXCEPTION 'worker id and host name are required' USING ERRCODE = '22023';
  END IF;
  INSERT INTO public.worker_heartbeats (worker_id, host_name, execution_enabled, last_seen_at)
  VALUES (p_worker_id, p_host_name, COALESCE(p_execution_enabled, false), pg_catalog.now())
  ON CONFLICT (worker_id) DO UPDATE
    SET host_name = EXCLUDED.host_name,
        execution_enabled = EXCLUDED.execution_enabled,
        last_seen_at = EXCLUDED.last_seen_at
  RETURNING last_seen_at INTO v_seen;
  UPDATE public.hosting_jobs AS j
     SET lease_until = pg_catalog.now() + interval '5 minutes', updated_at = pg_catalog.now()
   WHERE j.worker_id = p_worker_id AND j.status = 'running';
  RETURN v_seen;
END;
$function$;

-- Reconcile interrupted leases/processes when the operator replaces or restarts this worker.
CREATE OR REPLACE FUNCTION public.reconcile_worker(p_worker_id text)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $function$
DECLARE
  v_reconciled integer;
BEGIN
  IF p_worker_id IS NULL OR length(btrim(p_worker_id)) = 0 THEN
    RAISE EXCEPTION 'worker id is required' USING ERRCODE = '22023';
  END IF;
  UPDATE public.hosting_jobs AS j
     SET status = 'queued', worker_id = NULL, lease_until = NULL, updated_at = pg_catalog.now()
   WHERE j.worker_id = p_worker_id AND j.status = 'running';
  UPDATE public.repositories AS r
     SET status = 'stopped', worker_id = NULL, last_error = NULL, updated_at = pg_catalog.now()
   WHERE r.worker_id = p_worker_id AND r.status IN ('running', 'starting', 'stopping', 'cloning', 'importing');
  GET DIAGNOSTICS v_reconciled = ROW_COUNT;
  RETURN v_reconciled;
END;
$function$;

CREATE OR REPLACE FUNCTION public.set_repository_status(
  p_repo_id uuid,
  p_worker_id text,
  p_status text,
  p_error text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $function$
BEGIN
  IF p_status IS NULL OR length(btrim(p_status)) = 0 THEN
    RAISE EXCEPTION 'repository status is required' USING ERRCODE = '22023';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM public.hosting_jobs AS j
     WHERE j.repository_id = p_repo_id
       AND j.worker_id = p_worker_id
       AND j.status = 'running'
       AND j.lease_until > pg_catalog.now()
  ) AND NOT EXISTS (
    SELECT 1 FROM public.repositories AS r
     WHERE r.id = p_repo_id AND r.worker_id = p_worker_id
  ) THEN
    RAISE EXCEPTION 'worker has no active lease for this repository' USING ERRCODE = '42501';
  END IF;
  UPDATE public.repositories AS r
     SET status = p_status,
         last_error = p_error,
         worker_id = p_worker_id,
         updated_at = pg_catalog.now()
   WHERE r.id = p_repo_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'repository not found' USING ERRCODE = 'P0002';
  END IF;
END;
$function$;

CREATE OR REPLACE FUNCTION public.finish_hosting_job(
  p_job_id uuid,
  p_worker_id text,
  p_success boolean,
  p_result jsonb,
  p_error text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $function$
DECLARE
  v_job public.hosting_jobs%ROWTYPE;
BEGIN
  SELECT j.* INTO v_job
    FROM public.hosting_jobs AS j
   WHERE j.id = p_job_id
   FOR UPDATE;
  IF NOT FOUND OR v_job.status <> 'running' OR v_job.worker_id IS DISTINCT FROM p_worker_id
     OR v_job.lease_until IS NULL OR v_job.lease_until <= pg_catalog.now() THEN
    RAISE EXCEPTION 'job is not held by this worker with a live lease' USING ERRCODE = '42501';
  END IF;

  UPDATE public.hosting_jobs AS j
     SET status = CASE WHEN p_success THEN 'succeeded' ELSE 'failed' END,
         result = p_result,
         error = CASE WHEN p_success THEN NULL ELSE COALESCE(p_error, 'worker reported failure') END,
         lease_until = NULL,
         updated_at = pg_catalog.now()
   WHERE j.id = p_job_id;

  IF v_job.repository_id IS NULL THEN
    RETURN;
  END IF;

  IF p_success AND v_job.action = 'delete' THEN
    DELETE FROM public.repositories AS r WHERE r.id = v_job.repository_id;
  ELSIF p_success THEN
    UPDATE public.repositories AS r
       SET status = CASE
             WHEN v_job.action IN ('import', 'stop') THEN 'stopped'
             WHEN v_job.action = 'start' AND r.status IN ('starting', 'running') THEN 'running'
             ELSE r.status
           END,
           last_error = CASE WHEN r.status = 'error' THEN r.last_error ELSE NULL END,
           worker_id = p_worker_id,
           updated_at = pg_catalog.now()
     WHERE r.id = v_job.repository_id;
  ELSE
    UPDATE public.repositories AS r
       SET status = 'error', last_error = COALESCE(p_error, 'worker reported failure'),
           worker_id = p_worker_id, updated_at = pg_catalog.now()
     WHERE r.id = v_job.repository_id;
  END IF;
END;
$function$;

-- Service-side checkout preparation reserves voucher capacity for 30 minutes.
CREATE OR REPLACE FUNCTION public.prepare_checkout(
  p_user_id uuid,
  p_plan_id uuid,
  p_voucher_code text,
  p_reference text
)
RETURNS TABLE (reference text, amount_minor bigint, currency text, discount_minor bigint, expires_at timestamptz)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $function$
DECLARE
  v_plan public.plans%ROWTYPE;
  v_voucher public.vouchers%ROWTYPE;
  v_voucher_id uuid;
  v_discount bigint := 0;
  v_reserved bigint;
  v_user_reserved bigint;
  v_expiry timestamptz := pg_catalog.now() + interval '30 minutes';
BEGIN
  IF p_user_id IS NULL OR p_plan_id IS NULL OR p_reference IS NULL OR length(btrim(p_reference)) = 0 THEN
    RAISE EXCEPTION 'user, plan, and payment reference are required' USING ERRCODE = '22023';
  END IF;
  SELECT p.* INTO v_plan FROM public.plans AS p WHERE p.id = p_plan_id AND p.is_active FOR SHARE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'active plan not found' USING ERRCODE = '22023';
  END IF;
  IF v_plan.amount_minor <= 0 THEN
    RAISE EXCEPTION 'plan amount must be positive for Paystack checkout' USING ERRCODE = '22023';
  END IF;

  IF p_voucher_code IS NOT NULL AND length(btrim(p_voucher_code)) > 0 THEN
    SELECT v.* INTO v_voucher
      FROM public.vouchers AS v
     WHERE v.code = upper(btrim(p_voucher_code))
     FOR UPDATE;
    IF NOT FOUND OR NOT v_voucher.is_active OR (v_voucher.expires_at IS NOT NULL AND v_voucher.expires_at <= pg_catalog.now()) THEN
      RAISE EXCEPTION 'voucher is invalid or expired' USING ERRCODE = '22023';
    END IF;
    IF v_voucher.kind = 'free_days' THEN
      RAISE EXCEPTION 'free-days vouchers must use redeem_free_voucher' USING ERRCODE = '22023';
    END IF;
    IF v_voucher.plan_id IS NOT NULL AND v_voucher.plan_id <> p_plan_id THEN
      RAISE EXCEPTION 'voucher is not valid for this plan' USING ERRCODE = '22023';
    END IF;
    IF v_voucher.kind = 'fixed' AND v_voucher.currency <> v_plan.currency THEN
      RAISE EXCEPTION 'voucher currency does not match plan currency' USING ERRCODE = '22023';
    END IF;

    SELECT pg_catalog.count(*) INTO v_reserved
      FROM public.voucher_redemptions AS r WHERE r.voucher_id = v_voucher.id;
    SELECT v_reserved + pg_catalog.count(*) INTO v_reserved
      FROM public.payments AS p
     WHERE p.voucher_id = v_voucher.id AND p.status = 'pending' AND p.expires_at > pg_catalog.now();
    SELECT pg_catalog.count(*) INTO v_user_reserved
      FROM public.voucher_redemptions AS r
     WHERE r.voucher_id = v_voucher.id AND r.user_id = p_user_id;
    SELECT v_user_reserved + pg_catalog.count(*) INTO v_user_reserved
      FROM public.payments AS p
     WHERE p.voucher_id = v_voucher.id AND p.user_id = p_user_id
       AND p.status = 'pending' AND p.expires_at > pg_catalog.now();
    IF v_voucher.max_redemptions IS NOT NULL AND v_reserved >= v_voucher.max_redemptions THEN
      RAISE EXCEPTION 'voucher redemption limit reached' USING ERRCODE = '22023';
    END IF;
    IF v_user_reserved >= v_voucher.per_user_limit THEN
      RAISE EXCEPTION 'per-user voucher limit reached' USING ERRCODE = '22023';
    END IF;

    IF v_voucher.kind = 'percent' THEN
      v_discount := pg_catalog.floor(v_plan.amount_minor::numeric * v_voucher.value::numeric / 100)::bigint;
    ELSE
      v_discount := LEAST(v_plan.amount_minor, v_voucher.value);
    END IF;
    IF v_discount >= v_plan.amount_minor THEN
      RAISE EXCEPTION 'voucher leaves no payable amount; use an eligible free-days voucher instead' USING ERRCODE = '22023';
    END IF;
    v_voucher_id := v_voucher.id;
  END IF;

  INSERT INTO public.payments (
    reference, user_id, plan_id, voucher_id, status, amount_minor, currency,
    discount_minor, expires_at
  ) VALUES (
    btrim(p_reference), p_user_id, p_plan_id, v_voucher_id, 'pending',
    v_plan.amount_minor - v_discount, v_plan.currency, v_discount, v_expiry
  );

  RETURN QUERY SELECT btrim(p_reference), v_plan.amount_minor - v_discount, v_plan.currency, v_discount, v_expiry;
END;
$function$;

-- Call only after verifying the Paystack transaction server-to-server.
CREATE OR REPLACE FUNCTION public.fulfill_checkout(
  p_reference text,
  p_verified_amount bigint,
  p_verified_currency text,
  p_gateway_reference text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $function$
DECLARE
  v_payment public.payments%ROWTYPE;
  v_plan public.plans%ROWTYPE;
  v_old_expiry timestamptz;
BEGIN
  IF p_reference IS NULL OR p_verified_amount IS NULL OR p_verified_currency IS NULL
     OR p_gateway_reference IS NULL OR length(btrim(p_gateway_reference)) = 0 THEN
    RAISE EXCEPTION 'verified payment details are required' USING ERRCODE = '22023';
  END IF;

  SELECT p.* INTO v_payment FROM public.payments AS p WHERE p.reference = p_reference FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'payment reference not found' USING ERRCODE = 'P0002';
  END IF;
  IF v_payment.status = 'paid' THEN
    IF v_payment.gateway_reference = p_gateway_reference
       AND v_payment.amount_minor = p_verified_amount
       AND v_payment.currency = upper(p_verified_currency) THEN
      RETURN pg_catalog.jsonb_build_object('fulfilled', true, 'idempotent', true, 'user_id', v_payment.user_id);
    END IF;
    RAISE EXCEPTION 'payment reference was already fulfilled with different gateway details' USING ERRCODE = '23505';
  END IF;
  IF v_payment.status <> 'pending' THEN
    RAISE EXCEPTION 'payment is not pending' USING ERRCODE = '55000';
  END IF;
  IF v_payment.amount_minor <> p_verified_amount OR v_payment.currency <> upper(p_verified_currency) THEN
    RAISE EXCEPTION 'verified payment amount or currency does not match checkout' USING ERRCODE = '22023';
  END IF;
  IF v_payment.voucher_id IS NOT NULL AND v_payment.expires_at <= pg_catalog.now() THEN
    UPDATE public.payments AS p
       SET status = 'reconciliation_required', gateway_reference = btrim(p_gateway_reference)
     WHERE p.reference = v_payment.reference;
    RETURN pg_catalog.jsonb_build_object('fulfilled', false, 'reconciliation_required', true, 'user_id', v_payment.user_id);
  END IF;

  SELECT p.* INTO v_plan FROM public.plans AS p WHERE p.id = v_payment.plan_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'purchased plan no longer exists' USING ERRCODE = 'P0002';
  END IF;

  IF v_payment.voucher_id IS NOT NULL THEN
    PERFORM 1 FROM public.vouchers AS v WHERE v.id = v_payment.voucher_id FOR UPDATE;
    IF NOT FOUND THEN
      RAISE EXCEPTION 'payment voucher no longer exists' USING ERRCODE = 'P0002';
    END IF;
    INSERT INTO public.voucher_redemptions (voucher_id, user_id, payment_reference, discount_minor)
    VALUES (v_payment.voucher_id, v_payment.user_id, v_payment.reference, v_payment.discount_minor);
  END IF;

  PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(v_payment.user_id::text, 0));
  SELECT s.expires_at INTO v_old_expiry
    FROM public.subscriptions AS s WHERE s.user_id = v_payment.user_id FOR UPDATE;
  INSERT INTO public.subscriptions (user_id, plan_id, expires_at, updated_at)
  VALUES (
    v_payment.user_id,
    v_payment.plan_id,
    GREATEST(COALESCE(v_old_expiry, pg_catalog.now()), pg_catalog.now()) + pg_catalog.make_interval(days => v_plan.duration_days),
    pg_catalog.now()
  )
  ON CONFLICT (user_id) DO UPDATE
    SET plan_id = EXCLUDED.plan_id,
        expires_at = EXCLUDED.expires_at,
        updated_at = pg_catalog.now();

  UPDATE public.payments AS p
     SET status = 'paid', paid_at = pg_catalog.now(), gateway_reference = btrim(p_gateway_reference)
   WHERE p.reference = v_payment.reference;
  RETURN pg_catalog.jsonb_build_object('fulfilled', true, 'idempotent', false, 'user_id', v_payment.user_id);
END;
$function$;

CREATE OR REPLACE FUNCTION public.redeem_free_voucher(p_user_id uuid, p_code text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $function$
DECLARE
  v_voucher public.vouchers%ROWTYPE;
  v_plan_id uuid;
  v_expires_at timestamptz;
  v_active boolean := false;
  v_redemptions bigint;
  v_pending bigint;
BEGIN
  IF p_user_id IS NULL OR p_code IS NULL OR length(btrim(p_code)) = 0 THEN
    RAISE EXCEPTION 'user and voucher code are required' USING ERRCODE = '22023';
  END IF;

  SELECT v.* INTO v_voucher
    FROM public.vouchers AS v
   WHERE v.code = upper(btrim(p_code))
   FOR UPDATE;
  IF NOT FOUND OR NOT v_voucher.is_active OR v_voucher.kind <> 'free_days'
     OR (v_voucher.expires_at IS NOT NULL AND v_voucher.expires_at <= pg_catalog.now()) THEN
    RAISE EXCEPTION 'active free-days voucher not found' USING ERRCODE = '22023';
  END IF;

  SELECT pg_catalog.count(*) INTO v_redemptions
    FROM public.voucher_redemptions AS r WHERE r.voucher_id = v_voucher.id;
  SELECT pg_catalog.count(*) INTO v_pending
    FROM public.payments AS p
   WHERE p.voucher_id = v_voucher.id AND p.status = 'pending' AND p.expires_at > pg_catalog.now();
  IF v_voucher.max_redemptions IS NOT NULL AND v_redemptions + v_pending >= v_voucher.max_redemptions THEN
    RAISE EXCEPTION 'voucher redemption limit reached' USING ERRCODE = '22023';
  END IF;
  IF (SELECT pg_catalog.count(*) FROM public.voucher_redemptions AS r WHERE r.voucher_id = v_voucher.id AND r.user_id = p_user_id)
     + (SELECT pg_catalog.count(*) FROM public.payments AS p WHERE p.voucher_id = v_voucher.id AND p.user_id = p_user_id AND p.status = 'pending' AND p.expires_at > pg_catalog.now())
     >= v_voucher.per_user_limit THEN
    RAISE EXCEPTION 'per-user voucher limit reached' USING ERRCODE = '22023';
  END IF;

  PERFORM pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(p_user_id::text, 0));
  SELECT s.plan_id, s.expires_at, (s.expires_at > pg_catalog.now())
    INTO v_plan_id, v_expires_at, v_active
    FROM public.subscriptions AS s WHERE s.user_id = p_user_id FOR UPDATE;

  IF COALESCE(v_active, false) AND v_voucher.plan_id IS NOT NULL AND v_voucher.plan_id <> v_plan_id THEN
    RAISE EXCEPTION 'free-days voucher is not valid for the current plan' USING ERRCODE = '22023';
  END IF;

  IF NOT COALESCE(v_active, false) THEN
    v_plan_id := v_voucher.plan_id;
    IF v_plan_id IS NULL OR NOT EXISTS (
      SELECT 1 FROM public.plans AS p WHERE p.id = v_plan_id AND p.is_active
    ) THEN
      RAISE EXCEPTION 'voucher requires an active target plan for a user without an active subscription' USING ERRCODE = '22023';
    END IF;
    v_expires_at := pg_catalog.now() + pg_catalog.make_interval(days => v_voucher.value::integer);
  ELSE
    v_expires_at := GREATEST(v_expires_at, pg_catalog.now()) + pg_catalog.make_interval(days => v_voucher.value::integer);
  END IF;

  INSERT INTO public.subscriptions (user_id, plan_id, expires_at, updated_at)
  VALUES (p_user_id, v_plan_id, v_expires_at, pg_catalog.now())
  ON CONFLICT (user_id) DO UPDATE
    SET plan_id = EXCLUDED.plan_id,
        expires_at = EXCLUDED.expires_at,
        updated_at = pg_catalog.now();
  INSERT INTO public.voucher_redemptions (voucher_id, user_id, discount_minor)
  VALUES (v_voucher.id, p_user_id, 0);
  RETURN pg_catalog.jsonb_build_object('redeemed', true, 'plan_id', v_plan_id, 'expires_at', v_expires_at);
END;
$function$;

-- The database is private and functions execute only under trusted server credentials.
-- PUBLIC receives no direct table, sequence, or function privileges.
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM PUBLIC;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM PUBLIC;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA public FROM PUBLIC;

COMMIT;
