import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Activity, ArrowDownToLine, Boxes, CalendarDays, Check, CircleAlert, CircleCheck,
  CreditCard, ExternalLink, GitBranch, LayoutDashboard, LoaderCircle, LockKeyhole,
  LogOut, Menu, Plus, RefreshCw, ShieldCheck, Square, Ticket, Trash2, Users, X,
} from 'lucide-react';
import { supabase, supabaseConfigured } from './lib/supabase.js';
import { api } from './lib/api.js';

const tabs = [
  { id: 'overview', label: 'Overview', Icon: LayoutDashboard },
  { id: 'repositories', label: 'Repositories', Icon: Boxes },
  { id: 'billing', label: 'Billing', Icon: CreditCard },
  { id: 'admin', label: 'Admin', Icon: ShieldCheck },
];

function Brand() {
  return <div className="brand"><img src="/botdeck-mark.svg" alt="" /><span>BotDeck</span></div>;
}

function errorText(error, fallback = 'Something went wrong. Please try again.') {
  const message = typeof error?.message === 'string' ? error.message.trim() : '';
  return message && message.length < 240 ? message : fallback;
}

function isUnauthorized(error) {
  return error?.status === 401 || error?.statusCode === 401 || /\b401\b|unauthori[sz]ed/i.test(error?.message || '');
}

function formatDate(value) {
  if (!value) return '—';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '—' : new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(date);
}

function money(value, currency = 'USD') {
  const amount = Number(value);
  if (!Number.isFinite(amount)) return value || '—';
  try { return new Intl.NumberFormat(undefined, { style: 'currency', currency: String(currency || 'USD').toUpperCase() }).format(amount / 100); }
  catch { return `${currency || ''} ${(amount / 100).toFixed(2)}`; }
}

function Notice({ notice, onDismiss }) {
  if (!notice) return null;
  const Icon = notice.type === 'error' ? CircleAlert : CircleCheck;
  return <div className={`notice notice-${notice.type}`} role="status"><Icon size={17} /><span>{notice.text}</span><button className="icon-button" onClick={onDismiss} aria-label="Dismiss message"><X size={16} /></button></div>;
}

function AuthScreen() {
  const [mode, setMode] = useState('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState(null);

  const submit = async event => {
    event.preventDefault();
    setBusy(true); setMessage(null);
    try {
      if (mode === 'signup') {
        const { data, error } = await supabase.auth.signUp({ email: email.trim(), password, options: { emailRedirectTo: window.location.origin } });
        if (error) throw error;
        if (data?.session) setMessage({ type: 'success', text: 'Account created. You are signed in.' });
        else setMessage({ type: 'success', text: 'Account created. Check your email to confirm your address, then sign in.' });
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
      }
    } catch (error) { setMessage({ type: 'error', text: errorText(error, 'Authentication could not be completed.') }); }
    finally { setBusy(false); }
  };

  return <main className="auth-screen"><div className="auth-glow" /><section className="auth-card" aria-labelledby="auth-title">
    <Brand /><div className="auth-icon"><LockKeyhole size={21} /></div><p className="eyebrow">YOUR BOT WORKSPACE</p>
    {!supabaseConfigured && <div className="notice notice-error" role="alert"><CircleAlert size={17} /><span>Supabase is not configured. Set VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY (or the legacy VITE_SUPABASE_ANON_KEY) to enable account access.</span></div>}
    <h1 id="auth-title">{mode === 'signin' ? 'Welcome back.' : 'Create your account.'}</h1>
    <p className="auth-copy">Manage your repositories and subscription from one secure workspace.</p>
    <div className="auth-switch" role="tablist" aria-label="Account access"><button type="button" role="tab" aria-selected={mode === 'signin'} className={mode === 'signin' ? 'selected' : ''} onClick={() => { setMode('signin'); setMessage(null); }}>Sign in</button><button type="button" role="tab" aria-selected={mode === 'signup'} className={mode === 'signup' ? 'selected' : ''} onClick={() => { setMode('signup'); setMessage(null); }}>Create account</button></div>
    <form className="form-stack" onSubmit={submit}>
      <label htmlFor="auth-email">Email address</label><input id="auth-email" className="field" type="email" autoComplete="email" value={email} onChange={event => setEmail(event.target.value)} placeholder="you@example.com" required />
      <label htmlFor="auth-password">Password</label><input id="auth-password" className="field" type="password" autoComplete={mode === 'signin' ? 'current-password' : 'new-password'} value={password} onChange={event => setPassword(event.target.value)} minLength={6} required />
      {message && <div className={`inline-message ${message.type}`} role="status">{message.text}</div>}
      <button className="button button-primary submit-button" type="submit" disabled={busy}>{busy ? <LoaderCircle className="spin" size={16} /> : null}{busy ? 'Please wait…' : mode === 'signin' ? 'Sign in' : 'Create account'}</button>
    </form>
    <p className="auth-foot"><ShieldCheck size={14} /> Your account is secured by Supabase authentication.</p>
  </section><p className="auth-caption">Repository controls are available after signing in.</p></main>;
}

const repositoryOperations = ['queued', 'cloning', 'starting', 'running', 'stopping', 'deleting', 'importing'];
const repositoryActionPending = repositoryOperations.filter(status => status !== 'running');
const operationLabel = { queued: 'Queued', cloning: 'Importing', importing: 'Importing', starting: 'Starting', stopping: 'Stopping', deleting: 'Deleting', stopped: 'Stopped', error: 'Needs attention', running: 'Running' };

function StatusBadge({ status }) {
  const value = String(status || 'unknown').toLowerCase();
  const busy = repositoryOperations.includes(value);
  const label = operationLabel[value] || value.replace(/[_-]/g, ' ').replace(/^\w/, char => char.toUpperCase());
  const Icon = value === 'running' ? Activity : value === 'error' ? CircleAlert : busy ? LoaderCircle : Square;
  return <span className={`status-badge status-${value}`}><Icon size={13} className={busy ? 'spin' : ''} />{label}</span>;
}

function Repositories({ repos, loading, onRefresh, onImport, onAction, busyId, importing, workerStatus }) {
  const [repoUrl, setRepoUrl] = useState('');
  const [filter, setFilter] = useState('');
  const filtered = repos.filter(repo => `${repo.name || ''} ${repo.url || ''}`.toLowerCase().includes(filter.toLowerCase()));
  const submit = async event => { event.preventDefault(); const value = repoUrl.trim(); if (!value) return; const okay = await onImport(value); if (okay) setRepoUrl(''); };

  return <section className="panel-section" aria-labelledby="repositories-title">
    <div className="section-heading"><div><p className="eyebrow">YOUR PROJECTS</p><h2 id="repositories-title">Repositories <span className="count-pill">{repos.length}</span></h2><p className="muted">Import and control repositories connected to your account.</p></div><button className="button button-secondary" onClick={onRefresh} disabled={loading}><RefreshCw size={15} className={loading ? 'spin' : ''} />Refresh</button></div>
    <div className="panel import-panel"><div className="panel-title"><span className="tile-icon"><GitBranch size={19} /></span><div><h3>Import a repository</h3><p>Paste the URL of a public GitHub repository.</p></div></div>
      <form className="import-form" onSubmit={submit}><label className="sr-only" htmlFor="repo-url">Repository URL</label><input id="repo-url" className="field url-field" type="url" inputMode="url" placeholder="https://github.com/owner/repository" value={repoUrl} onChange={event => setRepoUrl(event.target.value)} required /><button className="button button-primary" type="submit" disabled={importing || !repoUrl.trim()}>{importing ? <LoaderCircle size={15} className="spin" /> : <Plus size={16} />}{importing ? 'Importing…' : 'Import repository'}</button></form>
    </div>
    <div className="list-toolbar"><div><h3>All repositories</h3><span className="muted">{repos.length} total</span></div><label className="search-field"><span className="sr-only">Filter repositories</span><input className="field" value={filter} onChange={event => setFilter(event.target.value)} placeholder="Filter repositories" /></label></div>
    <div className="notice" role="status"><ShieldCheck size={17} /><span>{workerStatus?.connected ? workerStatus.executionEnabled ? 'Worker connected, but repository execution is enabled. Public repository code runs under the same Pterodactyl service account; there is no per-repository OS sandbox.' : 'Worker connected; repository execution is disabled by default. Start jobs will not run until the host explicitly enables it. Do not enable public code execution without per-repository isolation and resource limits.' : 'Worker is not connected. Jobs remain queued in Supabase until a worker connects. On host migration, deploy the worker against the same Supabase project and keep the same WORKER_ID; running processes do not migrate.'}</span></div>
    <div className="repo-list">{loading ? <div className="loading-state"><LoaderCircle className="spin" size={18} />Loading repositories…</div> : filtered.length ? filtered.map(repo => <article className="repo-item" key={repo.id}>
      <span className="repo-icon"><GitBranch size={18} /></span><div className="repo-main"><strong>{repo.name || 'Unnamed repository'}</strong><a href={repo.url} target="_blank" rel="noreferrer">{repo.url}<ExternalLink size={12} /></a><small>Added {formatDate(repo.created_at)}</small>{repo.last_error && <p className="repo-error"><CircleAlert size={13} />{repo.last_error}</p>}</div><StatusBadge status={repo.status} />
      <div className="repo-actions">{String(repo.status).toLowerCase() === 'running' ? <button className="button button-small button-secondary" disabled={busyId === repo.id} onClick={() => onAction(repo, 'stop')}><Square size={13} />Stop</button> : <button className="button button-small button-primary" disabled={busyId === repo.id || repositoryActionPending.includes(String(repo.status).toLowerCase())} onClick={() => onAction(repo, 'start')}><ArrowDownToLine size={13} />Start</button>}<button className="button button-small button-danger-outline" disabled={busyId === repo.id || repositoryActionPending.includes(String(repo.status).toLowerCase())} onClick={() => { if (window.confirm(`Delete ${repo.name || 'this repository'} from your workspace?`)) onAction(repo, 'delete'); }} aria-label={`Delete ${repo.name || 'repository'}`}><Trash2 size={13} />Delete</button></div>
    </article>) : <div className="empty-state"><div className="empty-icon"><Boxes size={21} /></div><strong>{repos.length ? 'No matching repositories' : 'No repositories yet'}</strong><p>{repos.length ? 'Try a different search.' : 'Import a repository above to get started.'}</p></div>}</div>
  </section>;
}

function Billing({ plans, subscription, currentPlan, loading, onReload, onCheckout, onRedeem, busy }) {
  const [voucher, setVoucher] = useState('');
  const [checkoutVoucher, setCheckoutVoucher] = useState('');
  const [redeeming, setRedeeming] = useState(false);
  const submitVoucher = async event => { event.preventDefault(); setRedeeming(true); const ok = await onRedeem(voucher.trim()); if (ok) setVoucher(''); setRedeeming(false); };
  const status = subscription?.status || 'No active subscription';
  const expiry = subscription?.expires_at || subscription?.current_period_end || subscription?.expiry_date;
  return <section className="panel-section" aria-labelledby="billing-title">
    <div className="section-heading"><div><p className="eyebrow">PLAN & PAYMENTS</p><h2 id="billing-title">Billing</h2><p className="muted">View your plan, manage your subscription, or apply a voucher.</p></div><button className="button button-secondary" onClick={onReload} disabled={loading}><RefreshCw size={15} className={loading ? 'spin' : ''} />Refresh</button></div>
    <div className="billing-current panel"><div className="billing-symbol"><CreditCard size={20} /></div><div className="billing-current-info"><span className="eyebrow">CURRENT SUBSCRIPTION</span><h3>{currentPlan?.name || 'No plan selected'}</h3><p>Status: <strong>{status}</strong>{expiry && <> · Expires {formatDate(expiry)}</>}</p></div><span className={`plan-state ${subscription?.status === 'active' ? 'is-active' : ''}`}>{subscription?.status || 'Inactive'}</span></div>
    <div className="plans-heading"><h3>Available plans</h3><span className="muted">One-time payment via Paystack; renew manually when needed.</span></div>
    <div className="panel voucher-panel"><div className="panel-title"><span className="tile-icon"><Ticket size={19} /></span><div><h3>Checkout discount</h3><p>Optional percent or fixed-amount discount voucher for a plan purchase.</p></div></div><label htmlFor="checkout-voucher" className="sr-only">Discount voucher code</label><input id="checkout-voucher" className="field" value={checkoutVoucher} onChange={event => setCheckoutVoucher(event.target.value)} placeholder="Discount code (optional)" autoComplete="off" /></div>
    {loading ? <div className="loading-state"><LoaderCircle className="spin" size={18} />Loading plans…</div> : plans.length ? <div className="plan-grid">{plans.map(plan => { const isCurrentPlan = plan.id === currentPlan?.id && subscription?.status === 'active'; return <article className={`plan-card ${isCurrentPlan ? 'plan-current' : ''}`} key={plan.id}><div className="plan-card-head"><div><h4>{plan.name || 'Plan'}</h4><p>{plan.description || 'Repository hosting plan'}</p></div>{isCurrentPlan && <span className="current-label"><Check size={13} />Current</span>}</div><div className="plan-price">{money(plan.amount ?? plan.price ?? plan.price_amount, plan.currency)}<small></small></div><p className="plan-limit">{plan.repository_limit ?? plan.max_repositories ?? '—'} repositories · {plan.duration_days ?? '—'} days</p><button className="button button-primary plan-button" onClick={() => onCheckout(plan, checkoutVoucher.trim())} disabled={busy || isCurrentPlan}>{busy ? <LoaderCircle size={15} className="spin" /> : <ExternalLink size={15} />}{isCurrentPlan ? 'Current plan' : 'Continue to checkout'}</button></article>; })}</div> : <div className="empty-state compact-empty"><strong>No plans are available</strong><p>Plans may not be configured for this workspace yet.</p></div>}
    <div className="panel voucher-panel"><div className="panel-title"><span className="tile-icon"><Ticket size={19} /></span><div><h3>Redeem free days</h3><p>This form is only for free-days vouchers. Discount codes belong in the checkout field above.</p></div></div><form className="voucher-form" onSubmit={submitVoucher}><label className="sr-only" htmlFor="voucher-code">Voucher code</label><input id="voucher-code" className="field" value={voucher} onChange={event => setVoucher(event.target.value)} placeholder="Enter code" autoComplete="off" required /><button className="button button-secondary" disabled={redeeming || !voucher.trim()}>{redeeming ? <LoaderCircle size={15} className="spin" /> : null}{redeeming ? 'Applying…' : 'Apply voucher'}</button></form></div>
  </section>;
}

function Admin({ overview, loading, loginRequired, onLogin, onReload, onLogout, onCreatePlan, onCreateVoucher, onToggleVoucher, busy }) {
  const [password, setPassword] = useState('');
  const [planForm, setPlanForm] = useState({ id: '', name: '', description: '', amount: '', currency: 'NGN', duration_days: '30', repository_limit: '1', active: true });
  const [voucherForm, setVoucherForm] = useState({ code: '', kind: 'percent', value: '', currency: '', plan_id: '', expires_at: '', max_redemptions: '', per_user_cap: '' });
  const [formError, setFormError] = useState('');
  const editPlan = plan => setPlanForm({ id: plan.id || '', name: plan.name || '', description: plan.description || '', amount: plan.amount ?? plan.amount_minor ?? '', currency: plan.currency || 'NGN', duration_days: plan.duration_days ?? 30, repository_limit: plan.repository_limit ?? plan.max_repositories ?? 1, active: plan.active !== false });
  const submitPlan = async event => { event.preventDefault(); setFormError(''); const payload = { ...(planForm.id ? { id: planForm.id } : {}), name: planForm.name, description: planForm.description, amount: Number(planForm.amount), currency: planForm.currency.toUpperCase(), duration_days: Number(planForm.duration_days), repository_limit: Number(planForm.repository_limit), active: planForm.active }; const ok = await onCreatePlan(payload); if (!ok) setFormError('The plan could not be saved. Check the details and try again.'); else setPlanForm({ id: '', name: '', description: '', amount: '', currency: 'NGN', duration_days: '30', repository_limit: '1', active: true }); };
  const submitVoucher = async event => { event.preventDefault(); setFormError(''); const payload = { ...voucherForm, value: Number(voucherForm.value), currency: voucherForm.currency || undefined, plan_id: voucherForm.plan_id || undefined, expires_at: voucherForm.expires_at ? new Date(voucherForm.expires_at).toISOString() : undefined, max_redemptions: voucherForm.max_redemptions ? Number(voucherForm.max_redemptions) : undefined, per_user_cap: voucherForm.per_user_cap ? Number(voucherForm.per_user_cap) : undefined }; const ok = await onCreateVoucher(payload); if (!ok) setFormError('The voucher could not be created. Check the details and try again.'); else setVoucherForm({ code: '', kind: 'percent', value: '', currency: '', plan_id: '', expires_at: '', max_redemptions: '', per_user_cap: '' }); };
  if (loginRequired) return <section className="panel-section"><div className="section-heading"><div><p className="eyebrow">RESTRICTED AREA</p><h2>Admin access</h2><p className="muted">Enter the admin password to manage plans and vouchers.</p></div></div><form className="admin-login panel" onSubmit={event => { event.preventDefault(); onLogin(password); }}><label htmlFor="admin-password">Admin password</label><input id="admin-password" className="field" type="password" autoComplete="current-password" value={password} onChange={event => setPassword(event.target.value)} required /><button className="button button-primary" disabled={busy || !password}>{busy ? <LoaderCircle size={15} className="spin" /> : <LockKeyhole size={15} />}{busy ? 'Checking…' : 'Continue'}</button></form></section>;
  if (loading && !overview) return <div className="loading-state panel"><LoaderCircle className="spin" size={18} />Loading admin overview…</div>;
  if (!overview) return <section className="panel-section"><div className="notice notice-error"><CircleAlert size={17} /><span>Admin overview is not available. Check configuration and try again.</span><button className="button button-secondary" onClick={onReload}>Retry</button></div></section>;
  const plans = overview.plans || [], vouchers = overview.vouchers || [], payments = overview.payments || [], redemptions = overview.redemptions || [];
  return <section className="panel-section" aria-labelledby="admin-title">
    <div className="section-heading"><div><p className="eyebrow">WORKSPACE CONTROL</p><h2 id="admin-title">Admin</h2><p className="muted">Manage availability, vouchers, and recent billing activity.</p></div><div className="heading-actions"><button className="button button-secondary" onClick={onReload} disabled={loading}><RefreshCw size={15} className={loading ? 'spin' : ''} />Refresh</button><button className="button button-quiet" onClick={onLogout} disabled={busy}><LogOut size={15} />Admin logout</button></div></div>
    {formError && <div className="notice notice-error" role="alert"><CircleAlert size={16} />{formError}</div>}
    <div className="admin-grid">
      <div className="panel admin-panel"><div className="panel-title"><span className="tile-icon"><Boxes size={18} /></span><div><h3>{planForm.id ? 'Edit plan' : 'Create plan'}</h3><p>Save a new plan or update an existing one.</p></div></div><form className="admin-form" onSubmit={submitPlan}>
        {planForm.id && <div className="field-note">Editing plan <code>{planForm.id}</code> <button type="button" className="text-button" onClick={() => setPlanForm({ id: '', name: '', description: '', amount: '', currency: 'NGN', duration_days: '30', repository_limit: '1', active: true })}>Cancel edit</button></div>}
        <label>Plan name<input className="field" value={planForm.name} onChange={e => setPlanForm({ ...planForm, name: e.target.value })} required /></label><label>Description<input className="field" value={planForm.description} onChange={e => setPlanForm({ ...planForm, description: e.target.value })} /></label>
        <div className="form-row"><label>Amount (minor units)<input className="field" type="number" min="1" step="1" value={planForm.amount} onChange={e => setPlanForm({ ...planForm, amount: e.target.value })} required /></label><label>Currency<input className="field" value={planForm.currency} maxLength={3} onChange={e => setPlanForm({ ...planForm, currency: e.target.value })} required /></label></div>
        <div className="form-row"><label>Duration (days)<input className="field" type="number" min="1" step="1" value={planForm.duration_days} onChange={e => setPlanForm({ ...planForm, duration_days: e.target.value })} required /></label><label>Repository limit<input className="field" type="number" min="1" step="1" value={planForm.repository_limit} onChange={e => setPlanForm({ ...planForm, repository_limit: e.target.value })} required /></label></div><p className="field-note">Amount is in minor currency units (for example, 1000 kobo = ₦10). Purchases are one-time with manual renewal.</p>
        <label className="check-label"><input type="checkbox" checked={planForm.active} onChange={e => setPlanForm({ ...planForm, active: e.target.checked })} /> Plan is active</label><button className="button button-primary" disabled={busy}>{busy ? <LoaderCircle size={15} className="spin" /> : <Plus size={15} />}{planForm.id ? 'Save plan' : 'Create plan'}</button>
      </form><div className="admin-list"><h4>Plans ({plans.length})</h4>{plans.map(plan => <div className="admin-row" key={plan.id}><span><strong>{plan.name}</strong><small>{money(plan.amount, plan.currency)} · {plan.active === false ? 'Inactive' : 'Active'}</small></span><button className="button button-small button-secondary" onClick={() => editPlan(plan)}>Edit</button></div>)}</div></div>
      <div className="panel admin-panel"><div className="panel-title"><span className="tile-icon"><Ticket size={18} /></span><div><h3>Create voucher</h3><p>Configure a discount or free subscription days.</p></div></div><form className="admin-form" onSubmit={submitVoucher}>
        <label>Voucher code<input className="field" value={voucherForm.code} onChange={e => setVoucherForm({ ...voucherForm, code: e.target.value.toUpperCase() })} required /></label><div className="form-row"><label>Kind<select className="field" value={voucherForm.kind} onChange={e => setVoucherForm({ ...voucherForm, kind: e.target.value })}><option value="percent">Percent</option><option value="fixed">Fixed amount</option><option value="free_days">Free days</option></select></label><label>Value<input className="field" type="number" min="1" step="1" value={voucherForm.value} onChange={e => setVoucherForm({ ...voucherForm, value: e.target.value })} required /></label></div>
        <div className="form-row"><label>Currency (optional)<input className="field" value={voucherForm.currency} maxLength={3} onChange={e => setVoucherForm({ ...voucherForm, currency: e.target.value.toUpperCase() })} /></label><label>Plan ID (optional)<select className="field" value={voucherForm.plan_id} onChange={e => setVoucherForm({ ...voucherForm, plan_id: e.target.value })}><option value="">Any plan</option>{plans.map(plan => <option value={plan.id} key={plan.id}>{plan.name}</option>)}</select></label></div>
        <label>Expiry (optional)<input className="field" type="datetime-local" value={voucherForm.expires_at} onChange={e => setVoucherForm({ ...voucherForm, expires_at: e.target.value })} /></label>
        <div className="form-row"><label>Max redemptions<input className="field" type="number" min="1" value={voucherForm.max_redemptions} onChange={e => setVoucherForm({ ...voucherForm, max_redemptions: e.target.value })} /></label><label>Per-user cap<input className="field" type="number" min="1" value={voucherForm.per_user_cap} onChange={e => setVoucherForm({ ...voucherForm, per_user_cap: e.target.value })} /></label></div><button className="button button-primary" disabled={busy}>{busy ? <LoaderCircle size={15} className="spin" /> : <Plus size={15} />}Create voucher</button>
      </form><div className="admin-list"><h4>Vouchers ({vouchers.length})</h4>{vouchers.map(voucher => <div className="admin-row" key={voucher.id}><span><strong>{voucher.code}</strong><small>{voucher.kind} · {voucher.value} · {voucher.enabled === false ? 'Disabled' : 'Enabled'}</small></span><button className="button button-small button-secondary" disabled={busy} onClick={() => onToggleVoucher(voucher)}>{voucher.enabled === false ? 'Enable' : 'Disable'}</button></div>)}</div></div>
    </div>
    <div className="activity-grid"><DataList title="Recent payments" Icon={CreditCard} rows={payments} dateKeys={['created_at', 'paid_at']} primaryKeys={['email', 'user_email', 'reference']} secondaryKeys={['status', 'amount']} /><DataList title="Recent redemptions" Icon={Users} rows={redemptions} dateKeys={['created_at', 'redeemed_at']} primaryKeys={['code', 'voucher_code', 'email']} secondaryKeys={['user_email', 'kind', 'value']} /></div>
  </section>;
}

function DataList({ title, Icon, rows, dateKeys, primaryKeys, secondaryKeys }) {
  const pick = (row, keys) => keys.map(key => row?.[key]).find(value => value !== undefined && value !== null && value !== '');
  return <div className="panel data-panel"><div className="panel-title"><span className="tile-icon"><Icon size={18} /></span><div><h3>{title}</h3><p>Latest account activity</p></div></div>{rows.length ? <div className="data-list">{rows.slice(0, 8).map((row, index) => <div className="data-row" key={row.id || row.reference || index}><span><strong>{pick(row, primaryKeys) || 'Activity'}</strong><small>{pick(row, secondaryKeys) || row.plan_name || '—'}</small></span><time>{formatDate(pick(row, dateKeys))}</time></div>)}</div> : <p className="muted empty-note">No recent records.</p>}</div>;
}

function Overview({ user, repos, subscription, plan, loading, onRepositories }) {
  const limit = plan?.repository_limit ?? plan?.repositoryLimit ?? plan?.max_repositories;
  const usage = limit === undefined || limit === null ? `${repos.length}` : `${repos.length} / ${limit}`;
  const expiry = subscription?.expires_at || subscription?.current_period_end || subscription?.expiry_date;
  const running = repos.filter(repo => String(repo.status).toLowerCase() === 'running').length;
  return <section className="panel-section"><div className="page-heading"><div><p className="eyebrow">YOUR WORKSPACE</p><h1>Welcome, {user.email || 'there'}.</h1><p className="muted">A clear view of your repositories and account plan.</p></div><span className="workspace-chip"><ShieldCheck size={15} />Personal workspace</span></div>
    <div className="stats-grid"><article className="stat-card"><span>Repositories</span><strong>{loading ? '—' : usage}</strong><small>Repository usage</small><Boxes className="stat-watermark" size={19} /></article><article className="stat-card"><span>Running</span><strong>{loading ? '—' : running}</strong><small>Current repository status</small><Activity className="stat-watermark" size={19} /></article><article className="stat-card"><span>Subscription</span><strong className="stat-plan">{loading ? '—' : plan?.name || 'No active plan'}</strong><small>{subscription?.status || 'Choose a plan in Billing'}</small><CreditCard className="stat-watermark" size={19} /></article><article className="stat-card"><span>Plan expiry</span><strong className="stat-date">{loading ? '—' : expiry ? formatDate(expiry) : '—'}</strong><small>{expiry ? 'Subscription period end' : 'No expiry date available'}</small><CalendarDays className="stat-watermark" size={19} /></article></div>
    <div className="overview-grid"><div className="panel overview-panel"><div className="section-heading"><div><p className="eyebrow">RECENT WORK</p><h2>Your repositories</h2></div><button className="text-link text-link-button" onClick={onRepositories}>Manage repositories <ExternalLink size={14} /></button></div>{repos.length ? repos.slice(0, 5).map(repo => <div className="overview-repo" key={repo.id}><span className="repo-icon"><GitBranch size={17} /></span><span><strong>{repo.name || 'Unnamed repository'}</strong><small>{repo.url}</small></span><StatusBadge status={repo.status} /></div>) : <div className="empty-state short-empty"><div className="empty-icon"><Boxes size={20} /></div><strong>No repositories yet</strong><p>Import your first repository from the Repositories tab.</p></div>}</div><div className="panel account-panel"><p className="eyebrow">ACCOUNT</p><div className="account-avatar">{(user.email || 'U').slice(0, 1).toUpperCase()}</div><h3>{user.email}</h3><p>Authenticated with Supabase</p><div className="account-divider" /><span className="muted">Plan</span><strong>{plan?.name || 'No active plan'}</strong><span className="muted">Status</span><strong>{subscription?.status || 'Inactive'}</strong></div></div>
  </section>;
}

function Dashboard({ user, onLogout }) {
  const [tab, setTab] = useState('overview');
  const [repos, setRepos] = useState([]);
  const [repoLoading, setRepoLoading] = useState(true);
  const [repoBusy, setRepoBusy] = useState('');
  const [importing, setImporting] = useState(false);
  const [plans, setPlans] = useState([]);
  const [subscription, setSubscription] = useState(null);
  const [currentPlan, setCurrentPlan] = useState(null);
  const [billingLoading, setBillingLoading] = useState(true);
  const [checkoutBusy, setCheckoutBusy] = useState(false);
  const [notice, setNotice] = useState(null);
  const [adminOverview, setAdminOverview] = useState(null);
  const [adminLoading, setAdminLoading] = useState(false);
  const [adminRequired, setAdminRequired] = useState(false);
  const [adminBusy, setAdminBusy] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);
  const [workerStatus, setWorkerStatus] = useState(null);
  const [workerLoading, setWorkerLoading] = useState(false);
  const callbackHandled = useRef(false);

  const loadRepositories = useCallback(async () => {
    setRepoLoading(true);
    try { const result = await api('/api/repositories'); setRepos(Array.isArray(result?.repositories) ? result.repositories : []); }
    catch (error) { setNotice({ type: 'error', text: errorText(error, 'Repositories could not be loaded.') }); }
    finally { setRepoLoading(false); }
  }, []);
  const loadWorkerStatus = useCallback(async () => {
    setWorkerLoading(true);
    try { setWorkerStatus(await api('/api/worker/status')); }
    catch { setWorkerStatus(null); }
    finally { setWorkerLoading(false); }
  }, []);
  const loadBilling = useCallback(async () => {
    setBillingLoading(true);
    try {
      const [planResult, subscriptionResult] = await Promise.all([api('/api/plans'), api('/api/subscription')]);
      setPlans(Array.isArray(planResult?.plans) ? planResult.plans : []); setSubscription(subscriptionResult?.subscription || null); setCurrentPlan(subscriptionResult?.plan || null);
    } catch (error) { setNotice({ type: 'error', text: errorText(error, 'Billing information is unavailable.') }); }
    finally { setBillingLoading(false); }
  }, []);
  const loadAdmin = useCallback(async () => {
    setAdminLoading(true);
    try { const result = await api('/api/admin/overview'); setAdminOverview(result); setAdminRequired(false); }
    catch (error) { if (isUnauthorized(error)) { setAdminRequired(true); setAdminOverview(null); } else setNotice({ type: 'error', text: errorText(error, 'Admin overview could not be loaded.') }); }
    finally { setAdminLoading(false); }
  }, []);

  useEffect(() => { loadRepositories(); loadBilling(); loadWorkerStatus(); }, [loadRepositories, loadBilling, loadWorkerStatus]);
  useEffect(() => {
    if (!repos.some(repo => repositoryOperations.includes(String(repo.status).toLowerCase()))) return undefined;
    const timer = window.setInterval(loadRepositories, 5000);
    return () => window.clearInterval(timer);
  }, [repos, loadRepositories]);
  useEffect(() => {
    const timer = window.setInterval(loadWorkerStatus, 15000);
    return () => window.clearInterval(timer);
  }, [loadWorkerStatus]);
  useEffect(() => {
    const reference = new URLSearchParams(window.location.search).get('reference');
    if (!reference || callbackHandled.current) return;
    callbackHandled.current = true;
    (async () => {
      try {
        const result = await api(`/api/paystack/verify?reference=${encodeURIComponent(reference)}`);
        if (result?.reconciliationRequired) setNotice({ type: 'error', text: `Payment succeeded after its voucher reservation expired. Contact the administrator and provide reference ${reference}.` });
        else setNotice({ type: result?.paid ? 'success' : 'error', text: result?.paid ? 'Payment verified successfully.' : 'Payment was not confirmed. You can retry checkout or contact support.' });
        if (result?.paid) { await loadBilling(); }
      } catch (error) { setNotice({ type: 'error', text: errorText(error, 'Payment verification could not be completed.') }); }
      finally { const url = new URL(window.location.href); url.searchParams.delete('reference'); window.history.replaceState({}, '', `${url.pathname}${url.search}${url.hash}`); }
    })();
  }, [loadBilling]);
  useEffect(() => { if (tab === 'admin' && !adminOverview && !adminRequired && !adminLoading) loadAdmin(); }, [tab, adminOverview, adminRequired, adminLoading, loadAdmin]);

  const importRepo = async url => {
    if (!/^https:\/\/github\.com\/[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+(?:\.git)?\/?$/i.test(url)) { setNotice({ type: 'error', text: 'Enter a valid public GitHub repository URL.' }); return false; }
    setImporting(true); setNotice(null);
    try { const result = await api('/api/repositories/import', { method: 'POST', body: { repoUrl: url.replace(/\/$/, '') } }); setNotice({ type: 'success', text: `${result?.repository?.name || 'Repository'} import queued${result?.jobId ? ` (job ${result.jobId})` : ''}.` }); await loadRepositories(); return true; }
    catch (error) { setNotice({ type: 'error', text: errorText(error, 'Repository import could not be started.') }); return false; }
    finally { setImporting(false); }
  };
  const repoAction = async (repo, action) => {
    setRepoBusy(repo.id); setNotice(null);
    try {
      if (action === 'delete') await api(`/api/repositories/${encodeURIComponent(repo.id)}`, { method: 'DELETE' });
      else await api(`/api/repositories/${encodeURIComponent(repo.id)}/${action}`, { method: 'POST', body: {} });
      setNotice({ type: 'success', text: action === 'delete' ? 'Repository removal requested.' : `${action === 'start' ? 'Start' : 'Stop'} requested for ${repo.name || 'repository'}.` }); await loadRepositories();
    } catch (error) { setNotice({ type: 'error', text: errorText(error, 'Repository action failed.') }); }
    finally { setRepoBusy(''); }
  };
  const checkout = async (plan, voucherCode = '') => {
    setCheckoutBusy(true); setNotice(null);
    try { const result = await api('/api/paystack/initialize', { method: 'POST', body: { planId: plan.id, voucherCode } }); if (!result?.authorizationUrl) throw new Error('Checkout is not configured for this environment.'); window.location.assign(result.authorizationUrl); }
    catch (error) { setNotice({ type: 'error', text: errorText(error, 'Checkout could not be initialized.') }); setCheckoutBusy(false); }
  };
  const redeem = async code => {
    setNotice(null);
    try { await api('/api/vouchers/redeem', { method: 'POST', body: { code } }); setNotice({ type: 'success', text: 'Voucher redeemed successfully.' }); await loadBilling(); return true; }
    catch (error) { setNotice({ type: 'error', text: errorText(error, 'Voucher could not be redeemed.') }); return false; }
  };
  const adminLogin = async password => {
    setAdminBusy(true); setNotice(null);
    try { await api('/api/admin/login', { method: 'POST', body: { password } }); const result = await api('/api/admin/overview'); setAdminOverview(result); setAdminRequired(false); setNotice({ type: 'success', text: 'Admin access granted.' }); }
    catch (error) { if (isUnauthorized(error)) setAdminRequired(true); setNotice({ type: 'error', text: errorText(error, 'Admin login failed.') }); }
    finally { setAdminBusy(false); }
  };
  const adminLogout = async () => { setAdminBusy(true); try { await api('/api/admin/logout', { method: 'POST' }); } catch (error) { setNotice({ type: 'error', text: errorText(error, 'Admin logout failed.') }); } finally { setAdminOverview(null); setAdminRequired(true); setAdminBusy(false); } };
  const adminMutation = async (route, body, success) => {
    setAdminBusy(true); setNotice(null);
    try { await api(route, { method: 'POST', body }); await loadAdmin(); setNotice({ type: 'success', text: success }); return true; }
    catch (error) { setNotice({ type: 'error', text: errorText(error, 'Admin action could not be completed.') }); return false; }
    finally { setAdminBusy(false); }
  };
  const toggleVoucher = voucher => adminMutation(`/api/admin/vouchers/${encodeURIComponent(voucher.id)}/toggle`, {}, `Voucher ${voucher.enabled === false ? 'enabled' : 'disabled'}.`);

  const activeLabel = tabs.find(item => item.id === tab)?.label || 'Overview';
  return <div className="app-layout">
    <aside className={`sidebar ${mobileNav ? 'sidebar-open' : ''}`}><div className="sidebar-brand-row"><Brand /><button className="icon-button mobile-close" aria-label="Close navigation" onClick={() => setMobileNav(false)}><X size={18} /></button></div><p className="nav-label">WORKSPACE</p><nav className="side-nav" aria-label="Main navigation">{tabs.map(({ id, label, Icon }) => <button key={id} className={`nav-item ${tab === id ? 'nav-active' : ''}`} onClick={() => { setTab(id); setMobileNav(false); }}><Icon size={17} /><span>{label}</span>{id === 'repositories' && <span className="nav-count">{repos.length}</span>}</button>)}</nav><div className="sidebar-bottom"><div className="account-mini"><span className="account-avatar small-avatar">{(user.email || 'U').slice(0, 1).toUpperCase()}</span><div className="user-label"><strong>{user.email}</strong><small>Signed in</small></div><button className="icon-button logout-button" onClick={onLogout} aria-label="Sign out"><LogOut size={16} /></button></div></div></aside>
    {mobileNav && <button className="mobile-scrim" onClick={() => setMobileNav(false)} aria-label="Close navigation" />}
    <div className="main-column"><header className="topbar"><button className="icon-button mobile-menu-button" onClick={() => setMobileNav(true)} aria-label="Open navigation"><Menu size={19} /></button><div className="breadcrumbs"><span>BotDeck</span><span className="crumb-divider">/</span><strong>{activeLabel}</strong></div><div className="topbar-right"><span className="user-email">{user.email}</span><button className="icon-button refresh-button" onClick={() => { loadRepositories(); loadBilling(); loadWorkerStatus(); if (tab === 'admin') loadAdmin(); }} aria-label="Refresh workspace"><RefreshCw size={16} /></button></div></header>
      <main className="content"><Notice notice={notice} onDismiss={() => setNotice(null)} />
        {tab === 'overview' && <><div className={`notice ${workerStatus?.connected ? 'notice-success' : 'notice-error'}`} role="status"><Activity size={17} /><span><strong>Worker {workerStatus?.connected ? 'connected' : 'disconnected'}.</strong> The website and replacement worker share the same Neon database; Supabase handles sign-in only.{!workerStatus?.connected && <> Last seen: {workerStatus?.lastSeenAt ? formatDate(workerStatus.lastSeenAt) : 'not reported'}.</>}</span><button className="icon-button" onClick={loadWorkerStatus} disabled={workerLoading} aria-label="Refresh worker status"><RefreshCw size={15} className={workerLoading ? 'spin' : ''} /></button></div><Overview user={user} repos={repos} subscription={subscription} plan={currentPlan} loading={repoLoading || billingLoading} onRepositories={() => setTab('repositories')} /></>}
        {tab === 'repositories' && <Repositories repos={repos} loading={repoLoading} onRefresh={() => { loadRepositories(); loadWorkerStatus(); }} onImport={importRepo} onAction={repoAction} busyId={repoBusy} importing={importing} workerStatus={workerStatus} />}
        {tab === 'billing' && <Billing plans={plans.filter(plan => plan.active !== false)} subscription={subscription} currentPlan={currentPlan} loading={billingLoading} onReload={() => { loadBilling(); loadWorkerStatus(); }} onCheckout={checkout} onRedeem={redeem} busy={checkoutBusy} />}
        {tab === 'admin' && <Admin overview={adminOverview} loading={adminLoading} loginRequired={adminRequired} onLogin={adminLogin} onReload={loadAdmin} onLogout={adminLogout} onCreatePlan={payload => adminMutation('/api/admin/plans', payload, 'Plan saved.')} onCreateVoucher={payload => adminMutation('/api/admin/vouchers', payload, 'Voucher created.')} onToggleVoucher={toggleVoucher} busy={adminBusy} />}
        <footer className="page-footer"><span>BotDeck <span className="footer-dot">·</span> Repository workspace</span><span>{user.email}</span></footer>
      </main>
    </div>
  </div>;
}

export default function App() {
  const [user, setUser] = useState(null);
  const [checking, setChecking] = useState(true);
  useEffect(() => {
    let alive = true;
    if (!supabaseConfigured) { setUser(null); setChecking(false); return () => { alive = false; }; }
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => { if (alive) { setUser(session?.user || null); setChecking(false); } });
    supabase.auth.getSession().then(({ data, error }) => { if (alive) { setUser(error ? null : data?.session?.user || null); setChecking(false); } }).catch(() => { if (alive) { setUser(null); setChecking(false); } });
    return () => { alive = false; listener?.subscription?.unsubscribe(); };
  }, []);
  const signOut = async () => { const { error } = await supabase.auth.signOut(); if (error) return; setUser(null); };
  if (checking) return <div className="loading-screen"><Brand /><div className="loading-state"><LoaderCircle className="spin" size={18} />Checking your session…</div></div>;
  return user ? <Dashboard user={user} onLogout={signOut} /> : <AuthScreen />;
}
