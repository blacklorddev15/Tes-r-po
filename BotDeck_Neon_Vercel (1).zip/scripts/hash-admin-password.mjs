#!/usr/bin/env node
import crypto from 'node:crypto';
import readline from 'node:readline';

if (!process.stdin.isTTY || typeof process.stdin.setRawMode !== 'function') {
  console.error('Run this helper in an interactive terminal so the password is not echoed.');
  process.exit(1);
}

readline.emitKeypressEvents(process.stdin);
process.stdin.setRawMode(true);
process.stdin.resume();
process.stdout.write('New admin password (12+ characters; input hidden): ');
let password = '';

const cleanup = () => {
  try { process.stdin.setRawMode(false); } catch {}
  process.stdin.pause();
  process.stdout.write('\n');
};

process.stdin.on('keypress', (text, key = {}) => {
  if (key.ctrl && key.name === 'c') {
    cleanup();
    process.exit(130);
  }
  if (key.name === 'return' || key.name === 'enter') {
    cleanup();
    if (password.length < 12 || Buffer.byteLength(password) > 1024) {
      console.error('Password must be at least 12 characters and no more than 1024 bytes.');
      process.exit(1);
    }
    const salt = crypto.randomBytes(16);
    const hash = crypto.scryptSync(password, salt, 32);
    password = '';
    console.log(`ADMIN_PASSWORD_HASH=scrypt$${salt.toString('hex')}$${hash.toString('hex')}`);
    console.log('Copy only this hash into the Vercel server-side environment variable. Do not commit it.');
    process.exit(0);
  }
  if (key.name === 'backspace') password = password.slice(0, -1);
  else if (!key.ctrl && !key.meta && typeof text === 'string') password += text;
});
