# BotDeck — Vercel website

BotDeck is a React/Vite dashboard for open email/password sign-up through Supabase Auth. **Neon Postgres is the application database and the bridge shared by this website and the separate Pterodactyl worker.** Supabase is used for identity only; Telegram, Supabase Postgres, and Supabase Storage are not used by the application.

The dashboard adapts the user's Mechon reference with charcoal surfaces, compact hosting controls, violet accents, and status-focused cards. It is a separate implementation, not a copy of the Mechon hosting backend.

## Architecture

```text
Browser ── Supabase Auth (public URL + publishable/anon key) ──► Supabase Auth
   │
   └── verified Supabase access token ──► Vercel Node.js Functions
                                                ├── Neon Postgres (private DATABASE_URL)
                                                └── Paystack (private secret; hosted checkout)

Pterodactyl worker ── outbound Neon queries ──► same Neon database
```

The browser never connects to Neon. The Vercel API validates Supabase access tokens with Supabase Auth, then uses the verified user's UUID in parameterized Neon queries. The worker has no public control API; it claims queued operations directly from Neon. The site does not depend on a Pterodactyl hostname, inbound port, panel API key, or tunnel. Both packages must use the same private Neon `DATABASE_URL`.

## Features

- Open Supabase Auth email/password sign-up and sign-in; checkout requires email confirmation. Telegram sign-in and bot commands were removed.
- Per-user public GitHub imports, repository status, and owner-scoped start/stop/delete actions.
- Neon stores profiles, plans, subscriptions, repositories, job queue/leases, worker heartbeats, payments, vouchers/redemptions, and bounded runtime-log tails.
- Paystack hosted one-time checkout with manual renewal; server-side verification and webhook handling before access is granted.
- Password-gated Admin for plans, vouchers, and recent payment/redemption records.
- Outbound Pterodactyl worker queue, without an inbound website-to-worker control API.

## Requirements

- Node.js 22 or newer and npm.
- A Supabase project with Auth/email-password enabled. Supabase Postgres and Storage are not required.
- A Neon Postgres project.
- A Paystack account whose merchant profile supports the plan currencies.
- The separate Node.js 22+ Pterodactyl worker package.

## Supabase Auth setup

1. Create or select a Supabase project and enable email/password sign-up. Keep open sign-up enabled as requested.
2. Enable email confirmation and configure the Auth Site URL and redirect allow-list for your Vercel domain. Checkout requires a confirmed email address.
3. Copy the project URL and publishable key (older projects may call it the anon key). These Auth values are the only Supabase settings used by the app. Do **not** copy a Supabase service-role key; this project does not need it.

## Neon setup

1. Create a Neon project and database.
2. In Neon's SQL Editor, run [`neon/migrations/001_botdeck.sql`](neon/migrations/001_botdeck.sql) once against a fresh database. It creates the private application tables, indexes, repository/worker queue functions, payment/voucher functions, and log-tail storage. It has no Supabase `auth.users` foreign keys or RLS context: the trusted Vercel API must derive each user UUID from the verified Supabase Auth token and apply owner filters itself.
3. In Neon **Connect**, copy a connection string that requires TLS (`sslmode=require`). Set it as `DATABASE_URL` in both Vercel and the Pterodactyl worker. Keep it private; do not use a `VITE_` prefix, commit it, or send it to the browser.
4. The packages use `@neondatabase/serverless` HTTP query mode. Atomic workflows such as job claims, subscription extension, and voucher reservation are performed inside PostgreSQL functions so the application does not depend on a long-lived database session.

## Local setup

```sh
npm ci
cp .env.example .env
npm run dev
```

The Vite preview can render the sign-in UI with the two public Supabase Auth variables set. Vercel Functions do not run in Vite's static development server; to test `/api/*` locally, use `npx vercel dev` with the private variables configured. Run `npm run check` for the production build and API syntax checks.

## Vercel deployment

1. Import this directory into Vercel or upload the contents of `BotDeck_Neon_Vercel.zip`. Select Node.js 22, the Vite preset, install command `npm ci`, build command `npm run build`, and output directory `dist`.
2. Add these environment variables in Vercel. Keep database, Paystack, and admin secrets server-side only:

   | Variable | Use |
   | --- | --- |
   | `VITE_SUPABASE_URL` | Browser Supabase Auth project URL |
   | `VITE_SUPABASE_PUBLISHABLE_KEY` | Browser Supabase Auth publishable/anon key only |
   | `SUPABASE_URL` | Supabase Auth server-side project URL |
   | `SUPABASE_PUBLISHABLE_KEY` | Auth token verification with Supabase; public key, not service role |
   | `DATABASE_URL` | Private Neon Postgres connection string |
   | `PAYSTACK_SECRET_KEY` | Paystack server-side secret; begin with test mode |
   | `ADMIN_SESSION_SECRET` | At least 32 random bytes for signed admin sessions |
   | `ADMIN_PASSWORD_HASH` | Salted scrypt hash, never the plaintext password |
   | `APP_ORIGIN` | Exact public site origin, e.g. `https://your-panel.vercel.app` |

   `VITE_SUPABASE_ANON_KEY` and `SUPABASE_ANON_KEY` are supported aliases for older Supabase projects. Never add `DATABASE_URL`, Paystack secrets, admin hashes, or session-signing secrets as `VITE_` variables.

3. Create a fresh, unique admin password. Do not reuse a password previously sent in chat. In a trusted local copy, run `npm run hash:admin`, enter the password at the hidden prompt, and copy the generated `scrypt$...` hash into Vercel's `ADMIN_PASSWORD_HASH` secret. Generate `ADMIN_SESSION_SECRET` with `openssl rand -hex 32`. The Admin page also requires a signed-in Supabase account.
4. In Paystack, set the webhook URL to `https://YOUR-DOMAIN/api/paystack/webhook` and enable `charge.success`. Start with a test key; exercise sign-up, email confirmation, plan creation, hosted checkout, callback verification, and webhook delivery before switching to live credentials.
5. Set the Supabase Auth Site URL and allowed redirect URLs to the production domain. Redeploy after changing build-time `VITE_` variables.

## Billing and vouchers

Create or edit plans in the Admin tab. Prices are integer minor currency units (for example, kobo or pesewas); the currency must be supported by the Paystack merchant profile. Each plan defines its duration and repository allowance. Payments are one-time and renewal is manual; BotDeck does not store card data or make recurring charges.

Admins can issue percentage or fixed-amount checkout vouchers and plan-scoped free-days vouchers, with expiry, overall redemption caps, and per-account limits. Discount reservations last 30 minutes. If Paystack confirms a discounted payment after its reservation expired, the payment is marked `reconciliation_required` and does not receive access automatically; the administrator must review the reference in Paystack. Free-days vouchers are restricted to their configured plan when the user already has an active subscription.

## Worker safety and moving hosts

Repository execution is **disabled by default**. Importing and queueing can work without permission to execute public code. **Do not enable public repository execution on a shared worker without separate per-repository OS/container isolation and CPU, memory, disk, process, and network limits.** When enabled, arbitrary repository and dependency scripts run as the Pterodactyl worker's account. Filtering child environment variables is not a security boundary, especially when the worker has a Neon connection string.

To move the worker, stop the old worker first, then deploy the second ZIP on the replacement Pterodactyl server with the same private `DATABASE_URL` and stable `WORKER_ID`. Vercel does not need a Pterodactyl URL change. Repository source is re-cloned from the public GitHub URL when the next import/start action runs; running processes and uncommitted local files do not migrate. While no worker is connected, jobs remain in Neon.

## API routes

The Vercel function handles repository listing/import/actions, worker status, plans/subscription, Paystack initialize/verify/webhook, free-days voucher redemption, and password-gated admin operations. It obtains user identity from the validated Supabase Auth token, never from a browser-supplied owner ID, and scopes database access in Neon. `/api/health` is a non-sensitive health response. Vercel rewrites `/api/*` to `api/index.js` and serves the built Vite SPA for the dashboard route.

## References and theme

- [Neon serverless driver](https://neon.com/docs/serverless/serverless-driver), [Node.js guide](https://neon.com/docs/guides/node), and [Vercel connection methods](https://neon.com/docs/guides/vercel-connection-methods) document server-side Neon connections and HTTP versus pooled connection choices.
- [Supabase Auth](https://supabase.com/docs/guides/auth) and [email/password authentication](https://supabase.com/docs/guides/auth/passwords) document open sign-up and user tokens.
- [Paystack Transaction API](https://paystack.com/docs/api/transaction/), [Accept Payments](https://paystack.com/docs/payments/accept-payments/), and [Webhooks](https://paystack.com/docs/payments/webhooks/) document hosted checkout, server verification, and raw-body HMAC-SHA512 verification.
- [Vercel Node.js Functions](https://vercel.com/docs/functions/runtimes/node-js) document the Node.js API handler runtime.
- Visual reference: [jub0t/mechon](https://github.com/jub0t/mechon), MIT licensed. BotDeck adapts the style but does not include Mechon's backend.
