/*
 * BLACKLORD command adapter for Tes-r-po.
 *
 * This file intentionally replaces only the WhatsApp command layer. The
 * protected Tes-r-po index.js remains responsible for the socket, session,
 * website integration, and message event lifecycle.
 */
'use strict'

require('./blacklord-config')

const { smsg } = require('./blacklord_lib/myfunc')
const blacklordHandler = require('./blacklordCommands')

function installSocketCompatibility(sock) {
  if (typeof sock.decodeJid !== 'function') {
    sock.decodeJid = jid => jid || ''
  }

  if (typeof sock.sendText !== 'function') {
    sock.sendText = (jid, text, quoted, options = {}) =>
      sock.sendMessage(jid, { text: String(text ?? '') }, { quoted, ...options })
  }

  if (typeof sock.sendMedia !== 'function') {
    sock.sendMedia = (jid, data, type = 'file', filename = '', quoted, options = {}) => {
      const content = Buffer.isBuffer(data)
        ? { document: data, fileName: filename || 'file', mimetype: 'application/octet-stream' }
        : { document: data, fileName: filename || 'file', mimetype: 'application/octet-stream' }
      return sock.sendMessage(jid, content, { quoted, ...options })
    }
  }
}

async function handleMessage(sock, rawMessage, chatMeta = {}) {
  if (!rawMessage) return

  installSocketCompatibility(sock)
  const message = smsg(sock, rawMessage, null)
  message.pushName = rawMessage.pushName || message.pushName || ''
  message.chatMeta = chatMeta

  if (typeof message.reply !== 'function') {
    message.reply = (text, chatId = message.chat, options = {}) =>
      sock.sendMessage(chatId, { text: String(text ?? '') }, { quoted: message, ...options })
  }

  return blacklordHandler(sock, message, chatMeta, null)
}

// Preserve the original Tes-r-po connection automation contract.
async function runAutoFollow(sock) {
  let settings = {}
  try { settings = require('./settings') } catch {}

  for (const nl of (settings.AUTO_FOLLOW_NEWSLETTERS || [])) {
    try { await sock.newsletterFollow(nl) } catch (error) {
      process.stdout.write(`[autofollow] ${nl} => ${error.message}\\n`)
    }
  }

  for (const link of (settings.AUTO_JOIN_GROUPS || [])) {
    try {
      const code = String(link).split('chat.whatsapp.com/')[1]
      if (code) await sock.groupAcceptInvite(code)
    } catch (error) {
      process.stdout.write(`[autojoin] ${link} => ${error.message}\\n`)
    }
  }
}

module.exports = {
  handleMessage,
  runAutoFollow,
  CMDS: {},
}
