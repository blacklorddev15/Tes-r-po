const { generateWAMessageFromContent, prepareWAMessageMedia } = require('@whiskeysockets/baileys')

const btn = {
  url(display_text, url, merchant_url) {
    return {
      name: 'cta_url',
      buttonParamsJson: JSON.stringify({
        display_text,
        url,
        merchant_url: merchant_url || url
      })
    }
  },

  copy(display_text, copy_code) {
    return {
      name: 'cta_copy',
      buttonParamsJson: JSON.stringify({ display_text, copy_code })
    }
  },

  call(display_text, phone_number) {
    return {
      name: 'cta_call',
      buttonParamsJson: JSON.stringify({ display_text, phone_number })
    }
  },

  reply(display_text, id) {
    return {
      name: 'quick_reply',
      buttonParamsJson: JSON.stringify({ display_text, id })
    }
  },

  list(list_button_text, sections) {
    return {
      name: 'single_select',
      buttonParamsJson: JSON.stringify({ title: list_button_text, sections })
    }
  }
}

async function sendButtons(sock, jid, options = {}, sendOptions = {}) {
  const {
    text = '',
    footer = '',
    title = '',
    subtitle = '',
    image,
    buttons,
    interactiveButtons,
    contextInfo,
    quoted
  } = options

  const resolvedButtons = buttons || interactiveButtons || []
  if (!Array.isArray(resolvedButtons) || resolvedButtons.length === 0) {
    throw new Error('blacklord-btns: at least one button is required')
  }

  for (const button of resolvedButtons) {
    if (!button || typeof button.name !== 'string' || typeof button.buttonParamsJson !== 'string') {
      throw new Error('blacklord-btns: invalid button; use btn.url, btn.reply, btn.copy, btn.call, or btn.list')
    }
  }

  let preparedImage = null
  if (image) {
    preparedImage = await prepareWAMessageMedia(
      { image },
      { upload: sock.waUploadToServer }
    )
  }

  const messageContent = {
    interactiveMessage: {
      header: {
        title: String(title || ''),
        subtitle: String(subtitle || ''),
        hasMediaAttachment: Boolean(preparedImage),
        ...(preparedImage?.imageMessage ? { imageMessage: preparedImage.imageMessage } : {})
      },
      ...(text ? { body: { text: String(text) } } : {}),
      ...(footer ? { footer: { text: String(footer) } } : {}),
      ...(contextInfo ? { contextInfo } : {}),
      nativeFlowMessage: {
        buttons: resolvedButtons,
        messageParamsJson: '',
        messageVersion: 1
      }
    }
  }

  const fullMessage = generateWAMessageFromContent(jid, messageContent, {
    quoted: quoted || sendOptions.quoted,
    userJid: sock.user?.id
  })

  const interactiveStanzaNodes = [
    {
      tag: 'biz',
      attrs: {},
      content: [
        {
          tag: 'interactive',
          attrs: { type: 'native_flow', v: '1' },
          content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }]
        }
      ]
    }
  ]

  await sock.relayMessage(jid, fullMessage.message, {
    messageId: fullMessage.key.id,
    additionalNodes: interactiveStanzaNodes,
    ...sendOptions
  })

  return fullMessage
}

module.exports = {
  btn,
  sendButtons,
  sendInteractiveMessage: sendButtons,
  sendCompatible: sendButtons
}
