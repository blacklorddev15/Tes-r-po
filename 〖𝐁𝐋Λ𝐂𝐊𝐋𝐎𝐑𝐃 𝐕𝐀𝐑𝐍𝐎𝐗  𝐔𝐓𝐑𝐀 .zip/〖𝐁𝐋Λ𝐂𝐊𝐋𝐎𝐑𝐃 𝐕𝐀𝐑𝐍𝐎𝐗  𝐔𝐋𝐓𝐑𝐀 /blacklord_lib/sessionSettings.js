const fs = require('fs')
const path = require('path')

const SESSION_SETTING_FILES = [
  'welcome.json',
  'chatbot.json',
  'antilink.json',
  'antistatus.json',
  'warnings.json',
  'anticall.json'
]

function resetSessionSettings(sessionId, databaseDir = path.join(process.cwd(), 'database')) {
  if (!sessionId) throw new Error('A session ID is required')

  const results = []
  for (const filename of SESSION_SETTING_FILES) {
    const filePath = path.join(databaseDir, filename)
    if (!fs.existsSync(filePath)) continue

    let data
    try {
      data = JSON.parse(fs.readFileSync(filePath, 'utf8') || '{}')
    } catch {
      continue
    }

    let changed = false
    if (filename === 'chatbot.json' && data && data.chats && typeof data.chats === 'object') {
      changed = Object.prototype.hasOwnProperty.call(data.chats, sessionId)
      delete data.chats[sessionId]
    } else if (data && !Array.isArray(data) && typeof data === 'object') {
      changed = Object.prototype.hasOwnProperty.call(data, sessionId)
      delete data[sessionId]
    }

    if (changed) {
      fs.writeFileSync(filePath, JSON.stringify(data, null, 2))
      results.push(filename)
    }
  }

  return results
}

module.exports = { resetSessionSettings, SESSION_SETTING_FILES }
